# DHC Gus v0.17.31 R115 — SEO + Catalog Governor

Release objective: finish the backend pass identified by live Discount Halloween City catalog QA without creating a separate app or code path.

## Live store issue closed before packaging

- Archived the two remaining active products with zero total inventory.
- Verified live Shopify state after the archive: zero active products with total inventory <= 0.
- Corrected the source-of-truth model for Shop: the manual `All Products` collection is merchandising content, not the Shop sales-channel feed. The Shop publication is now audited independently.

## Backend changes

### Catalog data normalization
- Preserves Shopify list metafield types when canonicalizing taxonomy values.
- Normalizes deterministic size/color aliases including `ONE SIZE` -> `One Size` and `Multicolour` -> `Multicolor`.
- Extracts explicit US age labels from supplier wrappers such as `Size 140(7-8T)` without inventing conversions for raw numeric sizes.
- Adds collision protection: variant option normalization will not merge two distinct variants into the same canonical option combination.
- Adds deterministic high-confidence product-type classification for costumes, masks, accessories and Halloween decorations.
- Fixes Catalog Data Normalizer JobRun writes to the actual Prisma schema (`details`, `scanned`, `changed`, `warnings`).
- Fixes Product Touch Learning instrumentation to the current `entityId` / `windowsDays` contract.

### Shop / sales-channel catalog governor
- New always-on `salesChannelGovernor` engine.
- Discovers the Shop channel/publication instead of treating a manual collection as the sales-channel feed.
- Archives active zero-total-inventory products when live writes are enabled.
- Keeps raw/new products hidden from Shop until catalog + SEO readiness gates pass.
- Publishes a hidden active product to Shop only after title, inventory, product type, description, SEO metadata, image, variant inventory and taxonomy checks pass.
- Records holds as `SHOP_FEED_READINESS_HOLD` findings instead of silently publishing incomplete imports.
- Reports the manual `All Products` collection separately and explicitly labels it as non-authoritative for Shop publication.

### Duplicate collection / cannibalization protection
- Adds a structural collection intent key independent of Google Search Console availability.
- Detects legacy aliases such as `Men's Collection` vs `Men's Halloween Costumes`.
- Selects a primary candidate using current GSC evidence when available, then catalog depth / SEO completeness.
- Prevents automated SEO strengthening of duplicate loser collections.
- Creates approval-required `SEO_COLLECTION_DUPLICATE_REVIEW` work rather than auto-deleting or auto-redirecting a live collection.

### Unique PDP content
- Replaces generic "Shop the X for Halloween..." template fallback with evidence-backed PDP copy generated only from verified title, product type and selectable option values.
- Never invents material, included pieces, fit, measurements or shipping claims.
- New-product intake can now set a high-confidence product type before generating PDP copy.
- Existing catalog self-healing detects generic legacy PDP templates and rebuilds them from verified product evidence.

### Content publishing
- Commerce Editorial, SEO Blog Draft Factory and SEO Blog Publishing are now part of the orchestrated SEO engine rotation.
- Publishing is limited to safe `DRAFT_READY` content with no fact-risk flags, sufficient body content and required internal links.
- Default cadence is one safe article approximately every 20 hours, bounded to one per cycle, with `GUS_SEO_BLOG_AUTO_PUBLISH_ENABLED=false` as a kill switch.

## QA

- Full Node test suite: 295 / 295 passed.
- TypeScript syntax check: passed.
- Relative import resolution: passed across 689 source files.
- Route uniqueness: passed (229 registrations, 0 duplicates).
- Client/server route boundary check: passed.
- Static app-link contract: passed (263 `/app` links checked).
- Interactive controls: passed (201 buttons, 120 links, 173 forms; 0 failures / 0 warnings).
- Runtime wiring: passed; 387 service modules reachable; 0 unexpected unreachable modules.
- Engine certification: passed; 25 / 25 integrated engine contracts.
- Rules validation: passed.

A full `tsc --noEmit` / production bundle was not re-run in this isolated source package because dependencies are intentionally not bundled and `npm install` did not complete inside the sandbox timeout. The release therefore does not claim a dependency-backed typecheck/build beyond the checks above.
