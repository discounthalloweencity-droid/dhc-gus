# DHC Gus v0.17.32 R116 — Engine Readiness Truth + Connector Recovery

Release objective: make Gus distinguish **installed code** from **actually runnable production engines** and repair connector/readiness logic that could falsely report a working engine as missing (or a configured engine as healthy without provider-specific evidence).

## Confirmed defects fixed

### 1. Google / SEO readiness used the wrong auth test
The readiness screen previously recognized only `GOOGLE_ACCESS_TOKEN`, even though the real Google connector also supports:
- Google OAuth refresh: `GOOGLE_REFRESH_TOKEN + GOOGLE_CLIENT_ID + GOOGLE_CLIENT_SECRET`
- Windsor Search Console: `WINDSOR_API_KEY + GSC_SITE_URL/WINDSOR_GSC_ACCOUNT`

R116 now uses the same auth rules as the production Google connector. Search Console and GA4 are evaluated separately so Windsor GSC does not falsely certify GA4.

### 2. Runtime certification referenced ghost / obsolete environment variables
Removed false checks for:
- `DSERS_FEED_URL`
- `SYNCEE_FEED_URL`
- `GOOGLE_SEARCH_CONSOLE_SITE_URL`
- `GUS_GSC_ENDPOINT`
- `GUS_RETAIL_INTELLIGENCE_ENDPOINT`
- `DSERS_REPLACEMENT_FEED_URL`
- `GUS_SUPPORT_IMAP_HOST`

The certification layer now checks the actual production variables used by Gus.

### 3. Supplier health was not provider-specific
The old Connection Health Director reused global stock-evidence counts for CJ, DSers and Syncee. That could make one supplier look healthy because another supplier had evidence.

R116 now evaluates each supplier independently from its own enabled `SupplierVariantLink` records, live `AvailabilityObservation` rows and current shipping evidence.

### 4. Readiness UI had a second, stale source of truth
`/app/readiness` duplicated connection logic instead of using the Connection Health Director. R116 removes that duplicate path. The readiness page, Recovery Director and connection findings now consume the same source of truth.

### 5. Important operational dependencies were invisible
Connection Health / Runtime Certification now surface:
- Google Search Console
- GA4
- CJ
- DSers
- Syncee
- AliExpress replacement evidence
- carrier tracking provider
- support email transport
- EasyPost return-label automation
- OpenAI model-assisted engines
- backlink outreach provider
- authenticated Gus/cron bridge

Missing optional integrations degrade only their dependent engines; they no longer masquerade as complete production proof.

### 6. Engine Certification Lab version was stale
`ENGINE_CERTIFICATION_RELEASE` was still `0.17.28-r112` inside R115. It now matches R116 (`0.17.32-r116`).

## What this changes operationally

After R116 is deployed, Gus can tell the difference between:
- source code present,
- connector configured,
- provider-specific evidence observed,
- stale evidence,
- missing dependency,
- and live production execution.

This directly strengthens the Recovery Director because it already consumes `connectionHealthSnapshot()`. A broken/missing connector now points Gus to the right repair instead of letting an unrelated supplier/provider make the engine appear healthy.

## QA

- Full Node suite: 302 / 302 passed.
- TypeScript syntax checks: passed.
- Relative import resolution: passed across 689 source files.
- Route registrations: 229; duplicate route modules: 0.
- Client/server route boundaries: passed.
- Static app links: 263 checked; passed.
- Interactive controls: 201 buttons, 120 links, 173 forms; 0 failures / 0 warnings.
- Runtime wiring: 387 service modules reachable; 0 unexpected unreachable modules.
- Engine certification contracts: 25 / 25 present.
- Prisma application/production parity: 49 / 49 models.
- Rules validation: passed.

## R116 regression coverage

- OAuth-refresh Google credentials are recognized for Search Console and GA4.
- Windsor is recognized for Search Console without falsely certifying GA4.
- Actual DSers/Syncee environment variable names are used.
- Tracking, EasyPost, OpenAI, backlink outreach and cron bridge dependencies are visible.
- Ghost connector variable names are rejected by regression tests.
- Readiness UI consumes the unified Connection Health source of truth.

## Deployment note

The deployment ZIP intentionally excludes `node_modules`. The source package therefore does not claim a dependency-backed production build in this isolated sandbox. Run the normal host install/build flow after upload, then open **Installation & data readiness** and **Engine Certification Lab** to see the actual production connector/evidence states.
