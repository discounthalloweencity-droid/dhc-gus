# DHC Gus v0.16.96 R80 — Production Proof Fail-Closed Hardening

R80 hardens the R79 Production Proof / Reality Check so the diagnostic system itself remains useful when the production backend is partially broken.

## Why this release exists

R79 proved work from queue movement, mission transitions, completed jobs, ChangeLog evidence and live Shopify readback. The remaining weakness was that several database reads still ran together and could fail the whole proof page if production was missing a table, had a schema mismatch, or a query/provider hung. Proof-history persistence also did not verify that its audit snapshot was actually readable after writing.

R80 changes the rule: **unavailable evidence is UNKNOWN/BROKEN, never zero and never healthy.**

## R80 changes

- Added `production-proof-safety.ts` with isolated, timed proof-signal capture.
- Every major Production Proof dependency now has its own timeout and health record.
- Critical reads include automation control, Turbo state, orchestrator history, RetailMission state, engine mission state, RetailMissionEvent history, JobRun activity, ChangeLog activity/total and live Shopify readback.
- Noncritical diagnostic reads include oldest pending mission, critical-error registry, stale-worker counts, catalog snapshot freshness and previous proof history.
- A missing/bad table or timed-out dependency is shown explicitly as `FAILED` or `TIMEOUT` with the source name, duration and error.
- Failed reads are no longer silently converted to `0`, `OFF`, or “no errors.”
- Added `Production telemetry integrity` to the reality verdict. A failed critical proof source makes the verdict `NOT_WORKING` until the source/schema is repaired.
- Automation/Turbo/orchestrator read failures are labeled UNKNOWN/BROKEN instead of being misreported as stopped/off/never-run.
- Added verified proof-history persistence:
  1. writes a Production Proof audit JobRun with an audit nonce,
  2. re-reads that exact JobRun,
  3. verifies nonce, shop, job type and DONE status.
- If proof-history persistence cannot be verified, the current live proof still renders but interval queue-delta conclusions are marked degraded.
- `Run Gus + Start Proof Window` now catches an orchestrator launch failure and still runs Production Proof, so the diagnostic route does not disappear when the run request itself fails.
- Added Data Source Health UI with per-signal criticality, OK/FAILED/TIMEOUT state, query duration and failure detail.
- `/health/proof` now returns `dataSources` and `persistence` evidence.
- Machine-readable proof JSON now includes signal health and persistence verification.
- Runtime identity advanced to `0.16.96-r80`.

## Regression coverage added

- Healthy signal returns its value.
- Broken table/query is captured instead of thrown.
- Hung dependency times out.
- Critical and noncritical signal failures are separated.
- Critical telemetry failure produces `NOT_WORKING`.
- Unreadable automation state is not mislabeled `STOPPED`.
- Unverified proof history degrades an otherwise working runtime.
- Wiring contract requires signal isolation, proof-history readback and Data Source Health UI.

## Production interpretation

A green switch is not proof. R80 requires observable evidence and also proves that the evidence sources themselves were readable. After deployment, run Production Proof, create a baseline, then run it again after 5–15 minutes. Use the failed signal/check rows and Copy Repair Packet to trace any stuck subsystem.
