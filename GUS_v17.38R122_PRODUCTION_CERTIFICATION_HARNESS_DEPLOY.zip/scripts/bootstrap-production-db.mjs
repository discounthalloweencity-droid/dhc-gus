import { PrismaClient } from "@prisma/client";
import { applyDatabaseUrl } from "./lib/godaddy-db-env.mjs";

applyDatabaseUrl(process.env);
const url = String(process.env.DATABASE_URL || "");
if (!url.startsWith("mysql://")) {
  console.error("Production database bootstrap requires a MySQL DATABASE_URL.");
  process.exit(1);
}

// Upgrade-safe production bootstrap.
// Existing DHC tables are NEVER schema-pushed during an installer upgrade.
// This avoids Prisma diffing or rewriting the known-good production baseline.
// Only the new Gus-owned tables introduced after v0.13.34 are created, and only
// with CREATE TABLE IF NOT EXISTS. The only existing-column change permitted is
// the guarded Session.scope VARCHAR-to-TEXT widening required for Shopify OAuth.
// No DROP, truncate, force-reset, schema push, or other destructive migration is permitted here.
const prisma = new PrismaClient();

try {
  await prisma.$queryRawUnsafe("SELECT 1");
  const dbNameRows = await prisma.$queryRawUnsafe("SELECT DATABASE() AS dbName");
  const dbName = String(Array.isArray(dbNameRows) ? (dbNameRows[0]?.dbName || "") : "");
  if (!dbName) throw new Error("Managed MySQL connection did not select a database.");
  console.log("Gus production database connectivity verified.");

  const knownCore = ["StoreConfig","ProductSnapshot","Finding","ChangeLog","JobRun","ActionProposal"];
  const tableRows = await prisma.$queryRawUnsafe(`
    SELECT TABLE_NAME AS tableName
    FROM INFORMATION_SCHEMA.TABLES
    WHERE TABLE_SCHEMA = DATABASE()
  `);
  const existing = new Set((Array.isArray(tableRows) ? tableRows : []).map((r) => String(r?.tableName || "")));
  const recognizedCore = knownCore.filter((name) => existing.has(name));

  if (!existing.has("Session")) {
    if (recognizedCore.length === 0 && process.env.DHC_ALLOW_EMPTY_PRODUCTION_DB_BOOTSTRAP !== "true") {
      throw new Error("Shopify Session table is missing and the selected MySQL database contains no recognized DHC core tables. Refusing to initialize an unknown/empty database. Verify DATABASE_URL/DB_* points to the established DHC database.");
    }
    await prisma.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS \`Session\` (
        \`id\` VARCHAR(191) NOT NULL,
        \`shop\` VARCHAR(191) NOT NULL,
        \`state\` VARCHAR(191) NOT NULL,
        \`isOnline\` BOOLEAN NOT NULL DEFAULT false,
        \`scope\` TEXT NULL,
        \`expires\` DATETIME(3) NULL,
        \`accessToken\` VARCHAR(191) NOT NULL,
        \`userId\` BIGINT NULL,
        \`firstName\` VARCHAR(191) NULL,
        \`lastName\` VARCHAR(191) NULL,
        \`email\` VARCHAR(191) NULL,
        \`accountOwner\` BOOLEAN NOT NULL DEFAULT false,
        \`locale\` VARCHAR(191) NULL,
        \`collaborator\` BOOLEAN NULL DEFAULT false,
        \`emailVerified\` BOOLEAN NULL DEFAULT false,
        PRIMARY KEY (\`id\`)
      ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
    `);
    console.log(`Shopify Session table repaired safely in ${dbName}; recognized DHC tables=${recognizedCore.length}.`);
  }

  const scopeColumn = await prisma.$queryRawUnsafe(`
    SELECT DATA_TYPE AS dataType, CHARACTER_MAXIMUM_LENGTH AS maxLength
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'Session'
      AND COLUMN_NAME = 'scope'
    LIMIT 1
  `);
  if (Array.isArray(scopeColumn) && scopeColumn.length) {
    const dataType = String(scopeColumn[0]?.dataType || '').toLowerCase();
    const maxLength = Number(scopeColumn[0]?.maxLength || 0);
    if (dataType !== 'text' && dataType !== 'mediumtext' && dataType !== 'longtext') {
      await prisma.$executeRawUnsafe('ALTER TABLE `Session` MODIFY COLUMN `scope` TEXT NULL');
      console.log(`Session.scope widened safely from ${dataType || 'unknown'}${maxLength ? `(${maxLength})` : ''} to TEXT.`);
    } else console.log('Session.scope is already TEXT-capable; no schema change needed.');
  } else throw new Error('Session.scope column is missing after Session table verification.');

  await prisma.$queryRawUnsafe('SELECT COUNT(*) AS sessionCount FROM `Session`');

  // v0.16.25H: the essential readiness gate requires StoreConfig and JobRun,
  // but older/partially-recovered production databases can legitimately be missing
  // one or both. Repair these foundational control tables additively before the
  // final readiness check. CREATE TABLE IF NOT EXISTS is intentionally non-destructive.
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`StoreConfig\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`shop\` VARCHAR(191) NOT NULL,
      \`mode\` VARCHAR(191) NOT NULL DEFAULT 'AUTOPILOT',
      \`targetMargin\` DOUBLE NOT NULL DEFAULT 0.30,
      \`minimumMargin\` DOUBLE NOT NULL DEFAULT 0.30,
      \`competitiveExceptionMargin\` DOUBLE NOT NULL DEFAULT 0.25,
      \`maxShippingDays\` INT NOT NULL DEFAULT 12,
      \`archiveSlowShipping\` BOOLEAN NOT NULL DEFAULT false,
      \`autoPricing\` BOOLEAN NOT NULL DEFAULT true,
      \`shippingChargeUnder\` DOUBLE NOT NULL DEFAULT 59.0,
      \`customerShippingCharge\` DOUBLE NOT NULL DEFAULT 6.99,
      \`shippingRevenueMode\` VARCHAR(191) NOT NULL DEFAULT 'CONSERVATIVE',
      \`defaultPaymentPercent\` DOUBLE NOT NULL DEFAULT 0.029,
      \`defaultPaymentFixed\` DOUBLE NOT NULL DEFAULT 0.30,
      \`adultCostumeFloor\` DOUBLE NOT NULL DEFAULT 29.97,
      \`kidsCostumeFloor\` DOUBLE NOT NULL DEFAULT 19.97,
      \`latexMaskFloor\` DOUBLE NOT NULL DEFAULT 16.97,
      \`seasonalSwitchMode\` VARCHAR(191) NOT NULL DEFAULT 'AUTO',
      \`seasonalCutoffMonth\` INT NOT NULL DEFAULT 10,
      \`seasonalCutoffDay\` INT NOT NULL DEFAULT 12,
      \`seasonalRestoreMonth\` INT NOT NULL DEFAULT 11,
      \`seasonalRestoreDay\` INT NOT NULL DEFAULT 1,
      \`createdAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE INDEX \`StoreConfig_shop_key\` (\`shop\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`JobRun\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`shop\` VARCHAR(191) NOT NULL,
      \`jobType\` VARCHAR(191) NOT NULL,
      \`status\` VARCHAR(191) NOT NULL,
      \`scanned\` INT NOT NULL DEFAULT 0,
      \`changed\` INT NOT NULL DEFAULT 0,
      \`warnings\` INT NOT NULL DEFAULT 0,
      \`details\` LONGTEXT NULL,
      \`startedAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`finishedAt\` DATETIME(3) NULL,
      PRIMARY KEY (\`id\`),
      INDEX \`JobRun_shop_jobType_startedAt_idx\` (\`shop\`, \`jobType\`, \`startedAt\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  console.log('Essential StoreConfig/JobRun tables verified or repaired additively.');
  // R111: production engine-schema closure. R109/R110 generated a 49-model Prisma client,
  // but established production databases could still contain only the older 45 model tables.
  // These CREATE TABLE IF NOT EXISTS statements are additive only: no DROP, reset, truncate,
  // data rewrite, or destructive migration is permitted.
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`RetailExperiment\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`shop\` VARCHAR(191) NOT NULL,
      \`experimentKey\` VARCHAR(191) NOT NULL,
      \`name\` VARCHAR(191) NOT NULL,
      \`targetType\` VARCHAR(191) NOT NULL,
      \`targetId\` VARCHAR(191) NOT NULL,
      \`primaryMetric\` VARCHAR(191) NOT NULL,
      \`status\` VARCHAR(191) NOT NULL DEFAULT 'DRAFT',
      \`controlJson\` LONGTEXT NOT NULL,
      \`variantJson\` LONGTEXT NOT NULL,
      \`guardrailsJson\` LONGTEXT NOT NULL,
      \`minSample\` INT NOT NULL DEFAULT 50,
      \`minDays\` INT NOT NULL DEFAULT 7,
      \`maxDays\` INT NOT NULL DEFAULT 21,
      \`trafficSplit\` DOUBLE NOT NULL DEFAULT 0.5,
      \`autoPromote\` BOOLEAN NOT NULL DEFAULT false,
      \`startedAt\` DATETIME(3) NULL,
      \`endedAt\` DATETIME(3) NULL,
      \`winner\` VARCHAR(191) NULL,
      \`confidence\` DOUBLE NULL,
      \`resultJson\` LONGTEXT NULL,
      \`createdAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE INDEX \`RetailExperiment_experimentKey_key\` (\`experimentKey\`),
      INDEX \`RetailExperiment_shop_status_createdAt_idx\` (\`shop\`, \`status\`, \`createdAt\`),
      INDEX \`RetailExperiment_shop_targetType_targetId_idx\` (\`shop\`, \`targetType\`, \`targetId\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`ExperimentExposure\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`shop\` VARCHAR(191) NOT NULL,
      \`experimentId\` INT NOT NULL,
      \`experimentKey\` VARCHAR(191) NOT NULL,
      \`sessionKey\` VARCHAR(191) NOT NULL,
      \`arm\` VARCHAR(191) NOT NULL,
      \`occurredAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE INDEX \`ExperimentExposure_shop_experimentKey_sessionKey_key\` (\`shop\`, \`experimentKey\`, \`sessionKey\`),
      INDEX \`ExperimentExposure_shop_experimentId_occurredAt_idx\` (\`shop\`, \`experimentId\`, \`occurredAt\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`OperatorFeedback\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`shop\` VARCHAR(191) NOT NULL,
      \`feedbackKey\` VARCHAR(191) NOT NULL,
      \`targetType\` VARCHAR(191) NOT NULL,
      \`targetId\` VARCHAR(191) NOT NULL,
      \`verdict\` VARCHAR(191) NOT NULL,
      \`reasonCode\` VARCHAR(191) NULL,
      \`note\` TEXT NULL,
      \`source\` VARCHAR(191) NOT NULL DEFAULT 'COMMAND_CENTER',
      \`evidenceJson\` LONGTEXT NOT NULL,
      \`appliedToLearning\` BOOLEAN NOT NULL DEFAULT false,
      \`createdAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`appliedAt\` DATETIME(3) NULL,
      PRIMARY KEY (\`id\`),
      UNIQUE INDEX \`OperatorFeedback_feedbackKey_key\` (\`feedbackKey\`),
      INDEX \`OperatorFeedback_shop_targetType_targetId_idx\` (\`shop\`, \`targetType\`, \`targetId\`),
      INDEX \`OperatorFeedback_shop_appliedToLearning_createdAt_idx\` (\`shop\`, \`appliedToLearning\`, \`createdAt\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`TurboCleanupControl\` (
      \`shop\` VARCHAR(191) NOT NULL,
      \`enabled\` BOOLEAN NOT NULL DEFAULT false,
      \`autoDisableWhenEmpty\` BOOLEAN NOT NULL DEFAULT true,
      \`enabledAt\` DATETIME(3) NULL,
      \`updatedAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`shop\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  console.log('R111 engine tables verified or repaired additively: RetailExperiment, ExperimentExposure, OperatorFeedback, TurboCleanupControl.');

  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`GusConversation\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`shop\` VARCHAR(191) NOT NULL,
      \`title\` VARCHAR(191) NOT NULL DEFAULT 'Gus Command Center',
      \`status\` VARCHAR(191) NOT NULL DEFAULT 'OPEN',
      \`createdAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      INDEX \`GusConversation_shop_updatedAt_idx\` (\`shop\`, \`updatedAt\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`GusMessage\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`conversationId\` INT NOT NULL,
      \`shop\` VARCHAR(191) NOT NULL,
      \`role\` VARCHAR(191) NOT NULL,
      \`content\` TEXT NOT NULL,
      \`intent\` VARCHAR(191) NULL,
      \`actionJson\` TEXT NULL,
      \`createdAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      INDEX \`GusMessage_shop_createdAt_idx\` (\`shop\`, \`createdAt\`),
      INDEX \`GusMessage_conversationId_createdAt_idx\` (\`conversationId\`, \`createdAt\`),
      CONSTRAINT \`GusMessage_conversationId_fkey\` FOREIGN KEY (\`conversationId\`) REFERENCES \`GusConversation\` (\`id\`) ON DELETE CASCADE ON UPDATE CASCADE
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`AutomationControl\` (
      \`shop\` VARCHAR(191) NOT NULL,
      \`running\` BOOLEAN NOT NULL DEFAULT false,
      \`generation\` INT NOT NULL DEFAULT 0,
      \`updatedAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`shop\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`GusOrchestratorRun\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`shop\` VARCHAR(191) NOT NULL,
      \`trigger\` VARCHAR(191) NOT NULL DEFAULT 'MANUAL',
      \`status\` VARCHAR(191) NOT NULL DEFAULT 'RUNNING',
      \`generation\` INT NULL,
      \`summaryJson\` LONGTEXT NOT NULL,
      \`startedAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`finishedAt\` DATETIME(3) NULL,
      PRIMARY KEY (\`id\`),
      INDEX \`GusOrchestratorRun_shop_startedAt_idx\` (\`shop\`, \`startedAt\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);

  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`RetailMission\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`missionKey\` VARCHAR(191) NOT NULL,
      \`shop\` VARCHAR(191) NOT NULL,
      \`engine\` VARCHAR(191) NOT NULL,
      \`goal\` TEXT NOT NULL,
      \`source\` VARCHAR(191) NOT NULL,
      \`dependenciesJson\` LONGTEXT NOT NULL,
      \`entityType\` VARCHAR(191) NULL,
      \`entityId\` VARCHAR(191) NULL,
      \`opportunityScore\` DOUBLE NOT NULL DEFAULT 0,
      \`priority\` INT NOT NULL DEFAULT 50,
      \`evidenceJson\` LONGTEXT NOT NULL,
      \`riskLevel\` VARCHAR(191) NOT NULL DEFAULT 'MEDIUM',
      \`expectedValue\` DOUBLE NULL,
      \`state\` VARCHAR(191) NOT NULL DEFAULT 'DISCOVERED',
      \`retries\` INT NOT NULL DEFAULT 0,
      \`maxRetries\` INT NOT NULL DEFAULT 5,
      \`scheduledAt\` DATETIME(3) NULL,
      \`availableAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`lockedAt\` DATETIME(3) NULL,
      \`lockToken\` VARCHAR(191) NULL,
      \`heartbeatAt\` DATETIME(3) NULL,
      \`timeoutAt\` DATETIME(3) NULL,
      \`stopRequestedAt\` DATETIME(3) NULL,
      \`generation\` INT NULL,
      \`approvalState\` VARCHAR(191) NOT NULL DEFAULT 'AUTO',
      \`beforeJson\` LONGTEXT NULL,
      \`actionJson\` LONGTEXT NULL,
      \`afterJson\` LONGTEXT NULL,
      \`resultJson\` LONGTEXT NULL,
      \`measurementWindowJson\` LONGTEXT NULL,
      \`outcomeJson\` LONGTEXT NULL,
      \`learnedLesson\` LONGTEXT NULL,
      \`rollbackState\` VARCHAR(191) NOT NULL DEFAULT 'NONE',
      \`cooldownUntil\` DATETIME(3) NULL,
      \`createdAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      \`startedAt\` DATETIME(3) NULL,
      \`finishedAt\` DATETIME(3) NULL,
      PRIMARY KEY (\`id\`),
      UNIQUE INDEX \`RetailMission_missionKey_key\` (\`missionKey\`),
      INDEX \`RetailMission_shop_state_availableAt_idx\` (\`shop\`, \`state\`, \`availableAt\`),
      INDEX \`RetailMission_shop_engine_state_idx\` (\`shop\`, \`engine\`, \`state\`),
      INDEX \`RetailMission_shop_entityType_entityId_idx\` (\`shop\`, \`entityType\`, \`entityId\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`RetailMissionEvent\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`missionId\` INT NOT NULL,
      \`shop\` VARCHAR(191) NOT NULL,
      \`fromState\` VARCHAR(191) NULL,
      \`toState\` VARCHAR(191) NOT NULL,
      \`eventType\` VARCHAR(191) NOT NULL,
      \`detailsJson\` LONGTEXT NOT NULL,
      \`createdAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      INDEX \`RetailMissionEvent_shop_createdAt_idx\` (\`shop\`, \`createdAt\`),
      INDEX \`RetailMissionEvent_missionId_createdAt_idx\` (\`missionId\`, \`createdAt\`),
      CONSTRAINT \`RetailMissionEvent_missionId_fkey\` FOREIGN KEY (\`missionId\`) REFERENCES \`RetailMission\` (\`id\`) ON DELETE CASCADE ON UPDATE CASCADE
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`IntelligenceSignal\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`shop\` VARCHAR(191) NOT NULL,
      \`dedupeKey\` VARCHAR(191) NOT NULL,
      \`source\` VARCHAR(191) NOT NULL,
      \`signalType\` VARCHAR(191) NOT NULL,
      \`entityType\` VARCHAR(191) NULL,
      \`entityId\` VARCHAR(191) NULL,
      \`metric\` VARCHAR(191) NULL,
      \`score\` DOUBLE NULL,
      \`value\` DOUBLE NULL,
      \`confidence\` DOUBLE NOT NULL DEFAULT 0.5,
      \`direction\` VARCHAR(191) NULL,
      \`severity\` VARCHAR(191) NOT NULL DEFAULT 'INFO',
      \`observedAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`expiresAt\` DATETIME(3) NULL,
      \`evidenceJson\` LONGTEXT NOT NULL,
      \`createdAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE INDEX \`IntelligenceSignal_shop_dedupeKey_key\` (\`shop\`, \`dedupeKey\`),
      INDEX \`IntelligenceSignal_shop_signalType_observedAt_idx\` (\`shop\`, \`signalType\`, \`observedAt\`),
      INDEX \`IntelligenceSignal_shop_entityType_entityId_idx\` (\`shop\`, \`entityType\`, \`entityId\`),
      INDEX \`IntelligenceSignal_shop_severity_observedAt_idx\` (\`shop\`, \`severity\`, \`observedAt\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`ConversionEvent\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`shop\` VARCHAR(191) NOT NULL,
      \`eventId\` VARCHAR(191) NOT NULL,
      \`eventType\` VARCHAR(191) NOT NULL,
      \`sessionKey\` VARCHAR(191) NULL,
      \`productGid\` VARCHAR(191) NULL,
      \`collectionHandle\` VARCHAR(191) NULL,
      \`source\` VARCHAR(191) NOT NULL,
      \`occurredAt\` DATETIME(3) NOT NULL,
      \`value\` DOUBLE NULL,
      \`currency\` VARCHAR(191) NULL,
      \`metadataJson\` LONGTEXT NOT NULL,
      \`createdAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE INDEX \`ConversionEvent_shop_eventId_key\` (\`shop\`, \`eventId\`),
      INDEX \`ConversionEvent_shop_eventType_occurredAt_idx\` (\`shop\`, \`eventType\`, \`occurredAt\`),
      INDEX \`ConversionEvent_shop_sessionKey_occurredAt_idx\` (\`shop\`, \`sessionKey\`, \`occurredAt\`),
      INDEX \`ConversionEvent_shop_productGid_occurredAt_idx\` (\`shop\`, \`productGid\`, \`occurredAt\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  // v0.16.43: Seasonal Switch restoration is safety-critical. The production
  // readiness path must create its ledger before the worker can run; waiting for
  // the optional background schema audit leaves post-Halloween restoration unsafe.
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`SeasonalManagedArchive\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`shop\` VARCHAR(191) NOT NULL,
      \`productGid\` VARCHAR(191) NOT NULL,
      \`seasonYear\` INT NOT NULL,
      \`previousStatus\` VARCHAR(191) NOT NULL,
      \`evidenceJson\` LONGTEXT NOT NULL,
      \`archiveApplied\` BOOLEAN NOT NULL DEFAULT false,
      \`createdAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`archivedAt\` DATETIME(3) NULL,
      \`restoredAt\` DATETIME(3) NULL,
      \`restoreReason\` LONGTEXT NULL,
      PRIMARY KEY (\`id\`),
      UNIQUE INDEX \`SeasonalManagedArchive_shop_productGid_seasonYear_key\` (\`shop\`, \`productGid\`, \`seasonYear\`),
      INDEX \`SeasonalManagedArchive_shop_restoredAt_idx\` (\`shop\`, \`restoredAt\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await prisma.$queryRawUnsafe('SELECT 1 FROM `SeasonalManagedArchive` LIMIT 0');
  console.log('SeasonalManagedArchive restoration ledger verified or repaired additively.');

  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS \`CompetitorSnapshot\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`shop\` VARCHAR(191) NOT NULL,
      \`retailer\` VARCHAR(191) NOT NULL,
      \`offerId\` VARCHAR(191) NOT NULL,
      \`sourceUrl\` VARCHAR(191) NOT NULL,
      \`observedAt\` DATETIME(3) NOT NULL,
      \`evidenceJson\` LONGTEXT NOT NULL,
      \`importedAt\` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      INDEX \`CompetitorSnapshot_shop_observedAt_idx\` (\`shop\`, \`observedAt\`),
      INDEX \`CompetitorSnapshot_shop_retailer_offerId_observedAt_idx\` (\`shop\`, \`retailer\`, \`offerId\`, \`observedAt\`)
    ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  console.log("Gus production database and Shopify session storage are ready. Existing production data was preserved.");
} catch (error) {
  console.error("Gus upgrade-safe database initialization failed:", error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
} finally {
  await prisma.$disconnect().catch(() => {});
}
