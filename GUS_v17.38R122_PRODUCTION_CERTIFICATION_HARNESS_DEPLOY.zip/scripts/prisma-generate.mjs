import {spawnSync} from "node:child_process";
import {fileURLToPath} from "node:url";
import path from "node:path";
import fs from "node:fs";
import {applyDatabaseUrl} from "./lib/godaddy-db-env.mjs";
const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,"..");
const cli=path.join(root,"node_modules","prisma","build","index.js");
const env={...process.env};
applyDatabaseUrl(env);
const url=String(env.DATABASE_URL||"");
const schema=/^mysql:\/\//i.test(url)?path.join(root,"prisma","mysql","schema.prisma"):path.join(root,"prisma","schema.prisma");
if(!fs.existsSync(cli)){console.error("Prisma setup failed: installed Prisma CLI not found at "+cli);process.exit(1)}
if(schema.includes('/prisma/mysql/schema.prisma')&&!/^mysql:\/\//i.test(url))env.DATABASE_URL="mysql://build:build@127.0.0.1:3306/build";
if(schema.endsWith('/prisma/schema.prisma')&&!/^file:/i.test(url))env.DATABASE_URL="file:./dev.sqlite";
const r=spawnSync(process.execPath,[cli,"generate","--schema",schema],{stdio:"inherit",env,cwd:root});
if(r.error)console.error("Prisma setup failed to launch: "+r.error.message);
process.exit(r.status??1);
