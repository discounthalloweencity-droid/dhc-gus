const base=String(process.env.GUS_PUBLIC_RUNTIME_URL||process.env.SHOPIFY_APP_URL||'').trim().replace(/\/$/,'');
const secret=String(process.env.AUTHORITY_CRON_SECRET||'').trim();
if(!base)throw new Error('GUS_PUBLIC_RUNTIME_URL or SHOPIFY_APP_URL is required. Point this at the PUBLISHED Gus runtime, not preview.');
if(/preview\./i.test(base))throw new Error(`Refusing preview runtime for unattended production heartbeat: ${base}`);
if(!secret)throw new Error('AUTHORITY_CRON_SECRET is required.');
const controller=new AbortController();
const timeout=setTimeout(()=>controller.abort(),120000);
try{
  const response=await fetch(`${base}/jobs/orchestrator`,{method:'POST',headers:{authorization:`Bearer ${secret}`,'user-agent':'DHC-Gus-External-Engine-Heartbeat/1.0'},signal:controller.signal});
  const text=await response.text();
  if(!response.ok)throw new Error(`Heartbeat HTTP ${response.status}: ${text.slice(0,1000)}`);
  let payload;try{payload=JSON.parse(text)}catch{payload={raw:text}}
  console.log(JSON.stringify({ok:true,at:new Date().toISOString(),base,status:response.status,payload}));
}finally{clearTimeout(timeout)}
