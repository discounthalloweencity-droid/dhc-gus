import {validateEnvironment,stagingDatabasePath} from './lib/staging-policy.mjs';
import {existsSync} from 'node:fs';
const env=process.env;
const report=validateEnvironment(env,{requireSecrets:true,requireStaging:true});
try{const path=stagingDatabasePath(env);if(existsSync(path))report.errors.push('Staging database already exists; bootstrap refuses to overwrite it');}catch(e){report.errors.push(e.message)}
report.ok=report.errors.length===0;
console.log(JSON.stringify(report,null,2));if(!report.ok)process.exitCode=1;
