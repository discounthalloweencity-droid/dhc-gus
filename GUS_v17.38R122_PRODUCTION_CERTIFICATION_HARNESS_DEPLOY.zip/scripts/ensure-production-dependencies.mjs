import {createHash} from 'node:crypto';
import {existsSync,readFileSync,writeFileSync,mkdirSync,unlinkSync,statSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
const nodeModules=path.join(root,'node_modules');
const stamp=path.join(nodeModules,'.gus-dependency-stamp.json');
const errorFile=path.join(root,'.gus-dependency-error.json');
const pkgPath=path.join(root,'package.json');
const force=process.argv.includes('--force');
const npmCommand=process.platform==='win32'?'npm.cmd':'npm';
const COMMAND_TIMEOUT_MS=180_000;
const RETRY_DELAY_MS=4_000;
const MAX_INSTALL_ATTEMPTS=2;
const PACKAGE_STABILITY_ATTEMPTS=40;
const PACKAGE_STABILITY_DELAY_MS=250;
let packageCache=null;

const requiredPackages=[
  '@prisma/client','prisma','@shopify/shopify-app-react-router',
  '@shopify/shopify-app-session-storage-prisma','@react-router/node',
  '@react-router/dev','react-router','react','react-dom','vite','typescript',
];
const requiredFiles=[
  'node_modules/@prisma/client/package.json',
  'node_modules/prisma/build/index.js',
  'node_modules/@shopify/shopify-app-react-router/package.json',
  'node_modules/@shopify/shopify-app-session-storage-prisma/package.json',
  'node_modules/@react-router/node/package.json',
  'node_modules/@react-router/dev/bin.js',
  'node_modules/react-router/package.json',
  'node_modules/react/package.json',
  'node_modules/react-dom/package.json',
  'node_modules/vite/package.json',
  'node_modules/typescript/package.json',
];

function readJson(file){try{return JSON.parse(readFileSync(file,'utf8'));}catch{return null;}}
function packageSnapshot(){
  try{
    const text=readFileSync(pkgPath,'utf8');
    const parsed=JSON.parse(text);
    if(!parsed||typeof parsed!=='object'||Array.isArray(parsed)) throw new Error('package.json root is not an object');
    return {parsed,text};
  }catch(error){return {parsed:null,error};}
}
async function waitForStablePackageJson(){
  let lastError=null;
  for(let attempt=1;attempt<=PACKAGE_STABILITY_ATTEMPTS;attempt++){
    const snap=packageSnapshot();
    if(snap.parsed){
      packageCache=snap.parsed;
      if(attempt>1) console.info(`[gus-deps] package.json became readable after ${attempt} checks; continuing after deployment file stabilization.`);
      return packageCache;
    }
    lastError=snap.error;
    if(attempt===1) console.warn('[gus-deps] package.json is temporarily unreadable during deployment; waiting for GoDaddy file replacement to settle instead of failing immediately.');
    if(attempt<PACKAGE_STABILITY_ATTEMPTS) await wait(PACKAGE_STABILITY_DELAY_MS);
  }
  let detail='';
  try{detail=` exists=${existsSync(pkgPath)} size=${statSync(pkgPath).size}`;}catch{detail=` exists=${existsSync(pkgPath)}`;}
  throw new Error(`package.json could not be parsed after ${PACKAGE_STABILITY_ATTEMPTS} stability checks (${PACKAGE_STABILITY_ATTEMPTS*PACKAGE_STABILITY_DELAY_MS}ms).${detail}${lastError?.message?` lastError=${lastError.message}`:''}`);
}
function pkg(){const p=packageCache||readJson(pkgPath);if(!p)throw new Error('package.json could not be parsed');packageCache=p;return p;}
function dependencyHash(){
  const p=pkg();
  const material=JSON.stringify({dependencies:p.dependencies||{},devDependencies:p.devDependencies||{}});
  return createHash('sha256').update(material).digest('hex');
}
function missingFiles(){return requiredFiles.filter(rel=>!existsSync(path.join(root,rel)));}
function expectedVersion(name){const p=pkg();return p.dependencies?.[name]??p.devDependencies?.[name]??null;}
function installedVersion(name){return readJson(path.join(nodeModules,...name.split('/'),'package.json'))?.version??null;}
function versionMismatches(){
  const out=[];
  for(const name of requiredPackages){
    const expected=expectedVersion(name),actual=installedVersion(name);
    if(expected&&/^\d+\.\d+\.\d+(?:[-+].*)?$/.test(expected)&&actual&&expected!==actual) out.push({name,expected,actual});
  }
  return out;
}
function readStamp(){return readJson(stamp);}
function clearError(){try{unlinkSync(errorFile);}catch{}}
function writeError(stage,message,tail=[]){
  const payload={stage,message:String(message||''),tail:Array.isArray(tail)?tail.slice(-40):[],at:new Date().toISOString(),node:process.version};
  try{writeFileSync(errorFile,JSON.stringify(payload,null,2)+'\n');}catch{}
}
function wait(ms){return new Promise(resolve=>setTimeout(resolve,ms));}
function transient(text){return /EAI_AGAIN|ETIMEDOUT|ECONNRESET|ECONNREFUSED|ENETUNREACH|ENOTFOUND|ERR_SOCKET|503|502|504|network/i.test(text||'');}
function runCommand(command,args,label,{timeoutMs=COMMAND_TIMEOUT_MS}={}){
  return new Promise(resolve=>{
    console.info(`[gus-deps] ${label}: ${command} ${args.join(' ')}`);
    let child;
    const tail=[];
    const push=(chunk,target)=>{
      const text=String(chunk||'');
      target.write(text);
      for(const line of text.split(/\r?\n/)) if(line.trim()){tail.push(line.trim());if(tail.length>80)tail.shift();}
    };
    try{
      child=spawn(command,args,{cwd:root,env:{...process.env,NODE_ENV:'development'},stdio:['ignore','pipe','pipe']});
    }catch(error){return resolve({ok:false,code:null,signal:null,tail:[String(error?.message||error)],launchError:error});}
    child.stdout?.on('data',d=>push(d,process.stdout));
    child.stderr?.on('data',d=>push(d,process.stderr));
    let timedOut=false;
    const timer=setTimeout(()=>{timedOut=true;console.error(`[gus-deps] ${label} timed out after ${timeoutMs}ms`);child.kill('SIGTERM');},timeoutMs);
    timer.unref?.();
    child.on('error',error=>{clearTimeout(timer);resolve({ok:false,code:null,signal:null,tail:[...tail,String(error?.message||error)],launchError:error,timedOut});});
    child.on('exit',(code,signal)=>{clearTimeout(timer);resolve({ok:code===0&&!timedOut,code,signal,tail,timedOut});});
  });
}
async function generatePrisma(){
  const result=await runCommand(process.execPath,[path.join(root,'scripts','prisma-generate-production.mjs')],'Prisma client generation');
  if(!result.ok){writeError('prisma-generate',`Prisma client generation failed code=${result.code??'null'} signal=${result.signal??'none'}`,result.tail);return false;}
  return true;
}
async function installDependencies(){
  const args=['install','--include=dev','--no-audit','--no-fund','--legacy-peer-deps','--prefer-offline','--package-lock=true','--fetch-retries=3','--fetch-retry-mintimeout=1000','--fetch-retry-maxtimeout=15000'];
  let last=null;
  for(let attempt=1;attempt<=MAX_INSTALL_ATTEMPTS;attempt++){
    console.info(`[gus-deps] Dependency install attempt ${attempt}/${MAX_INSTALL_ATTEMPTS}. Existing node_modules will not be deleted first.`);
    const result=await runCommand(npmCommand,args,`dependency install attempt ${attempt}`);
    if(result.ok) return true;
    last=result;
    const text=result.tail.join('\n');
    console.error(`[gus-deps] Dependency install attempt ${attempt} failed code=${result.code??'null'} signal=${result.signal??'none'}.`);
    if(attempt<MAX_INSTALL_ATTEMPTS){
      console.warn(`[gus-deps] Retrying ${transient(text)?'transient-looking ':''}dependency failure without deleting the existing dependency tree.`);
      await wait(RETRY_DELAY_MS);
    }
  }
  writeError('npm-install',`npm install failed after ${MAX_INSTALL_ATTEMPTS} attempts; code=${last?.code??'null'} signal=${last?.signal??'none'}`,last?.tail||[]);
  return false;
}

async function main(){
  clearError();
  await waitForStablePackageJson();
  const depHash=dependencyHash();
  const prior=readStamp();
  const missing=missingFiles();
  const mismatches=versionMismatches();

  // A healthy, version-matched dependency tree is usable even when the old release
  // did not leave a Gus stamp. This prevents a source-only hotfix from needlessly
  // going back to the npm registry on every GoDaddy restart.
  if(!force && missing.length===0 && mismatches.length===0){
    if(prior?.dependencyHash===depHash){
      clearError();
      console.info('[gus-deps] Dependency readiness passed from matching dependency stamp. No registry access required.');
      return;
    }
    console.info('[gus-deps] Installed production dependencies are complete and top-level versions match package.json. Refreshing Prisma client and adopting the existing tree without registry access.');
    if(!await generatePrisma()) process.exitCode=1;
    else{
      mkdirSync(nodeModules,{recursive:true});
      writeFileSync(stamp,JSON.stringify({dependencyHash:depHash,installedAt:new Date().toISOString(),node:process.version,adoptedExistingTree:true},null,2)+'\n');
      clearError();
      console.info('[gus-deps] Dependency readiness passed by adopting the verified existing dependency tree.');
    }
    return;
  }

  console.info(`[gus-deps] Dependency repair required. force=${force} missing=${missing.length} mismatches=${mismatches.length}.`);
  if(missing.length) console.warn('[gus-deps] Missing dependency files:',missing);
  if(mismatches.length) console.warn('[gus-deps] Version mismatches:',mismatches);

  if(!await installDependencies()){process.exitCode=1;return;}

  const afterMissing=missingFiles();
  const afterMismatch=versionMismatches();
  if(afterMissing.length||afterMismatch.length){
    const message=`Required dependencies are still incomplete after npm install. missing=${afterMissing.length} mismatches=${afterMismatch.length}`;
    console.error('[gus-deps] '+message,afterMissing,afterMismatch);
    writeError('verify-installed-tree',message,[...afterMissing,...afterMismatch.map(x=>`${x.name}: expected ${x.expected} got ${x.actual}`)]);
    process.exitCode=1;return;
  }
  if(!await generatePrisma()){process.exitCode=1;return;}

  mkdirSync(nodeModules,{recursive:true});
  writeFileSync(stamp,JSON.stringify({dependencyHash:depHash,installedAt:new Date().toISOString(),node:process.version,installMode:'npm-install-nondestructive'},null,2)+'\n');
  clearError();
  console.info('[gus-deps] Dependency readiness passed after non-destructive install + Prisma generation.');
}

main().catch(error=>{
  console.error(`[gus-deps] Fatal dependency readiness error: ${error?.stack||error}`);
  writeError('fatal',error?.message||String(error),[error?.stack||String(error)]);
  process.exitCode=1;
});
