import {spawnSync} from 'node:child_process';
import {readFileSync,existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {PrismaClient} from '@prisma/client';
import {applyDatabaseUrl} from './lib/godaddy-db-env.mjs';
import {parsePrismaSchemaContract} from './lib/prisma-schema-contract.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
const schemaPath=path.join(root,'prisma','mysql','schema.prisma');
applyDatabaseUrl(process.env);
const url=String(process.env.DATABASE_URL||'');
if(!/^mysql:\/\//i.test(url)){
  console.error('[gus-schema] Production schema reconciliation requires a MySQL DATABASE_URL.');
  process.exit(1);
}
if(!existsSync(schemaPath)){
  console.error(`[gus-schema] Canonical MySQL schema is missing: ${schemaPath}`);
  process.exit(1);
}

const contract=parsePrismaSchemaContract(readFileSync(schemaPath,'utf8'));
const expectedTables=[...contract.keys()];
if(!expectedTables.length){
  console.error('[gus-schema] Canonical schema contained no models; refusing production reconciliation.');
  process.exit(1);
}

async function inventory(){
  const prisma=new PrismaClient();
  try{
    const dbRows=await prisma.$queryRawUnsafe('SELECT DATABASE() AS dbName');
    const dbName=String(Array.isArray(dbRows)?(dbRows[0]?.dbName||''):'');
    if(!dbName)throw new Error('Managed MySQL connection did not select a database.');
    const tables=await prisma.$queryRawUnsafe('SELECT TABLE_NAME AS tableName FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE()');
    const columns=await prisma.$queryRawUnsafe('SELECT TABLE_NAME AS tableName, COLUMN_NAME AS columnName FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE()');
    return {dbName,tables:new Set((Array.isArray(tables)?tables:[]).map(r=>String(r?.tableName||'')).filter(Boolean)),columns:Array.isArray(columns)?columns:[]};
  }finally{await prisma.$disconnect().catch(()=>{});}
}

const before=await inventory();
const recognized=expectedTables.filter(name=>before.tables.has(name));
if(before.tables.size>0&&recognized.length===0){
  console.error(`[gus-schema] Selected database ${before.dbName} has tables but none match the Gus schema. Refusing to modify the wrong database.`);
  process.exit(1);
}
const unexpected=[...before.tables].filter(name=>!contract.has(name)&&name!=='_prisma_migrations');
if(unexpected.length){
  console.warn(`[gus-schema] Legacy/additional tables detected and preserved in ${before.dbName}: ${unexpected.slice(0,12).join(', ')}${unexpected.length>12?'…':''}`);
}

const missingBefore=expectedTables.filter(name=>!before.tables.has(name));
const missingColumnsBefore=[];
const colsByTable=new Map();
for(const row of before.columns){const table=String(row?.tableName||''),column=String(row?.columnName||'');if(!table||!column)continue;if(!colsByTable.has(table))colsByTable.set(table,new Set());colsByTable.get(table).add(column);}
for(const [model,fields] of contract){if(!before.tables.has(model))continue;const have=colsByTable.get(model)||new Set();for(const field of fields)if(!have.has(field))missingColumnsBefore.push(`${model}.${field}`);}

if(!missingBefore.length&&!missingColumnsBefore.length){
  console.log(`[gus-schema] Production schema already matches the required table/column contract (${expectedTables.length} models).`);
  process.exit(0);
}

console.warn(`[gus-schema] Schema drift detected in ${before.dbName}: missing tables=${missingBefore.length}, missing scalar columns=${missingColumnsBefore.length}.`);
if(unexpected.length && missingColumnsBefore.length){
  console.warn('[gus-schema] Legacy/additional tables are present, so full db push remains disabled. Running the additive-only column repair instead.');
  const additive=path.join(root,'scripts','repair-production-schema-additive.mjs');
  const additiveResult=spawnSync(process.execPath,[additive],{cwd:root,env:process.env,stdio:'inherit'});
  if(additiveResult.status!==0){
    console.error(`[gus-schema] Additive repair failed (exit ${additiveResult.status??'null'}); legacy tables were not modified.`);
    process.exit(additiveResult.status??1);
  }
  const afterAdditive=await inventory();
  const afterCols=new Map();
  for(const row of afterAdditive.columns){const table=String(row?.tableName||''),column=String(row?.columnName||'');if(!table||!column)continue;if(!afterCols.has(table))afterCols.set(table,new Set());afterCols.get(table).add(column);}
  const stillMissingTables=expectedTables.filter(name=>!afterAdditive.tables.has(name));
  const stillMissingColumns=[];
  for(const [model,fields] of contract){if(!afterAdditive.tables.has(model))continue;const have=afterCols.get(model)||new Set();for(const field of fields)if(!have.has(field))stillMissingColumns.push(`${model}.${field}`);}
  if(!stillMissingTables.length&&!stillMissingColumns.length){
    console.log(`[gus-schema] Additive reconciliation completed with legacy tables preserved (${expectedTables.length} model tables/columns available).`);
    process.exit(0);
  }
  console.warn(`[gus-schema] Additive repair left missing tables=${stillMissingTables.join(', ')||'none'}; missing columns=${stillMissingColumns.slice(0,20).join(', ')||'none'}.`);
  process.exit(2);
}
if(unexpected.length){
  console.warn('[gus-schema] Missing model tables require manual review because legacy/additional tables are present. No destructive schema operation was attempted.');
  process.exit(2);
}
console.warn('[gus-schema] Running guarded Prisma db push WITHOUT --accept-data-loss or --force-reset. Prisma must refuse any destructive change.');
const cli=path.join(root,'node_modules','prisma','build','index.js');
if(!existsSync(cli)){
  console.error(`[gus-schema] Prisma CLI is unavailable at ${cli}; cannot repair schema safely.`);
  process.exit(1);
}
const result=spawnSync(process.execPath,[cli,'db','push','--schema',schemaPath,'--skip-generate'],{cwd:root,env:process.env,stdio:'inherit'});
if(result.status!==0){
  console.error(`[gus-schema] Guarded Prisma db push refused or failed (exit ${result.status??'null'}). No destructive override was used.`);
  process.exit(result.status??1);
}

const after=await inventory();
const missingTablesAfter=expectedTables.filter(name=>!after.tables.has(name));
const afterColsByTable=new Map();
for(const row of after.columns){const table=String(row?.tableName||''),column=String(row?.columnName||'');if(!table||!column)continue;if(!afterColsByTable.has(table))afterColsByTable.set(table,new Set());afterColsByTable.get(table).add(column);}
const missingColumnsAfter=[];
for(const [model,fields] of contract){const have=afterColsByTable.get(model)||new Set();for(const field of fields)if(!have.has(field))missingColumnsAfter.push(`${model}.${field}`);}
if(missingTablesAfter.length||missingColumnsAfter.length){
  console.error(`[gus-schema] Reconciliation incomplete: missing tables=${missingTablesAfter.join(', ')||'none'}; missing columns=${missingColumnsAfter.slice(0,20).join(', ')||'none'}.`);
  process.exit(1);
}
console.log(`[gus-schema] Production schema reconciled non-destructively: ${expectedTables.length} model tables and required scalar columns are present.`);
