import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {applyDatabaseUrl} from './lib/godaddy-db-env.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
applyDatabaseUrl(process.env);
const url=String(process.env.DATABASE_URL||'');
if(!/^mysql:\/\//i.test(url)){
  console.error('[gus-db-deploy] Production database deploy requires a normalized mysql:// DATABASE_URL.');
  process.exit(1);
}

// IMPORTANT: prisma/migrations contains the historical SQLite staging migration lineage.
// Never run `prisma migrate deploy` against production MySQL from this package.
// Production uses guarded, additive reconciliation only.
const steps=['ensure-production-db.mjs','reconcile-production-schema.mjs','verify-production-db.mjs'];
for(const script of steps){
  console.log(`[gus-db-deploy] Running safe production step: ${script}`);
  const result=spawnSync(process.execPath,[path.join(root,'scripts',script)],{cwd:root,env:process.env,stdio:'inherit'});
  if(result.error){console.error(`[gus-db-deploy] ${script} failed to launch: ${result.error.message}`);process.exit(1);}
  if(result.status!==0){console.error(`[gus-db-deploy] ${script} failed with exit ${result.status??'null'}. No destructive migration fallback will be attempted.`);process.exit(result.status??1);}
}
console.log('[gus-db-deploy] Safe MySQL bootstrap/reconciliation/verification completed.');
