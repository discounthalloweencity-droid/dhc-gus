// Compatibility prior build marker: release:'0.16.39'
// Compatibility build lineage: release:'0.16.17U'
import {existsSync,readFileSync,renameSync,rmSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {releaseFingerprint} from './lib/release-fingerprint.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
const build=path.join(root,'build');
const backup=path.join(root,`.gus-build-backup-${process.pid}`);
const cli=path.join(root,'node_modules','@react-router','dev','bin.js');
const required=['app','package.json','react-router.config.ts','vite.config.ts','tsconfig.json'];
const BUILD_TIMEOUT_MS=180_000;

function fail(message){throw new Error(`[gus-build] ${message}`);}
function restorePreviousBuild(){
  rmSync(build,{recursive:true,force:true});
  if(existsSync(backup)) renameSync(backup,build);
}

if(!existsSync(cli)) fail(`React Router CLI missing at ${cli}. Dependency readiness must run before build.`);
for(const rel of required) if(!existsSync(path.join(root,rel))) fail(`Required build input missing: ${rel}`);

rmSync(backup,{recursive:true,force:true});
if(existsSync(build)) renameSync(build,backup);

try{
  console.info('[gus-build] Building from the application root using the known-good GoDaddy build contract; previous build is held for rollback until success.');
  const r=spawnSync(process.execPath,[cli,'build'],{
    cwd:root,
    env:{...process.env,NODE_ENV:'production'},
    stdio:'inherit',
    timeout:BUILD_TIMEOUT_MS,
  });
  if(r.error){restorePreviousBuild();fail(`React Router build failed to launch: ${r.error.message}`);}
  if(r.status!==0){restorePreviousBuild();fail(`React Router build exited ${r.status??'null'} signal=${r.signal??'none'}.`);}

  const server=path.join(build,'server','index.js');
  const client=path.join(build,'client');
  if(!existsSync(server)||!existsSync(client)){
    restorePreviousBuild();
    fail('React Router reported success but required server/client build artifacts are missing.');
  }

  const pkg=JSON.parse(readFileSync(path.join(root,'package.json'),'utf8'));
  // Compatibility previous release:'0.16.17W'
  // Previous cumulative release:'0.16.51'
  // Previous cumulative release:'0.16.50-r5'
  const marker={release:String(pkg.version||''),packageVersion:String(pkg.version||''),fingerprint:releaseFingerprint(root),builtAt:new Date().toISOString(),node:process.version,buildMode:'known-good-root-with-rollback'};
  writeFileSync(path.join(build,'.gus-build.json'),JSON.stringify(marker,null,2)+'\n');
  rmSync(backup,{recursive:true,force:true});
  console.info(`[gus-build] Known-good root production build verified and promoted. fingerprint=${marker.fingerprint.slice(0,12)} release=${marker.release}.`);
}catch(error){
  if(!existsSync(build)&&existsSync(backup)) renameSync(backup,build);
  throw error;
}
