import {readFileSync,readdirSync,existsSync} from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
let ts;try{ts=require('typescript')}catch{try{ts=require(process.env.TYPESCRIPT_PATH||'/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript')}catch{throw new Error('TypeScript is required for source verification. Install dependencies first.')}}
const schema=readFileSync('prisma/schema.prisma','utf8');
const models=[...schema.matchAll(/^model\s+(\w+)\s*\{/gm)].map(x=>x[1]);
assert.equal(new Set(models).size,models.length,'Duplicate Prisma model');
const toml=existsSync('shopify.app.toml')?readFileSync('shopify.app.toml','utf8'):null;
if(toml){assert(toml.includes('api_version = "2026-07"'));assert(!toml.includes('orders/fulfilled""'));}
const pkg=JSON.parse(readFileSync('package.json','utf8'));
assert(pkg.dependencies['@react-router/serve']);
assert(!pkg.dependencies['react-router-serve']);
assert(existsSync('prisma/bootstrap/README.md'));
assert(!readFileSync('server.js','utf8').includes('migrate deploy'));
if(existsSync('Dockerfile'))assert(!readFileSync('Dockerfile','utf8').includes('migrate deploy'));
assert(!pkg.scripts.setup.includes('migrate'));
let count=0;
function walk(dir){for(const entry of readdirSync(dir,{withFileTypes:true})){const f=dir+'/'+entry.name;if(entry.isDirectory())walk(f);else if(/\.tsx?$/.test(f)){const result=ts.transpileModule(readFileSync(f,'utf8'),{fileName:f,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX}});const errors=(result.diagnostics||[]).filter(x=>x.category===ts.DiagnosticCategory.Error);assert.equal(errors.length,0,errors.map(e=>ts.flattenDiagnosticMessageText(e.messageText,' ')).join('; '));count++;}}}
walk('app');walk('tests');
console.log(JSON.stringify({status:'PASS',models:models.length,transpiledFiles:count,scope:'source syntax and structural checks; not a dependency typecheck or production build'},null,2));

// Deployment runtime invariant: Framework Mode server entry must be explicit on GoDaddy.
import { existsSync as __existsSync } from 'node:fs';
if (!__existsSync('app/entry.server.tsx')) { console.error('Missing app/entry.server.tsx'); process.exit(1); }

assert(pkg.scripts['check:boundaries'],'Missing route boundary check script');
