import {execFileSync} from 'node:child_process';
import {existsSync} from 'node:fs';
import {validateEnvironment} from './lib/staging-policy.mjs';
const report=validateEnvironment(process.env,{requireSecrets:true});
if(!report.ok)throw new Error(report.errors.join('; '));
if(!existsSync('package-lock.json'))throw new Error('Genuine package-lock.json required. Resolve dependencies on a registry-connected staging machine and commit the lockfile.');
function run(command,args){execFileSync(command,args,{stdio:'inherit',env:process.env});}
run('npm',['ci','--no-audit','--no-fund']);
run('npx',['prisma','validate']);run('npx',['prisma','generate']);
run('npm',['run','verify:source']);run('npm',['test']);run('npm',['run','lint:rules']);run('npm',['run','typecheck']);run('npm',['run','build']);run('npm',['run','verify:deployment']);
console.log('Local build checks passed. Database bootstrap and authenticated Shopify acceptance are separate explicit steps.');
