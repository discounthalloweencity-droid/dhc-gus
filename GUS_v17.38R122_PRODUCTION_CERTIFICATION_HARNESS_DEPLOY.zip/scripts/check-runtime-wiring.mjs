import fs from 'node:fs';
import path from 'node:path';
import {extractRouteRefs} from './check-route-uniqueness.mjs';

const cwd=process.cwd(),app=path.resolve('app'),services=path.resolve('app/services'),routesDir=path.resolve('app/routes');
const exts=['.ts','.tsx','.js','.jsx','.mjs','.cjs','.json'];
function walk(dir){const out=[];for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())out.push(...walk(p));else if(exts.includes(path.extname(e.name)))out.push(p);}return out;}
function resolveRelative(file,spec){const base=path.resolve(path.dirname(file),spec),candidates=[base,...exts.map(e=>base+e)];if(fs.existsSync(base)&&fs.statSync(base).isDirectory())for(const e of exts)candidates.push(path.join(base,'index'+e));return candidates.find(x=>fs.existsSync(x)&&fs.statSync(x).isFile())||null;}
const importRe=/(?:from\s+|import\s*\()(['"])(\.[^'"]+)\1/g;
const routeSource=fs.readFileSync(path.resolve('app/routes.ts'),'utf8'),refs=extractRouteRefs(routeSource),registered=new Set(refs.map(r=>r.moduleRef.replace(/\\/g,'/')));
// The lightweight route parser intentionally cannot parse the multiline parent route with nested children.
if(routeSource.includes('route("app", "routes/app.tsx"'))registered.add('routes/app.tsx');
const routeFiles=walk(routesDir).filter(f=>['.ts','.tsx'].includes(path.extname(f))).map(f=>'routes/'+path.relative(routesDir,f).replace(/\\/g,'/'));
const unregistered=routeFiles.filter(f=>!registered.has(f));
const seeds=[];for(const r of refs){const p=path.resolve('app',r.moduleRef);if(fs.existsSync(p))seeds.push(p);}const appParent=path.resolve('app/routes/app.tsx');if(fs.existsSync(appParent))seeds.push(appParent);for(const rel of ['app/root.tsx','app/entry.client.tsx','app/entry.server.tsx','app/shopify.server.ts']){const p=path.resolve(rel);if(fs.existsSync(p))seeds.push(p);}
const seen=new Set(),stack=[...new Set(seeds)];while(stack.length){const file=stack.pop();if(seen.has(file))continue;seen.add(file);let txt='';try{txt=fs.readFileSync(file,'utf8')}catch{continue;}for(const m of txt.matchAll(importRe)){const dep=resolveRelative(file,m[2]);if(dep&&!seen.has(dep))stack.push(dep);}}
const serviceFiles=walk(services).filter(f=>f.endsWith('.ts'));
const appSourceFiles=walk(app).filter(f=>['.ts','.tsx'].includes(path.extname(f)));
const appSourceCorpus=appSourceFiles.map(f=>{try{return fs.readFileSync(f,'utf8')}catch{return ''}}).join('\n');
const executionExportAllowlist=new Map([
  ['basket-builder-rules.ts:buildBasket','Pure deterministic composition helper retained for rule-level regression tests; production basket intelligence consumes basketCompatibility directly.'],
]);
const inertExecutionExports=[];
const executionExportRe=/export\s+(?:async\s+)?function\s+([A-Za-z0-9_]+)\s*\(/g;
const executionNameRe=/^(run|build|request|start|stop|refresh|execute|apply|publish|create|repair|reconcile|evaluate|sync|process)/i;
for(const file of serviceFiles){const src=fs.readFileSync(file,'utf8');for(const match of src.matchAll(executionExportRe)){const name=match[1];if(!executionNameRe.test(name))continue;const occurrences=(appSourceCorpus.match(new RegExp(`\\b${name}\\b`,'g'))||[]).length;if(occurrences<=1){const key=`${path.basename(file)}:${name}`;if(!executionExportAllowlist.has(key))inertExecutionExports.push(key);}}}
const staleExecutionAllowlist=[...executionExportAllowlist.keys()].filter(key=>{const [file,name]=key.split(':');const source=serviceFiles.find(x=>path.basename(x)===file);if(!source)return true;const occurrences=(appSourceCorpus.match(new RegExp(`\\b${name}\\b`,'g'))||[]).length;return occurrences>1;});
const legacyAllowlist=new Map();
const unreachable=serviceFiles.filter(f=>!seen.has(f)).map(f=>path.basename(f));
const unexpectedUnreachable=[...unreachable];
const staleAllowlist=[];
const packageJson=JSON.parse(fs.readFileSync('package.json','utf8')),scriptMissing=[];
for(const [name,cmd] of Object.entries(packageJson.scripts||{})){for(const m of String(cmd).matchAll(/\b(tests\/[A-Za-z0-9._-]+\.(?:ts|tsx|js|mjs))\b/g)){if(!fs.existsSync(m[1]))scriptMissing.push(`${name}: ${m[1]}`);}}
const mustReach=['automation-control.server.ts','catalog.server.ts','catalog-self-healing.server.ts','pricing.server.ts','supplier-feed.server.ts','cj-shipping-refresh.server.ts','seasonal-switch.server.ts','promotions.server.ts','promotion-publisher.server.ts','recommendations.server.ts','gus-shopping-recommendation.server.ts','support.server.ts','support-actions.server.ts','bottom-line.server.ts','retail-intelligence-core.server.ts','traffic-quality-engine.server.ts','seo-self-evolving-director.server.ts','seo-experiment-lab.server.ts','seo-content-intelligence.server.ts','seo-blog-draft-factory.server.ts','seo-blog-publisher.server.ts','weekly-collection-maintenance.server.ts','shop-roi-engine.server.ts','executive.server.ts','storefront-conversion-director.server.ts','brain.server.ts','gus-operator-intelligence.server.ts','orchestrator.server.ts','runtime-orchestrator-pulse.server.ts','fulfillment-product-quality.server.ts','shipping-replacement-engine.server.ts','customer-service-director.server.ts','order-guardian.server.ts','storefront-gus-ai.server.ts','continuous-product-learning-director.server.ts','learning-instrumentation-coverage.server.ts','supplier-feed.server.ts','cj-shipping-refresh.server.ts','customer-service-language.ts','job-progress-token.server.ts','basket-builder-intelligence.server.ts','dhc-complete-look-graph.server.ts'];
const notReached=mustReach.filter(name=>{const p=path.resolve(services,name);return fs.existsSync(p)&&!seen.has(p)});
const moduleRuntimeContracts={
  core:['automation-control.server.ts'],
  catalog:['catalog.server.ts','catalog-self-healing.server.ts'],
  pricing:['pricing.server.ts'],
  supplier:['supplier-feed.server.ts','cj-shipping-refresh.server.ts'],
  seasonal_switch:['seasonal-switch.server.ts'],
  promotions:['promotions.server.ts','promotion-publisher.server.ts'],
  recommendations:['recommendations.server.ts','gus-shopping-recommendation.server.ts'],
  support:['support.server.ts','support-actions.server.ts'],
  'bottom-line':['bottom-line.server.ts'],
  'retail-intelligence':['retail-intelligence-core.server.ts'],
  'traffic-quality':['traffic-quality-engine.server.ts'],
  growth:['seo-self-evolving-director.server.ts','seo-content-intelligence.server.ts'],
  stocking:['reporting.ts','stock-evidence.ts'],
  collections:['weekly-collection-maintenance.server.ts'],
  'shop-roi':['shop-roi-engine.server.ts'],
  executive:['executive.server.ts'],
  storefront_conversion:['storefront-conversion-director.server.ts'],
  brain:['brain.server.ts','continuous-product-learning-director.server.ts','learning-instrumentation-coverage.server.ts'],
  operator:['gus-operator-intelligence.server.ts'],
  orchestrator:['orchestrator.server.ts','runtime-orchestrator-pulse.server.ts'],
  fulfillment_product_quality:['fulfillment-product-quality.server.ts'],
  shipping_replacement:['shipping-replacement-engine.server.ts'],
  storefront_support_integration:['gus-app-proxy-dispatch.server.ts'],
  customer_service_director:['customer-service-director.server.ts','customer-service-language.ts','customer-service-email.server.ts','support-order-status-rules.ts'],
  order_guardian:['order-guardian.server.ts'],
};
const registrySource=fs.readFileSync(path.resolve('app/services/feature-registry.ts'),'utf8');
const integratedKeys=[...registrySource.matchAll(/\{key:'([^']+)'[^\n]*status:'INTEGRATED'/g)].map(m=>m[1]);
const missingModuleContracts=integratedKeys.filter(key=>!moduleRuntimeContracts[key]);
const moduleContractFailures=[];
for(const [key,names] of Object.entries(moduleRuntimeContracts))for(const name of names){const file=path.resolve(services,name);if(!fs.existsSync(file))moduleContractFailures.push(`${key}: missing ${name}`);else if(!seen.has(file))moduleContractFailures.push(`${key}: unreachable ${name}`);}
const errors=[...unregistered.map(x=>`Unregistered route module: ${x}`),...unexpectedUnreachable.map(x=>`Unreachable service module: ${x}`),...staleAllowlist.map(x=>`Legacy allowlist entry is now reachable and must be removed: ${x}`),...scriptMissing.map(x=>`Broken package test script reference: ${x}`),...notReached.map(x=>`Required runtime system is not reachable: ${x}`),...missingModuleContracts.map(x=>`Integrated feature registry module lacks runtime contract: ${x}`),...moduleContractFailures.map(x=>`Feature registry runtime contract failed: ${x}`),...inertExecutionExports.map(x=>`Execution-like service export is not invoked by production code: ${x}`),...staleExecutionAllowlist.map(x=>`Execution export allowlist is stale: ${x}`)];
const report={status:errors.length?'FAIL':'PASS',routeRegistrations:refs.length,routeFiles:routeFiles.length,unregisteredRoutes:unregistered,serviceModules:serviceFiles.length,reachableServiceModules:serviceFiles.length-unreachable.length,legacyUnreachable:[...legacyAllowlist].filter(([f])=>unreachable.includes(f)).map(([file,reason])=>({file,reason})),unexpectedUnreachable,brokenScriptReferences:scriptMissing,requiredSystemsNotReached:notReached,integratedFeatureModules:integratedKeys.length,featureModulesWithoutRuntimeContract:missingModuleContracts,featureModuleRuntimeContractFailures:moduleContractFailures,inertExecutionExports,executionExportAllowlist:[...executionExportAllowlist].map(([symbol,reason])=>({symbol,reason}))};
console.log(JSON.stringify(report,null,2));if(errors.length){console.error(errors.join('\n'));process.exit(1);}
