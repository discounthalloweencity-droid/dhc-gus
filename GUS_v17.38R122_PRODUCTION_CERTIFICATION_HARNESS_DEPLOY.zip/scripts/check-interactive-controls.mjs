import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
const appDir=path.join(root,'app');
const routesFile=path.join(appDir,'routes.ts');
const routesSource=fs.readFileSync(routesFile,'utf8');

const routePaths=new Set(['/']);
let inApp=false;
for(const line of routesSource.split(/\r?\n/)){
  const appStart=line.match(/route\("app"\s*,/);
  if(appStart){routePaths.add('/app');inApp=true;continue;}
  const m=line.match(/\broute\("([^"]+)"\s*,/);
  if(m){
    const p=m[1];
    routePaths.add(inApp?`/app/${p}`:`/${p}`);
  }
  if(inApp && /^\s*\]\)/.test(line)) inApp=false;
}

const tsx=[];
function walk(dir){
  for(const ent of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir,ent.name);
    if(ent.isDirectory())walk(full);
    else if(/\.tsx$/.test(ent.name))tsx.push(full);
  }
}
walk(appDir);

const failures=[];
const warnings=[];
const stats={files:tsx.length,buttons:0,links:0,anchors:0,forms:0,postForms:0,staticControlValues:0,internalTargets:0,operationRows:0};
const proxyAllowlist=new Set(['/apps/gus-support']);
const dispatchNames=new Set(['intent','kind','mode','action','command','cmd']);

function lineAt(src,pos){return src.slice(0,pos).split('\n').length;}
function staticAttr(attrs,name){
  const m=attrs.match(new RegExp(`\\b${name}\\s*=\\s*["']([^"']*)["']`));
  return m?.[1]??null;
}
function hasAttr(attrs,name){return new RegExp(`\\b${name}(?:\\s*=|\\s|$)`).test(attrs);}
function normalizedRoute(target){
  if(!target)return null;
  const clean=target.split('#')[0].split('?')[0].replace(/\/$/,'');
  return clean||'/';
}
function isInternalStatic(target){return target?.startsWith('/')&&!target.startsWith('//');}
function targetExists(target){
  const n=normalizedRoute(target);
  if(!n)return true;
  if(proxyAllowlist.has(n))return true;
  if(n.startsWith('/api/')||n.startsWith('/gus/')||n.startsWith('/jobs/')||n.startsWith('/health')||n.startsWith('/bootstrap/')||n.startsWith('/support-center')||n.startsWith('/storefront/')||n.startsWith('/auth/')) return routePaths.has(n)||[...routePaths].some(x=>x.endsWith('/*')&&n.startsWith(x.slice(0,-1)));
  return routePaths.has(n)||[...routePaths].some(x=>x.endsWith('/*')&&n.startsWith(x.slice(0,-1)));
}

for(const file of tsx){
  const src=fs.readFileSync(file,'utf8');
  const rel=path.relative(root,file);
  const routeAction=/export\s+(?:async\s+)?function\s+action\b|export\s+const\s+action\b/.test(src);

  // Form nesting and button wiring.
  const tagRx=/<(\/)?((?:[A-Za-z_$][A-Za-z0-9_$]*\.)?Form|form|button)\b([^>]*)>/gs;
  const stack=[];
  for(const m of src.matchAll(tagRx)){
    const closing=Boolean(m[1]), name=m[2], attrs=m[3]||'';
    if(name==='form'||name==='Form'||name.endsWith('.Form')){
      if(closing){
        for(let i=stack.length-1;i>=0;i--){if(stack[i].name===name){stack.splice(i,1);break;}}
      }else{
        stats.forms++;
        const method=(staticAttr(attrs,'method')||'get').toLowerCase();
        const action=staticAttr(attrs,'action');
        if(method==='post'){
          stats.postForms++;
          if(!action&&!routeAction) failures.push(`${rel}:${lineAt(src,m.index)} POST form has no route action export`);
        }
        if(action&&isInternalStatic(action)){
          stats.internalTargets++;
          if(!targetExists(action)) failures.push(`${rel}:${lineAt(src,m.index)} form action has no registered endpoint: ${action}`);
        }
        stack.push({name,attrs,pos:m.index});
      }
      continue;
    }
    if(name==='button'&&!closing){
      stats.buttons++;
      const line=lineAt(src,m.index);
      const type=(staticAttr(attrs,'type')||'submit').toLowerCase();
      const onClick=/\bonClick\s*=/.test(attrs);
      const formAction=/\bformAction\s*=/.test(attrs);
      const staticDisabled=/\bdisabled\b(?!\s*=)/.test(attrs);
      const insideForm=stack.length>0;
      if(staticDisabled) failures.push(`${rel}:${line} button is permanently disabled`);
      if(type==='button'){
        if(!onClick&&!formAction) failures.push(`${rel}:${line} type=button has no click handler`);
      }else if(type==='submit'){
        if(!insideForm&&!formAction&&!onClick) failures.push(`${rel}:${line} submit button is not inside a form and has no formAction/click handler`);
      }else if(!onClick&&!insideForm&&!formAction){
        failures.push(`${rel}:${line} button has no actionable wiring`);
      }
    }
  }

  // Links / anchors. Static internal targets must resolve. Dynamic targets are still counted and structurally required.
  for(const m of src.matchAll(/<Link\b([^>]*)>/gs)){
    stats.links++;
    const attrs=m[1]||'';
    const target=staticAttr(attrs,'to');
    if(target!==null){
      if(!target) failures.push(`${rel}:${lineAt(src,m.index)} Link has an empty to target`);
      if(target==='#') failures.push(`${rel}:${lineAt(src,m.index)} Link uses placeholder # target`);
      if(isInternalStatic(target)){
        stats.internalTargets++;
        if(!targetExists(target)) failures.push(`${rel}:${lineAt(src,m.index)} Link has no registered route: ${target}`);
      }
    }else if(!/\bto\s*=\s*\{/.test(attrs)){
      failures.push(`${rel}:${lineAt(src,m.index)} Link has no to target`);
    }
  }
  for(const m of src.matchAll(/<a\b([^>]*)>/gs)){
    if(/\\["']/.test(m[1]||'')) continue;
    stats.anchors++;
    const attrs=m[1]||'';
    const target=staticAttr(attrs,'href');
    if(target!==null){
      if(!target||target==='#') failures.push(`${rel}:${lineAt(src,m.index)} anchor has empty/placeholder href`);
      if(isInternalStatic(target)){
        stats.internalTargets++;
        // Query-only anchors are current-route actions and valid.
        if(!target.startsWith('?')&&!targetExists(target)) failures.push(`${rel}:${lineAt(src,m.index)} anchor has no registered route: ${target}`);
      }
    }else if(!/\bhref\s*=\s*\{/.test(attrs)){
      failures.push(`${rel}:${lineAt(src,m.index)} anchor has no href`);
    }
  }

  // Static control values must appear in route logic as well as markup.
  for(const m of src.matchAll(/<(?:input|button)\b([^>]*)>/gs)){
    const attrs=m[1]||'';
    const name=staticAttr(attrs,'name');
    const value=staticAttr(attrs,'value');
    if(!name||value===null||!dispatchNames.has(name))continue;
    stats.staticControlValues++;
    if(!routeAction&&rel.startsWith('app/routes/')) failures.push(`${rel}:${lineAt(src,m.index)} ${name}=${value} control has no route action`);
    const escaped=value.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    const occurrences=(src.match(new RegExp(`(["'])${escaped}\\1`,'g'))||[]).length;
    if(occurrences<2) warnings.push(`${rel}:${lineAt(src,m.index)} ${name}=${value} appears only in markup; verify generic dispatch intentionally handles it`);
  }
}

// Manual Operations Control is data-driven; every advertised operation ID must map to a dashboard action handler.
const opsFile=path.join(appDir,'services','operations-control.server.ts');
const dashFile=path.join(appDir,'routes','app._index.tsx');
const ops=fs.readFileSync(opsFile,'utf8');
const dash=fs.readFileSync(dashFile,'utf8');
const operationIds=[...ops.matchAll(/\{id:'([^']+)'/g)].map(m=>m[1]);
const handlers=new Set([...dash.matchAll(/if\(intent===["']([^"']+)["']\)/g)].map(m=>m[1]));
stats.operationRows=operationIds.length;
for(const id of operationIds) if(!handlers.has(id)) failures.push(`app/services/operations-control.server.ts operation '${id}' has no dashboard action handler`);
for(const m of ops.matchAll(/route:'([^']+)'/g)){
  stats.internalTargets++;
  if(!targetExists(m[1])) failures.push(`app/services/operations-control.server.ts operation route missing: ${m[1]}`);
}

const report={status:failures.length?'FAIL':'PASS',...stats,failures,warnings};
console.log(JSON.stringify(report,null,2));
if(failures.length)process.exit(1);
