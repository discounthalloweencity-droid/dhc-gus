import {existsSync,readFileSync} from 'node:fs';
import {validateEnvironment} from './lib/staging-policy.mjs';
const report=validateEnvironment(process.env,{requireSecrets:true});
const checks={environment:report.ok,lockfile:existsSync('package-lock.json'),dependencies:existsSync('node_modules/@prisma/client')&&existsSync('node_modules/@react-router/serve'),build:existsSync('build/server/index.js')};
const errors=[...report.errors];for(const [key,ok] of Object.entries(checks))if(!ok)errors.push(key+' check failed');
console.log(JSON.stringify({ok:errors.length===0,checks,errors,scope:'Local deployment prerequisites only; Shopify and hosting acceptance still required'},null,2));if(errors.length)process.exitCode=1;
