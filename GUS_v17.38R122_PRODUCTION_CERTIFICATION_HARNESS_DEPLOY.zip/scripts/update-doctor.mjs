import {mkdirSync,writeFileSync,unlinkSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {spawnSync} from 'node:child_process';
const root=resolve(process.env.DHC_UPDATE_ROOT||'.dhc-updates');mkdirSync(root,{recursive:true});
let writable=true;try{const p=resolve(root,'.doctor');writeFileSync(p,'ok');unlinkSync(p);}catch{writable=false;}
const unzip=spawnSync('unzip',['-v'],{encoding:'utf8'}).status===0;
const restart=resolve(process.env.DHC_RESTART_TOUCH_FILE||'tmp/restart.txt');let restartDir=true;try{mkdirSync(dirname(restart),{recursive:true});}catch{restartDir=false;}
const result={writable,unzip,restartFile:restart,restartDir,dbBackupReady:process.env.DHC_UPDATE_DB_BACKUP_READY==='true'};
console.log(JSON.stringify(result,null,2));if(!writable||!unzip||!restartDir)process.exit(1);
