import fs from 'node:fs';import path from 'node:path';
const registry=fs.readFileSync(path.resolve('app/services/feature-registry.ts'),'utf8');
const contract=fs.readFileSync(path.resolve('app/services/engine-certification-registry.ts'),'utf8');
const routes=fs.readFileSync(path.resolve('app/routes.ts'),'utf8');
const shell=fs.readFileSync(path.resolve('app/routes/app.tsx'),'utf8');
const integrated=[...registry.matchAll(/\{key:'([^']+)'[^\n]*status:'INTEGRATED'/g)].map(m=>m[1]);
const certified=[...contract.matchAll(/\{key:'([^']+)'/g)].map(m=>m[1]);
const missing=integrated.filter(k=>!certified.includes(k)),extra=certified.filter(k=>!integrated.includes(k)),dupes=certified.filter((k,i)=>certified.indexOf(k)!==i);
const modules=[...contract.matchAll(/modules:\[([^\]]+)\]/g)].flatMap(m=>[...m[1].matchAll(/'([^']+)'/g)].map(x=>x[1]));
const missingFiles=[...new Set(modules)].filter(f=>!fs.existsSync(path.resolve('app/services',f)));
const requiredFiles=['app/services/engine-certification.server.ts','app/services/engine-certification-rules.ts','app/routes/app.engine-certification-lab.tsx','app/routes/health.engines.tsx','tests/engine-certification-lab.test.ts'];
const missingRequired=requiredFiles.filter(f=>!fs.existsSync(path.resolve(f)));
const routeOk=/engine-certification-lab/.test(routes)&&/health\/engines/.test(routes)&&/Engine Certification Lab/.test(shell);
const errors=[...missing.map(x=>`Missing certification contract: ${x}`),...extra.map(x=>`Unexpected certification contract: ${x}`),...dupes.map(x=>`Duplicate certification contract: ${x}`),...missingFiles.map(x=>`Missing certification service file: ${x}`),...missingRequired.map(x=>`Missing lab file: ${x}`),...(!routeOk?['Certification routes/navigation not wired']:[])];
const report={status:errors.length?'FAIL':'PASS',integratedEngines:integrated.length,certificationContracts:certified.length,uniqueContracts:new Set(certified).size,missing,extra,duplicateContracts:[...new Set(dupes)],missingFiles,routeOk};console.log(JSON.stringify(report,null,2));if(errors.length){console.error(errors.join('\n'));process.exit(1)}
