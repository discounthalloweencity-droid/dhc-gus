import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PrismaClient } from '@prisma/client';
import { applyDatabaseUrl } from './lib/godaddy-db-env.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
const schemaPath=path.join(root,'prisma','mysql','schema.prisma');
const SCALARS=new Set(['String','Int','Float','Boolean','DateTime','BigInt','Decimal','Json','Bytes']);
const LONG_TEXT_FIELDS=new Set([
  'JobRun.details','Finding.message','ChangeLog.beforeValue','ChangeLog.afterValue','ChangeLog.reason',
  'ActionProposal.beforeValue','ActionProposal.afterValue','ActionProposal.reason','ActionProposal.error','BulkBatchItem.error',
  'GrowthEvidence.rowsJson','TrafficEvidenceRecord.evidenceJson','CompetitorEvidence.evidenceJson','CompetitorSnapshot.evidenceJson',
  'AvailabilityDecisionLog.evidenceJson',
  'ErrorEvent.message','ErrorEvent.stack','ErrorEvent.contextJson','ErrorEvent.resolution','UpdateRelease.notes','SupportCase.summary',
  'BrainQuestion.question','BrainQuestion.reason','BrainQuestion.evidenceJson','BrainKnowledge.statement','BrainKnowledge.evidenceJson','BrainEvalRun.detailsJson','BrainTransfer.details',
  'FraudRiskAssessment.reviewerNote','ExecutiveWorkItem.objective','ExecutiveWorkItem.title','ExecutiveWorkItem.evidenceJson','ExecutiveWorkItem.resultJson','ExecutiveWorkItem.error',
  'CollectionOptimizationPlan.beforeJson','CollectionOptimizationPlan.afterJson','CollectionOptimizationPlan.competitorJson',
  'CollectionOptimizationPlan.reason','GusMessage.content','GusMessage.actionJson',
  'RetailMission.dependenciesJson','RetailMission.evidenceJson','RetailMission.beforeJson','RetailMission.actionJson','RetailMission.afterJson',
  'RetailMission.resultJson','RetailMission.measurementWindowJson','RetailMission.outcomeJson','RetailMission.learnedLesson',
  'RetailMissionEvent.detailsJson','IntelligenceSignal.evidenceJson','ConversionEvent.metadataJson',
  'SeasonalManagedArchive.evidenceJson','SeasonalManagedArchive.restoreReason','SupplierVariantCoverage.supplierIdentitiesJson',
  'FraudRiskAssessment.signalsJson','ExecutiveDecisionRun.summaryJson','BottomLineSnapshot.sourceCoverageJson','GusOrchestratorRun.summaryJson'
]);

function ident(value){
  if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(value)) throw new Error(`Unsafe SQL identifier: ${value}`);
  return `\`${value}\``;
}

function parseSchema(source){
  const models=new Map();
  const modelRx=/\bmodel\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{([\s\S]*?)\n\}/g;
  for(const match of source.matchAll(modelRx)){
    const [,model,body]=match;
    const fields=[];
    for(const raw of body.split(/\r?\n/)){
      const line=raw.replace(/\/\/.*$/,'').trim();
      if(!line||line.startsWith('@@')) continue;
      const m=line.match(/^([A-Za-z_][A-Za-z0-9_]*)\s+([A-Za-z_][A-Za-z0-9_]*)(\?|\[\])?\s*(.*)$/);
      if(!m||!SCALARS.has(m[2])||m[3]==='[]') continue;
      fields.push({name:m[1],type:m[2],optional:m[3]==='?',attrs:m[4]||'',line});
    }
    models.set(model,fields);
  }
  return models;
}

function nativeSqlType(field,model){
  const key=`${model}.${field.name}`;
  if(LONG_TEXT_FIELDS.has(key)) return 'LONGTEXT';
  const native=field.attrs.match(/@db\.(VarChar|Char|Text|TinyText|MediumText|LongText|Decimal|DateTime|Timestamp|Binary|VarBinary)\s*(?:\(([^)]*)\))?/i);
  if(native){
    const type=native[1].toUpperCase();
    const args=(native[2]||'').trim();
    if(type==='VARCHAR'||type==='CHAR'||type==='DECIMAL'||type==='DATETIME'||type==='TIMESTAMP'||type==='BINARY'||type==='VARBINARY') return `${type}${args?`(${args})`:''}`;
    return type;
  }
  switch(field.type){
    case 'String': return 'VARCHAR(191)';
    case 'Int': return 'INT';
    case 'Float': return 'DOUBLE';
    case 'Boolean': return 'BOOLEAN';
    case 'DateTime': return 'DATETIME(3)';
    case 'BigInt': return 'BIGINT';
    case 'Decimal': return 'DECIMAL(65,30)';
    case 'Json': return 'JSON';
    case 'Bytes': return 'LONGBLOB';
    default: throw new Error(`Unsupported scalar ${field.type}`);
  }
}

function parseDefault(field){
  const m=field.attrs.match(/@default\(([^)]*(?:\)[^)]*)?)\)/);
  if(!m) return null;
  const raw=m[1].trim();
  if(raw==='autoincrement()'||raw.startsWith('autoincrement(')) return {auto:true};
  if(raw==='now()') return {sql:'CURRENT_TIMESTAMP(3)'};
  if(raw==='true'||raw==='false'||/^-?\d+(?:\.\d+)?$/.test(raw)) return {sql:raw==='true'?'1':raw==='false'?'0':raw};
  const q=raw.match(/^"([\s\S]*)"$/);
  if(q) return {sql:`'${q[1].replace(/'/g,"''")}'`};
  return null;
}

function additiveDefinition(field,model){
  if(/@id\b/.test(field.attrs)) return null;
  const type=nativeSqlType(field,model);
  const isLong=/TEXT|BLOB|JSON/i.test(type);
  if(field.optional) return `${type} NULL`;
  const def=parseDefault(field);
  if(def?.auto) return null;
  if(field.attrs.includes('@updatedAt')) return `${type} NOT NULL DEFAULT CURRENT_TIMESTAMP(3)`;
  if(def?.sql && !isLong) return `${type} NOT NULL DEFAULT ${def.sql}`;
  if(def?.sql && isLong) return `${type} NULL`;
  if(isLong) return `${type} NULL`;
  if(field.type==='String') return `${type} NOT NULL DEFAULT ''`;
  if(field.type==='Boolean') return `${type} NOT NULL DEFAULT 0`;
  if(field.type==='DateTime') return `${type} NOT NULL DEFAULT CURRENT_TIMESTAMP(3)`;
  if(['Int','Float','BigInt','Decimal'].includes(field.type)) return `${type} NOT NULL DEFAULT 0`;
  return `${type} NULL`;
}

applyDatabaseUrl(process.env);
if(!/^mysql:\/\//i.test(String(process.env.DATABASE_URL||''))){
  console.error('[gus-schema-additive] MySQL DATABASE_URL is required.');
  process.exit(1);
}

const schema=parseSchema(readFileSync(schemaPath,'utf8'));
const prisma=new PrismaClient();
let added=0,widened=0,skipped=0;
try{
  const tableRows=await prisma.$queryRawUnsafe('SELECT TABLE_NAME AS tableName FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE()');
  const tables=new Set((Array.isArray(tableRows)?tableRows:[]).map(r=>String(r?.tableName||'')).filter(Boolean));
  const columnRows=await prisma.$queryRawUnsafe('SELECT TABLE_NAME AS tableName,COLUMN_NAME AS columnName,DATA_TYPE AS dataType,IS_NULLABLE AS nullable FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE()');
  const columns=new Map();
  for(const row of Array.isArray(columnRows)?columnRows:[]){
    const table=String(row?.tableName||''),column=String(row?.columnName||'');
    if(!table||!column) continue;
    if(!columns.has(table)) columns.set(table,new Map());
    columns.get(table).set(column,{dataType:String(row?.dataType||'').toLowerCase(),nullable:String(row?.nullable||'')});
  }

  for(const [model,fields] of schema){
    if(!tables.has(model)) continue;
    const have=columns.get(model)||new Map();
    for(const field of fields){
      const key=`${model}.${field.name}`;
      if(!have.has(field.name)){
        const def=additiveDefinition(field,model);
        if(!def){
          skipped++;
          console.warn(`[gus-schema-additive] Missing ${key} requires a primary-key/autoincrement migration; skipped for safety.`);
          continue;
        }
        const sql=`ALTER TABLE ${ident(model)} ADD COLUMN ${ident(field.name)} ${def}`;
        console.warn(`[gus-schema-additive] Adding missing scalar column ${key} (${def}).`);
        await prisma.$executeRawUnsafe(sql);
        added++;
        have.set(field.name,{dataType:def.split(/\s+/)[0].toLowerCase(),nullable:def.includes(' NULL')?'YES':'NO'});
      }

      const nativeTarget=nativeSqlType(field,model).toUpperCase();
      const explicitTextTarget=['TEXT','MEDIUMTEXT','LONGTEXT'].includes(nativeTarget)?nativeTarget:null;
      const targetTextType=explicitTextTarget||(LONG_TEXT_FIELDS.has(key)?'LONGTEXT':null);
      if(targetTextType){
        const current=have.get(field.name);
        const dataType=String(current?.dataType||'').toLowerCase();
        const targetDataType=targetTextType.toLowerCase();
        const ranks={tinytext:1,text:2,mediumtext:3,longtext:4};
        const needsWiden=!ranks[dataType]||ranks[dataType]<ranks[targetDataType];
        if(needsWiden){
          console.warn(`[gus-schema-additive] Widening ${key} from ${dataType||'unknown'} to ${targetTextType}.`);
          await prisma.$executeRawUnsafe(`ALTER TABLE ${ident(model)} MODIFY COLUMN ${ident(field.name)} ${targetTextType} NULL`);
          if(!field.optional){
            const defaultMatch=field.attrs.match(/@default\("([\s\S]*?)"\)/);
            const fill=defaultMatch?defaultMatch[1]:(field.name.toLowerCase().includes('json')?'{}':'');
            await prisma.$executeRawUnsafe(`UPDATE ${ident(model)} SET ${ident(field.name)}=? WHERE ${ident(field.name)} IS NULL`,fill);
            await prisma.$executeRawUnsafe(`ALTER TABLE ${ident(model)} MODIFY COLUMN ${ident(field.name)} ${targetTextType} NOT NULL`);
          }
          widened++;
          have.set(field.name,{dataType:targetDataType,nullable:field.optional?'YES':'NO'});
        }
      }
    }
  }
  console.log(`[gus-schema-additive] Safe additive repair complete: columns added=${added}, text columns widened=${widened}, unsafe primary-key changes skipped=${skipped}. No table/column was dropped.`);
}catch(error){
  console.error('[gus-schema-additive] Safe additive repair failed:',error instanceof Error?(error.stack||error.message):String(error));
  process.exitCode=1;
}finally{
  await prisma.$disconnect().catch(()=>{});
}
