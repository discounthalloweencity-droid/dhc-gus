import fs from 'node:fs';
import path from 'node:path';

export function extractRouteRefs(source) {
  const refs = [];
  const callRe = /\b(route|index|layout)\s*\(([^\n]*?)\)/g;
  let m;
  while ((m = callRe.exec(source))) {
    const kind = m[1];
    const args = m[2];
    const strings = [...args.matchAll(/["'`]([^"'`]+)["'`]/g)].map(x => x[1]);
    let routePath = null;
    let moduleRef = null;
    if (kind === 'route') {
      routePath = strings[0] ?? null;
      moduleRef = strings[1] ?? null;
    } else {
      moduleRef = strings[0] ?? null;
    }
    if (moduleRef) refs.push({kind, routePath, moduleRef, offset:m.index});
  }
  return refs;
}

export function findDuplicateRouteModules(source) {
  const refs = extractRouteRefs(source);
  const byModule = new Map();
  for (const ref of refs) {
    const key = ref.moduleRef.replace(/\\/g,'/').replace(/\.(tsx?|jsx?)$/i,'');
    const arr = byModule.get(key) ?? [];
    arr.push(ref);
    byModule.set(key, arr);
  }
  return [...byModule.entries()]
    .filter(([, refs]) => refs.length > 1)
    .map(([routeId, refs]) => ({routeId, refs}));
}

export function assertUniqueRoutes(file) {
  const source = fs.readFileSync(file,'utf8');
  const duplicates = findDuplicateRouteModules(source);
  if (duplicates.length) {
    const detail = duplicates.map(d => `${d.routeId} (${d.refs.length} registrations)`).join(', ');
    throw new Error(`Duplicate React Router route module(s) detected: ${detail}`);
  }
  return extractRouteRefs(source).length;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const file = path.resolve(process.argv[2] || 'app/routes.ts');
  try {
    const count = assertUniqueRoutes(file);
    console.log(JSON.stringify({status:'PASS',file,routeRegistrations:count,duplicateRouteModules:0},null,2));
  } catch (error) {
    console.error(JSON.stringify({status:'FAIL',file,error:String(error?.message || error)},null,2));
    process.exit(1);
  }
}
