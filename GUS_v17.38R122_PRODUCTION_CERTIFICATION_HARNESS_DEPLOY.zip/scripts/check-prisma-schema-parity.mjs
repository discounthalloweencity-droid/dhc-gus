import {readFileSync} from 'node:fs';
function names(file){return [...readFileSync(file,'utf8').matchAll(/^model\s+([A-Za-z0-9_]+)\s*\{/gm)].map(m=>m[1]).sort();}
const app=names('prisma/schema.prisma'),prod=names('prisma/mysql/schema.prisma');
const onlyApp=app.filter(x=>!prod.includes(x)),onlyProd=prod.filter(x=>!app.includes(x));
if(onlyApp.length||onlyProd.length){console.error(`[gus-prisma] schema parity failed onlyApp=${onlyApp.join(',')||'none'} onlyProd=${onlyProd.join(',')||'none'}`);process.exit(1);}
console.log(`[gus-prisma] application/production Prisma schema parity verified: ${app.length}/${app.length} models.`);
