console.error('Database migration refused. Use the explicit new-database staging bootstrap or a separately reviewed production migration.');process.exit(1);
