import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const root=process.cwd();
const hidden=resolve(root,'node_modules/.package-lock.json');
const rootLock=resolve(root,'package-lock.json');
const source=existsSync(rootLock)?rootLock:(existsSync(hidden)?hidden:null);
let lockSummary={present:false,source:null,packages:null};
if(source){
  try{
    const parsed=JSON.parse(readFileSync(source,'utf8'));
    lockSummary={present:true,source:source.endsWith('package-lock.json')?'package-lock.json':'node_modules/.package-lock.json',packages:Object.keys(parsed.packages||{}).length,lockfileVersion:parsed.lockfileVersion||null};
  }catch(error){lockSummary={present:false,source:'unreadable',error:String(error?.message||error)}}
}
const pkg=JSON.parse(readFileSync(resolve(root,'package.json'),'utf8'));
const report={
  generatedAt:new Date().toISOString(),
  version:pkg.version,
  node:process.version,
  npm:process.env.npm_config_user_agent||null,
  lock:lockSummary,
  note:'This file is generated after host static gates pass. It contains no secrets.',
};
writeFileSync(resolve(root,'QA_HOST_STATIC_PASS.json'),JSON.stringify(report,null,2)+'\n');
console.log('[qa-host] static gates PASS',JSON.stringify(report));
