import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {PrismaClient} from '@prisma/client';
import {parsePrismaSchemaContract} from './lib/prisma-schema-contract.mjs';
import {applyDatabaseUrl} from './lib/godaddy-db-env.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
applyDatabaseUrl(process.env);
const url=String(process.env.DATABASE_URL||'');
if(!/^mysql:\/\//i.test(url)){console.error('Production DB verification requires normalized MySQL DATABASE_URL.');process.exit(1)}
const schema=readFileSync(path.join(root,'prisma','mysql','schema.prisma'),'utf8');
const contract=parsePrismaSchemaContract(schema);
const prisma=new PrismaClient();
try{
  const dbRows=await prisma.$queryRawUnsafe('SELECT DATABASE() AS dbName');
  const dbName=String(Array.isArray(dbRows)?(dbRows[0]?.dbName||''):'');
  if(!dbName)throw new Error('No MySQL database selected');
  const tableRows=await prisma.$queryRawUnsafe('SELECT TABLE_NAME AS tableName FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE()');
  const names=new Set((Array.isArray(tableRows)?tableRows:[]).map(r=>String(r?.tableName||'')));
  const missingTables=[...contract.keys()].filter(name=>!names.has(name));
  if(missingTables.length)throw new Error(`Required Gus tables are missing after reconciliation: ${missingTables.join(', ')}`);

  const columnRows=await prisma.$queryRawUnsafe('SELECT TABLE_NAME AS tableName, COLUMN_NAME AS columnName, DATA_TYPE AS dataType FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE()');
  const colsByTable=new Map();
  const typeByField=new Map();
  for(const row of Array.isArray(columnRows)?columnRows:[]){const table=String(row?.tableName||''),column=String(row?.columnName||'');if(!table||!column)continue;if(!colsByTable.has(table))colsByTable.set(table,new Set());colsByTable.get(table).add(column);typeByField.set(`${table}.${column}`,String(row?.dataType||'').toLowerCase());}
  const missingColumns=[];
  for(const [model,fields] of contract){const have=colsByTable.get(model)||new Set();for(const field of fields)if(!have.has(field))missingColumns.push(`${model}.${field}`);}
  if(missingColumns.length)throw new Error(`Required Gus columns are missing after reconciliation: ${missingColumns.slice(0,30).join(', ')}${missingColumns.length>30?'…':''}`);

  // Native text-width verification catches production drift that column-presence checks miss.
  // JSON/evidence/log payloads must not silently regress to VARCHAR(191), which produces
  // MySQL "Data too long for column" errors under real traffic.
  const textRanks={tinytext:1,text:2,mediumtext:3,longtext:4};
  const textRequirements=[];
  const modelRx=/\bmodel\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{([\s\S]*?)\n\}/g;
  for(const match of schema.matchAll(modelRx)){
    const [,model,body]=match;
    for(const raw of body.split(/\r?\n/)){
      const line=raw.replace(/\/\/.*$/,'').trim();
      const field=line.match(/^([A-Za-z_][A-Za-z0-9_]*)\s+String\??\s*(.*)$/);
      if(!field)continue;
      const native=field[2].match(/@db\.(Text|MediumText|LongText)\b/i);
      if(native)textRequirements.push({key:`${model}.${field[1]}`,target:native[1].toLowerCase()});
    }
  }
  const badText=[];
  for(const req of textRequirements){
    const actual=typeByField.get(req.key)||'';
    if(!textRanks[actual]||textRanks[actual]<textRanks[req.target])badText.push(`${req.key}: expected ${req.target}, found ${actual||'missing'}`);
  }
  if(badText.length)throw new Error(`MySQL text-width drift detected: ${badText.slice(0,30).join(', ')}${badText.length>30?'…':''}`);

  await prisma.$queryRawUnsafe('SELECT COUNT(*) AS sessionCount FROM `Session`');
  await prisma.$queryRawUnsafe('SELECT 1 FROM `StoreConfig` LIMIT 0');
  await prisma.$queryRawUnsafe('SELECT 1 FROM `JobRun` LIMIT 0');
  await prisma.$queryRawUnsafe('SELECT 1 FROM `AutomationControl` LIMIT 0');
  console.log(`Production DB verification passed for ${dbName}; ${contract.size} Gus tables and scalar-column contracts are readable.`);
}catch(e){console.error('Production DB verification failed:',e instanceof Error?e.message:String(e));process.exitCode=1}finally{await prisma.$disconnect().catch(()=>{})}
