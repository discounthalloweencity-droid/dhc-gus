import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('app');
const exts=['.ts','.tsx','.js','.jsx','.mjs','.cjs','.json'];
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(exts.includes(path.extname(e.name)))files.push(p)}}
walk(root);
const re=/(?:from\s+|import\s*\()(['"])(\.[^'"]+)\1/g;
const missing=[];
function resolves(base){
  if(fs.existsSync(base)&&fs.statSync(base).isFile()) return true;
  for(const ext of exts) if(fs.existsSync(base+ext)) return true;
  if(fs.existsSync(base)&&fs.statSync(base).isDirectory()) for(const ext of exts) if(fs.existsSync(path.join(base,'index'+ext))) return true;
  return false;
}
for(const file of files){const txt=fs.readFileSync(file,'utf8');for(const m of txt.matchAll(re)){const spec=m[2];const base=path.resolve(path.dirname(file),spec);if(!resolves(base))missing.push(`${path.relative(process.cwd(),file)} -> ${spec}`)}}
if(missing.length){console.error('Unresolved relative imports:\n'+missing.join('\n'));process.exit(1)}
console.log(`Relative import resolution passed (${files.length} source files scanned).`);
