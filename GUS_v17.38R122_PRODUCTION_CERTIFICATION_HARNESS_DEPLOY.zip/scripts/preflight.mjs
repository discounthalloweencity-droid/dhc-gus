import {validateEnvironment} from './lib/staging-policy.mjs';
import {existsSync} from 'node:fs';
const report=validateEnvironment(process.env,{requireSecrets:true});
const checks={lockfile:existsSync('package-lock.json'),dependencies:existsSync('node_modules')};
for(const [key,ok] of Object.entries(checks))if(!ok)report.errors.push(key+' missing');
report.ok=report.errors.length===0;console.log(JSON.stringify(report,null,2));if(!report.ok)process.exitCode=1;
