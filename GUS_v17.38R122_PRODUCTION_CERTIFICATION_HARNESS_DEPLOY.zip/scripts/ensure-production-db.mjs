import {spawnSync} from "node:child_process";
import {fileURLToPath} from "node:url";
import path from "node:path";
import {readFileSync} from "node:fs";
import {PrismaClient} from "@prisma/client";
import {applyDatabaseUrl} from "./lib/godaddy-db-env.mjs";

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,"..");
applyDatabaseUrl(process.env);
const url=String(process.env.DATABASE_URL||"");
if(!/^mysql:\/\//i.test(url)){
  console.error("Production database readiness requires a MySQL DATABASE_URL.");
  process.exit(1);
}

// v0.15.88: startup gates only on the database pieces required to open Gus safely.
// Full historical-schema reconciliation is intentionally NOT a startup blocker.
// Legacy/extra tables are allowed and preserved.
const prisma=new PrismaClient();
try{
  const dbRows=await prisma.$queryRawUnsafe("SELECT DATABASE() AS dbName");
  const dbName=String(Array.isArray(dbRows)?(dbRows[0]?.dbName||""):"");
  if(!dbName)throw new Error("Managed MySQL connection did not select a database.");

  const rows=await prisma.$queryRawUnsafe("SELECT TABLE_NAME AS tableName FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE()");
  const names=(Array.isArray(rows)?rows:[]).map(r=>String(r?.tableName||"")).filter(Boolean);
  if(names.length===0){
    console.log(`[gus-runtime] ${dbName} is empty; creating the complete Gus schema safely.`);
    await prisma.$disconnect();
    const cli=path.join(root,"node_modules","prisma","build","index.js");
    const r=spawnSync(process.execPath,[cli,"db","push","--schema",path.join(root,"prisma","mysql","schema.prisma"),"--skip-generate"],{cwd:root,env:process.env,stdio:"inherit"});
    if(r.status!==0)throw new Error("Prisma db push failed while initializing the empty managed MySQL database.");
  } else {
    const recognized=new Set(["Session","StoreConfig","ProductSnapshot","Finding","ChangeLog","JobRun","ActionProposal","OrderProfitSnapshot","GusConversation","GusMessage","AutomationControl"]);
    const recognizedCount=names.filter(n=>recognized.has(n)).length;
    if(recognizedCount===0)throw new Error(`Selected MySQL database ${dbName} contains tables but none are recognized as Gus/DHC tables. Refusing to modify the wrong database.`);
    console.log(`[gus-runtime] Recognized established Gus/DHC database ${dbName}; preserving ${names.length} existing tables.`);
  }
} finally { await prisma.$disconnect().catch(()=>{}); }

const bootstrap=spawnSync(process.execPath,[path.join(root,"scripts","bootstrap-production-db.mjs")],{cwd:root,env:process.env,stdio:"inherit"});
if(bootstrap.status!==0)process.exit(bootstrap.status??1);

// Repair only additive scalar drift and widen known log/JSON columns. This helper never
// drops tables/columns and intentionally tolerates legacy DHC tables. A repair failure is
// logged but does not deadlock the whole admin app; read-only routes have degraded fallbacks.
const additive=spawnSync(process.execPath,[path.join(root,"scripts","repair-production-schema-additive.mjs")],{cwd:root,env:process.env,stdio:"inherit"});
if(additive.status!==0)console.warn(`[gus-runtime] Additive schema repair exited ${additive.status??'null'}; continuing with essential readiness so Gus can open in degraded mode.`);

const verify=new PrismaClient();
try{
  await verify.$queryRawUnsafe('SELECT COUNT(*) AS sessionCount FROM `Session`');
  await verify.$queryRawUnsafe('SELECT 1 FROM `StoreConfig` LIMIT 0');
  await verify.$queryRawUnsafe('SELECT 1 FROM `JobRun` LIMIT 0');
  await verify.$queryRawUnsafe('SELECT 1 FROM `AutomationControl` LIMIT 0');
  await verify.$queryRawUnsafe('SELECT 1 FROM `GusConversation` LIMIT 0');
  await verify.$queryRawUnsafe('SELECT 1 FROM `GusMessage` LIMIT 0');
  await verify.$queryRawUnsafe('SELECT 1 FROM `GusOrchestratorRun` LIMIT 0');
  await verify.$queryRawUnsafe('SELECT 1 FROM `SeasonalManagedArchive` LIMIT 0');
  await verify.$queryRawUnsafe('SELECT 1 FROM `RetailExperiment` LIMIT 0');
  await verify.$queryRawUnsafe('SELECT 1 FROM `ExperimentExposure` LIMIT 0');
  await verify.$queryRawUnsafe('SELECT 1 FROM `OperatorFeedback` LIMIT 0');
  await verify.$queryRawUnsafe('SELECT 1 FROM `TurboCleanupControl` LIMIT 0');
  const schemaText=readFileSync(path.join(root,'prisma','mysql','schema.prisma'),'utf8');
  const expected=[...schemaText.matchAll(/^model\s+([A-Za-z0-9_]+)\s*\{/gm)].map(m=>m[1]);
  const tableRows=await verify.$queryRawUnsafe('SELECT TABLE_NAME AS tableName FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE()');
  const existing=new Set((Array.isArray(tableRows)?tableRows:[]).map(r=>String(r?.tableName||'')));
  const missing=expected.filter(name=>!existing.has(name));
  if(missing.length)throw new Error(`Production engine schema is incomplete after additive bootstrap: ${missing.join(', ')}`);
  console.log(`[gus-runtime] Full engine table readiness passed: ${expected.length}/${expected.length} Prisma model tables present.`);
  console.log("[gus-runtime] Essential production database + Shopify Session + all engine table readiness passed. Full schema audit will run after Gus opens.");
}catch(error){
  console.error("[gus-runtime] Essential production database readiness failed:",error instanceof Error?error.message:String(error));
  process.exitCode=1;
}finally{await verify.$disconnect().catch(()=>{});}
