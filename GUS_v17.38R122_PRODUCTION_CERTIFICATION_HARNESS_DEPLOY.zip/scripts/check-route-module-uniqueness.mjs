import fs from 'node:fs';
const text=fs.readFileSync(new URL('../app/routes.ts', import.meta.url),'utf8');
const refs=[...text.matchAll(/(?:route|index|layout)\([^\n]*?"(routes\/[^"]+)"/g)].map(m=>m[1]);
const seen=new Map();
for(const f of refs) seen.set(f,(seen.get(f)||0)+1);
const dup=[...seen].filter(([,n])=>n>1);
if(dup.length){console.error('Duplicate route module references can collide in React Router route manifests: '+dup.map(([f,n])=>`${f} x${n}`).join(', '));process.exit(1)}
console.log(`Route module uniqueness passed: ${refs.length} configured route modules are unique.`);
