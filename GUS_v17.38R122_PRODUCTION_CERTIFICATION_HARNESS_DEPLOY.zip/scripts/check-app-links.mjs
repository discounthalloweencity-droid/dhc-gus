import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
const routesSource=fs.readFileSync(path.join(root,'app','routes.ts'),'utf8');
const routePaths=new Set([...routesSource.matchAll(/\broute\("([^"]+)"\s*,/g)].map(m=>m[1].replace(/^\//,'')));
const missing=[];
let checked=0;
function walk(dir){
 for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
  const full=path.join(dir,entry.name);
  if(entry.isDirectory())walk(full);
  else if(/\.(?:ts|tsx)$/.test(entry.name)){
   const source=fs.readFileSync(full,'utf8');
   const targets=new Set();
   for(const rx of [/\bto\s*=\s*["'](\/app(?:\/[^"'#?]*)?)/g,/\bto\s*:\s*["'](\/app(?:\/[^"'#?]*)?)/g,/\bhref\s*=\s*["'](\/app(?:\/[^"'#?]*)?)/g])for(const m of source.matchAll(rx))targets.add(m[1]);
   for(const target of targets){
    checked++;
    if(target==='/app'||target==='/app/')continue;
    const child=target.replace(/^\/app\/?/,'').replace(/\/$/,'');
    if(!routePaths.has(child))missing.push(`${path.relative(root,full)} -> ${target}`);
   }
  }
 }
}
walk(path.join(root,'app'));
if(missing.length){
 console.error(`Static app-link contract failed (${missing.length} missing route targets):`);
 for(const row of missing)console.error(`- ${row}`);
 process.exit(1);
}
console.log(`Static app-link contract passed (${checked} /app links checked).`);
