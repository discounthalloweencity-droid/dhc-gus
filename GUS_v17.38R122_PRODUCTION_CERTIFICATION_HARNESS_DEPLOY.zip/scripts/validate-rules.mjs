const ladder = p => p>=19.97 ? Number((19.97 + Math.floor((Math.floor(p)-19)/5)*5).toFixed(2)) : p;
const examples = [[41.97,39.97],[31.97,29.97],[47.97,44.97]];
for (const [input,expected] of examples) {
  const got=ladder(input);
  if(got!==expected) throw new Error(`${input} expected ${expected}, got ${got}`);
}
console.log("DHC price-ladder examples validated.");
