import {readFileSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
const routes='app/routes';
const failures=[];
for(const name of readdirSync(routes).filter(x=>x.endsWith('.tsx')||x.endsWith('.ts'))){
 const file=join(routes,name); const src=readFileSync(file,'utf8');
 const clientStart=src.search(/export\s+default\s+(?:function|class|\()/);
 if(clientStart<0) continue;
 const client=src.slice(clientStart);
 const re=/import\s+(?:type\s+)?\{([^}]+)\}\s+from\s+['\"]([^'\"]+\.server)['\"];?/g;
 let m;
 while((m=re.exec(src))){
   const imports=m[1].split(',').map(x=>x.trim()).filter(Boolean).map(x=>x.replace(/^type\s+/,'').split(/\s+as\s+/).pop().trim());
   for(const symbol of imports){
     if(new RegExp('\\\\b'+symbol.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&')+'\\\\b').test(client)) failures.push(`${file}: client-rendered default export references ${symbol} from server-only module ${m[2]}`);
   }
 }
}
if(failures.length){console.error('CLIENT/SERVER BOUNDARY CHECK FAILED');for(const f of failures)console.error(' - '+f);process.exit(1)}
console.log('Client/server route boundary check passed.');
