import {spawnSync} from "node:child_process";
import {fileURLToPath} from "node:url";
import path from "node:path";
import fs from "node:fs";
import {applyDatabaseUrl} from "./lib/godaddy-db-env.mjs";

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,"..");
const cli=path.join(root,"node_modules","prisma","build","index.js");
const schema=path.join(root,"prisma","mysql","schema.prisma");
if(!fs.existsSync(cli)){console.error("Prisma production generation failed: Prisma CLI missing at "+cli);process.exit(1)}
if(!fs.existsSync(schema)){console.error("Prisma production generation failed: schema missing at "+schema);process.exit(1)}
const env={...process.env};
applyDatabaseUrl(env);
if(!/^mysql:\/\//i.test(String(env.DATABASE_URL||""))) env.DATABASE_URL="mysql://build:build@127.0.0.1:3306/build";
const r=spawnSync(process.execPath,[cli,"generate","--schema",schema],{stdio:"inherit",env,cwd:root});
if(r.error) console.error("Prisma production generation failed to launch: "+r.error.message);
if((r.status??1)!==0) process.exit(r.status??1);

// R109: fail closed if the generated production client is missing any model delegate.
// A table can exist in MySQL while an out-of-date generated Prisma client still
// exposes `undefined` for that model, which previously crashed Gus workers at `.upsert()`.
const schemaText=fs.readFileSync(schema,'utf8');
const modelNames=[...schemaText.matchAll(/^model\s+([A-Za-z0-9_]+)\s*\{/gm)].map(m=>m[1]);
const delegateName=(model)=>model.charAt(0).toLowerCase()+model.slice(1);
try{
  const mod=await import('@prisma/client');
  const client=new mod.PrismaClient();
  const missing=modelNames.map(delegateName).filter(name=>!(name in client));
  await client.$disconnect().catch(()=>{});
  if(missing.length){
    console.error(`[gus-prisma] Generated production client is missing delegates: ${missing.join(', ')}`);
    process.exit(1);
  }
  console.info(`[gus-prisma] Generated production client delegate contract verified: ${modelNames.length}/${modelNames.length} models.`);
}catch(error){
  console.error('[gus-prisma] Could not verify generated production Prisma delegates:',error instanceof Error?error.stack||error.message:error);
  process.exit(1);
}
process.exit(0);
