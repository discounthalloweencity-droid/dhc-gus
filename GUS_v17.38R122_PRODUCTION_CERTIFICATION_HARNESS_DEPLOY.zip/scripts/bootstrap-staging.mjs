import {existsSync,mkdirSync,openSync,closeSync,rmSync,writeFileSync,readFileSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {execFileSync} from 'node:child_process';
import {validateStagingBootstrapEnvironment,stagingDatabasePath} from './lib/staging-policy.mjs';
const env=process.env;
const report=validateStagingBootstrapEnvironment(env);
if(!report.ok)throw new Error(report.errors.join('; '));
const db=stagingDatabasePath(env);
if(existsSync(db))throw new Error('Database already exists; refusing to modify it');
const prisma=resolve('node_modules/prisma/build/index.js');
if(!existsSync(prisma))throw new Error('Install dependencies before initializing staging');
mkdirSync(dirname(db),{recursive:true});
const lock=db+'.bootstrap-lock';
const fd=openSync(lock,'wx',0o600);closeSync(fd);
function run(args){execFileSync(process.execPath,[prisma,...args],{stdio:'inherit',env});}
try{
 if(existsSync(db))throw new Error('Database appeared during bootstrap');
 run(['validate']);
 // Generate a complete initial migration with the installed Prisma engine.
 const name='00000000000000_staging_baseline';
 const migrations=resolve('prisma/staging-baseline/migrations');
 const target=resolve(migrations,name);
 if(existsSync(target))throw new Error('Staging baseline already exists; use a clean source copy');
 const sql=execFileSync(process.execPath,[prisma,'migrate','diff','--from-empty','--to-schema-datamodel','prisma/schema.prisma','--script'],{encoding:'utf8',env});
 if(!sql.trim())throw new Error('Prisma returned an empty baseline');
 mkdirSync(target,{recursive:true});writeFileSync(resolve(target,'migration.sql'),sql,{flag:'wx'});
 // Use a separate schema directory so historical incremental migrations cannot run.
 const original=readFileSync(resolve('prisma/schema.prisma'),'utf8');
 const schemaPath=resolve('prisma/staging-baseline/schema.prisma');
 writeFileSync(schemaPath,original);
 env.DATABASE_URL='file:'+db;
 writeFileSync(resolve(migrations,'migration_lock.toml'),'provider = "sqlite"\n');
 run(['migrate','deploy','--schema',schemaPath]);
 run(['generate','--schema','prisma/schema.prisma']);
 console.log('New staging database initialized with a complete Prisma baseline. Live writes remain disabled.');
}catch(e){
 // Never delete an existing or partially created database automatically.
 console.error('Bootstrap failed. Inspect the staging database and migration history before retrying.');throw e;
}finally{rmSync(lock,{force:true});}
