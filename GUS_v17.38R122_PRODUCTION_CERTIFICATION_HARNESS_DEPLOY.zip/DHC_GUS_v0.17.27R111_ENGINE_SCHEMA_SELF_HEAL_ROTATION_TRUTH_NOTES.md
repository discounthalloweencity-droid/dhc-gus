# GUS v0.17.27 R111 — Engine Schema Self-Heal + Rotation Truth

- Additively creates the four engine tables missing from the established 45-table production database: RetailExperiment, ExperimentExposure, OperatorFeedback, TurboCleanupControl.
- Startup verifies all canonical Prisma model tables before reporting engine database readiness.
- Engine schema health now includes these four models and pauses affected workers before execution if a prerequisite is missing.
- Deployment live-write locks and provider throttling are displayed as BLOCKED / SAFE WAIT rather than ERROR.
- No live-write safety gate is bypassed or auto-enabled.
- R110 71-engine rotation and live Engine Activity window are preserved.
