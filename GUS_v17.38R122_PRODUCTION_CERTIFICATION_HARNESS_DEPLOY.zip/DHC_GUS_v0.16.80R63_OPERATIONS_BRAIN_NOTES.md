# R63 Operations Brain + Engine Watchdog

Operations Brain continuously audits engine/job health instead of assuming code presence equals operation.

## Added
- Engine state: RUNNING / HEALTHY / IDLE / BLOCKED / FAILED / STALLED.
- 24-hour scanned, changed, waiting, failure and throughput telemetry.
- Open Finding and proposal backlog visibility.
- Automatic OPERATIONS findings for unhealthy engines.
- Copyable code-repair packet generator for a failed JobRun. It includes exact engine/job evidence, recent failures, safeguards, regression-test requirement, QA requirements and rollback/operator notes.
- Operations Brain runs from the existing orchestrator every cycle, internally cadence-gated to five minutes.
- R62 Catalog Data Normalizer is now wired into the orchestrator rather than merely existing as a callable service.

## Safety
The repair packet is diagnostic/developer input. It does not let Gus silently rewrite and deploy his own production code. Code changes remain testable/reviewable and cannot bypass Production Write Gate, approvals, reversible ChangeLog behavior or Shopify readback verification.
