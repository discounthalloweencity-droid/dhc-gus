# R69 Conversation Stop & Resolution Guard

- Detects explicit customer stop/resolved/accidental-contact language before normal support intents.
- New terminal service intent: CUSTOMER_CLOSED_NO_ACTION.
- Explicit `do not reply/contact/email me` is silent: no acknowledgement.
- Other clear closure language permits one short closure acknowledgement.
- Existing support case is marked RESOLVED with a durable CUSTOMER_CLOSED_NO_ACTION audit note.
- Closing the conversation never authorizes an order cancellation, refund, return, exchange, or other commerce action.
- A later new customer request can be processed normally; the stop detector does not suppress an active new request.
- Stop handling is applied to both normal inbox processing and replay processing.
