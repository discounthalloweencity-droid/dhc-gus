# Gus v0.17.37 R121 — Sandbox SEO Correctness Recovery

R121 was produced only after extracting R120 into a clean sandbox and treating the prior package as untrusted.

## Problems proven during the clean audit

1. Two live SEO mutations were invalid against the current Shopify Admin GraphQL schema because generic `UserError` was queried for a nonexistent `code` field:
   - product title repair
   - collection title/content repair
2. Search Console fallback evidence (verified snapshot/imported/stale) could still be marked promotion-eligible and authorize autonomous metadata writes.
3. The catalog GSC mapper could keep the first query encountered instead of the highest-impression query for a page.
4. Collection intent normalization contained literal backspace characters instead of word-boundary year matching, so `2026` aliases did not consolidate as intended.
5. Long product titles could be automatically truncated at 100 characters and end on awkward/incomplete wording.
6. Aggressive Organic Growth had a second promotion path that checked margin/availability/delivery but not whether GSC evidence itself was live.
7. Autonomous metadata execution treated missing `promotionEligible` as permission rather than failing closed.
8. Blog publishing defaulted to a new `halloween-guides` blog even though the live store already has `News`, potentially splitting content authority.
9. Blog auto-publish defaulted ON despite draft-generation text saying net-new public content was approval-gated.
10. PageRank/internal-link automation could still consume stale Search Console fallback rows when selecting link opportunities.
11. The deployment package has no package lock and no bundled node_modules. Source tests therefore did not prove a dependency-backed production build.

## R121 corrections

- Removed invalid `code` selection from generic product/collection `UserError` mutations.
- Added `gscPromotionEligibility()`:
  - only `GOOGLE_SEARCH_CONSOLE`
  - status `AVAILABLE`
  - observed within 30 hours
  can authorize autonomous metadata promotion.
- Snapshot, imported, stale and failed-refresh GSC evidence is analysis-only and carries explicit block reasons.
- Aggressive Organic Growth uses the same GSC evidence gate.
- Autonomous metadata executor now requires `promotionEligible === true`; undefined/missing eligibility is blocked.
- Evidence-blocked work stays `BLOCKED`, not `COMPLETED`, so the next fresh workforce pass can requeue it when valid evidence returns.
- Added `strongestGscQueryByPage()` and corrected the best-query selection to the highest-impression query.
- Fixed year alias normalization to `/\b20\d{2}\b/`.
- Added `safeTitleRepairDecision()`:
  - length-only title problems require review
  - any long title requires review instead of blind truncation
  - cleaned titles ending in stopwords/punctuation are not auto-written
  - deterministic short supplier-junk/repetition cleanup can still auto-run.
- Unsafe product titles are routed to `SEO_PRODUCT_TITLE_REVIEW` with `writerReady:false` rather than auto execution.
- Collection content repair preserves the current collection title unless the title cleanup passes the same deterministic AUTO gate.
- Blog default now targets the existing `news` blog.
- `GUS_SEO_BLOG_AUTO_PUBLISH_ENABLED` is now explicit opt-in; default is OFF. Draft generation remains autonomous.
- PageRank/cannibalization automatic internal-link logic now ignores stale/imported/snapshot GSC rows for promotion decisions and records the GSC block reasons.
- Mission-progress cache key advanced to R121 to prevent stale in-process cache shape reuse.

## What was independently checked

### Clean sandbox source/runtime checks
- 332/332 cumulative Node tests passed.
- 690 source files passed relative import resolution.
- 229 route registrations; 0 duplicate route modules.
- 263 internal `/app` link contracts passed.
- 201 buttons, 120 links, 24 anchors, 173 forms, 171 POST forms checked; 0 failures/warnings.
- 388/388 service modules reachable.
- 25/25 engine certification contracts passed.
- 49/49 application/production Prisma models matched.
- TypeScript syntax and source transpilation checks passed (770 transpiled files).

### New R121 regression tests
- stale/imported/snapshot GSC cannot authorize autonomous writes
- fresh live GSC can authorize promotion
- highest-impression query is selected per page
- 2026 collection aliases normalize to the same commercial intent
- long-only title does not auto-truncate
- deterministic short supplier title cleanup remains auto-safe
- product-title/collection-content GraphQL no longer requests invalid `UserError.code`
- blog defaults to News and auto-publish is explicit opt-in
- catalog workforce propagates GSC gate and sends unsafe titles to review
- all autonomous metadata execution requires explicit promotion eligibility
- PageRank automatic internal-link logic cannot act on stale GSC rows

### Live Shopify schema validation
19 core SEO read/write operations were validated against the currently connected Shopify Admin schema after the R121 fixes, including:
- product SEO read/write
- collection SEO read/write
- product title repair
- product description repair
- collection description/content repair
- structured-data metafield set/delete
- blog lookup/create
- article lookup/create/publish
- catalog workforce product/collection reads
- Image Lens read
- review-candidate order read
- PDP QA read
- product media read/alt write

All validated successfully. Three operations/fields are currently valid but deprecated by Shopify and should be migrated in a later maintenance release: `productUpdateMedia`, `Product.featuredImage`, and `ProductVariant.image`.

## What is NOT proven in this sandbox

The ZIP intentionally contains no `node_modules`, and there is no `package-lock.json`. The sandbox cannot reach `registry.npmjs.org` (`EAI_AGAIN`), so exact project dependencies cannot be installed here. Therefore:
- no dependency-backed `tsc --noEmit` claim is made;
- no production React Router bundle/build claim is made;
- `verify:deployment` correctly remains red for missing production secrets, lockfile, dependencies and build.

A true final deployment proof still requires installing the exact dependencies on a networked build host, running the production build/typecheck there, deploying R121, and then validating live runtime/engine actions.
