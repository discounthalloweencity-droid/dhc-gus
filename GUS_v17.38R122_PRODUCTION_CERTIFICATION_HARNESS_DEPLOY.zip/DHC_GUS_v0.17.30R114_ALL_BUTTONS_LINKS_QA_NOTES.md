# DHC Gus v0.17.30 R114 — All Buttons & Links QA

R114 is the cumulative R113 build plus a complete interactive-control contract audit.

## Fixed

The Command Center Manual Work Queue included `fulfillment_control_tower` as a runnable row, but `app._index.tsx` did not handle that intent. The button is now wired to `runFulfillmentControlTower(admin, shop, true)`.

## New release gate

`scripts/check-interactive-controls.mjs` now fails the build for:

- inert buttons,
- permanently disabled buttons,
- POST forms without route actions,
- links/forms targeting missing internal routes,
- empty/placeholder links,
- static command controls with missing action surfaces,
- Operations Control rows without dashboard intent handlers.

## QA results

- 201 buttons checked
- 144 rendered links/anchors checked
- 173 forms checked
- 165 static control values checked
- 18 Operations Control rows checked
- 263 `/app` link targets checked by the existing route-link contract
- 288/288 regression tests passed
- 229 route registrations / 0 duplicate route modules
- 385/385 service modules reachable
- 25/25 engine certification contracts
- 49/49 Prisma models in production parity
- TypeScript syntax check passed

R113 embedded navigation fallback behavior remains intact.
