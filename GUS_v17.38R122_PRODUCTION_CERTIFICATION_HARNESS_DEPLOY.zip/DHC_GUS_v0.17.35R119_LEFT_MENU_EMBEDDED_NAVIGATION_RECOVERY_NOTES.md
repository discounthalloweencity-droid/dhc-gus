# DHC Gus v0.17.35 R119 — Left Menu Embedded Navigation Recovery

## Production defect
Every custom left-rail link used React Router `reloadDocument`. In an embedded Shopify app this forces a full iframe document request. If Shopify refreshes or re-establishes the admin session, the response can redirect toward `admin.shopify.com`, which Shopify correctly refuses to render inside the iframe. Because the full left rail shared this behavior, the entire menu could appear dead or produce `admin.shopify.com refused to connect`.

## Repair
- Removed `reloadDocument` from all internal shell navigation links.
- Left rail now uses React Router client-side navigation.
- Mission card, RUN/STOP footer link, Ask Gus footer link, top Talk to Gus, floating Gus, and Shopify NavMenu internal links use the same embedded-safe navigation path.
- Manual POST actions remain document submissions only where their action route explicitly implements embedded-auth recovery.
- Replaced the old R113/R114 regression assertions that incorrectly required document reloads.
- Added R119 regression coverage proving all pinned routes exist and custom navigation contains no document reloads.

## Expected production behavior
After deployment the header/runtime should report `0.17.35-r119`. Clicking any left-menu item should transition inside Gus without attempting to frame Shopify Admin.
