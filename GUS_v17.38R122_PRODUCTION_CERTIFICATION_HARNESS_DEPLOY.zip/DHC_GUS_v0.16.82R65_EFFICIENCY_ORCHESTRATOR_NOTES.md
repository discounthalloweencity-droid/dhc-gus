# R65 Operations Orchestrator + Efficiency Layer

## Purpose
Stop Gus from repeatedly running expensive engines when their evidence is still fresh, while keeping safety/customer/revenue work ahead of growth and cleanup.

## Added
- Central engine work-lane policy: CRITICAL, CUSTOMER, REVENUE, GROWTH, CLEANUP, LEARNING.
- Per-engine priority, cost class and minimum refresh interval.
- Deterministic work dedupe keys.
- Central freshness decisions before orchestrator steps execute.
- Failed efficiency jobs are eligible for retry rather than being hidden by freshness.
- Bounded exponential-backoff rule for worker/retry consumers.
- Durable `EFFICIENCY:<step>` JobRun evidence for executed/skipped/failed decisions.
- Operations Brain now includes 24-hour efficiency telemetry.
- Operations Center shows redundant runs prevented, efficiency failures and lane-level run/change/failure counts.

## Important
R65 optimizes orchestration around existing engines. It does not claim Shopify webhooks/event-bus ingestion that is not present in the source build, and it does not bypass engine-level write gates, approval queues, readback verification or ChangeLog safety.
