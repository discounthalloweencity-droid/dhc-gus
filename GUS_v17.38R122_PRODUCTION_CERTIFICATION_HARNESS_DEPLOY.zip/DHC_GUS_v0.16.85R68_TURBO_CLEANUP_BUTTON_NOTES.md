# R68 One-Click Turbo Cleanup

- Adds a persistent TurboCleanupControl table.
- Main Gus Command Center now has one-click `⚡ TURBO CLEANUP OFF/ON`.
- Turning Turbo ON persists the setting and immediately queues an orchestrator cycle.
- Worker pool reads the database setting; production no longer requires `GUS_TURBO_CLEANUP=true`.
- Turbo automatically disables when its automatic mission queue reaches zero.
- Main screen shows target workers, queue, measured items/hour and ETA.
- Safety/customer/order/fulfillment priorities remain protected.
