# R67 High-Throughput Worker Pool

- Replaces the orchestrator's fixed RetailMission batch of 10 with an adaptive pool controller.
- NORMAL target concurrency up to 6; TURBO_CLEANUP target up to 12 based on queue depth.
- High recent failure rate reduces worker target.
- Throttle-aware rule is implemented; current source does not expose Shopify GraphQL throttle telemetry into this controller yet, so runtime passes `throttled=false` until that evidence is wired.
- Batch drain scales to 10x target worker slots, bounded at 120 missions per orchestrator pass.
- Turbo isolates catalog/normalization/quality/taxonomy/PDP work while preserving safety/customer/order/fulfillment/risk handlers.
- Operations Center displays queue, running count, target slots, measured completions/hour, evidence-based ETA, and flags large backlog with zero workers as an operational fault.
- No write gate, approval, lease, retry, heartbeat, or mission checkpoint protections are bypassed.

`GUS_TURBO_CLEANUP=true` enables Turbo Cleanup on the host.
