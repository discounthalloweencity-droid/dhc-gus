# R122 Production Certification Harness

R122 is a release-gating build. It adds `/app/production-certification` and a pinned `Production Certification` command-center navigation item.

The certification harness combines artifact/build proof, exact dependency presence/version checks, database SELECT + temporary create/readback/delete, authenticated Shopify reads, Shop backlog/zero-stock proof, Runtime Certification, Engine Certification, Production Proof, SEO certification, persisted certification history, and an optional reversible Shopify canary.

The reversible canary is fail-closed and requires BOTH `GUS_CERTIFICATION_CANARY_ENABLED=true` and `AUTHORITY_LIVE_WRITES_ENABLED=true`, plus the operator must type `RUN SAFE CANARY`. It uses a dedicated DRAFT product, internal collection, and UNPUBLISHED temporary article. Product and collection SEO/content changes are read back and restored; the article is deleted.

R122 also fixes the production build marker so `build/.gus-build.json` records the actual package version instead of stale hard-coded release `0.16.57`. Engine rotation and Engine Certification Lab release IDs now align to R122.

Important: the source ZIP still cannot prove dependency installation or a production React Router build by itself when `package-lock.json`, `node_modules`, or `build/` are absent. R122 intentionally reports those as critical failures instead of hiding them.

## Live Shopify canary proof during R122 QA

The R122 canary operations were executed manually against the connected DHC Shopify store after live schema validation. A dedicated DRAFT certification product and internal certification collection were provisioned. Product title/description/SEO and collection description/SEO were changed, read back exactly, restored, and read back again. An UNPUBLISHED article was created in the existing News blog, verified unpublished, deleted, and confirmed absent. No live storefront product/article was used for the test.
