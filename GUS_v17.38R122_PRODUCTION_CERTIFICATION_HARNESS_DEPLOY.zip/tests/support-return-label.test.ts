import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {isReturnLabelQuestion,returnLabelCustomerMessage,returnLabelEvidenceFromGraphql,returnLabelEvidenceStatus,returnLabelMissingCustomerMessage,type ReturnLabelEvidence} from '../app/services/support-return-label-rules.ts';

test('detects customer requests to resend a return label',()=>{
 for(const message of [
  'Can you resend my return label?',
  'I never received the FedEx label',
  'Where is the return label?',
  "I can't find the shipping label for my return",
 ])assert.equal(isReturnLabelQuestion(message),true,message);
 assert.equal(isReturnLabelQuestion('Where is my Halloween costume shipment?'),false);
});

test('Shopify reverse-delivery evidence verifies label and FedEx tracking',()=>{
 const data={return:{id:'gid://shopify/Return/1',name:'#R1',status:'OPEN',reverseFulfillmentOrders:{nodes:[{id:'gid://shopify/ReverseFulfillmentOrder/1',status:'OPEN',lineItems:{nodes:[{id:'gid://shopify/ReverseFulfillmentOrderLineItem/1',totalQuantity:2}]},reverseDeliveries:{nodes:[{id:'gid://shopify/ReverseDelivery/1',deliverable:{label:{publicFileUrl:'https://cdn.shopify.com/s/files/return-label.pdf',createdAt:'2026-09-22T18:00:00Z',updatedAt:'2026-09-22T18:00:00Z'},tracking:{carrierName:'FedEx',number:'792766804982',url:'https://www.fedex.com/fedextrack/?trknbr=792766804982'}}}]}}]}}};
 const e=returnLabelEvidenceFromGraphql(data);
 assert.ok(e);
 assert.equal(e?.labelUrl,'https://cdn.shopify.com/s/files/return-label.pdf');
 assert.equal(e?.trackingNumber,'792766804982');
 assert.equal(e?.carrier,'FedEx');
 assert.equal(returnLabelEvidenceStatus(e),'LABEL_AND_TRACKING_READY');
});

test('Francesca-style resend message includes verified label and tracking',()=>{
 const e:ReturnLabelEvidence={returnId:'gid://shopify/Return/1',returnName:'#R1',returnStatus:'OPEN',reverseFulfillmentOrderId:'gid://shopify/ReverseFulfillmentOrder/1',reverseDeliveryId:'gid://shopify/ReverseDelivery/1',labelUrl:'https://cdn.shopify.com/s/files/return-label.pdf',labelCreatedAt:null,labelUpdatedAt:null,trackingNumber:'792766804982',trackingUrl:'https://www.fedex.com/fedextrack/?trknbr=792766804982',carrier:'FedEx'};
 const body=returnLabelCustomerMessage(e,'DHC1066','Francesca');
 assert.match(body,/Hi Francesca/);
 assert.match(body,/verified the return label directly from the Shopify return record/i);
 assert.match(body,/792766804982/);
 assert.match(body,/FedEx/);
 assert.match(body,/return-label\.pdf/);
});

test('missing Shopify label fails closed and does not claim a label was sent',()=>{
 const body=returnLabelMissingCustomerMessage('DHC1066',true);
 assert.match(body,/do not see a verified downloadable return label/i);
 assert.match(body,/do not want to send you an incorrect or invented label/i);
 assert.doesNotMatch(body,/I(?:’|')ve resent the label/i);
});

test('customer-service email intercepts return-label requests before generic shipment status',()=>{
 const src=fs.readFileSync('app/services/customer-service-email.server.ts','utf8');
 const labelAt=src.indexOf('const returnLabelRequest=isReturnLabelQuestion');
 const orderStatusAt=src.indexOf('if(isOrderStatusWorkflow(issue))');
 assert.ok(labelAt>0&&orderStatusAt>labelAt);
 assert.match(src,/RETURN_LABEL_RESENT/);
 assert.match(src,/RETURN_LABEL_REVIEW_REQUIRED/);
 assert.match(src,/SHOPIFY_ADMIN_RETURN_LABEL/);
 assert.match(src,/customerReturnTrackingNumber:evidence\.trackingNumber/);
});

test('direct SMTP supports verified return-label attachment MIME while keeping URL allowlist',()=>{
 const src=fs.readFileSync('app/services/support-email-protocol.server.ts','utf8');
 assert.match(src,/multipart\/mixed/);
 assert.match(src,/Content-Disposition: attachment/);
 assert.match(src,/cdn\.shopify\.com/);
 assert.match(src,/MAX_OUTBOUND_ATTACHMENT_BYTES/);
 assert.match(src,/resolveOutboundAttachments/);
});
