import test from 'node:test';import assert from 'node:assert/strict';import {autoTurboDecision} from '../app/services/auto-turbo-rules.ts';
test('auto turbo activates on large backlog',()=>assert.equal(autoTurboDecision({enabled:false,queued:500,itemsPerHour:500,running:2}).enabled,true));
test('auto turbo activates on slow backlog',()=>assert.equal(autoTurboDecision({enabled:false,queued:407,itemsPerHour:80,running:4}).enabled,true));
test('auto turbo activates when backlog workers idle',()=>assert.equal(autoTurboDecision({enabled:false,queued:120,itemsPerHour:0,running:0}).enabled,true));
test('auto turbo turns off at zero',()=>assert.equal(autoTurboDecision({enabled:true,queued:0,itemsPerHour:100,running:2}).enabled,false));
test('normal capacity stays normal',()=>assert.equal(autoTurboDecision({enabled:false,queued:40,itemsPerHour:300,running:2}).enabled,false));
