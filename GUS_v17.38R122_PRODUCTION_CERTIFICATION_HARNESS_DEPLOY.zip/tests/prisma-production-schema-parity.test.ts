import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";

function models(file:string){
  const text=readFileSync(file,"utf8");
  return [...text.matchAll(/^model\s+([A-Za-z0-9_]+)\s*\{/gm)].map(m=>m[1]).sort();
}

test("production MySQL Prisma schema exposes every application model",()=>{
  const app=models("prisma/schema.prisma");
  const prod=models("prisma/mysql/schema.prisma");
  assert.deepEqual(prod,app,"production MySQL schema drifted from application schema");
  for(const name of ["RetailExperiment","ExperimentExposure","OperatorFeedback","TurboCleanupControl"])
    assert.ok(prod.includes(name),`missing production Prisma model ${name}`);
});

test("production generation fails closed on missing Prisma delegates",()=>{
  const source=readFileSync("scripts/prisma-generate-production.mjs","utf8");
  assert.match(source,/Generated production client is missing delegates/);
  assert.match(source,/modelNames\.map\(delegateName\)/);
});
