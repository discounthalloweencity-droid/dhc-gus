import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(p:string)=>fs.readFileSync(p,'utf8');

test('R106 excludes evidence-wait findings from executable mission ETA backlog',()=>{
 const svc=read('app/services/mission-progress.server.ts');
 assert.match(svc,/decision\.lane==='AUTO_FIX'\|\|decision\.lane==='AUTO_VERIFY'\)autoFindings\+=weight/);
 assert.match(svc,/decision\.lane==='EVIDENCE_WAIT'\)evidenceWaitFindings\+=weight/);
 assert.doesNotMatch(svc,/decision\.lane==='EVIDENCE_WAIT'[^\n]*autoFindings\+=weight/);
});

test('R106 mission card exposes evidence wait separately from auto left',()=>{
 const app=read('app/routes/app.tsx');
 assert.match(app,/evidenceWaitFindings/);
 assert.match(app,/auto left · .* evidence · .* review/);
});
