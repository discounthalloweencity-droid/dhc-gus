import test from 'node:test';
import assert from 'node:assert/strict';
import {captureProofSignal,proofSignalSummary} from '../app/services/production-proof-safety.ts';

test('Production Proof signal isolation preserves a healthy read',async()=>{
  const r=await captureProofSignal('healthy',true,async()=>({count:7}),1000);
  assert.equal(r.ok,true);
  assert.deepEqual(r.value,{count:7});
  assert.equal(r.error,null);
});

test('Production Proof signal isolation records an exception instead of throwing',async()=>{
  const r=await captureProofSignal('broken-table',true,async()=>{throw new Error('no such table: RetailMission')},1000);
  assert.equal(r.ok,false);
  assert.equal(r.value,null);
  assert.match(r.error||'',/RetailMission/);
  assert.equal(r.timedOut,false);
});

test('Production Proof signal isolation times out a hung dependency',async()=>{
  const r=await captureProofSignal('hung-query',false,()=>new Promise(()=>{}),25);
  assert.equal(r.ok,false);
  assert.equal(r.timedOut,true);
  assert.match(r.error||'',/timed out/);
});

test('Production Proof signal summary separates critical from noncritical failures',()=>{
  const s=proofSignalSummary([
    {name:'a',critical:true,ok:false,durationMs:2,timedOut:false,error:'bad'},
    {name:'b',critical:false,ok:false,durationMs:3,timedOut:false,error:'bad'},
    {name:'c',critical:true,ok:true,durationMs:1,timedOut:false,error:null},
  ]);
  assert.equal(s.failed,2);
  assert.equal(s.criticalFailed,1);
  assert.deepEqual(s.criticalFailedNames,['a']);
});
