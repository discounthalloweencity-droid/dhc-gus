import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read=(p:string)=>fs.readFileSync(p,'utf8');

test('Shop catalog governor verifies a derived publication candidate instead of failing the whole engine',()=>{
 const s=read('app/services/sales-channel-catalog-governor.server.ts');
 assert.match(s,/publication\(id:\$id\)/);
 assert.match(s,/VERIFIED_CHANNEL_ID_PUBLICATION_LOOKUP/);
 assert.match(s,/shopPublicationVerified:Boolean\(shopPub\)/);
 assert.doesNotMatch(s,/throw new Error\('Shop publication mapping unavailable; governor will not guess a publication ID\.'/);
 assert.match(s,/if\(!shopPub\)\{held\+\+;[\s\S]*?continue;\}/);
});

test('Shop catalog governor can still audit inventory and hidden products without a publication id',()=>{
 const s=read('app/services/sales-channel-catalog-governor.server.ts');
 assert.match(s,/GusChannelGovernorProducts\(\$after:String,\$query:String!\)/);
 assert.doesNotMatch(s,/GusChannelGovernorProducts\(\$after:String,\$query:String!,\$publicationId:ID!\)/);
 assert.match(s,/status:active AND inventory_total:<=0/);
 assert.match(s,/published_status:\$\{shopChannel\.handle\}-hidden/);
});

test('Mission progress uses grouped finding counts instead of loading fifty thousand rows every poll',()=>{
 const s=read('app/services/mission-progress.server.ts');
 assert.match(s,/db\.finding\.groupBy/);
 assert.match(s,/_count:\{_all:true\}/);
 assert.doesNotMatch(s,/take:50000/);
 assert.match(s,/cachedMissionProgress/);
});

test('Mission status tolerates a transient database read by reusing only a fresh verified cache',()=>{
 const app=read('app/routes/app.tsx');
 const api=read('app/routes/api.job-progress.tsx');
 assert.match(app,/GUS_MISSION_DATA_TIMEOUT_MS/);
 assert.match(app,/cachedMissionProgress\(shop,15_000\)/);
 assert.match(api,/cachedMissionProgress\(claims\.shop,15_000\)/);
 assert.match(api,/MISSION_PROGRESS_LIVE_READ_TRANSIENT/);
});

test('R118+ engine rotation release stays aligned with the package release',()=>{
 const s=read('app/services/engine-rotation.server.ts');
 const pkg=JSON.parse(read('package.json'));
 const escaped=String(pkg.version).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 assert.match(s,new RegExp(`ENGINE_ROTATION_RELEASE='${escaped}'`));
 const release=Number(String(pkg.version).match(/-r(\d+)$/)?.[1]||0);
 assert.ok(release>=118);
});
