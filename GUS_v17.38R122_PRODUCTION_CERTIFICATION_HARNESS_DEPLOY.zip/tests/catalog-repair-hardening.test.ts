import test from 'node:test';
import assert from 'node:assert/strict';
import {supplierTitleRisk,cleanLegacyTitle,classifyCatalogIntent} from '../app/services/catalog-repair-rules.ts';

test('flags marketplace-style title patterns seen on live DHC catalog',()=>{
 for(const title of ['NEW PESENAR 80s 90sHip Hop Costume Kit Metal Chain Flat Top Sunglasses Rapper Big','1 Pcs Medieval Gothic Armor Gloves Wide Cuffs Bracers Armor Arm',"NEW Men's 1920s Men's Accessories Outfit Set"]) assert.equal(supplierTitleRisk(title).dirty,true,title);
});

test('cleans supplier tokens without deleting core identity',()=>{
 const cleaned=cleanLegacyTitle('NEW PESENAR 80s 90sHip Hop Costume Kit Metal Chain Flat Top Sunglasses Rapper Big');
 assert.doesNotMatch(cleaned,/PESENAR|^NEW\b/i);
 assert.match(cleaned,/80s|90s|Hip Hop|Costume/i);
});

test('costume intent beats bad product type when title is explicit',()=>{
 const intent=classifyCatalogIntent("Men's Yellow 3D Muscle Superhero Costume - Jumpsuit",[], 'Halloween Masks');
 assert.equal(intent.kind,'COSTUME');
 assert.equal(intent.audience,'MEN');
 assert.equal(intent.collection,"Men's Costumes");
});
