import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const shell=fs.readFileSync('app/routes/app.tsx','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));

test('R119 navigation recovery remains present in later releases',()=>{
  const release=Number(String(pkg.version).match(/-r(\d+)$/)?.[1]||0);
  assert.ok(release>=119);
});

test('all custom left-rail links use embedded client-side navigation',()=>{
  const nav=shell.match(/<nav className="cc-nav"[\s\S]*?<\/nav>/)?.[0]||'';
  assert.match(nav,/to=\{item\.to\} onClick=/);
  assert.doesNotMatch(nav,/reloadDocument/);
});

test('sidebar support links do not force document reloads',()=>{
  for(const target of ['/app/queue','/app/automation','/app/gus']){
    const escaped=target.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    assert.doesNotMatch(shell,new RegExp(`to="${escaped}"[^>]*reloadDocument`));
  }
});

test('every pinned left-menu route exists on disk',()=>{
  const paths=[...shell.matchAll(/pinned\("(\/app[^\"]*)"/g)].map(m=>m[1]);
  assert.ok(paths.length>=54,`expected full pinned navigation, got ${paths.length}`);
  const missing=[];
  for(const route of paths){
    const file=route==='/app'?'app._index.tsx':`app.${route.slice('/app/'.length)}.tsx`;
    if(!fs.existsSync(path.join('app','routes',file))) missing.push({route,file});
  }
  assert.deepEqual(missing,[]);
});

test('Shopify NavMenu links are also client-side inside the embedded app',()=>{
  const block=shell.match(/<NavMenu>[\s\S]*?<\/NavMenu>/)?.[0]||'';
  assert.match(block,/to="\/app"/);
  assert.doesNotMatch(block,/reloadDocument/);
});
