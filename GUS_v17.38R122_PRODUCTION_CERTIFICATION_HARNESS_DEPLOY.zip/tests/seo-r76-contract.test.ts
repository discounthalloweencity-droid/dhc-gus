import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const read=(p:string)=>readFileSync(new URL(`../${p}`,import.meta.url),'utf8');

test('SEO experiment lab uses time checkpoints and not visitor exposures',()=>{
 const s=read('app/services/seo-experiment-lab.server.ts');
 assert.match(s,/SEO_CHECKPOINTS=\[7,14,28,60,90\]/);
 assert.doesNotMatch(s,/ExperimentExposure/);
 assert.match(s,/SEO_BEFORE_AFTER_MATCHED_REFERENCE/);
 assert.match(s,/observational causal evidence/);
 assert.match(s,/r\.mode==='AUTO_APPLIED'/);
});

test('generic experiment evaluator excludes SEO experiments',()=>{
 const s=read('app/services/controlled-experiment.server.ts');
 assert.match(s,/SEOEXP:/);
});

test('learned SEO policy feeds content and strike keyword prioritization',()=>{
 const content=read('app/services/seo-content-intelligence.server.ts');
 const strike=read('app/services/strike-keyword.server.ts');
 assert.match(content,/learnedSeoAdjustment/);
 assert.match(strike,/learnedSeoAdjustment/);
 assert.match(strike,/learningAdjustment/);
});

test('SEO drafting remains internal until explicit governed publication',()=>{
 const factory=read('app/services/seo-blog-draft-factory.server.ts');
 const publisher=read('app/services/seo-blog-publisher.server.ts');
 assert.match(factory,/INTERNAL_DRAFT_ONLY/);
 assert.match(publisher,/requireLiveWrites\(\)/);
 assert.match(publisher,/unresolved fact-risk flag/);
 assert.match(publisher,/title_tag/);
 assert.match(publisher,/description_tag/);
 assert.match(publisher,/duplicateArticle/);
});

test('SEO learning runs after organic growth evidence refresh',()=>{
 const s=read('app/services/orchestrator.server.ts');
 assert.ok(s.indexOf("runStep('organicGrowth'") < s.indexOf("runStep('seoSelfEvolvingDirector'"));
});
