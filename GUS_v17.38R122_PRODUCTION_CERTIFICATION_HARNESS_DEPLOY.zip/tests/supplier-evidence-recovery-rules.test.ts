import test from 'node:test';import assert from 'node:assert/strict';
import {supplierEvidenceState,supplierRecoveryPriority,evidenceCoverage} from '../app/services/supplier-evidence-recovery-rules.ts';
test('blocked when connector is not configured',()=>assert.equal(supplierEvidenceState({enabledLinks:100,freshAvailability:0,freshShipping:0,freshCostFacts:0,configured:false}),'BLOCKED'));
test('healthy requires strong availability and shipping evidence',()=>assert.equal(supplierEvidenceState({enabledLinks:100,freshAvailability:98,freshShipping:85,freshCostFacts:80,configured:true}),'HEALTHY'));
test('partial evidence is stale and prioritized',()=>{const s=supplierEvidenceState({enabledLinks:100,freshAvailability:40,freshShipping:20,freshCostFacts:30,configured:true});assert.equal(s,'STALE');assert.equal(supplierRecoveryPriority(s,40),95)});
test('configured source with no evidence is missing',()=>assert.equal(supplierEvidenceState({enabledLinks:100,freshAvailability:0,freshShipping:0,freshCostFacts:0,configured:true}),'MISSING'));
test('coverage is stable',()=>assert.equal(evidenceCoverage(407,500),81.4));
