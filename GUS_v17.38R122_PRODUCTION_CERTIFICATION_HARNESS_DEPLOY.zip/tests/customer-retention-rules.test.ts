
import {strict as assert} from 'node:assert';
import {customerRetentionDecision} from '../app/services/customer-retention-rules.ts';
let r=customerRetentionDecision({delivered:true,daysSinceDelivery:5,openSupportCases:0,resolvedSupportCases:1,returnCount:0,exchangeCount:0,refundSignals:0,qualitySignals:0,purchases90d:1,repeatPurchases90d:0,daysSinceLastPurchase:5});
assert.equal(r.reviewEligible,true);assert.equal(r.crossSellEligible,true);
r=customerRetentionDecision({delivered:true,daysSinceDelivery:5,openSupportCases:1,resolvedSupportCases:0,returnCount:1,exchangeCount:0,refundSignals:1,qualitySignals:1,purchases90d:1,repeatPurchases90d:0,daysSinceLastPurchase:5});
assert.equal(r.health,'AT_RISK');assert.equal(r.reviewEligible,false);
r=customerRetentionDecision({delivered:true,daysSinceDelivery:10,openSupportCases:0,resolvedSupportCases:0,returnCount:0,exchangeCount:0,refundSignals:0,qualitySignals:0,purchases90d:3,repeatPurchases90d:1,daysSinceLastPurchase:10});
assert.equal(r.health,'LOYAL');
console.log('customer-retention-rules: 3/3 passed');
