
import {strict as assert} from 'node:assert';
import fs from 'node:fs';
const s=fs.readFileSync(new URL('../app/services/product-touch-learning.server.ts',import.meta.url),'utf8');
assert.match(s,/measurementWindowsDays/);assert.match(s,/\[7,14,30,60\]/);assert.match(s,/POSITIVE/);assert.match(s,/NEGATIVE/);assert.match(s,/NEUTRAL_WEAK/);
console.log('product-touch-learning: lifecycle contract present');
