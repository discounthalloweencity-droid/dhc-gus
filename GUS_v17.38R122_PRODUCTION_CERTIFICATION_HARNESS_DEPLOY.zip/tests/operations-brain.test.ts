import test from 'node:test';import assert from 'node:assert/strict';import {classifyEngine,throughput,repairPacket} from '../app/services/operations-brain-rules.ts';
const now=Date.now();
test('flags stale running engine',()=>assert.equal(classifyEngine({running:1,failed:0,waiting:0,lastRunAt:new Date(now-8*3600000),now}),'STALLED'));
test('flags blocked backlog',()=>assert.equal(classifyEngine({running:0,failed:0,waiting:100,now}),'BLOCKED'));
test('flags recent successful engine healthy',()=>assert.equal(classifyEngine({running:0,failed:0,waiting:0,lastSuccessAt:new Date(now-1000),now}),'HEALTHY'));
test('calculates throughput',()=>assert.equal(throughput(100,new Date(now-3600000),new Date(now),now),100));
test('repair packet contains safeguards and regression requirement',()=>{const p=repairPacket({engine:'TEST_ENGINE',error:'boom'});assert.match(p.prompt,/smallest safe code patch/i);assert.match(p.prompt,/regression test/i);assert.match(p.prompt,/Production Write Gate/);});
