import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const helper=fs.readFileSync('app/services/manual-growth-action-auth.server.ts','utf8');
const routes=[
  'app/routes/app.aggressive-organic-growth.tsx',
  'app/routes/app.commerce-editorial.tsx',
  'app/routes/app.weekly-seo-watch.tsx',
  'app/routes/app.authority-growth.tsx',
  'app/routes/app.strike-keywords.tsx',
  'app/routes/app.growth.tsx',
  'app/routes/app.seo-domination.tsx',
];

test('manual growth commands do not have to iframe a Shopify re-auth redirect',()=>{
  assert.match(helper,/error instanceof Response&&error\.status>=300&&error\.status<400/);
  assert.match(helper,/getDhcOfflineAdmin\(\)/);
  assert.match(helper,/SIGNED_OFFLINE_FALLBACK/);
  assert.match(helper,/verifyManualGrowthActionToken/);
});

test('all manual growth routes carry a short-lived signed command token',()=>{
  for(const file of routes){
    const s=fs.readFileSync(file,'utf8');
    assert.match(s,/createManualGrowthActionToken/,`${file} loader must mint token`);
    assert.match(s,/manualGrowthActionContext/,`${file} action must use embedded/offline fallback`);
    assert.match(s,/_gusManualToken/,`${file} forms must submit token`);
  }
});

test('growth engines remain registered in the always-on rotation',()=>{
  const orchestrator=fs.readFileSync('app/services/orchestrator.server.ts','utf8');
  for(const key of ['organicGrowth','commerceEditorial','seoBlogDrafts','seoBlogPublishing','seoSelfEvolvingDirector','turboSeoMonthly','backlinkTurboDaily','strikeKeywords','retailIntelligence','weeklySeo']){
    assert.match(orchestrator,new RegExp(`runStep\\('${key}'`),`${key} must remain in autonomous orchestrator`);
  }
});
