import {strict as assert} from 'node:assert';
import {productQualityRiskDecision} from '../app/services/product-quality-risk-rules.ts';
assert.equal(productQualityRiskDecision({title:'Elegant armor dress',description:'3D printed armor and jewel design flat digital print',notAsDescribedCount:1}).archive,true);
assert.equal(productQualityRiskDecision({title:'Skeleton printed dress',description:'3D printed skeleton graphic polyester dress'}).archive,false);
assert.equal(productQualityRiskDecision({title:'Velvet witch dress',description:'Velvet dress with real lace trim'}).level,'LOW');
assert.equal(productQualityRiskDecision({title:'Costume',description:'polyester',notAsDescribedCount:2,complaintCount:3}).archive,true);
console.log('product-quality-risk: 4/4 passed');
