import test from 'node:test';
import assert from 'node:assert/strict';
import {consumerHealth,producerBackpressure} from '../app/services/retail-mission-consumer-rules.ts';

test('R103 consumer is offline when worker heartbeat is stale',()=>{
  assert.deepEqual(consumerHealth({automationRunning:true,heartbeatAgeMs:120_000,claimableQueued:435,claimedLastCycle:0,completedLastCycle:0,failedLastCycle:0}),{state:'OFFLINE',reason:'CONSUMER_HEARTBEAT_STALE'});
});
test('R103 consumer degrades when claimable queue exists but nothing is claimed',()=>{
  assert.deepEqual(consumerHealth({automationRunning:true,heartbeatAgeMs:10_000,claimableQueued:435,claimedLastCycle:0,completedLastCycle:0,failedLastCycle:0}),{state:'DEGRADED',reason:'CLAIMABLE_BACKLOG_NOT_CLAIMED'});
});
test('R103 backpressures producers instead of growing a broken queue',()=>{
  assert.equal(producerBackpressure({claimableQueued:435,consumerState:'DEGRADED'}),true);
  assert.equal(producerBackpressure({claimableQueued:20,consumerState:'DEGRADED'}),false);
  assert.equal(producerBackpressure({claimableQueued:435,consumerState:'ONLINE'}),false);
});
