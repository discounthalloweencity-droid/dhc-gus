import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeCjFreight,selectCjShipping} from '../app/services/cj-shipping.server.ts';

test('CJ freight normalization accepts audited price and transit bounds',()=>{
 const quotes=normalizeCjFreight({result:true,code:200,requestId:'freight-1',data:[{logisticName:'CJPacket',logisticPrice:8.25,logisticAging:'4-7'}]});
 assert.deepEqual(quotes,[{method:'CJPacket',priceUsd:8.25,minTransitDays:4,maxTransitDays:7,reference:'freight-1'}]);
 const selected=selectCjShipping(quotes,'CJPacket',1,3);assert.equal(selected.minDays,5);assert.equal(selected.maxDays,10);assert.equal(selected.priceUsd,8.25);
});

test('CJ shipping selection refuses unconfigured methods and unverified processing bounds',()=>{
 const q=[{method:'CJPacket',priceUsd:5,minTransitDays:4,maxTransitDays:6,reference:'r'}];
 assert.throws(()=>selectCjShipping(q,'Other',1,2));assert.throws(()=>selectCjShipping(q,'CJPacket',3,1));
});
