import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

test('R101 brain training is deterministic and failure isolated',()=>{
 const src=fs.readFileSync('app/services/brain.server.ts','utf8');
 assert.match(src,/for\(const \[pack,install\] of installers\)/);
 assert.match(src,/BRAIN_TRAINING_PACK/);
 assert.match(src,/status:training\.failed\?"DEGRADED":"COMPLETE"/);
 assert.doesNotMatch(src,/return Promise\.all\(\[ensureBuiltinDhcBrandMerchOperatingPlan/);
});

test('R101 brain still analyzes gaps after isolated training failure',()=>{
 const src=fs.readFileSync('app/services/brain.server.ts','utf8');
 const start=src.indexOf('export async function analyzeKnowledgeGaps');
 const body=src.slice(start,start+3500);
 assert.match(body,/const training=await ensureAllBuiltinTraining/);
 assert.match(body,/db\.errorEvent\.findMany/);
 assert.match(body,/createdOrRefreshed/);
});
