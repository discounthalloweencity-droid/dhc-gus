
import {strict as assert} from 'node:assert';
import {supplierRiskDecision} from '../app/services/supplier-risk-rules.ts';
let r=supplierRiskDecision({observations:1,available:1,outOfStock:0,unknown:0,staleRatio:0,avgDeliveryMaxDays:7,deliveryVariance:0,complaintCount:0,notAsDescribedCount:0,refundCount:0,alternateSources:0,usWarehouse:false,daysToHalloween:30});
assert.equal(r.risk,'UNKNOWN');
r=supplierRiskDecision({observations:20,available:19,outOfStock:1,unknown:0,staleRatio:0,avgDeliveryMaxDays:6,deliveryVariance:1,complaintCount:0,notAsDescribedCount:0,refundCount:0,alternateSources:2,usWarehouse:true,daysToHalloween:30});
assert.equal(r.risk,'LOW');assert.equal(r.action,'PREFERRED');
r=supplierRiskDecision({observations:20,available:8,outOfStock:10,unknown:2,staleRatio:.2,avgDeliveryMaxDays:15,deliveryVariance:5,complaintCount:4,notAsDescribedCount:2,refundCount:3,alternateSources:0,usWarehouse:false,daysToHalloween:15});
assert.ok(['HIGH','CRITICAL'].includes(r.risk));assert.ok(['DIVERSIFY_NOW','PAUSE_SOURCE'].includes(r.action));
r=supplierRiskDecision({observations:10,available:8,outOfStock:2,unknown:0,staleRatio:0,avgDeliveryMaxDays:9,deliveryVariance:2,complaintCount:0,notAsDescribedCount:0,refundCount:0,alternateSources:0,usWarehouse:false,daysToHalloween:40});
assert.equal(r.action,'ADD_BACKUP');
console.log('supplier-risk-rules: 4/4 passed');
