import test from 'node:test';
import assert from 'node:assert/strict';
import {classifySeoExecutionFailure} from '../app/services/seo-execution-recovery-rules.ts';

test('R100 retries transient Shopify failures',()=>{const r=classifySeoExecutionFailure(new Error('HTTP 503 service unavailable'));assert.equal(r.kind,'TRANSIENT_SHOPIFY');assert.equal(r.retryable,true);assert.ok(r.retryAfterMs>0);});
test('R100 quarantines readback mismatches before retry',()=>{const r=classifySeoExecutionFailure('SEO_READBACK_MISMATCH_ROLLBACK_ATTEMPTED');assert.equal(r.kind,'READBACK_MISMATCH');assert.equal(r.retryable,true);assert.ok(r.retryAfterMs>=24*60*60*1000);});
test('R100 does not loop unresolved targets',()=>{const r=classifySeoExecutionFailure('SHOPIFY_TARGET_UNRESOLVED');assert.equal(r.kind,'TARGET_UNRESOLVED');assert.equal(r.retryable,false);});
