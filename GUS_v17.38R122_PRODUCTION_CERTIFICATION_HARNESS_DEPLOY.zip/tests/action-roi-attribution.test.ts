
import {strict as assert} from 'node:assert';
import {actionAttributionDecision} from '../app/services/action-roi-rules.ts';
const w=(orders:number,revenue:number,refunds:number,contribution:number)=>({orders,units:orders,revenue,refunds,estimatedContribution:contribution});
let r=actionAttributionDecision({action:'PRODUCT_TITLE',before:w(5,100,10,30),after:w(8,180,5,70),baselineDays:7,measurementDays:7});
assert.equal(r.verdict,'POSITIVE');assert.equal(r.incrementalContribution,40);
r=actionAttributionDecision({action:'SEO',before:w(8,180,5,70),after:w(3,80,15,20),baselineDays:7,measurementDays:7});
assert.equal(r.verdict,'NEGATIVE');
r=actionAttributionDecision({action:'ARCHIVE',before:w(5,100,0,30),after:w(0,0,0,0),baselineDays:7,measurementDays:7});
assert.equal(r.mode,'PROTECTED');assert.equal(r.incrementalContribution,null);
r=actionAttributionDecision({action:'IMAGE_ALT',before:w(0,0,0,0),after:w(0,0,0,0),baselineDays:7,measurementDays:7});
assert.equal(r.verdict,'INCONCLUSIVE');
console.log('action-roi-attribution: 4/4 passed');
