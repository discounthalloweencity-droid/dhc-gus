
import {strict as assert} from 'node:assert';
import fs from 'node:fs';
const inv=fs.readFileSync(new URL('../app/services/inventory-protection.server.ts',import.meta.url),'utf8');
const q=fs.readFileSync(new URL('../app/services/product-quality-risk.server.ts',import.meta.url),'utf8');
const demand=fs.readFileSync(new URL('../app/services/demand-availability-forecast.server.ts',import.meta.url),'utf8');
const bridge=fs.readFileSync(new URL('../app/services/job-learning-instrumentation.server.ts',import.meta.url),'utf8');
assert.match(inv,/recordProductTouch/);assert.match(q,/recordProductTouch/);assert.match(demand,/recordProductTouch/);
assert.match(bridge,/jobRun\.findMany/);assert.match(bridge,/recordProductTouch/);
console.log('full-engine-learning-instrumentation: contract present');
