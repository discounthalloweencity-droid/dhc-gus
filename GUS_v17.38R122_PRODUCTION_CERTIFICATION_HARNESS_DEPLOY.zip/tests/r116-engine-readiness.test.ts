import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import pkg from '../package.json' with {type:'json'};
import {connectorConfiguration,googleAuthModes} from '../app/services/connection-health-rules.ts';

test('R116 recognizes Google OAuth refresh as real GSC + GA4 configuration',()=>{
 const env={GOOGLE_REFRESH_TOKEN:'r',GOOGLE_CLIENT_ID:'c',GOOGLE_CLIENT_SECRET:'s',GSC_SITE_URL:'sc-domain:discounthalloweencity.com',GA4_PROPERTY_ID:'123'};
 const g=googleAuthModes(env);assert.equal(g.oauthRefresh,true);assert.equal(g.searchConsoleConfigured,true);assert.equal(g.ga4Configured,true);
});

test('R116 recognizes Windsor for GSC without falsely certifying GA4',()=>{
 const env={WINDSOR_API_KEY:'w',WINDSOR_GSC_ACCOUNT:'sc-domain:discounthalloweencity.com'};
 const g=googleAuthModes(env);assert.equal(g.searchConsoleConfigured,true);assert.equal(g.ga4Configured,false);
});

test('R116 uses actual DSers and Syncee production variable names',()=>{
 const c=connectorConfiguration({DSERS_SUPPLIER_FEED_URL:'https://d',SYNCEE_SUPPLIER_FEED_URL:'https://s'});
 assert.equal(c.dsers,true);assert.equal(c.syncee,true);
 const ghost=connectorConfiguration({DSERS_FEED_URL:'https://old',SYNCEE_FEED_URL:'https://old'} as any);
 assert.equal(ghost.dsers,false);assert.equal(ghost.syncee,false);
});

test('R116 exposes the operational dependencies that can make engines look installed but not work',()=>{
 const c=connectorConfiguration({AUTHORITY_CRON_SECRET:'x',GUS_TRACKING_PROVIDER_ENDPOINT:'https://t',EASYPOST_API_KEY:'e',OPENAI_API_KEY:'o',GUS_BACKLINK_OUTREACH_PROVIDER_ENDPOINT:'https://b'});
 assert.equal(c.bridge,true);assert.equal(c.tracking,true);assert.equal(c.easyPost,true);assert.equal(c.openai,true);assert.equal(c.backlinkOutreach,true);
});

test('R116 removes ghost connector variables from runtime certification and engine certification',()=>{
 const runtime=fs.readFileSync(new URL('../app/services/runtime-certification.server.ts',import.meta.url),'utf8');
 const registry=fs.readFileSync(new URL('../app/services/engine-certification-registry.ts',import.meta.url),'utf8');
 for(const ghost of ['DSERS_FEED_URL','SYNCEE_FEED_URL','GOOGLE_SEARCH_CONSOLE_SITE_URL','GUS_GSC_ENDPOINT','GUS_RETAIL_INTELLIGENCE_ENDPOINT','DSERS_REPLACEMENT_FEED_URL','GUS_SUPPORT_IMAP_HOST']){
  assert.equal(runtime.includes(ghost)||registry.includes(ghost),false,`ghost runtime variable remains: ${ghost}`);
 }
 const m=registry.match(/ENGINE_CERTIFICATION_RELEASE='0\.17\.(\d+)-r(\d+)'/); assert.ok(m); assert.ok(Number(m[2])>=116,`expected engine certification release R116+, got ${m?.[0]}`);
});

test('R116 readiness UI consumes one connection-health source of truth',()=>{
 const ui=fs.readFileSync(new URL('../app/routes/app.readiness.tsx',import.meta.url),'utf8');
 assert.match(ui,/health\.configuration\.googleSearchConsole/);
 assert.doesNotMatch(ui,/const providers=/);
});

test('R116 release identity advances',()=>{const release=Number(String(pkg.version).match(/-r(\d+)$/)?.[1]||0);assert.ok(release>=116,`expected R116 or later, got ${pkg.version}`);});
