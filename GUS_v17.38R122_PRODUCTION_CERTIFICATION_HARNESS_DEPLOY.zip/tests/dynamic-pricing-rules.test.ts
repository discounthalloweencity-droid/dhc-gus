
import {strict as assert} from 'node:assert';
import {dynamicPricingDecision} from '../app/services/dynamic-pricing-rules.ts';
const base={productCost:10,supplierShippingCost:3,targetMargin:.30,minimumMargin:.25,shippingThreshold:59,customerShippingCharge:6.99,shippingRevenueMode:'CONSERVATIVE' as const,paymentPercent:.029,paymentFixed:.30,floorPrice:null,daysToHalloween:30,competitorPrice:null,acquisitionCostPerOrder:null};
let r=dynamicPricingDecision({...base,title:"Kids Complete Vampire Costume",productType:'Costumes',currentPrice:18.97,demandState:'STEADY',stockoutRisk:'LOW',supplierRisk:'LOW'});
assert.ok((r.recommendedPrice??0)>=19.97);
r=dynamicPricingDecision({...base,title:"Women's Witch Costume Dress",productType:'Costumes',currentPrice:27.97,demandState:'STEADY',stockoutRisk:'LOW',supplierRisk:'LOW'});
assert.ok((r.recommendedPrice??0)>=29.97);
r=dynamicPricingDecision({...base,title:"Latex Monster Mask",productType:'Masks',currentPrice:14.97,demandState:'STEADY',stockoutRisk:'LOW',supplierRisk:'LOW'});
assert.ok((r.recommendedPrice??0)>=16.97);
r=dynamicPricingDecision({...base,title:"Costume Wig Accessory",productType:'Accessories',currentPrice:14.97,demandState:'STEADY',stockoutRisk:'LOW',supplierRisk:'LOW'});
assert.ok((r.recommendedPrice??0)<29.97);
r=dynamicPricingDecision({...base,title:"Men's Complete Costume",productType:'Costumes',currentPrice:34.97,demandState:'SURGING',stockoutRisk:'HIGH',supplierRisk:'HIGH'});
assert.ok((r.recommendedPrice??0)>=34.97);
assert.equal(r.estimatedContribution,null);
console.log('dynamic-pricing-rules: 6/6 passed');
