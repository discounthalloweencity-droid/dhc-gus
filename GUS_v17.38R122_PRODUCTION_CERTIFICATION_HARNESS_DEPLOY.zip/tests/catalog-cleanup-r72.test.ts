import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeCatalogValue} from '../app/services/catalog-data-normalizer-rules.ts';
import {cleanlinessForProduct,cleanlinessPercent} from '../app/services/catalog-cleanliness-rules.ts';
import {catalogCleanlinessGate} from '../app/services/catalog-cleanliness-gate.server.ts';

test('R72 collapses canonical color and theme synonyms',()=>{
 assert.equal(normalizeCatalogValue('color','Multicolour').canonical,'Multicolor');
 assert.equal(normalizeCatalogValue('theme','TV & Movie').canonical,'Movie & TV');
 assert.equal(normalizeCatalogValue('theme','Movie-Inspired').canonical,'Movie & TV');
 assert.equal(normalizeCatalogValue('theme','Renaissance').canonical,'Medieval & Renaissance');
});

test('R72 flags supplier numeric size for review instead of inventing US size',()=>{
 const r=normalizeCatalogValue('size','120');
 assert.equal(r.status,'REVIEW');
 assert.equal(r.canonical,null);
});

test('R72 cleanliness gate blocks dirty storefront taxonomy',()=>{
 const product={metafields:{nodes:[{key:'color',value:'Multicolour'}]},variants:{nodes:[{selectedOptions:[{name:'Size',value:'120'}]}]}};
 const counts=cleanlinessForProduct(product);
 assert.equal(counts.dirtyColor,1);
 assert.equal(counts.variantSizeIssues,1);
 assert.equal(counts.totalIssues,2);
 assert.equal(catalogCleanlinessGate(product).allowed,false);
 assert.ok(cleanlinessPercent(counts)<100);
});

test('R72 cleanliness gate passes canonical values',()=>{
 const product={metafields:{nodes:[{key:'color',value:'Multicolor'},{key:'theme',value:'Movie & TV'}]},variants:{nodes:[{selectedOptions:[{name:'Size',value:'M'}]}]}};
 assert.equal(catalogCleanlinessGate(product).allowed,true);
});
