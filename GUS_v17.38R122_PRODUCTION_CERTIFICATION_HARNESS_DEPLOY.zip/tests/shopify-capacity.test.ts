import test from 'node:test';import assert from 'node:assert/strict';import {capacityPct,capacityBand,adaptiveConcurrency} from '../app/services/shopify-capacity-rules.ts';
test('capacity percentage derives from Shopify throttle status',()=>assert.equal(capacityPct(800,1000),80));
test('healthy capacity is classified',()=>assert.equal(capacityBand(80,false),'HEALTHY'));
test('throttled overrides percentage',()=>assert.equal(capacityBand(90,true),'THROTTLED'));
test('turbo can use full 12 slots at abundant capacity',()=>assert.equal(adaptiveConcurrency(12,90,false,0),12));
test('low capacity backs turbo down',()=>assert.ok(adaptiveConcurrency(12,20,false,0)<12));
test('throttle aggressively backs off',()=>assert.equal(adaptiveConcurrency(12,90,true,0),3));
test('unknown capacity is conservative',()=>assert.equal(adaptiveConcurrency(12,null,false,0),6));
