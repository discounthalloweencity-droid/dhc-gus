
import {strict as assert} from 'node:assert';
import {runGoldenCases} from '../app/services/golden-evaluation-rules.ts';
const r=runGoldenCases();
assert.ok(r.total>=21);
if(r.failures.length)console.error(JSON.stringify(r.failures,null,2));
assert.equal(r.passed,r.total);
assert.equal(r.score,1);
console.log(`golden-evaluation: ${r.passed}/${r.total} passed`);
