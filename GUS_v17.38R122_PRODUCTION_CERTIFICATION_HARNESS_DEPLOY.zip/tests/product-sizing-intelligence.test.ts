import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {extractProductSizingEvidence,isProductSizingQuestion,productSizingReply,type ProductSizingResult} from '../app/services/product-sizing-intelligence.server.ts';

test('detects pre-sale product sizing questions',()=>{
 assert.equal(isProductSizingQuestion("What's the size guide for the women's Wolverine jumpsuit?"),true);
 assert.equal(isProductSizingQuestion('Do you have this mask in stock?'),false);
});

test('extracts exact product measurement evidence and converts cm to inches without inventing values',()=>{
 const product={
  sizeChart:{value:'<table><tr><th>Size</th><th>Bust</th><th>Waist</th></tr><tr><td>S</td><td>84-88 cm</td><td>66-70 cm</td></tr><tr><td>M</td><td>88-92 cm</td><td>70-74 cm</td></tr></table>'},
  descriptionHtml:'<p>Stretch fabric. Choose the larger size if between sizes.</p>'
 };
 const e=extractProductSizingEvidence(product);
 assert.equal(e.measurementSource,'Size chart');
 assert.match(e.measurementLines.join('\n'),/84-88 cm \(33\.1-34\.6 in\)/);
 assert.match(e.measurementLines.join('\n'),/66-70 cm \(26\.0-27\.6 in\)/);
 assert.match(e.fitNotes.join('\n'),/between sizes/i);
});

test('exact sizing reply labels evidence as product-specific instead of generic',()=>{
 const r:ProductSizingResult={version:'test',status:'EXACT_WITH_MEASUREMENTS',confidence:.99,product:{id:'gid://shopify/Product/1',title:"Women's Wolverine Jumpsuit",handle:'wolverine-jumpsuit',url:'https://discounthalloweencity.com/products/wolverine-jumpsuit',score:.99,availableSizes:['S','M','L'],allSizes:['S','M','L'],priceFrom:39.97},candidates:[],measurementLines:['S | Bust 84-88 cm (33.1-34.6 in) | Waist 66-70 cm (26.0-27.6 in)'],measurementSource:'Size chart',availableSizes:['S','M','L'],allSizes:['S','M','L'],outOfStockSizes:[],fitNotes:[],evidenceWarnings:[],needsCatalogEvidence:false};
 const reply=productSizingReply(r);
 assert.match(reply,/exact live listing/i);
 assert.match(reply,/not a generic women's size chart/i);
 assert.match(reply,/33\.1-34\.6 in/);
 assert.match(reply,/discounthalloweencity\.com\/products\/wolverine-jumpsuit/);
});

test('missing exact measurements fails closed instead of substituting a generic chart',()=>{
 const r:ProductSizingResult={version:'test',status:'EXACT_WITHOUT_MEASUREMENTS',confidence:.95,product:{id:'gid://shopify/Product/1',title:'Exact Jumpsuit',handle:'exact-jumpsuit',url:'https://discounthalloweencity.com/products/exact-jumpsuit',score:.95,availableSizes:['S','M'],allSizes:['S','M'],priceFrom:29.97},candidates:[],measurementLines:[],measurementSource:null,availableSizes:['S','M'],allSizes:['S','M'],outOfStockSizes:[],fitNotes:[],evidenceWarnings:['missing'],needsCatalogEvidence:true};
 const reply=productSizingReply(r);
 assert.match(reply,/does not currently contain verified product-specific body measurements/i);
 assert.match(reply,/don't want to substitute a generic size chart/i);
 assert.doesNotMatch(reply,/Bust 34|Waist 26|Hips 36/);
});

test('customer-service email routes size-guide questions through exact sizing intelligence',()=>{
 const src=fs.readFileSync('app/services/customer-service-email.server.ts','utf8');
 assert.match(src,/productSizingIntelligence/);
 assert.match(src,/PREORDER_EXACT_SIZING_ANSWER/);
 assert.match(src,/PRODUCT_SIZING_EVIDENCE_MISSING/);
});

test('Heather-style Wolverine women jumpsuit question resolves the women-specific live product before quoting sizing',async()=>{
 const {productSizingIntelligence}=await import('../app/services/product-sizing-intelligence.server.ts');
 const searchNodes=[
  {id:'gid://shopify/Product/2',title:'Superhero Jumpsuit Halloween Costume - Adults & Kids, S-2XL',handle:'zawaland-wolverine-deadpool-cosplay-jumpsuit-superhero-boys-girls',status:'ACTIVE',productType:'Costumes',variants:{nodes:[{title:'Wolverine boy / S',price:'24.97',availableForSale:true,inventoryQuantity:10,selectedOptions:[{name:'Size',value:'S'}]}]}},
  {id:'gid://shopify/Product/1',title:"Women's Superhero Jumpsuit Halloween Costume - 5 Styles",handle:'halloween-cosplay-costume-hero-wolverine-movie-deadpool-zentai-suit-jumpsuit-festival-theme-party-role-playing-for-adult-women',status:'ACTIVE',productType:"Women's Costumes",variants:{nodes:[{title:'B142-517 / S',price:'52.97',availableForSale:true,inventoryQuantity:10,selectedOptions:[{name:'Size',value:'S'}]}]}}
 ];
 const detail={id:'gid://shopify/Product/1',title:"Women's Superhero Jumpsuit Halloween Costume - 5 Styles",handle:searchNodes[1].handle,status:'ACTIVE',productType:"Women's Costumes",descriptionHtml:'<p>Sizes S through XL</p>',variants:{nodes:[{title:'B142-517 / S',price:'52.97',availableForSale:true,inventoryQuantity:10,selectedOptions:[{name:'Size',value:'S'}]},{title:'B142-517 / M',price:'52.97',availableForSale:true,inventoryQuantity:10,selectedOptions:[{name:'Size',value:'M'}]}]},sizeChart:null,sizeGuide:null,fitGuide:null,measurements:null,sizing:null,sizeAndFit:null};
 const admin={graphql:async(query:string)=>({ok:true,status:200,headers:{get:()=>null},text:async()=>JSON.stringify({data:query.includes('GusProductSizingDetail')?{product:detail}:{products:{nodes:searchNodes}}})})};
 const r=await productSizingIntelligence(admin,"I'm wondering what the size guide is for your women jumpsuits? Specifically the wolverine jumpsuit");
 assert.equal(r.product?.id,'gid://shopify/Product/1');
 assert.equal(r.status,'EXACT_WITHOUT_MEASUREMENTS');
 assert.deepEqual(r.availableSizes,['S','M']);
 assert.equal(r.needsCatalogEvidence,true);
});
