import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {tuneMysqlPool} from '../scripts/lib/godaddy-db-env.mjs';
const read=(p:string)=>fs.readFileSync(p,'utf8');

test('R108 tunes Prisma MySQL pool conservatively while preserving existing URL',()=>{
  const url=tuneMysqlPool('mysql://u:p@db.example:3306/dhc',{GUS_DB_CONNECTION_LIMIT:'16',GUS_DB_POOL_TIMEOUT_SECONDS:'30',GUS_DB_CONNECT_TIMEOUT_SECONDS:'10'} as any);
  assert.match(url,/connection_limit=16/);assert.match(url,/pool_timeout=30/);assert.match(url,/connect_timeout=10/);
});

test('R108 production uses one global Prisma client',()=>{
  const db=read('app/db.server.ts');
  assert.match(db,/globalThis/);assert.match(db,/__dhcPrisma/);assert.doesNotMatch(db,/NODE_ENV !== ["']production["']/);
});

test('R108 dashboard limits database concurrency and removes non-cancelling Promise.race timeouts',()=>{
  const route=read('app/routes/app._index.tsx');
  assert.match(route,/GUS_DASHBOARD_DB_CONCURRENCY/);assert.match(route,/dashboardConcurrency/);assert.match(route,/task:\(\)=>Promise<T>/);
  assert.doesNotMatch(route,/Promise\.race\(\[task/);
});

test('R108 dedicated worker pauses during full orchestrator cycle instead of colliding for DB connections',()=>{
  const pulse=read('app/services/runtime-orchestrator-pulse.server.ts');
  assert.match(pulse,/state\.inFlight\.has\(shop\).*PAUSED_ORCHESTRATOR_RUNNING/s);
});

test('R108 consumer exposes database pool pressure instead of fake zero queue',()=>{
  const consumer=read('app/services/retail-mission-consumer.server.ts');
  assert.match(consumer,/DATABASE_POOL_BUSY/);assert.match(consumer,/lastGoodThroughput/);
});

test('R108 dashboard shows database pressure as DEGRADED instead of STOPPED/zero proof',()=>{
  const route=read('app/routes/app._index.tsx');
  assert.match(route,/DATABASE_POOL_BUSY/);assert.match(route,/heroState=databaseBusy\?'DEGRADED'/);assert.match(route,/retrying instead of falsely reporting STOPPED/);
});
