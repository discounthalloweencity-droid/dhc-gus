
import {strict as assert} from 'node:assert';
import {forecastDemandAvailability} from '../app/services/demand-availability-forecast-rules.ts';
let r=forecastDemandAvailability({sales1:3,sales3:7,sales7:10,sales14:12,sales30:15,inventoryQuantity:5,tracked:true,availableForSale:true,supplierStatus:'UNKNOWN',supplierQuantity:null,coverageComplete:false,contributionPerUnit:10,daysToHalloween:20});
assert.ok(['SURGING','RISING'].includes(r.demandState));assert.ok(['CRITICAL','HIGH'].includes(r.stockoutRisk));assert.equal(r.action,'FIND_BACKUP_SOURCE');
r=forecastDemandAvailability({sales1:0,sales3:0,sales7:1,sales14:2,sales30:4,inventoryQuantity:100,tracked:true,availableForSale:true,supplierStatus:'AVAILABLE',supplierQuantity:100,coverageComplete:true,contributionPerUnit:8,daysToHalloween:40});
assert.equal(r.stockoutRisk,'LOW');
r=forecastDemandAvailability({sales1:1,sales3:2,sales7:4,sales14:8,sales30:15,inventoryQuantity:0,tracked:true,availableForSale:false,supplierStatus:'OUT_OF_STOCK',supplierQuantity:0,coverageComplete:true,contributionPerUnit:5,daysToHalloween:10});
assert.equal(r.stockoutRisk,'CRITICAL');assert.equal(r.action,'BLOCK_NOW');
r=forecastDemandAvailability({sales1:0,sales3:0,sales7:0,sales14:0,sales30:0,inventoryQuantity:null,tracked:false,availableForSale:true,supplierStatus:'UNKNOWN',supplierQuantity:null,coverageComplete:false,contributionPerUnit:null,daysToHalloween:30});
assert.equal(r.stockoutRisk,'UNKNOWN');
console.log('demand-availability-forecast: 4/4 passed');
