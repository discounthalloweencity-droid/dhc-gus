import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const bootstrap=fs.readFileSync('scripts/bootstrap-production-db.mjs','utf8');
const ensure=fs.readFileSync('scripts/ensure-production-db.mjs','utf8');
const health=fs.readFileSync('app/services/database-schema-health.server.ts','utf8');
const orchestrator=fs.readFileSync('app/services/orchestrator.server.ts','utf8');
for(const table of ['RetailExperiment','ExperimentExposure','OperatorFeedback','TurboCleanupControl']){
  test(`R111 additively repairs ${table}`,()=>{
    assert.ok(bootstrap.includes(table));
    assert.ok(ensure.includes(table));
    assert.ok(health.includes(table));
  });
}
test('R111 verifies every canonical Prisma model table before readiness',()=>{
  assert.match(ensure,/Full engine table readiness passed/);
  assert.match(ensure,/schemaText\.matchAll/);
});
test('R111 classifies safety locks and throttles as blocked rather than engine failures',()=>{
  assert.match(orchestrator,/SAFE_WRITE_LOCK/);
  assert.match(orchestrator,/PROVIDER_THROTTLED/);
  assert.match(orchestrator,/markEngineBlocked/);
  assert.match(orchestrator,/status:'WAITING'/);
});
