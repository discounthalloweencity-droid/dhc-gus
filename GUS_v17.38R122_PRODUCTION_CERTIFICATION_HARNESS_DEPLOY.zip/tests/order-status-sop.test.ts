import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {evaluateShopifyOrderStatus,isOrderStatusWorkflow} from '../app/services/support-order-status-rules.ts';
import {understandCustomerServiceLanguage} from '../app/services/customer-service-language.ts';
import {supportIntent} from '../app/services/customer-service-director-rules.ts';

const base={name:'DHC1167',createdAt:'2026-09-14T12:00:00Z',financialStatus:'PAID',fulfillmentStatus:'FULFILLED',cancelledAt:null};

test('where-is-my-order workflow recognizes shipment status intents',()=>{
 assert.equal(isOrderStatusWorkflow('SHIPMENT_STATUS'),true);
 assert.equal(isOrderStatusWorkflow('NOT_SHIPPED'),true);
 assert.equal(isOrderStatusWorkflow('REFUND'),false);
});

test('direct has-it-shipped questions route into Shopify-first shipment status',()=>{
 for(const message of ['Has it been shipped?','Has my order shipped?','Did my order ship?','Is my order shipped?']){
  const language=understandCustomerServiceLanguage(message);
  assert.equal(language.primaryIntent,'ORDER_STATUS',message);
  assert.equal(supportIntent('OTHER',language.normalized),'SHIPMENT_STATUS',message);
 }
});

test('DHC1167-style fulfilled order answers with real tracking and ETA without escalation',()=>{
 const d=evaluateShopifyOrderStatus({...base,fulfillments:[{id:'f1',status:'SUCCESS',displayStatus:'IN_TRANSIT',createdAt:'2026-09-16T14:00:00Z',estimatedDeliveryAt:'2026-09-26T12:00:00Z'}],tracking:[{status:'SUCCESS',displayStatus:'IN_TRANSIT',fulfillmentCreatedAt:'2026-09-16T14:00:00Z',estimatedDeliveryAt:'2026-09-26T12:00:00Z',company:'YunExpress',number:'YT2626000705271120',url:'https://tracking.example/YT2626000705271120'}]},new Date('2026-09-22T12:00:00Z'));
 assert.equal(d.resolution,'ORDER_SHIPPED_IN_WINDOW');
 assert.equal(d.requiresInvestigation,false);
 assert.match(d.replyBody,/fulfilled on Wednesday, September 16/);
 assert.match(d.replyBody,/Saturday, September 26/);
 assert.match(d.replyBody,/YT2626000705271120/);
 assert.doesNotMatch(d.replyBody,/delivered/i);
});

test('fulfilled is never confused with delivered',()=>{
 const d=evaluateShopifyOrderStatus({...base,fulfillments:[{id:'f1',status:'SUCCESS',displayStatus:'FULFILLED',createdAt:'2026-09-16T14:00:00Z'}],tracking:[{status:'SUCCESS',displayStatus:'FULFILLED',fulfillmentCreatedAt:'2026-09-16T14:00:00Z',number:'ABC123'}]},new Date('2026-09-22T12:00:00Z'));
 assert.equal(d.resolution,'ORDER_SHIPPED_NO_ETA');
 assert.doesNotMatch(d.replyBody,/recorded as delivered/i);
});

test('delivered requires explicit Shopify delivery evidence',()=>{
 const d=evaluateShopifyOrderStatus({...base,fulfillments:[{id:'f1',status:'SUCCESS',displayStatus:'DELIVERED',createdAt:'2026-09-16T14:00:00Z',deliveredAt:'2026-09-20T18:00:00Z'}],tracking:[{status:'SUCCESS',displayStatus:'DELIVERED',fulfillmentCreatedAt:'2026-09-16T14:00:00Z',deliveredAt:'2026-09-20T18:00:00Z',number:'ABC123'}]},new Date('2026-09-22T12:00:00Z'));
 assert.equal(d.resolution,'ORDER_DELIVERED');
 assert.match(d.replyBody,/recorded as delivered/);
});

test('past Shopify ETA opens delivery investigation',()=>{
 const d=evaluateShopifyOrderStatus({...base,fulfillments:[{id:'f1',status:'SUCCESS',displayStatus:'IN_TRANSIT',createdAt:'2026-09-16T14:00:00Z',estimatedDeliveryAt:'2026-09-20T12:00:00Z'}],tracking:[{status:'SUCCESS',displayStatus:'IN_TRANSIT',fulfillmentCreatedAt:'2026-09-16T14:00:00Z',estimatedDeliveryAt:'2026-09-20T12:00:00Z',number:'ABC123'}]},new Date('2026-09-22T12:00:00Z'));
 assert.equal(d.resolution,'ORDER_DELIVERY_OVERDUE');
 assert.equal(d.requiresInvestigation,true);
 assert.equal(d.caseStatus,'OWNER_ACTION_REQUIRED');
});

test('fulfilled with no tracking fails closed to fulfillment review',()=>{
 const d=evaluateShopifyOrderStatus({...base,fulfillments:[{id:'f1',status:'SUCCESS',displayStatus:'FULFILLED',createdAt:'2026-09-16T14:00:00Z'}],tracking:[]},new Date('2026-09-22T12:00:00Z'));
 assert.equal(d.resolution,'ORDER_FULFILLED_NO_TRACKING');
 assert.equal(d.requiresInvestigation,true);
 assert.match(d.replyBody,/no usable tracking number/i);
});

test('delivery exception escalates instead of giving generic tracking answer',()=>{
 const d=evaluateShopifyOrderStatus({...base,fulfillments:[{id:'f1',status:'SUCCESS',displayStatus:'FAILURE',createdAt:'2026-09-16T14:00:00Z'}],tracking:[{status:'SUCCESS',displayStatus:'FAILURE',fulfillmentCreatedAt:'2026-09-16T14:00:00Z',number:'ABC123',events:[{status:'FAILURE',happenedAt:'2026-09-20T12:00:00Z',message:'Delivery exception'}]}]},new Date('2026-09-22T12:00:00Z'));
 assert.equal(d.resolution,'ORDER_DELIVERY_EXCEPTION');
 assert.equal(d.priority,'CRITICAL');
 assert.equal(d.requiresInvestigation,true);
});

test('email workflow is wired to Shopify-first order-status rules',()=>{
 const email=fs.readFileSync('app/services/customer-service-email.server.ts','utf8');
 const support=fs.readFileSync('app/services/support.server.ts','utf8');
 assert.match(email,/evaluateShopifyOrderStatus\(order,new Date\(\)\)/);
 assert.match(email,/shopifySourceOfTruth:true/);
 assert.match(email,/INTERNAL_ORDER_DELIVERY_INVESTIGATION/);
 assert.match(support,/estimatedDeliveryAt/);
 assert.match(support,/displayStatus/);
 assert.match(support,/events\(first:20,reverse:true\)/);
});
