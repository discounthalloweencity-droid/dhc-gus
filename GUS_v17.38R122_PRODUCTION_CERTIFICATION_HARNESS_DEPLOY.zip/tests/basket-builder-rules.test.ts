
import {strict as assert} from 'node:assert';
import {basketCompatibility,buildBasket} from '../app/services/basket-builder-rules.ts';
const costume={productId:'1',title:"Women's Witch Costume Dress",productType:'Costume',tags:['witch','women'],price:34.97,margin:.32,available:true,deliveryMaxDays:7};
const wig={productId:'2',title:"Women's Witch Black Wig",productType:'Wig',tags:['witch','women'],price:14.97,margin:.35,available:true,deliveryMaxDays:6};
const tomb={productId:'3',title:'Graveyard Tombstone',productType:'Outdoor Decor',tags:['graveyard'],price:19.97,margin:.35,available:true,deliveryMaxDays:6};
let r=basketCompatibility(costume,wig);assert.equal(r.eligible,true);assert.equal(r.slot,'WIG');
r=basketCompatibility(costume,tomb);assert.equal(r.eligible,false);
const b=buildBasket(costume,[wig,tomb]);assert.equal(b.items.length,1);assert.equal(b.items[0].item.productId,'2');
console.log('basket-builder-rules: 3/3 passed');
