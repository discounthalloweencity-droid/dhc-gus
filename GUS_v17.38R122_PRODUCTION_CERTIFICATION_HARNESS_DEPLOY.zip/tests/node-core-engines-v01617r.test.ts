import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {Readable,Transform} from 'node:stream';
import {setTimeout as delay} from 'node:timers/promises';

test('Node 22 crypto/buffer primitives required by Gus are available',()=>{const h=crypto.createHash('sha256').update('gus').digest('hex');assert.equal(h.length,64);assert.equal(Buffer.from('gus').toString('base64'),'Z3Vz');});
test('Node stream transform path works',async()=>{const chunks:string[]=[];const upper=new Transform({transform(c,_e,cb){cb(null,String(c).toUpperCase())}});for await(const c of Readable.from(['gu','s']).pipe(upper))chunks.push(String(c));assert.equal(chunks.join(''),'GUS');});
test('Node promise timers resolve',async()=>{await delay(1);assert.ok(true);});
