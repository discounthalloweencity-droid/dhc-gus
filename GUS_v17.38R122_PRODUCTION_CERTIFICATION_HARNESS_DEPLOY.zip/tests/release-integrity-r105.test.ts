import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const server=fs.readFileSync('server.js','utf8');
const identity=fs.readFileSync('app/routes/runtime.identity.tsx','utf8');
const legacyQa=fs.readFileSync('scripts/qa-r37-offline-admin.mjs','utf8');

test('R105 runtime and health release identity are package-derived',()=>{
  const release=Number(String(pkg.version).match(/-r(\d+)$/)?.[1]||0);assert.ok(release>=105,`expected R105+, got ${pkg.version}`);
  assert.match(server,/const HOTFIX_TAG=VERSION/);
  assert.match(identity,/hotfix: pkg\.version/);
});

test('R105 preserves R92 return automation lineage without advertising R92 as current runtime',()=>{
  assert.match(identity,/returnAutomationRelease: "0\.17\.8-r92-return-automation-14-day-scan"/);
  assert.doesNotMatch(server,/const HOTFIX_TAG='0\.17\.8-r92-return-automation-14-day-scan'/);
});

test('R105 default test command includes legacy singular test directory QA',()=>{
  assert.match(pkg.scripts.test,/test\/\*\.qa\.ts/);
  assert.match(fs.readFileSync('test/inventory-protection.qa.ts','utf8'),/inventory-protection-rules\.ts/);
});

test('R105 legacy offline-admin QA validates current runtime identity instead of stale R37 tag',()=>{
  assert.match(legacyQa,/runtime identity derived from package version/);
  assert.doesNotMatch(legacyQa,/check\('R37 runtime tag'/);
});
