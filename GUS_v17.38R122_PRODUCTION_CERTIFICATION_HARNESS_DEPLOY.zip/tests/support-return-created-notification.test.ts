import test from 'node:test';
import assert from 'node:assert/strict';
import {buildReturnCreatedInternalNotice,returnCreatedNoticeLabel} from '../app/services/support-return-created-notification.ts';
import {readFileSync} from 'node:fs';

const sample={
 caseKey:'DHC-SUP-ABC12345',
 orderName:'DHC1143',
 returnId:'gid://shopify/Return/123',
 returnName:'DHC1143-R2',
 customerName:'Karla Lacayo',
 customerEmail:'karla@example.com',
 items:[
  {title:'Child Grey',variant:'Large',reason:'Damaged or defective'},
  {title:'Adult Grey',variant:'Small',reason:'Too big'},
 ],
 replacementSummary:'Child Grey / Large replacement remains active',
 refundSummary:'Not issued — awaiting return/normal resolution workflow',
};

test('successful return notification uses Shopify return name and contains operations summary',()=>{
 const notice=buildReturnCreatedInternalNotice(sample);
 assert.equal(returnCreatedNoticeLabel(sample),'DHC1143-R2');
 assert.equal(notice.subject,'RETURN CREATED — DHC1143 — DHC1143-R2');
 assert.match(notice.message,/Return successfully created in Shopify\./);
 assert.match(notice.message,/Customer: Karla Lacayo/);
 assert.match(notice.message,/• Child Grey — Large — Damaged or defective/);
 assert.match(notice.message,/Replacement: Child Grey \/ Large replacement remains active/);
 assert.match(notice.message,/Refund: Not issued — awaiting return\/normal resolution workflow/);
 assert.match(notice.message,/Gus will monitor return tracking and follow through to receipt\./);
});


test('R91 return-success notification uses canonical internal Gmail and the always-on return monitor is orchestrated',()=>{
 const config=readFileSync(new URL('../app/services/support-email-config.server.ts',import.meta.url),'utf8');
 const orchestrator=readFileSync(new URL('../app/services/runtime-orchestrator-pulse.server.ts',import.meta.url),'utf8');
 assert.match(config,/DEFAULT_INTERNAL_SUPPORT='discounthalloweencity@gmail\.com'/);
 assert.match(orchestrator,/reconcileCustomerReturnTracking/);
});

test('R91 return-success hook is durable and retryable',()=>{
 const email=readFileSync(new URL('../app/services/customer-service-email.server.ts',import.meta.url),'utf8');
 const monitor=readFileSync(new URL('../app/services/support-customer-return-monitor.server.ts',import.meta.url),'utf8');
 assert.match(email,/sendReturnCreatedInternalNotice/);
 assert.match(email,/returnCreatedInternalNoticePayload/);
 assert.match(email,/returnCreatedInternalNoticeSent/);
 assert.match(monitor,/returnCreatedInternalNoticeSent/);
 assert.match(monitor,/sendReturnCreatedInternalNotice/);
 assert.match(monitor,/Gus will continue retrying through the return monitor/);
});
