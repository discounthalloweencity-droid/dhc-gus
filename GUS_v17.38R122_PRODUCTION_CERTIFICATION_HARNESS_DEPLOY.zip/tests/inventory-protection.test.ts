import test from 'node:test';
import assert from 'node:assert/strict';
import {inventoryProtectionDecision} from '../app/services/inventory-protection-rules.ts';

test('blocks tracked zero-stock variants that are configured to continue selling',()=>{
 const d=inventoryProtectionDecision({id:'v1',inventoryQuantity:0,inventoryPolicy:'CONTINUE',inventoryItem:{tracked:true}},undefined);
 assert.equal(d.unsafe,true);assert.equal(d.shouldDeny,true);
});
test('keeps positive tracked inventory sellable',()=>assert.equal(inventoryProtectionDecision({id:'v1',inventoryQuantity:3,inventoryPolicy:'CONTINUE',inventoryItem:{tracked:true}},undefined).unsafe,false));
test('fresh complete supplier availability overrides unmirrored Shopify zero',()=>assert.equal(inventoryProtectionDecision({id:'v1',inventoryQuantity:0,inventoryPolicy:'CONTINUE',inventoryItem:{tracked:true}},{coverageComplete:true,status:'AVAILABLE'}).unsafe,false));
test('confirmed supplier stockout wins',()=>assert.equal(inventoryProtectionDecision({id:'v1',inventoryQuantity:9,inventoryPolicy:'CONTINUE',inventoryItem:{tracked:true}},{coverageComplete:true,status:'OUT_OF_STOCK'}).unsafe,true));
test('untracked unknown inventory is not auto archived',()=>assert.equal(inventoryProtectionDecision({id:'v1',inventoryQuantity:0,inventoryPolicy:'CONTINUE',inventoryItem:{tracked:false}},undefined).unsafe,false));
