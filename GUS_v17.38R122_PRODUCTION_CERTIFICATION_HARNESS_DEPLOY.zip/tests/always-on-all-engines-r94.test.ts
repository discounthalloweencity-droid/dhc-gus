import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(p:string)=>fs.readFileSync(new URL(`../${p}`,import.meta.url),'utf8');

test('R94 version advances',()=>{const p=JSON.parse(read('package.json'));const r=Number(String(p.version).match(/-r(\d+)$/)?.[1]||0);assert.ok(r>=94,`expected R94+, got ${p.version}`)});
test('cold start arms autonomous runtime without browser route',()=>{const s=read('app/shopify.server.ts');assert.match(s,/ensureRuntimeOrchestratorPulse\(DHC_CANONICAL_SHOP\)/);assert.match(s,/runAutonomousHeartbeat\(DHC_CANONICAL_SHOP,'COLD_START'\)/)});
test('external secured heartbeat exists and covers due autonomous engines',()=>{const s=read('app/routes/jobs.orchestrator.tsx');assert.match(s,/AUTHORITY_CRON_SECRET/);assert.match(s,/runAutonomousHeartbeat/);assert.match(s,/ALL_AUTONOMOUS_ENGINES_DUE/)});
test('external heartbeat script rejects preview and uses auth header',()=>{const s=read('scripts/external-engine-heartbeat.mjs');assert.match(s,/preview\\\./);assert.match(s,/authorization:`Bearer \$\{secret\}`/);assert.match(s,/\/jobs\/orchestrator/)});
test('orchestrator contains broad all-engine operating coverage',()=>{const s=read('app/services/orchestrator.server.ts');const steps=[...s.matchAll(/await runStep\('([^']+)'/g)].map(x=>x[1]);assert.ok(steps.length>=65,`only ${steps.length} orchestrated steps`);for(const name of ['inventoryProtection','customerService','organicGrowth','seoSelfEvolvingDirector','orderGuardian','fulfillmentControlTower','retailIntelligence','productionProof'])assert.ok(steps.includes(name),name)});
test('UI states browser is monitor only and preview is not production proof',()=>{const a=read('app/routes/app.automation.tsx');assert.match(a,/Browser required/);assert.match(a,/PREVIEW runtime/);const g=read('app/routes/app.aggressive-organic-growth.tsx');assert.match(g,/Browser required = NO/);assert.match(g,/Run extra growth cycle now/)});
test('runtime snapshot requires external heartbeat for browser independent proof',()=>{const s=read('app/services/runtime-orchestrator-pulse.server.ts');assert.match(s,/BROWSER_INDEPENDENT_PROVEN/);assert.match(s,/EXTERNAL_HEARTBEAT_NOT_PROVEN/);assert.match(s,/PREVIEW_NOT_PRODUCTION_PROOF/)});
