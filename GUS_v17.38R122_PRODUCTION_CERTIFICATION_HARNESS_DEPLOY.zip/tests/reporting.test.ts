import test from 'node:test';
import assert from 'node:assert/strict';
import {summarizeOrders,stockCandidate} from '../app/services/reporting.ts';

test('reporting does not invent contribution when supplier cost is missing',()=>{
 const orders=[{id:'1',date:'2026-09-22',revenue:50,refunds:0,discounts:0,shippingRevenue:0,lines:[{variantId:'v1',productId:'p1',title:'Costume',quantity:1,revenue:50}]}];
 const out=summarizeOrders(orders,new Map(),{percent:.03,fixed:.3});assert.equal(out.contribution,null);assert.equal(out.unknownCostOrders,1);
});

test('stocking requires verified return, lead-time and supplier-stock evidence',()=>{
 const out=stockCandidate({units:20,days:30,unitContribution:10,currentLandedCost:20,stockLandedCost:15});assert.equal(out.status,'REVIEW');
});
