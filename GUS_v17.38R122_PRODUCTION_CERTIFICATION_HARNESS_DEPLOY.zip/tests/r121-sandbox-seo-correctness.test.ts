import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {canonicalCollectionIntentKey,gscPromotionEligibility,safeTitleRepairDecision,strongestGscQueryByPage} from '../app/services/seo-workforce-rules.ts';

const read=(p:string)=>fs.readFileSync(p,'utf8');

test('R121+ runtime identity remains release-derived and current',()=>{
 const pkg=JSON.parse(read('package.json'));
 const release=Number(String(pkg.version).match(/-r(\d+)$/)?.[1]||0);
 assert.ok(release>=121,`expected R121+, got ${pkg.version}`);
 assert.ok(read('app/services/engine-rotation.server.ts').includes(`ENGINE_ROTATION_RELEASE='${pkg.version}'`));
});

test('stale snapshots and imported GSC evidence cannot authorize autonomous SEO writes',()=>{
 const now=new Date('2026-09-24T12:00:00Z');
 assert.equal(gscPromotionEligibility({source:'VERIFIED_GSC_SNAPSHOT',status:'AVAILABLE_VERIFIED_SNAPSHOT',observedAt:'2026-09-15T12:00:00Z'},now).eligible,false);
 assert.equal(gscPromotionEligibility({source:'IMPORTED_GSC_EVIDENCE',status:'IMPORTED_ONLY',observedAt:'2026-09-24T11:00:00Z'},now).eligible,false);
 assert.equal(gscPromotionEligibility({source:'GOOGLE_SEARCH_CONSOLE_STALE',status:'REFRESH_FAILED_USING_STALE_EVIDENCE',observedAt:'2026-09-24T11:00:00Z'},now).eligible,false);
 assert.equal(gscPromotionEligibility({source:'GOOGLE_SEARCH_CONSOLE',status:'AVAILABLE',observedAt:'2026-09-24T11:00:00Z'},now).eligible,true);
 assert.equal(gscPromotionEligibility({source:'GOOGLE_SEARCH_CONSOLE',status:'AVAILABLE',observedAt:'2026-09-22T11:00:00Z'},now).eligible,false);
});

test('page-level GSC mapper selects the strongest query instead of the first row',()=>{
 const page='https://www.discounthalloweencity.com/collections/mens-costumes';
 const map=strongestGscQueryByPage([
  {keys:['2026-09-20','mens party outfits',page],impressions:4,clicks:0,position:18},
  {keys:['2026-09-20','mens halloween costumes',page],impressions:80,clicks:6,position:8},
  {keys:['2026-09-20','adult costumes men',page],impressions:20,clicks:1,position:11},
 ]);
 const v=map.get(page)!;
 assert.equal(v.query,'mens halloween costumes');
 assert.equal(v.impressions,104);
 assert.equal(v.clicks,7);
});

test('collection intent normalizer collapses year aliases but preserves price intent',()=>{
 assert.equal(canonicalCollectionIntentKey("Men's Halloween Costumes 2026"),canonicalCollectionIntentKey("Men's Halloween Costumes"));
 assert.notEqual(canonicalCollectionIntentKey("Men's Halloween Costumes Under $50"),canonicalCollectionIntentKey("Men's Halloween Costumes"));
});

test('long-only supplier-style title is not autonomously truncated',()=>{
 const longTitle='Faux Leather Pirate Hat Brown Captain Hat Vintage Button Masquerade Party Cosplay Costume Hat For Men Women Halloween Props';
 const decision=safeTitleRepairDecision(longTitle);
 assert.equal(decision.status,'REVIEW');
 assert.match(String(decision.reason),/LONG|LENGTH/);
 assert.notEqual(decision.afterTitle,'');
});

test('deterministic short supplier phrase cleanup remains eligible for auto repair',()=>{
 const decision=safeTitleRepairDecision('Hot Sale Ghost Ghost Ghost Halloween Mask');
 assert.equal(decision.status,'AUTO');
 assert.equal(decision.afterTitle,'Ghost Halloween Mask');
});

test('Shopify generic UserError mutations do not request nonexistent code field',()=>{
 const s=read('app/services/shopify-api.server.ts');
 const product=s.match(/mutation GusSeoProductTitle[\s\S]*?`,\{product:\{id,title\}\}\);/)?.[0]||'';
 const collection=s.match(/mutation GusSeoCollectionContent[\s\S]*?`,\{input:\{id,title,descriptionHtml\}\}\);/)?.[0]||'';
 assert.ok(product);assert.ok(collection);
 assert.doesNotMatch(product,/userErrors\{[^}]*\bcode\b/);
 assert.doesNotMatch(collection,/userErrors\{[^}]*\bcode\b/);
 assert.match(product,/userErrors\{field message\}/);
 assert.match(collection,/userErrors\{field message\}/);
});

test('blog publisher defaults to existing News blog and requires explicit auto-publish opt-in',()=>{
 const s=read('app/services/seo-blog-publisher.server.ts');
 assert.match(s,/GUS_SEO_BLOG_HANDLE\|\|'news'/);
 assert.match(s,/GUS_SEO_BLOG_TITLE\|\|'News'/);
 assert.match(s,/GUS_SEO_BLOG_AUTO_PUBLISH_ENABLED\|\|'false'/);
 assert.match(s,/toLowerCase\(\)!=='true'/);
});

test('catalog workforce propagates GSC promotion gate and sends unsafe titles to review',()=>{
 const s=read('app/services/seo-catalog-workforce.server.ts');
 assert.match(s,/gscPromotionEligibility\(gsc\)/);
 assert.match(s,/gscByPage\(promotion\.eligible\?\(gsc\.rows\|\|\[\]\):\[\]\)/);
 assert.match(s,/SEO_PRODUCT_TITLE_REVIEW/);
 assert.match(s,/writerReady:false/);
});


test('all autonomous metadata execution requires explicit fresh promotion eligibility',()=>{
 const exec=read('app/services/autonomous-seo-execution.server.ts');
 assert.match(exec,/evidence\.promotionEligible!==true/);
 assert.match(exec,/status:'BLOCKED',completedAt:null,verifiedAt:null/);
 const growth=read('app/services/aggressive-organic-growth.server.ts');
 assert.match(growth,/gscPromotionEligibility\(gscEvidence\)/);
 assert.match(growth,/promotionBlockReasons:string\[\]=\[\.\.\.gscPromotion\.reasons\]/);
 assert.match(growth,/gscEvidenceAgeHours:gscPromotion\.ageHours/);
});


test('PageRank internal-link automation does not act on stale GSC fallback rows',()=>{
 const s=read('app/services/seo-pagerank-cannibalization.server.ts');
 assert.match(s,/gscPromotionEligibility\(gsc\)/);
 assert.match(s,/aggGsc\(promotion\.eligible\?\(gsc\.rows\|\|\[\]\):\[\]\)/);
});
