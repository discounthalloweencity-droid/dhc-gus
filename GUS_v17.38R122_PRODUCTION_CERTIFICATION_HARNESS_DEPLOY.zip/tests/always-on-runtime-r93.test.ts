import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

test('R93 always-on state resumes unless merchant explicitly stopped Gus',()=>{
 const s=fs.readFileSync('app/services/automation-control.server.ts','utf8');
 assert.match(s,/ensureAlwaysOnAutomation/);
 assert.match(s,/AUTOMATION_STOP/);
 assert.match(s,/AUTOMATION_AUTO_RESUME/);
 assert.match(s,/GUS_ALWAYS_ON_AUTOMATION_ENABLED/);
});

test('R93 turbo has no silent process-memory fallback',()=>{
 const s=fs.readFileSync('app/services/turbo-cleanup-control.server.ts','utf8');
 assert.doesNotMatch(s,/new Map/);
 assert.doesNotMatch(s,/FALLBACK/);
 assert.match(s,/turboCleanupControl\.upsert/);
});

test('R93 heartbeat is server-side, durable and externally callable',()=>{
 const pulse=fs.readFileSync('app/services/runtime-orchestrator-pulse.server.ts','utf8');
 const route=fs.readFileSync('app/routes/jobs.orchestrator.tsx','utf8');
 const startup=fs.readFileSync('app/shopify.server.ts','utf8');
 assert.match(pulse,/AUTONOMOUS_HEARTBEAT/);
 assert.match(pulse,/runAutonomousHeartbeat/);
 assert.match(pulse,/ensureAlwaysOnAutomation/);
 assert.match(route,/AUTHORITY_CRON_SECRET/);
 assert.match(route,/EXTERNAL_CRON/);
 assert.match(startup,/COLD_START/);
});

test('R93 high-throughput worker uses real bounded concurrency',()=>{
 const worker=fs.readFileSync('app/services/retail-mission-worker.server.ts','utf8');
 const pool=fs.readFileSync('app/services/high-throughput-worker-pool.server.ts','utf8');
 assert.match(worker,/Promise\.all\(Array\.from\(\{length:slots\}/);
 assert.match(worker,/workerSlots:slots/);
 assert.match(pool,/snap\.desiredConcurrency/);
});

test('R93 package identity advances',()=>{
 const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));const release=Number(String(pkg.version).match(/-r(\d+)$/)?.[1]||0);assert.ok(release>=93,`expected R93+, got ${pkg.version}`);
});


test('R93 dashboard proves server heartbeat and says browser is not required',()=>{
 const ui=fs.readFileSync('app/routes/app._index.tsx','utf8');
 assert.match(ui,/AUTONOMOUS_HEARTBEAT/);
 assert.match(ui,/Server heartbeat/);
 assert.match(ui,/Browser required: <b>NO<\/b>/);
});
