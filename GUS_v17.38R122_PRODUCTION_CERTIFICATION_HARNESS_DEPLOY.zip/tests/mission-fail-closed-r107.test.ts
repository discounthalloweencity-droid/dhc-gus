import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {catalogSweepProof,gateMissionState} from '../app/services/mission-progress-rules.ts';
import {missionSnapshotFresh,unavailableMission} from '../app/services/mission-progress-status.ts';

const read=(p:string)=>fs.readFileSync(p,'utf8');

test('R107 catalog sweep proof requires a recent complete full-coverage scan',()=>{
  const now=2_000_000_000_000;
  assert.equal(catalogSweepProof({status:'RUNNING',scanned:100,details:{phase:'CATALOG_AUDIT',total:500},finishedAtMs:null,nowMs:now}).verified,false);
  assert.equal(catalogSweepProof({status:'DONE',scanned:499,details:{phase:'COMPLETE',total:500},finishedAtMs:now-1000,nowMs:now}).verified,false);
  assert.equal(catalogSweepProof({status:'DONE',scanned:500,details:{phase:'COMPLETE',total:500},finishedAtMs:now-25*60*60_000,nowMs:now}).verified,false);
  assert.equal(catalogSweepProof({status:'DONE',scanned:500,details:{phase:'COMPLETE',total:500},finishedAtMs:now-1000,nowMs:now}).verified,true);
});

test('R107 ALL CLEAR is gated by evidence wait and verified catalog coverage',()=>{
  assert.equal(gateMissionState({runtimeState:'CLEAR',evidenceWaitFindings:4,catalogVerified:true}),'EVIDENCE');
  assert.equal(gateMissionState({runtimeState:'CLEAR',evidenceWaitFindings:0,catalogVerified:false}),'NOT_VERIFIED');
  assert.equal(gateMissionState({runtimeState:'CLEAR',evidenceWaitFindings:0,catalogVerified:true}),'CLEAR');
});

test('R107 unavailable snapshots can never masquerade as fresh verified mission data',()=>{
  const m=unavailableMission('db timeout');
  assert.equal(m.state,'UNAVAILABLE');
  assert.equal(m.verified,false);
  assert.equal(m.progress,null);
  assert.equal(missionSnapshotFresh(m,Date.now()),false);
});

test('R107 app and signed progress endpoint fail closed instead of returning fake zero backlog',()=>{
  const app=read('app/routes/app.tsx');
  const api=read('app/routes/api.job-progress.tsx');
  assert.match(app,/unavailableMission\("Mission progress query failed or timed out/);
  assert.doesNotMatch(app,/mission progress"[^\n]+state:"CLEAR"[^\n]+progress:100/);
  assert.match(app,/STATUS UNAVAILABLE/);
  assert.match(app,/NOT VERIFIED/);
  assert.match(api,/MISSION_PROGRESS_UNAVAILABLE/);
  assert.match(api,/status:503/);
});

test('R107 catalog worker keeps old findings until a full sweep completes',()=>{
  const scan=read('app/services/scan.server.ts');
  assert.doesNotMatch(scan,/if\(!resumed\)\{\s*await db\.finding\.updateMany\(\{where:\{shop,status:'OPEN'\}/s);
  assert.match(scan,/createdAt:\{lt:job\.startedAt\}/);
  assert.match(scan,/category:\{in:CATALOG_FINDING_CATEGORIES\}/);
  assert.match(scan,/supersededCatalogFindings/);
});

test('R107 version advances',()=>{
  const pkg=JSON.parse(read('package.json'));
  const release=Number(String(pkg.version).match(/-r(\d+)$/)?.[1]||0);assert.ok(release>=107,`expected R107+, got ${pkg.version}`);
});
