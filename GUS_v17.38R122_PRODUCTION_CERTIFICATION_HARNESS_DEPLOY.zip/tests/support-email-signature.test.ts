import test from 'node:test';
import assert from 'node:assert/strict';
import {supportSignature,enforceSupportEmailSignature} from '../app/services/customer-service-persona.ts';

test('Gus canonical signature matches DHC requirement exactly',()=>{
 assert.equal(supportSignature('Gus'),'Thank you,\nGus 👻\nCustomer Support\nDiscount Halloween City');
});

test('assigned support agent name is retained in customer-facing signature',()=>{
 const body=enforceSupportEmailSignature('Hi there,\n\nYour order is on the way.',{supportAgent:'Maya'});
 assert.match(body,/Thank you,\nMaya 👻\nCustomer Support\nDiscount Halloween City$/);
});

test('legacy team-only signature is replaced instead of duplicated',()=>{
 const body=enforceSupportEmailSignature('Hi there,\n\nUpdate.\n\nBest,\nDiscount Halloween City Support',{supportAgent:'Ethan'});
 assert.equal((body.match(/Discount Halloween City/g)||[]).length,1);
 assert.match(body,/Thank you,\nEthan 👻\nCustomer Support\nDiscount Halloween City$/);
 assert.doesNotMatch(body,/Best,/);
});

test('canonical signature enforcement is idempotent',()=>{
 const once=enforceSupportEmailSignature('Hi there,\n\nUpdate.',{supportAgent:'Olivia'});
 const twice=enforceSupportEmailSignature(once,{supportAgent:'Olivia'});
 assert.equal(twice,once);
});

test('emails without an assigned agent default to Gus',()=>{
 const body=enforceSupportEmailSignature('Internal support notification');
 assert.match(body,/Thank you,\nGus 👻\nCustomer Support\nDiscount Halloween City$/);
});
