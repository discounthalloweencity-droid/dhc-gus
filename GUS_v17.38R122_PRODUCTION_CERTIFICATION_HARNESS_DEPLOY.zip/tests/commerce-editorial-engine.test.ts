import test from 'node:test';
import assert from 'node:assert/strict';
import {MASK_EDITORIAL_INTENTS,normalizeMargin,productEditorialEligibility,productEditorialScore,queryDemandScore,queryMatchesIntent} from '../app/services/commerce-editorial-rules.ts';

const latex=MASK_EDITORIAL_INTENTS.find(x=>x.key==='latex-masks')!;
const under25=MASK_EDITORIAL_INTENTS.find(x=>x.key==='masks-under-25')!;
const base={id:'gid://shopify/Product/1',title:'Scary Latex Monster Mask',handle:'scary-latex-monster-mask',productType:'Masks',tags:['Halloween','Latex','Scary'],totalInventory:150,minPrice:19.97,maxPrice:24.97,availableVariants:3,margin:.34,shippingDays:8,qualityRisk:'LOW' as const};

test('normalizes percentage-style margin evidence',()=>{assert.equal(normalizeMargin(34),.34);assert.equal(normalizeMargin(.34),.34);assert.equal(normalizeMargin(null),null);});
test('matches latex intent from verified product language',()=>{assert.equal(productEditorialEligibility(base,latex).eligible,true);});
test('blocks known margin below DHC 25 percent floor',()=>{const out=productEditorialEligibility({...base,margin:.20},latex);assert.equal(out.eligible,false);assert.match(out.reasons.join(' '),/margin below 25%/i);});
test('blocks known delivery beyond 12 days',()=>{const out=productEditorialEligibility({...base,shippingDays:15},latex);assert.equal(out.eligible,false);assert.match(out.reasons.join(' '),/12-day/i);});
test('blocks high product quality risk',()=>{assert.equal(productEditorialEligibility({...base,qualityRisk:'HIGH'},latex).eligible,false);});
test('budget intent requires a qualifying live price',()=>{assert.equal(productEditorialEligibility({...base,minPrice:29.97},under25).eligible,false);assert.equal(productEditorialEligibility(base,under25).eligible,true);});
test('stronger evidence produces a high editorial score',()=>{assert.ok(productEditorialScore(base,latex)>=70);});
test('query classifier recognizes commercial long-tail mask demand',()=>{assert.equal(queryMatchesIntent('best latex halloween masks',latex),true);assert.equal(queryMatchesIntent('witch hats for adults',latex),false);});
test('positions 4-20 with impressions score as a strong opportunity',()=>{assert.ok(queryDemandScore('best halloween masks',400,4,11)>=60);});
