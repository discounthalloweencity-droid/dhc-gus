import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const shell=fs.readFileSync(new URL('../app/routes/app.tsx',import.meta.url),'utf8');
const dashboard=fs.readFileSync(new URL('../app/routes/app._index.tsx',import.meta.url),'utf8');
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url),'utf8'));

test('R113+ runtime identity is present',()=>{
  const release=Number(String(pkg.version).match(/-r(\d+)$/)?.[1]||0);
  assert.ok(release>=113,`expected R113 or later, got ${pkg.version}`);
  assert.match(dashboard,/Runtime 0\.17\.\d+ R\d+/);
});

test('left workspace navigation remains embedded-safe and client-side',()=>{
  assert.match(shell,/<details className=\{`cc-nav-group/);
  assert.match(shell,/<summary className="cc-nav-group-toggle"/);
  assert.match(shell,/to=\{item\.to\} onClick=/);
  assert.doesNotMatch(shell,/to=\{item\.to\} reloadDocument/);
  assert.doesNotMatch(shell,/setOpenGroups/);
});

test('operations control submits even when stale dashboard running state disagrees',()=>{
  assert.match(dashboard,/<Form method="post" reloadDocument><button type="submit" className="authority-button authority-primary" name="intent" value=\{r\.id\}>/);
  assert.doesNotMatch(dashboard,/disabled=\{!d\.operations\.running\}/);
});

test('retryable dashboard actions do not consume the original request body',()=>{
  assert.match(dashboard,/const authRequest=request\.clone\(\)/);
  assert.match(dashboard,/const formRequest=request\.clone\(\)/);
  assert.match(dashboard,/authenticate\.admin\(authRequest\)/);
  assert.match(dashboard,/formRequest\.formData\(\)/);
});
