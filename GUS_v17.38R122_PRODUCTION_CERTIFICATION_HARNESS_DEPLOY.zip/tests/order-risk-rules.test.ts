
import {strict as assert} from 'node:assert';
import {orderRiskDecision} from '../app/services/order-risk-rules.ts';
const base={orderValue:75,itemQuantity:2,distinctItems:2,ageMinutes:10,financialStatus:'PAID',fulfillmentStatus:'UNFULFILLED',cancelled:false,priorRefundSignals:0,priorSupportSignals:0,duplicateOrderSignals:0,contributionAfterAcquisition:20,fulfillmentRisk:null};
let r=orderRiskDecision(base);assert.equal(r.action,'ALLOW');
r=orderRiskDecision({...base,orderValue:650,itemQuantity:12,duplicateOrderSignals:1,priorRefundSignals:2,contributionAfterAcquisition:-20,fulfillmentRisk:'AT_RISK'});assert.equal(r.action,'MANUAL_REVIEW');assert.ok(['HIGH','CRITICAL'].includes(r.risk));
r=orderRiskDecision({...base,duplicateOrderSignals:1});assert.ok(['WATCH','MANUAL_REVIEW'].includes(r.action));
r=orderRiskDecision({...base,cancelled:true});assert.equal(r.action,'IGNORE');
console.log('order-risk-rules: 4/4 passed');
