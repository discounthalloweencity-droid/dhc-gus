import test from 'node:test';import assert from 'node:assert/strict';
import {normalizeCatalogValue,normalizeTags,productTypeMismatch} from '../app/services/catalog-data-normalizer-rules.ts';
test('unwraps malformed scalar arrays',()=>{const a=normalizeCatalogValue('size','["S"]');assert.equal(a.status,'NORMALIZE');assert.equal(a.canonical,'S');});
test('canonicalizes one size',()=>{assert.equal(normalizeCatalogValue('size','["one size"]' ).canonical,'One Size');});
test('canonicalizes adult',()=>{assert.equal(normalizeCatalogValue('age_group','["Adult"]').canonical,'Adult');});
test('does not invent supplier size mapping',()=>{assert.equal(normalizeCatalogValue('size','120').status,'REVIEW');});
test('deduplicates and removes supplier-only tags',()=>{const r=normalizeTags(['Kids','kids','CJdropshipping','["Retro"]']);assert.deepEqual(r.tags,['Kids','Retro']);});
test('flags costume typed as mask',()=>{assert.equal(productTypeMismatch({title:'Women Superhero Jumpsuit Costume',productType:'Halloween Masks'}).mismatch,true);});
