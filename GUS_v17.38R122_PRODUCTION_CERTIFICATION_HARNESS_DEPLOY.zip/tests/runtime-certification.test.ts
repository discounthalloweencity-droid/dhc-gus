import test from 'node:test';import assert from 'node:assert/strict';
import {evaluateRuntimeCertification,stuckRuntime} from '../app/services/runtime-certification-rules.ts';
test('certifies only when all signals pass',()=>{const r=evaluateRuntimeCertification([{key:'a',label:'a',ok:true,critical:true,evidence:'ok',repair:'none'}]);assert.equal(r.verdict,'CERTIFIED');assert.equal(r.score,100)});
test('critical runtime failure blocks certification',()=>{const r=evaluateRuntimeCertification([{key:'cron',label:'cron',ok:false,critical:true,evidence:'stale',repair:'cron'}]);assert.equal(r.verdict,'BLOCKED');assert.ok(r.score<100)});
test('optional connector gap degrades but does not masquerade as certified',()=>{const r=evaluateRuntimeCertification([{key:'cj',label:'CJ',ok:false,critical:false,evidence:'missing',repair:'connect'}]);assert.equal(r.verdict,'DEGRADED')});
test('missing scheduler heartbeat is stuck when automation is on',()=>{const r=stuckRuntime({automationRunning:true,orchestratorAgeMs:null,pending:1,running:0,completed60m:0,changeLogs60m:0,oldestPendingAgeMs:3600000});assert.equal(r.stuck,true)});
test('large idle backlog raises stuck alarm',()=>{const r=stuckRuntime({automationRunning:true,orchestratorAgeMs:60000,pending:200,running:0,completed60m:0,changeLogs60m:0,oldestPendingAgeMs:3600000});assert.equal(r.stuck,true)});
test('recent work evidence remains healthy',()=>{const r=stuckRuntime({automationRunning:true,orchestratorAgeMs:60000,pending:200,running:2,completed60m:12,changeLogs60m:3,oldestPendingAgeMs:3600000});assert.equal(r.stuck,false)});
