
import {strict as assert} from 'node:assert';
import {directorPriority,allocateDirectorFocus} from '../app/services/autonomous-retail-director-rules.ts';
let r=directorPriority({source:'ORDER_RISK_INTELLIGENCE',signalType:'ORDER_LOSS_RISK',severity:'CRITICAL',score:90,confidence:.9,metric:'CRITICAL'});
assert.equal(r.domain,'LOSS_PREVENTION');assert.ok(r.priority>=80);
r=directorPriority({source:'BASKET_BUILDER_INTELLIGENCE',signalType:'COMPLETE_THE_LOOK_EDGE',severity:'INFO',score:70,confidence:.8});
assert.equal(r.domain,'BASKET_GROWTH');
const rows=Array.from({length:10},(_,i)=>({source:'CONTENT_QUALITY_ENGINE',signalType:'PDP_CONTENT_QUALITY',severity:i<4?'HIGH':'MEDIUM',score:80-i,confidence:.9,entityId:String(i)}));
const f=allocateDirectorFocus(rows,12);assert.ok(f.length<=3);
console.log('autonomous-retail-director-rules: 3/3 passed');
