import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const route=fs.readFileSync(new URL('../app/routes/app.seo-domination.tsx',import.meta.url),'utf8');

test('SEO Domination isolates subsystem loader failures instead of failing the entire route',()=>{
  assert.match(route,/async function settled<[^>]+>\(/);
  assert.match(route,/settled\('SEO dashboard'/);
  assert.match(route,/settled\('Turbo SEO'/);
  assert.match(route,/settled\('Backlinks'/);
  assert.match(route,/settled\('SEO Command Center'/);
  assert.match(route,/settled\('Self-learning'/);
  assert.match(route,/seoHealth/);
  assert.match(route,/DEGRADED — PAGE STILL RUNNING/);
});

test('SEO Domination actions return an in-page error instead of throwing a route-level 503',()=>{
  assert.match(route,/catch\(error\).*ACTION FAILED/s);
  assert.match(route,/return \{ok:false,error:error instanceof Error\?error\.message:String\(error\)\}/);
});
