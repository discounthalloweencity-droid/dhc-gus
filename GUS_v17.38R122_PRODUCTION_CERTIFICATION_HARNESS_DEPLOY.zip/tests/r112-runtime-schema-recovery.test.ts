import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const supplier=fs.readFileSync('app/services/supplier-evidence-recovery.server.ts','utf8');
const brain=fs.readFileSync('app/services/brain.server.ts','utf8');
const mysqlSchema=fs.readFileSync('prisma/mysql/schema.prisma','utf8');
const repair=fs.readFileSync('scripts/repair-production-schema-additive.mjs','utf8');
const ensure=fs.readFileSync('scripts/ensure-production-db.mjs','utf8');
const server=fs.readFileSync('server.js','utf8');

function modelBlock(schema:string,name:string){
  const m=schema.match(new RegExp(`model\\s+${name}\\s*\\{([\\s\\S]*?)\\n\\}`));
  assert.ok(m,`model ${name} must exist`);
  return m[1];
}

test('R112 Supplier Evidence Recovery uses canonical JobRun.jobType',()=>{
  assert.match(supplier,/where:\{shop,jobType:'SUPPLIER_EVIDENCE_RECOVERY',status:'DONE'\}/);
  assert.match(supplier,/data:\{shop,jobType:'SUPPLIER_EVIDENCE_RECOVERY',status:'RUNNING'/);
  assert.doesNotMatch(supplier,/\btype:'SUPPLIER_EVIDENCE_RECOVERY'/);
});

test('R112 Gus Learning Brain never sends transient evidence into BrainQuestion Prisma data',()=>{
  assert.match(brain,/const \{evidence,\.\.\.question\}=input;/);
  assert.match(brain,/evidenceJson:JSON\.stringify\(evidence\)/);
  assert.doesNotMatch(brain,/create:\{shop,questionKey,\.\.\.input,evidenceJson/);
});

test('R112 production ExecutiveWorkItem.title is LONGTEXT and additive repair widens existing installs',()=>{
  const executive=modelBlock(mysqlSchema,'ExecutiveWorkItem');
  assert.match(executive,/\n\s*title\s+String\s+@db\.LongText\b/);
  assert.match(repair,/'ExecutiveWorkItem\.title'/);
});

test('R112 startup runs the guarded additive schema repair before Gus opens',()=>{
  assert.match(server,/ensure-production-db\.mjs/);
  assert.match(ensure,/repair-production-schema-additive\.mjs/);
});
