import test from 'node:test';
import assert from 'node:assert/strict';
import {evaluateAvailability,sourceAvailability,checkoutPlan} from '../app/services/availability-rules.ts';

test('availability refuses to call unknown evidence sellable',()=>{
 const now=new Date('2026-09-22T00:00:00Z');
 assert.equal(evaluateAvailability([],now,12,24),'UNKNOWN');
 assert.equal(sourceAvailability(['OUT_OF_STOCK','UNKNOWN'] as any),'UNKNOWN');
});

test('checkout blocks verified stockout instead of continuing to sell',()=>{
 const plan=checkoutPlan({status:'OUT_OF_STOCK',tracked:true,policy:'DENY',inventoryQuantity:0,ownedByDropshipper:true,coverageComplete:true});
 assert.equal(plan.action,'KEEP_EXISTING_POLICY');
});
