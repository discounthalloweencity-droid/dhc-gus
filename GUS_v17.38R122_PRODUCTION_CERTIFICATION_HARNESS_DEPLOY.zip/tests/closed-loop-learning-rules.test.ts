
import {strict as assert} from 'node:assert';
import {evaluateOutcome,learnedPriorityAdjustment} from '../app/services/closed-loop-learning-rules.ts';
let r=evaluateOutcome({domain:'PROFIT',baseline:100,after:112,higherIsBetter:true,confidence:.9,sampleAdequate:true});assert.equal(r.verdict,'POSITIVE');assert.ok(learnedPriorityAdjustment(r.verdict,r.weight)>0);
r=evaluateOutcome({domain:'LOSS_PREVENTION',baseline:20,after:10,higherIsBetter:false,confidence:.9,sampleAdequate:true});assert.equal(r.verdict,'POSITIVE');
r=evaluateOutcome({domain:'PROFIT',baseline:null,after:10,higherIsBetter:true,confidence:.9,sampleAdequate:false});assert.equal(r.verdict,'INSUFFICIENT_EVIDENCE');assert.equal(r.weight,0);
console.log('closed-loop-learning-rules: 3/3 passed');
