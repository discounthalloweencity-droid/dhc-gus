import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {ENGINE_CERTIFICATION_DEFINITIONS} from '../app/services/engine-certification-registry.ts';
import {classifyEngineCertification,summarizeCertification} from '../app/services/engine-certification-rules.ts';

const layer=(state:'PASS'|'FAIL'|'WARN'|'UNVERIFIED'|'SKIPPED',detail='fixture')=>({state,detail});

test('every integrated feature has exactly one engine certification contract',()=>{
 const source=fs.readFileSync(path.resolve('app/services/feature-registry.ts'),'utf8');
 const integrated=[...source.matchAll(/\{key:'([^']+)'[^\n]*status:'INTEGRATED'/g)].map(x=>x[1]).sort();
 const keys=ENGINE_CERTIFICATION_DEFINITIONS.map(x=>x.key).sort();
 assert.deepEqual(keys,integrated);
 assert.equal(new Set(keys).size,keys.length);
});

test('certification contracts point at real modules and required exports',()=>{
 for(const d of ENGINE_CERTIFICATION_DEFINITIONS){
  for(const file of d.modules){
   const full=path.resolve('app/services',file);assert.equal(fs.existsSync(full),true,`${d.key} missing ${file}`);
   const source=fs.readFileSync(full,'utf8');
   for(const symbol of d.requiredExports[file]||[])assert.match(source,new RegExp(`\\b${symbol}\\b`),`${d.key}/${file} missing ${symbol}`);
  }
 }
});

test('missing provider or execution proof cannot be mislabeled certified',()=>{
 const verdict=classifyEngineCertification({runtimeLoad:layer('PASS'),safeProbe:layer('PASS'),provider:layer('UNVERIFIED'),execution:layer('UNVERIFIED')});
 assert.equal(verdict,'LOGIC_PASS_PROVIDER_UNVERIFIED');
});

test('any failed runtime layer fails certification',()=>{
 for(const slot of ['runtimeLoad','safeProbe','provider','execution'] as const){
  const x:any={runtimeLoad:layer('PASS'),safeProbe:layer('PASS'),provider:layer('PASS'),execution:layer('PASS')};x[slot]=layer('FAIL');assert.equal(classifyEngineCertification(x),'FAILED');
 }
});

test('pure deterministic engines can certify from real fixture execution',()=>{
 assert.equal(classifyEngineCertification({runtimeLoad:layer('PASS'),safeProbe:layer('PASS'),provider:layer('UNVERIFIED'),execution:layer('PASS'),pureLogic:true}),'CERTIFIED');
});

test('warnings produce degraded rather than false-green certification',()=>{
 assert.equal(classifyEngineCertification({runtimeLoad:layer('PASS'),safeProbe:layer('PASS'),provider:layer('PASS'),execution:layer('WARN')}),'DEGRADED');
});

test('summary preserves all certification states',()=>{
 const s=summarizeCertification([{verdict:'CERTIFIED'},{verdict:'FAILED'},{verdict:'DEGRADED'},{verdict:'LOGIC_PASS_PROVIDER_UNVERIFIED'}]);
 assert.equal(s.total,4);assert.equal(s.CERTIFIED,1);assert.equal(s.FAILED,1);assert.equal(s.DEGRADED,1);assert.equal(s.LOGIC_PASS_PROVIDER_UNVERIFIED,1);assert.equal(s.allCertified,false);
});

test('lab is wired into authenticated UI and protected machine endpoint',()=>{
 const routes=fs.readFileSync(path.resolve('app/routes.ts'),'utf8');const shell=fs.readFileSync(path.resolve('app/routes/app.tsx'),'utf8');
 assert.match(routes,/engine-certification-lab/);assert.match(routes,/health\/engines/);assert.match(shell,/Engine Certification Lab/);
});
