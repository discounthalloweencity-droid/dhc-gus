import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {evaluateFinancialClosure,financialClosureEvidenceFromGraphql,verifiedFinancialClosureCustomerMessage} from '../app/services/support-financial-closure-rules.ts';

function data(overrides:any={}){return {order:{id:'gid://shopify/Order/1',name:'DHC1122',cancelledAt:null,cancelReason:null,displayFinancialStatus:'PAID',refundable:true,totalPriceSet:{shopMoney:{amount:'52.97',currencyCode:'USD'}},totalRefundedSet:{shopMoney:{amount:'0.00',currencyCode:'USD'}},refunds:[],transactions:[],...overrides}};}

test('staff click cannot create refund truth when Shopify has no refund evidence',()=>{
 const e=financialClosureEvidenceFromGraphql(data())!;const d=evaluateFinancialClosure(e,'REFUND');
 assert.equal(d.canTellCustomerCompleted,false);assert.equal(d.resolution,'REFUND_NOT_CONFIRMED');
});

test('Shopify refund record + total refunded confirms refund submission',()=>{
 const e=financialClosureEvidenceFromGraphql(data({displayFinancialStatus:'REFUNDED',totalRefundedSet:{shopMoney:{amount:'52.97',currencyCode:'USD'}},refunds:[{id:'gid://shopify/Refund/1',createdAt:'2026-09-22T20:00:00Z',processedAt:'2026-09-22T20:01:00Z',transactions:{nodes:[{id:'gid://shopify/OrderTransaction/2',kind:'REFUND',status:'SUCCESS',errorCode:null,gateway:'shopify_payments',processedAt:'2026-09-22T20:01:00Z',amountSet:{shopMoney:{amount:'52.97',currencyCode:'USD'}}}]}}]}))!;
 const d=evaluateFinancialClosure(e,'REFUND');assert.equal(d.canTellCustomerCompleted,true);assert.equal(d.resolution,'REFUND_CONFIRMED');assert.equal(d.verifiedRefundAmount?.amount,52.97);
 const msg=verifiedFinancialClosureCustomerMessage('DHC1122',d,5,10);assert.match(msg,/Shopify confirms USD 52\.97/i);assert.match(msg,/5–10 business days/);
});

test('cancelled order stays open until refund or void is also confirmed',()=>{
 const e=financialClosureEvidenceFromGraphql(data({cancelledAt:'2026-09-22T20:00:00Z'}))!;const d=evaluateFinancialClosure(e,'CANCEL');
 assert.equal(d.cancellationConfirmed,true);assert.equal(d.canTellCustomerCompleted,false);assert.equal(d.resolution,'CANCELLATION_CONFIRMED_REFUND_NOT_CONFIRMED');
});

test('cancel + full successful refund closes both cancellation and money lifecycle',()=>{
 const e=financialClosureEvidenceFromGraphql(data({cancelledAt:'2026-09-22T20:00:00Z',displayFinancialStatus:'REFUNDED',totalRefundedSet:{shopMoney:{amount:'52.97',currencyCode:'USD'}},refunds:[{id:'gid://shopify/Refund/1',processedAt:'2026-09-22T20:02:00Z',transactions:{nodes:[{id:'gid://shopify/OrderTransaction/3',kind:'REFUND',status:'SUCCESS',processedAt:'2026-09-22T20:02:00Z',amountSet:{shopMoney:{amount:'52.97',currencyCode:'USD'}}}]}}]}))!;
 const d=evaluateFinancialClosure(e,'CANCEL');assert.equal(d.resolution,'CANCELLATION_AND_REFUND_CONFIRMED');assert.equal(d.canTellCustomerCompleted,true);
});

test('cancelled authorization that Shopify voided is closed without pretending a refund credit exists',()=>{
 const e=financialClosureEvidenceFromGraphql(data({cancelledAt:'2026-09-22T20:00:00Z',displayFinancialStatus:'VOIDED'}))!;const d=evaluateFinancialClosure(e,'CANCEL');
 assert.equal(d.resolution,'CANCELLATION_VOID_CONFIRMED');assert.equal(d.canTellCustomerCompleted,true);assert.equal(d.refundConfirmed,false);
});

test('refund completion service is wired to live Shopify financial closure evidence',()=>{
 const src=fs.readFileSync('app/services/customer-service-refund-escalation.server.ts','utf8');
 assert.match(src,/loadFinancialClosureEvidence/);assert.match(src,/canTellCustomerCompleted/);assert.match(src,/SHOPIFY_FINANCIAL_CLOSURE_VERIFIED/);assert.doesNotMatch(src,/staff confirmed Shopify refund; customer confirmation sent/);
 const route=fs.readFileSync('app/routes/app.support-email.tsx','utf8');assert.match(route,/Verify Refund \/ Cancellation/);assert.match(route,/Shopify did not yet confirm financial closure/);
});

test('cancel submission remains explicitly submitted-not-confirmed',()=>{
 const src=fs.readFileSync('app/services/support-actions.server.ts','utf8');assert.match(src,/SHOPIFY_JOB_SUBMITTED_NOT_CONFIRMED/);
});
