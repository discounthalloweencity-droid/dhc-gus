import test from 'node:test';import assert from 'node:assert/strict';import {stepSpec,dedupeKey,shouldRunEfficiently,backoffMs} from '../app/services/operations-efficiency-rules.ts';
test('critical work outranks cleanup',()=>assert.ok(stepSpec('inventoryProtection').priority>stepSpec('catalog').priority));
test('customer work outranks growth',()=>assert.ok(stepSpec('customerService').priority>stepSpec('organicGrowth').priority));
test('dedupe key is deterministic',()=>assert.equal(dedupeKey('SHOP','catalog','STORE'),dedupeKey('shop','catalog','store')));
test('fresh expensive work is skipped',()=>assert.equal(shouldRunEfficiently({lastFinishedAt:new Date(9_000),now:10_000,minIntervalMs:5_000}).run,false));
test('failed work retries despite freshness',()=>assert.equal(shouldRunEfficiently({lastFinishedAt:new Date(9_000),lastStatus:'FAILED',now:10_000,minIntervalMs:50_000}).run,true));
test('backoff is bounded',()=>assert.ok(backoffMs(99)<=30*60_000));
