import test from 'node:test';import assert from 'node:assert/strict';import {desiredConcurrency,workerBatchSize,etaHours,operationalFault,lanePriority} from '../app/services/high-throughput-worker-rules.ts';
test('turbo scales deterministic backlog to 12 slots',()=>assert.equal(desiredConcurrency({mode:'TURBO_CLEANUP',queued:1000,running:0,recentFailureRate:0,throttled:false}),12));
test('throttle reduces concurrency',()=>assert.ok(desiredConcurrency({mode:'TURBO_CLEANUP',queued:1000,running:0,recentFailureRate:0,throttled:true})<12));
test('high failure rate reduces concurrency',()=>assert.ok(desiredConcurrency({mode:'NORMAL',queued:1000,running:0,recentFailureRate:.3,throttled:false})<6));
test('large idle backlog is an operational fault',()=>assert.match(operationalFault({queued:22014,running:0,mode:'NORMAL'})||'',/BACKLOG_WITH_IDLE_WORKERS/));
test('eta is evidence based',()=>assert.equal(etaHours(22014,1000),22));
test('batch size is bounded',()=>assert.equal(workerBatchSize(20),120));
test('inventory outranks SEO',()=>assert.ok(lanePriority('INVENTORY_PROTECTION')>lanePriority('SEO_GROWTH')));
