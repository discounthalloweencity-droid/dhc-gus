import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeCjStock,matchCjWarehouse,cjObservation} from '../app/services/cj-availability.server.ts';

test('CJ stock normalization preserves exact warehouse identity and quantity',()=>{
 const now=new Date('2026-09-22T00:00:00Z');
 const rows=normalizeCjStock({result:true,code:200,requestId:'req-1',data:[{vid:'v1',areaId:'US-1',countryCode:'US',storageNum:7}]},'v1',now);
 assert.equal(rows.length,1);assert.equal(rows[0].warehouse,'US-1');assert.equal(rows[0].quantity,7);assert.equal(matchCjWarehouse(rows,'US-1')?.countryCode,'US');assert.equal(matchCjWarehouse(rows,'CN-1'),undefined);
});

test('CJ observations never invent delivery days without fresh independent shipping evidence',()=>{
 const now=new Date('2026-09-22T00:00:00Z');
 const stock={vid:'v1',warehouse:'US-1',countryCode:'US',quantity:3,reference:'r',verifiedAt:now};
 const noShip=cjObservation(stock,undefined,now);assert.equal(noShip.deliveryMinDays,null);assert.equal(noShip.deliveryMaxDays,null);
 const valid=cjObservation(stock,{minDays:2,maxDays:5,reference:'s',verifiedAt:new Date('2026-09-21T23:00:00Z'),validUntil:new Date('2026-09-23T00:00:00Z')},now);assert.equal(valid.deliveryMinDays,2);assert.equal(valid.deliveryMaxDays,5);
});
