import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {ENGINE_ROTATION_SEQUENCE,beginEngineRotation,markEngineStart,markEngineComplete,markEngineFresh,completeEngineRotation,engineActivitySnapshot} from '../app/services/engine-rotation.server.ts';
import {EFFICIENCY_STEPS} from '../app/services/operations-efficiency-rules.ts';

test('R110 engine rotation defines every orchestrator step exactly once',()=>{
  const source=fs.readFileSync(new URL('../app/services/orchestrator.server.ts',import.meta.url),'utf8');
  const actual=[...source.matchAll(/await runStep\('([^']+)'/g)].map(m=>m[1]);
  const planned=ENGINE_ROTATION_SEQUENCE.map(x=>x.key);
  assert.equal(actual.length,75);
  assert.deepEqual(planned,actual);
  assert.equal(new Set(planned).size,planned.length);
});

test('R110 gives every engine an explicit cadence no longer than 24 hours',()=>{
  for(const engine of ENGINE_ROTATION_SEQUENCE){
    const spec=EFFICIENCY_STEPS[engine.key];
    assert.ok(spec,`missing cadence for ${engine.key}`);
    assert.ok(spec.minIntervalMs>=2*60_000,`${engine.key} cadence is too aggressive`);
    assert.ok(spec.minIntervalMs<=24*60*60_000,`${engine.key} cadence exceeds 24h`);
  }
});

test('R110 fresh skip cannot become a new persisted cadence anchor',()=>{
  const source=fs.readFileSync(new URL('../app/services/orchestrator.server.ts',import.meta.url),'utf8');
  const block=source.slice(source.indexOf('if(!efficiency.run){'),source.indexOf('const efficiencyStartedAt',source.indexOf('if(!efficiency.run){')));
  assert.match(block,/markEngineFresh/);
  assert.doesNotMatch(block,/recordEfficiencyStep/);
  const efficiency=fs.readFileSync(new URL('../app/services/operations-efficiency.server.ts',import.meta.url),'utf8');
  assert.match(efficiency,/NOT:\{details:\{contains:/);
});

test('R110 live engine snapshot exposes current, sequence and results',()=>{
  const shop='r110-test.myshopify.com';
  beginEngineRotation(shop,110);
  markEngineStart(shop,'connectionHealth');
  let snap=engineActivitySnapshot(shop);
  assert.equal(snap.cycle.id,110);
  assert.equal(snap.cycle.currentKey,'connectionHealth');
  assert.equal(snap.engines[0].status,'RUNNING');
  markEngineComplete(shop,'connectionHealth',{status:'DONE',scanned:8,changed:2},42);
  markEngineStart(shop,'operationsBrain');
  markEngineFresh(shop,'operationsBrain',{reason:'FRESH',lastFinishedAt:new Date(),lastStatus:'DONE'});
  completeEngineRotation(shop,'COMPLETE');
  snap=engineActivitySnapshot(shop);
  assert.equal(snap.cycle.total,75);
  assert.equal(snap.cycle.status,'COMPLETE');
  assert.equal(snap.engines[0].scanned,8);
  assert.equal(snap.engines[0].changed,2);
  assert.equal(snap.engines[1].status,'FRESH');
});
