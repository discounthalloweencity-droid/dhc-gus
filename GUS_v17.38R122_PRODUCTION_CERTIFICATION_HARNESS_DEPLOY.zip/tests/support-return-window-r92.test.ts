import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {cheapestValidReturnRate,explicitAdvanceExchangeChargeConsent,returnScanDeadline,returnWindowPhase} from '../app/services/support-return-window-rules.ts';

test('R92 14-day return window is based on first carrier scan, not delivery',()=>{
 const sent='2026-09-22T17:00:00.000Z';
 const deadline=returnScanDeadline(sent);
 assert.equal(deadline,'2026-10-06T17:00:00.000Z');
 assert.equal(returnWindowPhase({labelSentAt:sent,deadlineAt:deadline,firstScanAt:'2026-10-06T16:59:59.000Z'}).phase,'SCANNED_ON_TIME');
 assert.equal(returnWindowPhase({labelSentAt:sent,deadlineAt:deadline,firstScanAt:'2026-10-06T17:00:01.000Z'}).phase,'SCANNED_LATE');
 assert.equal(returnWindowPhase({labelSentAt:sent,deadlineAt:deadline,now:new Date('2026-09-29T17:00:00.000Z')}).phase,'REMINDER_DAY_7');
 assert.equal(returnWindowPhase({labelSentAt:sent,deadlineAt:deadline,now:new Date('2026-10-04T17:00:00.000Z')}).phase,'REMINDER_DAY_12');
 assert.equal(returnWindowPhase({labelSentAt:sent,deadlineAt:deadline,now:new Date('2026-10-05T17:00:00.000Z')}).phase,'FINAL_DAY_14');
 assert.equal(returnWindowPhase({labelSentAt:sent,deadlineAt:deadline,now:new Date('2026-10-06T17:00:01.000Z')}).phase,'OVERDUE');
});

test('R92 requires explicit advance-exchange charge consent',()=>{
 assert.equal(explicitAdvanceExchangeChargeConsent('I AGREE to the 14-day return terms and replacement charge.'),true);
 assert.equal(explicitAdvanceExchangeChargeConsent('yes, I authorize the charge if the return is late'),true);
 assert.equal(explicitAdvanceExchangeChargeConsent('thanks, send the replacement'),false);
});

test('R92 buys the cheapest valid USD return rate under the configured ceiling',()=>{
 const rate=cheapestValidReturnRate([
  {id:'r1',rate:'11.25',currency:'USD',carrier:'UPS',service:'Ground'},
  {id:'r2',rate:'8.40',currency:'USD',carrier:'USPS',service:'GroundAdvantage'},
  {id:'r3',rate:'7.00',currency:'CAD',carrier:'CanadaPost'},
  {id:'r4',rate:'80.00',currency:'USD',carrier:'FedEx'},
 ],50);
 assert.equal(rate?.id,'r2');
});

test('R92 return commerce engine uses Shopify calculation, EasyPost purchase, Shopify reverse delivery, and governed payment collection',()=>{
 const commerce=fs.readFileSync('app/services/support-return-commerce-automation.server.ts','utf8');
 assert.match(commerce,/returnCalculate/);
 assert.match(commerce,/READY_NOT_ISSUED/);
 assert.match(commerce,/\/shipments/);
 assert.match(commerce,/cheapestValidReturnRate/);
 assert.match(commerce,/reverseDeliveryCreateWithShipping/);
 assert.match(commerce,/notifyCustomer:false/);
 assert.match(commerce,/loadVerifiedReturnLabelEvidence/);
 assert.match(commerce,/orderCreateMandatePayment/);
 assert.match(commerce,/GUS_RETURN_OVERDUE_AUTO_CHARGE_ENABLED/);
 assert.match(commerce,/CONSENT_REQUIRED/);
});

test('R92 customer email sends verified label before starting deadline and does not claim refund issued',()=>{
 const email=fs.readFileSync('app/services/customer-service-email.server.ts','utf8');
 assert.match(email,/ensureCheapestReturnLabel/);
 assert.match(email,/prepareReturnRefundPreview/);
 assert.match(email,/I’ve sent your prepaid/);
 assert.match(email,/first acceptance scan/);
 assert.match(email,/READY but NOT ISSUED/);
 assert.match(email,/Reply “I AGREE”/);
 assert.match(email,/outbound\?\.sent&&returnLabel\?\.labelUrl/);
 assert.match(email,/returnDeadlineFromSent/);
 assert.match(email,/EASYPOST_SHOPIFY_RETURN_LABEL/);
});

test('R92 monitor uses EasyPost first scan, reminders, overdue enforcement, and runtime passes Shopify admin',()=>{
 const monitor=fs.readFileSync('app/services/support-customer-return-monitor.server.ts','utf8');
 const runtime=fs.readFileSync('app/services/runtime-orchestrator-pulse.server.ts','utf8');
 assert.match(monitor,/easyPostTrackerEvidence/);
 assert.match(monitor,/returnFirstCarrierScanAt/);
 assert.match(monitor,/REMINDER_DAY_7/);
 assert.match(monitor,/REMINDER_DAY_12/);
 assert.match(monitor,/FINAL_DAY_14/);
 assert.match(monitor,/overdueExchangeCollection/);
 assert.match(monitor,/PAYMENT_LINK_AVAILABLE/);
 assert.match(monitor,/CONSENT_REQUIRED/);
 assert.match(runtime,/reconcileCustomerReturnTracking\(admin,shop\)/);
});

test('R92 direct SMTP permits verified EasyPost label hosts',()=>{
 const smtp=fs.readFileSync('app/services/support-email-protocol.server.ts','utf8');
 assert.match(smtp,/easypost\.com/);
 assert.match(smtp,/easypost-files\.s3\.amazonaws\.com/);
});

test('R92 runtime identity is release-derived instead of the stale hardcoded 0.16.57 marker',()=>{
 const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
 const server=fs.readFileSync('server.js','utf8');
 const app=fs.readFileSync('app/routes/app.tsx','utf8');
 const release=Number(String(pkg.version).match(/-r(\d+)$/)?.[1]||0);assert.ok(release>=92,`expected R92+, got ${pkg.version}`);
 assert.match(server,/JSON\.parse\(readFileSync\(resolve\(APP_ROOT,'package\.json'\)/);
 assert.match(app,/const RUNTIME_VERSION=pkg\.version/);
 assert.match(app,/SYSTEM \{systemHealth\.status\} · v\{RUNTIME_VERSION\}/);
});
