import test from 'node:test';
import assert from 'node:assert/strict';
import {evaluateProductionProof} from '../app/services/production-proof-rules.ts';

const base={automationRunning:true,shopifyConnected:true,lastOrchestratorAt:new Date(),lastOrchestratorStatus:'COMPLETE',orchestratorAgeMs:2*60000,pending:40,running:0,oldestPendingAgeMs:60*60000,completed15m:0,completed60m:0,failed60m:0,missionEvents60m:0,jobsDone60m:0,jobsFailed60m:0,jobChanged60m:0,changeLogs60m:0,staleMissions:0,staleJobs:0,openCriticalErrors:0,turboEnabled:false,turboEnabledAgeMs:null,previous:null,completedSincePrevious:null,changesSincePrevious:null,verifiedReadbacks:0,driftedReadbacks:0,readbackCandidates:0,snapshotAgeMs:10*60000,now:Date.now()};

test('Production Proof calls a backlog with no execution NOT_WORKING',()=>{const r=evaluateProductionProof(base);assert.equal(r.verdict,'NOT_WORKING');assert.ok(r.checks.some(x=>x.key==='execution'&&x.status==='FAIL'));});

test('Production Proof detects counters that do not move',()=>{const now=Date.now();const r=evaluateProductionProof({...base,completed60m:1,missionEvents60m:2,jobsDone60m:2,previous:{capturedAt:new Date(now-15*60000).toISOString(),pending:40},completedSincePrevious:0,now});assert.equal(r.verdict,'STALLED');assert.ok(r.checks.some(x=>x.key==='queue-movement'&&x.status==='FAIL'));});

test('Production Proof detects Turbo false-healthy state',()=>{const r=evaluateProductionProof({...base,turboEnabled:true,turboEnabledAgeMs:45*60000,missionEvents60m:2,jobsDone60m:1});assert.ok(r.checks.some(x=>x.key==='turbo'&&x.status==='FAIL'));});

test('Production Proof calls real movement WORKING',()=>{const now=Date.now();const r=evaluateProductionProof({...base,pending:22,running:2,completed15m:4,completed60m:18,missionEvents60m:42,jobsDone60m:12,jobChanged60m:7,changeLogs60m:7,turboEnabled:true,turboEnabledAgeMs:30*60000,previous:{capturedAt:new Date(now-15*60000).toISOString(),pending:31},completedSincePrevious:9,changesSincePrevious:5,verifiedReadbacks:3,readbackCandidates:3,now});assert.equal(r.verdict,'WORKING');assert.ok(r.score>=90);});

test('Production Proof fails when live Shopify disagrees with recorded after-state',()=>{const r=evaluateProductionProof({...base,pending:0,completed60m:2,missionEvents60m:3,jobsDone60m:2,changeLogs60m:1,driftedReadbacks:1,readbackCandidates:1});assert.equal(r.verdict,'NOT_WORKING');assert.ok(r.checks.some(x=>x.key==='shopify-readback'&&x.status==='FAIL'));});

test('Production Proof fails closed when a critical telemetry source is unavailable',()=>{
 const r=evaluateProductionProof({...base,signalFailures:1,criticalSignalFailures:1,signalFailureNames:['retail-mission-states']});
 assert.equal(r.verdict,'NOT_WORKING');
 assert.ok(r.checks.some(x=>x.key==='data-sources'&&x.status==='FAIL'));
});

test('Production Proof does not mislabel unreadable automation state as STOPPED',()=>{
 const r=evaluateProductionProof({...base,automationKnown:false,automationRunning:false,signalFailures:1,criticalSignalFailures:1,signalFailureNames:['automation-control']});
 assert.equal(r.verdict,'NOT_WORKING');
 assert.ok(r.checks.some(x=>x.key==='automation'&&x.evidence.includes('could not be read')));
});

test('Production Proof marks unverified history persistence degraded when runtime otherwise works',()=>{
 const now=Date.now();
 const r=evaluateProductionProof({...base,pending:0,completed60m:2,missionEvents60m:3,jobsDone60m:2,changeLogs60m:1,verifiedReadbacks:1,readbackCandidates:1,persistenceRequested:true,persistenceVerified:false,persistenceError:'readback mismatch',now});
 assert.equal(r.verdict,'DEGRADED');
 assert.ok(r.checks.some(x=>x.key==='proof-history'&&x.status==='FAIL'));
});
