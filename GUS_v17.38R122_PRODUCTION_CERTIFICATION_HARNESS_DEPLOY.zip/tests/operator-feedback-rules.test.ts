
import {strict as assert} from 'node:assert';
import {feedbackLearningEffect} from '../app/services/operator-feedback-rules.ts';
assert.equal(feedbackLearningEffect('CORRECT').direction,'REINFORCE');
assert.equal(feedbackLearningEffect('WRONG').direction,'CORRECT');
assert.equal(feedbackLearningEffect('TOO_AGGRESSIVE').direction,'REDUCE_AGGRESSION');
assert.equal(feedbackLearningEffect('TOO_CONSERVATIVE').direction,'INCREASE_SENSITIVITY');
assert.equal(feedbackLearningEffect('UNDO_REQUESTED').direction,'REVIEW_ROLLBACK');
console.log('operator-feedback-rules: 5/5 passed');
