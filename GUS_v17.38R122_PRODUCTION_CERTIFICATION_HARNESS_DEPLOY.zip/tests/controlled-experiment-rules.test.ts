
import {strict as assert} from 'node:assert';
import {evaluateExperiment} from '../app/services/controlled-experiment-rules.ts';
let r=evaluateExperiment({exposures:30,conversions:3,value:0},{exposures:30,conversions:6,value:0},{minSample:100,minDaysMet:true});
assert.equal(r.status,'INSUFFICIENT_SAMPLE');
r=evaluateExperiment({exposures:500,conversions:50,value:0},{exposures:500,conversions:90,value:0},{minSample:100,minDaysMet:true});
assert.equal(r.status,'VARIANT_WINS');assert.equal(r.winner,'VARIANT');
r=evaluateExperiment({exposures:500,conversions:90,value:0},{exposures:500,conversions:50,value:0},{minSample:100,minDaysMet:true});
assert.equal(r.status,'CONTROL_WINS');
r=evaluateExperiment({exposures:500,conversions:50,value:0},{exposures:500,conversions:52,value:0},{minSample:100,minDaysMet:true});
assert.equal(r.status,'NO_CLEAR_WINNER');
r=evaluateExperiment({exposures:500,conversions:50,value:0},{exposures:500,conversions:90,value:0},{minSample:100,minDaysMet:true,guardrailBreached:true});
assert.equal(r.status,'GUARDRAIL_STOP');
console.log('controlled-experiment-rules: 5/5 passed');
