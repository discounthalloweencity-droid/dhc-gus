import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read=(p:string)=>fs.readFileSync(p,'utf8');

test('R120 backend completion truth remains present in later releases',()=>{
 const pkg=JSON.parse(read('package.json'));
 assert.match(String(pkg.version),/^0\.17\.(?:3[6-9]|[4-9]\d)-r\d+$/);
 assert.match(read('app/services/sales-channel-catalog-governor.server.ts'),/postReadback/);
});

test('Shop governor proves zero-stock and ready-Shop backlogs are drained after writes',()=>{
 const s=read('app/services/sales-channel-catalog-governor.server.ts');
 assert.match(s,/GusChannelGovernorCount/);
 assert.match(s,/postReadback=\{remainingZero,remainingHidden:hiddenAfter\.length,readyHiddenRemaining:readyHiddenAfter\.length/);
 assert.match(s,/status=writeBacklog\?'BACKLOG_REMAINS'/);
 assert.match(s,/dbStatus=status==='DONE'\?'DONE':status==='BACKLOG_REMAINS'\?'FAILED':'WAITING'/);
 assert.match(s,/ZERO_INVENTORY_BACKLOG/);
 assert.match(s,/SHOP_READY_BACKLOG/);
 assert.match(s,/holdReasonCounts/);
 assert.match(s,/heldProducts/);
});

test('Engine activity cannot turn failed or waiting work green merely because cadence is fresh',()=>{
 const s=read('app/services/engine-rotation.server.ts');
 assert.match(s,/prior==='FAILED'\?'ERROR':prior==='WAITING'\?'BLOCKED':'FRESH'/);
 assert.match(s,/s==='BACKLOG_REMAINS'/);
 assert.match(s,/s==='STALE'/);
 assert.match(s,/s==='WRITE_GATE_PROTECTED'/);
});

test('orchestrator runs the actual catalog data normalizer and persists semantic failures',()=>{
 const s=read('app/services/orchestrator.server.ts');
 assert.match(s,/runCatalogDataNormalizer\(admin,shop,false,liveWritesEnabled\(\)\)/);
 assert.match(s,/semanticFailure=\['FAILED','ERROR','STALE','BACKLOG_REMAINS','INCOMPLETE','VERIFICATION_FAILED'\]/);
 assert.match(s,/status:semanticFailure\?'FAILED':semanticBlocked\?'WAITING':'DONE'/);
 const roi=(s.match(/runStep\('actionRoiAttribution'/g)||[]).length;
 assert.equal(roi,1,'action ROI step should not be wired twice');
});

test('SEO blog publishing reports stale instead of successful no-op when overdue and empty',()=>{
 const s=read('app/services/seo-blog-publisher.server.ts');
 assert.match(s,/latestAutoPublishedWork/);
 assert.match(s,/status:'STALE'/);
 assert.match(s,/NO_ELIGIBLE_DRAFTS/);
 assert.match(s,/ALL_DRAFTS_HELD_OR_FAILED/);
 assert.match(s,/SEO_BLOG_PUBLISH_STALE/);
 const rules=read('app/services/operations-efficiency-rules.ts');
 assert.match(rules,/seoBlogPublishing:\{name:'seoBlogPublishing',lane:'GROWTH',minIntervalMs:60\*60_000/);
});

test('Mission status counts critical governor and blog failures as unfinished work',()=>{
 const s=read('app/services/mission-progress.server.ts');
 assert.match(s,/SALES_CHANNEL_CATALOG_GOVERNOR/);
 assert.match(s,/SEO_BLOG_PUBLISHING/);
 assert.match(s,/criticalEngineBacklog=governorFailure\+blogPublisherFailure/);
 assert.match(s,/criticalBacklog:\{governorFailure,governorRemaining,blogPublisherFailure/);
});
