import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(p:string)=>fs.readFileSync(p,'utf8');

test('R106 catalog normalizer retires stale findings after canonical/readback proof',()=>{
 const svc=read('app/services/catalog-data-normalizer.server.ts');
 assert.match(svc,/async function resolveFindings/);
 assert.match(svc,/status:'RESOLVED',resolvedAt:new Date\(\)/);
 assert.match(svc,/resolveFindings\(shop,p\.id,\['TAXONOMY_'\+c\.key\.toUpperCase\(\)\]\)/);
 assert.match(svc,/resolvedCodes\.push\('PRODUCT_TYPE_MISMATCH'\)/);
 assert.match(svc,/resolvedCodes\.push\('VARIANT_OPTION_SIZE'\)/);
});

test('R106 PDP self-heal retires title/description findings only after current clean evidence',()=>{
 const svc=read('app/services/catalog-self-healing.server.ts');
 assert.match(svc,/resolveOpenFindings/);
 assert.match(svc,/SUPPLIER_TITLE_NEEDS_EVIDENCE/);
 assert.match(svc,/PDP_DESCRIPTION_REVIEW/);
 assert.match(svc,/postDescription/);
});
