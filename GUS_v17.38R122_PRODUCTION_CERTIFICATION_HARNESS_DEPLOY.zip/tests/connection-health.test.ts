import test from 'node:test';import assert from 'node:assert/strict';import {classifyConnection,engineCapability} from '../app/services/connection-health-rules.ts';
test('missing configuration is missing',()=>assert.equal(classifyConnection({configured:false}),'MISSING'));
test('configured supplier without evidence is degraded',()=>assert.equal(classifyConnection({configured:true,records:0,requiresEvidence:true}),'DEGRADED'));
test('fresh configured connection is live',()=>assert.equal(classifyConnection({configured:true,records:12,requiresEvidence:true}),'LIVE'));
test('stale evidence is stale',()=>assert.equal(classifyConnection({configured:true,records:1,requiresEvidence:true,lastEvidenceAt:new Date(0),now:100000,staleMs:10}),'STALE'));
test('healthy engine with missing dependency is not healthy',()=>assert.equal(engineCapability('HEALTHY',['MISSING']),'DEGRADED_DATA_SOURCE'));
