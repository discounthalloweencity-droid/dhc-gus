import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const route=fs.readFileSync(new URL('../app/routes/app.customer-service-operations.tsx',import.meta.url),'utf8');
const routes=fs.readFileSync(new URL('../app/routes.ts',import.meta.url),'utf8');
const nav=fs.readFileSync(new URL('../app/routes/app.tsx',import.meta.url),'utf8');
const service=fs.readFileSync(new URL('../app/services/customer-service-operations.server.ts',import.meta.url),'utf8');

test('R88 customer service operations route is wired into route config and navigation',()=>{
  assert.match(routes,/customer-service-operations/);
  assert.match(nav,/Customer Service Ops/);
  assert.match(nav,/\/app\/customer-service-operations/);
});

test('R88 operations screen includes all evidence lanes and one customer timeline',()=>{
  for(const marker of ['Live Shopify order','Shipment status','Attachment evidence','Return & label','Size & fit evidence','Financial closure','Customer timeline'])assert.match(route,new RegExp(marker.replace(/[&]/g,'\\&')));
  assert.match(route,/Resend verified label/);
  assert.match(route,/Verify Refund \/ Cancellation/);
  assert.match(route,/Reprocess with Gus/);
});

test('R88 live order service is Shopify-first and reuses shipment evidence rules',()=>{
  assert.match(service,/query GusCustomerServiceOperationsOrder/);
  assert.match(service,/evaluateShopifyOrderStatus/);
  assert.match(service,/trackingInfo/);
  assert.match(service,/returns\(first:20/);
});


test('R89 operations screen surfaces the universal assigned-agent signature policy',()=>{
  assert.match(route,/Email signature standard/);
  assert.match(route,/Universal outbound signature/);
  assert.match(route,/Assigned Agent \/ Bot/);
  assert.match(route,/Customer Support/);
  assert.match(route,/Discount Halloween City/);
});
