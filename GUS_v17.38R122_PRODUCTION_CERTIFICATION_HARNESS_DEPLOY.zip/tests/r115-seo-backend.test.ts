import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeCatalogValue,productTypeMismatch,recommendedProductType,serializeCanonicalMetafieldValue,variantOptionNormalizationPlan} from '../app/services/catalog-data-normalizer-rules.ts';
import {buildVerifiedPdpDescription,genericPdpTemplateRisk} from '../app/services/catalog-repair-rules.ts';
import {canonicalCollectionIntentKey} from '../app/services/seo-workforce-rules.ts';
import {channelProductReadiness} from '../app/services/sales-channel-catalog-rules.ts';

test('preserves Shopify list metafield type serialization',()=>{
 assert.equal(serializeCanonicalMetafieldValue('list.single_line_text_field','S'),'["S"]');
 assert.equal(serializeCanonicalMetafieldValue('single_line_text_field','S'),'S');
});

test('extracts explicit US age sizing from supplier numeric wrapper',()=>{
 const a=normalizeCatalogValue('size','Size 140(7-8T)');assert.equal(a.status,'NORMALIZE');assert.equal(a.canonical,'7-8T');
 const b=normalizeCatalogValue('size','M 4-5Y)');assert.equal(b.canonical,'4-5Y');
});

test('classifies clear Halloween product types without inventing details',()=>{
 const neon=recommendedProductType({title:'Ghost Pumpkin USB Neon Sign Halloween Wall Decor',productType:'',tags:[]});assert.equal(neon.recommended,'Halloween Decorations');assert.ok(neon.confidence>=.96);
 const costume=productTypeMismatch({title:'Women Superhero Jumpsuit Costume',productType:'Masks',tags:['Women']});assert.equal(costume.recommended,"Women's Costumes");assert.equal(costume.mismatch,true);
});

test('normalizes bounded size/color variants and refuses collisions',()=>{
 const p={options:[{name:'Size',position:1},{name:'Color',position:2}],variants:{pageInfo:{hasNextPage:false},nodes:[{id:'v1',selectedOptions:[{name:'Size',value:'ONE SIZE'},{name:'Color',value:'Multicolour'}]}]}};
 const plan=variantOptionNormalizationPlan(p);assert.equal(plan.status,'READY');assert.deepEqual(plan.updates[0].after,['One Size','Multicolor']);
 const collision={options:[{name:'Size',position:1}],variants:{pageInfo:{hasNextPage:false},nodes:[{id:'v1',selectedOptions:[{name:'Size',value:'ONE SIZE'}]},{id:'v2',selectedOptions:[{name:'Size',value:'One Size'}]}]}};
 assert.equal(variantOptionNormalizationPlan(collision).status,'REVIEW');
});

test('verified PDP builder uses only title category and selectable option evidence',()=>{
 const html=buildVerifiedPdpDescription({title:'Girls Tiger Halloween Costume Dress',productType:'Kids Costumes',options:[{name:'Size',values:['2-3T','4-5Y']},{name:'Color',values:['Orange']}]});
 assert.match(html,/Girls Tiger Halloween Costume Dress/);assert.match(html,/2-3T/);assert.match(html,/Orange/);assert.doesNotMatch(html,/polyester|cotton|includes mask|fits true/i);
 assert.equal(genericPdpTemplateRisk('<p>Shop the Example for Halloween, costume parties, themed events and seasonal fun.</p>'),true);
});

test('duplicate collection intent collapses legacy aliases without collapsing price intents',()=>{
 assert.equal(canonicalCollectionIntentKey("Men's Halloween Costumes"),canonicalCollectionIntentKey("Men's Collection"));
 assert.notEqual(canonicalCollectionIntentKey("Men's Halloween Costumes Under $50"),canonicalCollectionIntentKey("Men's Halloween Costumes"));
});

test('Shop feed governor blocks raw imports and permits clean verified products',()=>{
 const dirty={status:'ACTIVE',title:'2025 New Hot Sale Ghost Neon Sign',productType:'',totalInventory:10,descriptionHtml:'<p>short</p>',seo:{title:'',description:''},featuredMedia:{preview:{image:{url:'https://example.com/a.jpg'}}},options:[],variants:{pageInfo:{hasNextPage:false},nodes:[{id:'v',inventoryQuantity:10,selectedOptions:[]}]},tags:[]};
 const d=channelProductReadiness(dirty);assert.equal(d.ready,false);assert.ok(d.reasons.includes('BLANK_PRODUCT_TYPE'));
 const clean={status:'ACTIVE',title:'Ghost Pumpkin Neon Sign Halloween Decoration',productType:'Halloween Decorations',totalInventory:10,descriptionHtml:'<p>A ghost and pumpkin neon sign for Halloween wall and party décor. Choose the currently available configuration shown on this product page before ordering.</p>',seo:{title:'Ghost Pumpkin Neon Sign | Discount Halloween City',description:'Shop a ghost pumpkin neon sign for Halloween decorating and parties. Check current options, availability and product details.'},featuredMedia:{preview:{image:{url:'https://example.com/a.jpg'}}},options:[],variants:{pageInfo:{hasNextPage:false},nodes:[{id:'v',inventoryQuantity:10,selectedOptions:[]}]},tags:['Halloween Decorations']};
 assert.equal(channelProductReadiness(clean).ready,true);
});
