
import {strict as assert} from 'node:assert';
import {contentQualityDecision} from '../app/services/content-quality-rules.ts';
let r=contentQualityDecision({title:'NEW PESENAR Womens Witch Costume',description:'Nice costume',productType:'Costumes',tags:[],imageCount:1,imageAltTexts:[''],variantCount:5,hasSizeChart:false});
assert.ok(['HIGH','CRITICAL'].includes(r.level));assert.ok(r.issues.some(x=>x.code==='SUPPLIER_TITLE'));assert.ok(r.issues.some(x=>x.code==='SIZE_GUIDE_GAP'));
r=contentQualityDecision({title:"Women's Witch Costume Dress",description:'Includes dress and hat. Polyester costume with care instructions. Size chart and fit guide available. A classic witch look for Halloween parties and costume events.',productType:'Costumes',tags:['Women'],imageCount:4,imageAltTexts:['Witch costume front','Witch costume back','Hat detail','Dress detail'],variantCount:5,hasSizeChart:true});
assert.equal(r.level,'GOOD');
r=contentQualityDecision({title:'Skeleton Graphic T-Shirt',description:'Printed skeleton graphic shirt. Free shipping on all orders.',productType:'Apparel',tags:[],imageCount:2,imageAltTexts:['',''],variantCount:4,hasSizeChart:true});
assert.ok(r.issues.some(x=>x.code==='SHIPPING_CONTRADICTION'));
console.log('content-quality-rules: 3/3 passed');
