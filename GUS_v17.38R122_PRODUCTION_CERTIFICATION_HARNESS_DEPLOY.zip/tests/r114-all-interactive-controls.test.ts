import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';

test('R114 all buttons, links, forms and data-driven operations pass static interaction QA',()=>{
  const raw=execFileSync(process.execPath,['scripts/check-interactive-controls.mjs'],{encoding:'utf8'});
  const report=JSON.parse(raw);
  assert.equal(report.status,'PASS');
  assert.ok(report.buttons>=200,`expected full button inventory, got ${report.buttons}`);
  assert.ok(report.links+report.anchors>=140,`expected full link inventory, got ${report.links+report.anchors}`);
  assert.ok(report.forms>=100,`expected full form inventory, got ${report.forms}`);
  assert.equal(report.operationRows,18);
  assert.deepEqual(report.failures,[]);
});

test('Fulfillment Control Tower manual command is wired end-to-end',()=>{
  const dashboard=fs.readFileSync('app/routes/app._index.tsx','utf8');
  const ops=fs.readFileSync('app/services/operations-control.server.ts','utf8');
  assert.match(ops,/id:'fulfillment_control_tower'/);
  assert.match(dashboard,/runFulfillmentControlTower/);
  assert.match(dashboard,/intent==="fulfillment_control_tower"/);
});

test('embedded left navigation stays client-side while manual operations retain POST fallback',()=>{
  const shell=fs.readFileSync('app/routes/app.tsx','utf8');
  const dashboard=fs.readFileSync('app/routes/app._index.tsx','utf8');
  assert.match(shell,/to=\{item\.to\} onClick=/);
  assert.doesNotMatch(shell,/to=\{item\.to\} reloadDocument/);
  assert.match(dashboard,/<Form method="post" reloadDocument><button type="submit" className="authority-button authority-primary" name="intent" value=\{r\.id\}>/);
});
