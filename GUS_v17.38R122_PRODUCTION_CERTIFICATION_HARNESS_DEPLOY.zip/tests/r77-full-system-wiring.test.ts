import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync,readFileSync} from 'node:fs';
import {evaluateCustomerServiceLanguageAcademy} from '../app/services/customer-service-language.ts';
import {createJobProgressToken,verifyJobProgressToken} from '../app/services/job-progress-token.server.ts';

const read=(p:string)=>readFileSync(new URL(`../${p}`,import.meta.url),'utf8');

test('job progress polling is registered, signed, and consumed by the app shell',()=>{
  const routes=read('app/routes.ts'),shell=read('app/routes/app.tsx');
  assert.match(routes,/api\/job-progress/);
  assert.match(shell,/createJobProgressToken/);
  assert.match(shell,/\/api\/job-progress\?token=/);
  const prior=process.env.GUS_JOB_PROGRESS_SECRET;
  process.env.GUS_JOB_PROGRESS_SECRET='r77-contract-secret';
  try{
    const token=createJobProgressToken('discount-halloween-city.myshopify.com',60_000);
    assert.ok(token);
    const claims=verifyJobProgressToken(token);
    assert.equal(claims?.shop,'discount-halloween-city.myshopify.com');
    assert.equal(verifyJobProgressToken(`${token}x`),null);
  }finally{
    if(prior===undefined)delete process.env.GUS_JOB_PROGRESS_SECRET;else process.env.GUS_JOB_PROGRESS_SECRET=prior;
  }
});

test('canonical Complete-the-Look graph is refreshed by the live basket intelligence engine',()=>{
  const basket=read('app/services/basket-builder-intelligence.server.ts');
  const graph=read('app/services/dhc-complete-look-graph.server.ts');
  assert.match(basket,/persistDhcCompleteLookEdge/);
  assert.match(basket,/pruneDhcCompleteLookEdgesBefore/);
  assert.match(graph,/36\*60\*60\*1000/);
  assert.match(graph,/expiresAt/);
  assert.doesNotMatch(graph,/buildAndPersistDhcCompleteLookEdges/);
});

test('specialist blog engines promote qualified work into the governed draft factory',()=>{
  const s=read('app/services/seo-content-intelligence.server.ts');
  assert.match(s,/parseShopperIntent/);
  assert.match(s,/shouldMergeSearchIntent/);
  assert.match(s,/promoteSpecialistCandidates/);
  assert.match(s,/SEO_NEW_CONTENT_CANDIDATE/);
  assert.match(s,/requiresHuman:true/);
});

test('SEO checkpoint failures retry instead of consuming a learning window',()=>{
  const s=read('app/services/seo-experiment-lab.server.ts');
  assert.match(s,/filter\([^\n]*MEASUREMENT_ERROR/);
  assert.match(s,/trafficSplit:1/);
  assert.match(s,/attempts/);
});

test('learning coverage and customer language academy are part of live learning gates',()=>{
  const director=read('app/services/continuous-product-learning-director.server.ts');
  const academy=read('app/services/gus-academy.server.ts');
  assert.match(director,/learning-instrumentation-coverage/);
  assert.match(academy,/evaluateCustomerServiceLanguageAcademy/);
  const result=evaluateCustomerServiceLanguageAcademy();
  assert.equal(result.total,63);
  assert.equal(result.passed,63);
  assert.equal(result.hardFailures.length,0);
  assert.equal(result.pass,true);
});

test('CJ freight evidence is live only through explicit configuration and supplier refresh',()=>{
  const supplier=read('app/services/supplier-feed.server.ts');
  const shipping=read('app/services/cj-shipping-refresh.server.ts');
  assert.match(supplier,/refreshCjShippingEvidence/);
  assert.match(shipping,/GUS_CJ_FREIGHT_CONFIG_JSON/);
  assert.match(shipping,/originCountry/);
  assert.match(shipping,/processingMinDays/);
  assert.match(shipping,/processingMaxDays/);
});

test('retail mission stop control is surfaced and preserves running-worker checkpoint semantics',()=>{
  const mission=read('app/services/retail-mission.server.ts');
  const queue=read('app/routes/app.queue.tsx');
  assert.match(mission,/current\.state!==['"]RUNNING['"]/);
  assert.match(mission,/CANCELLED/);
  assert.match(mission,/STOP_REQUESTED/);
  assert.match(queue,/requestStopRetailMission/);
  assert.match(queue,/stop-mission/);
});

test('obsolete duplicate service implementations stay removed and runtime wiring is a release gate',()=>{
  for(const rel of ['app/services/ctl-policy.ts','app/services/hero-merchandising-rules.ts','app/services/shipping.server.ts']){
    assert.equal(existsSync(new URL(`../${rel}`,import.meta.url)),false,`${rel} should remain removed`);
  }
  const pkg=JSON.parse(read('package.json'));
  assert.match(pkg.scripts['verify:pure'],/check-runtime-wiring\.mjs/);
  const release=Number(String(pkg.version).match(/-r(\d+)$/)?.[1]||0);assert.ok(release>=92,`expected R92+, got ${pkg.version}`);
});

test('Production Proof is wired into navigation, routing, orchestration and authenticated health proof',()=>{
  const routes=read('app/routes.ts');
  const nav=read('app/routes/app.tsx');
  const orchestrator=read('app/services/orchestrator.server.ts');
  const proof=read('app/services/production-proof.server.ts');
  const proofRoute=read('app/routes/app.production-proof.tsx');
  const healthProof=read('app/routes/health.proof.tsx');
  assert.match(routes,/health\/proof/);
  assert.match(routes,/production-proof/);
  assert.match(nav,/Production Proof/);
  assert.match(orchestrator,/productionProofSnapshot/);
  assert.match(orchestrator,/runStep\(['"]productionProof['"]/);
  assert.match(proof,/liveShopifyProof/);
  assert.match(proof,/retailMissionEvent/);
  assert.match(proof,/changeLog/);
  assert.match(proof,/captureProofSignal/);
  assert.match(proof,/proof-history-readback/);
  assert.match(proof,/dataSources/);
  assert.match(proofRoute,/Run Gus \+ Start Proof Window/);
  assert.match(proofRoute,/Data source health|Signal health|Telemetry/);
  assert.match(healthProof,/GUS_HEALTH_TOKEN/);
});
