# R107 Fail-Closed Mission Truth + Full-Sweep Proof

Release: 0.17.23-r107

R107 closes a false-green mission-state defect discovered after R106 showed `100% ALL CLEAR` despite the merchant knowing the catalog had not been swept.

## Root causes fixed

1. `/app` mission startup fallback previously converted mission query timeout/error into `{state:"CLEAR", progress:100, autoRemaining:0}`.
2. The signed `/api/job-progress` path could return no mission snapshot while the UI retained the prior green state.
3. `ALL CLEAR` did not require a recent successful full catalog sweep.
4. Evidence-wait work could coexist with an `ALL CLEAR` label.
5. The catalog scanner resolved historical OPEN findings at the start of a fresh scan. A failed/throttled/checkpointed partial scan could therefore make the backlog collapse before the catalog was actually rechecked.

## R107 behavior

- Query timeout/error => `STATUS UNAVAILABLE`, never `ALL CLEAR`.
- Stale/unverified mission snapshot => `NOT VERIFIED`.
- `ALL CLEAR` requires:
  - successful mission/backlog read,
  - zero executable automation backlog,
  - zero evidence-wait findings,
  - zero review backlog,
  - latest catalog scan status `DONE`,
  - catalog scan phase `COMPLETE`,
  - positive full coverage (`scanned >= total`),
  - completed catalog sweep no older than 24 hours.
- `EVIDENCE WAIT` is rendered distinctly from `ALL CLEAR`.
- Mission snapshots older than 15 seconds cannot remain green merely because polling stopped.
- Signed progress endpoint returns HTTP 503 + fail-closed mission payload on mission query failure.
- Catalog worker no longer bulk-resolves findings at scan start.
- Pre-scan catalog findings are retired only after Shopify pagination reaches the end and the replacement sweep records COMPLETE.
- Bulk finding retirement is limited to catalog categories and cannot silently resolve unrelated support/operations findings.

## Production acceptance

After deployment, do not accept `ALL CLEAR` until the mission card has a fresh verified snapshot and a recent complete catalog sweep. During a scan, old catalog findings remain visible until the full sweep completes.
