# DHC Gus v0.16.95 R79 — Production Proof / Reality Check

## Why this release exists
R79 adds an independent runtime proof system because an ON/RUNNING dashboard label is not proof that Gus is consuming work or changing Shopify. Production Proof evaluates observable outcomes instead of trusting self-reported engine state.

## New module: Production Proof
Navigation: Command -> Production Proof
Route: `/app/production-proof`

It independently checks:
- master automation state
- live Shopify Admin GraphQL connectivity
- orchestrator/control-loop heartbeat
- stale running RetailMission and JobRun workers
- current pending/running mission counts
- mission completions/transitions over 15/60 minutes
- JobRun completions/failures/claimed changed counts
- ChangeLog evidence over 60 minutes
- queue movement versus the previous persisted Production Proof snapshot
- Turbo state versus completions observed after Turbo was enabled
- recent Shopify readback of supported recorded product changes
- recent open CRITICAL ErrorEvent incidents
- product snapshot/catalog evidence freshness
- per-engine backlog reality (pending/running/completed/failed)

## False-healthy detection
Production Proof explicitly returns NOT_WORKING or STALLED when examples such as these are observed:
- backlog exists with zero mission transitions/completions/jobs
- queue does not fall across a meaningful proof window and there are zero completions
- Turbo remains ON for >15 minutes with backlog but zero completions since Turbo activation
- workers remain RUNNING without heartbeat/finish evidence
- Shopify is unreachable
- recent recorded supported product after-state disagrees with live Shopify readback
- critical runtime incidents contradict optimistic status

The module does not assume every read-only job must create ChangeLog rows. Claimed JobRun changes without ChangeLog evidence are WARN unless stronger contradiction exists.

## Run Gus + Start Proof Window
The UI can request a detached Gus cycle and save a proof baseline. Re-run Production Proof after 5–15 minutes. The next snapshot compares pending backlog and completed work against the baseline so static counters are visible rather than hidden by a RUNNING label.

## Repair packet
Every failed proof creates a copyable coding packet containing:
- release
- verdict
- exact observed evidence
- diagnosis
- code areas to trace
- instruction to trace scheduler -> orchestrator -> queue -> worker -> persistence -> Shopify readback
- requirement for a regression test and measurable post-fix proof

The page also exposes machine-readable runtime proof JSON for copy/paste diagnosis.

## Health bridge
New authenticated endpoint: `/health/proof`
Authorization: Bearer `GUS_HEALTH_TOKEN`; falls back to `AUTHORITY_CRON_SECRET` if a separate health token is not configured.

The endpoint returns sanitized operational proof and responds 503 for NOT_WORKING/STALLED. It does not expose tokens or customer data.

## Orchestrator integration
Production Proof is a CRITICAL efficiency step with a five-minute minimum interval and is invoked by the live Gus orchestrator. The UI can also run the proof independently, which matters when the orchestrator itself is what failed.

## Runtime identity
`/health` now returns the package release and points to `/health/proof`.
The canonical runtime identity now reads the actual package version rather than the old hard-coded 0.16.57 runtime marker.

## QA
- npm test: 97/97 passed
- check:syntax: passed
- check:imports: 640 source files scanned, passed
- check:routes: 225 registrations, 0 duplicates
- check:boundaries: passed
- check:links: 251 /app links passed
- runtime wiring: 342/342 service modules reachable; 0 unexpected unreachable; 0 unregistered routes; 0 broken scripts; 0 inert execution exports; 25/25 integrated feature modules satisfy runtime contracts
- DHC rule validation: passed
- Full React Router/TypeScript production typecheck could not execute in this source-only package because `node_modules/.bin/react-router` is absent (`react-router: not found`). This is an environment/dependency absence, not a TypeScript diagnostic.

## Deployment test
After deploying R79:
1. Open Command -> Production Proof.
2. Click Run Production Proof to establish a baseline.
3. If there is backlog, click Run Gus + Start Proof Window.
4. Wait 5–15 minutes.
5. Click Run Production Proof again.
6. Do not call Gus healthy unless queue/completion/result evidence supports the verdict.
7. If verdict is STALLED/NOT_WORKING, copy Repair Packet and fix the listed runtime path.
