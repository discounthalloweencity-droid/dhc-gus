# Gus v0.16.60 R43 — Product Quality Protection

Adds a daily catalog quality-risk engine to protect DHC from products likely to disappoint customers because the delivered construction materially differs from the merchandising impression.

## Behavior
- Runs daily from the autonomous orchestrator.
- Scans active product title, description, type, tags, image alt text, and recent stored quality/return signals.
- Detects high-risk representation mismatches such as dimensional-looking armor/jewels/chainmail/corset details that are actually described as flat/digital/3D printed graphics.
- Uses customer not-as-described/quality/refund evidence as corroboration.
- Archives only CRITICAL/high-confidence products after an immediate re-read and re-score.
- Review-level heuristics do not auto-archive.
- Every archive is written to changeLog with score and reasons.

## Safety doctrine
Do not archive merely because a costume uses printed graphics. Archive when multiple signals indicate a material expectation mismatch or repeated customer evidence confirms it.
