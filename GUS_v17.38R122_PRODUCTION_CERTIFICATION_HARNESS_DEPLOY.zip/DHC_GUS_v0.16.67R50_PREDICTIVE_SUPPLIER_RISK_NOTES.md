# Gus v0.16.67 R50 — Predictive Supplier Risk & Source Diversification

Scores every enabled supplier-variant link using:
- verified availability history and OOS frequency
- evidence staleness
- delivery maximum and delivery variance
- support / not-as-described / refund evidence
- alternate-source depth
- USA warehouse signal
- days-to-Halloween urgency

Outputs LOW / MEDIUM / HIGH / CRITICAL / UNKNOWN risk plus PREFERRED / WATCH / ADD_BACKUP / DIVERSIFY_NOW / PAUSE_SOURCE recommendations.

R50 is advisory: it never silently disables a supplier link, changes fulfillment ownership, or switches a live source. Those actions require a separately verified workflow.
