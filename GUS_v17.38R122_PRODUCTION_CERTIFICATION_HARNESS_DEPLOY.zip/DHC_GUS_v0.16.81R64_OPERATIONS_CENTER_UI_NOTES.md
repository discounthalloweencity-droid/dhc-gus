# R64 Operations Center UI

Adds `/app/operations-center` and pins Operations Center in Command navigation.

The page shows observed engines, running/healthy count, failed/stalled count, blocked count, open findings, master automation state, per-engine 24-hour scanned/changed/waiting/failures, recorded items/hour, last run, and last recorded error.

Every engine row with a JobRun exposes `Copy Fix Code`. The server generates the repair packet from the actual JobRun details and recent failures; no browser-supplied error text is trusted.

`Run Operations Brain` forces a health audit. The Operations Brain remains cadence-driven from the orchestrator as well.

R64 does not grant self-deploying code privileges. Repair packets preserve Production Write Gate, approvals, readback verification, regression tests and rollback expectations.
