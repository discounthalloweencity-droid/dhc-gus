export type JobProgressSnapshot = {
  id: number;
  jobType: string;
  status: string;
  scanned: number;
  changed: number;
  warnings: number;
  details: string | null;
  startedAt: string;
  finishedAt: string | null;
};
