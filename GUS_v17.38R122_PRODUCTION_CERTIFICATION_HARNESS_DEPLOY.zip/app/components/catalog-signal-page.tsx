import { Badge, Card, Grid, Metric, Page, Table } from "./ui";

type Row={product:string;detail:string;signal:string;severity?:string;status?:string};
export function CatalogSignalPage({title,subtitle,metrics,rows,empty="No matching catalog issues are currently open."}:{title:string;subtitle:string;metrics:Array<{label:string;value:string|number}>;rows:Row[];empty?:string}){
 return <Page title={title} subtitle={subtitle}>
   <Grid>{metrics.map(m=><Metric key={m.label} label={m.label} value={m.value}/>)}</Grid>
   <div style={{height:18}}/>
   <Card>
    <h2>Current catalog signals</h2>
    {rows.length?<Table headers={["Product","Detail","Signal","Status"]} rows={rows.map(r=>[
      r.product,r.detail,<Badge tone={r.severity==="HIGH"?"bad":r.severity==="MEDIUM"?"warn":"neutral"}>{r.signal}</Badge>,r.status||"OPEN"
    ])}/>:<p>{empty}</p>}
   </Card>
 </Page>
}
