import {useState} from "react";
export function DiagnosticDownload({url,label="Download diagnostic bundle"}:{url:string,label?:string}){
 const [status,setStatus]=useState("");
 async function run(){try{setStatus("Preparing…");const r=await fetch(url,{credentials:"same-origin",headers:{Accept:"application/json"}});if(!r.ok)throw new Error(`HTTP ${r.status}`);const blob=await r.blob();const cd=r.headers.get("content-disposition")||"";const m=/filename=([^;]+)/i.exec(cd);const name=(m?.[1]||`GUS_DIAGNOSTIC_${Date.now()}.json`).replace(/["']/g,"");const href=URL.createObjectURL(blob);const a=document.createElement("a");a.href=href;a.download=name;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(href);setStatus("Downloaded");}catch(e:any){setStatus(`Download failed: ${String(e?.message||e)}`);}}
 return <><button type="button" onClick={run}>{label}</button>{status&&<span style={{marginLeft:10,color:"#616161"}}>{status}</span>}</>;
}
