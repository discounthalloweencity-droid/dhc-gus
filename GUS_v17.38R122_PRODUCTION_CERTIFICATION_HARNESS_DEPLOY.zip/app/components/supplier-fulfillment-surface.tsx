import { Link } from 'react-router';
import { Badge, Card, Grid, Metric, Page, Table } from './ui';

type Data=Awaited<ReturnType<typeof import('../services/supplier-fulfillment-dashboard.server').loadSupplierFulfillmentDashboard>>;
export function SupplierFulfillmentSurface({title,subtitle,data,focus,supplier}:{title:string;subtitle:string;data:Data;focus:string[];supplier?:string}){
  const rows=supplier?data.latest.filter(o=>o.link.supplier.toLowerCase().includes(supplier.toLowerCase())):data.latest;
  const links=supplier?data.links.filter(l=>l.supplier.toLowerCase().includes(supplier.toLowerCase())):data.links;
  const findings=data.supplierFindings.filter(f=>!supplier||`${f.message} ${f.code}`.toLowerCase().includes(supplier.toLowerCase()));
  return <Page title={title} subtitle={subtitle}>
    <div className="authority-toolbar">
      <Link className="authority-button authority-primary" to="/app/supplier-command">Supplier Command</Link>
      <Link className="authority-button" to="/app/supplier-stock">Supplier Stock</Link>
      <Link className="authority-button" to="/app/shipping-times">Shipping Times</Link>
      <Link className="authority-button" to="/app/fulfillment-exceptions">Exceptions</Link>
    </div>
    <Grid>
      <Metric label="Mapped supplier variants" value={links.length}/>
      <Metric label="In-stock evidence" value={rows.filter(o=>o.status==='IN_STOCK').length}/>
      <Metric label="Out-of-stock evidence" value={rows.filter(o=>o.status==='OUT_OF_STOCK').length}/>
      <Metric label="Open supplier findings" value={findings.length}/>
    </Grid>
    <div style={{height:18}}/>
    <Card><h2>Operating focus</h2><ul>{focus.map(x=><li key={x}>{x}</li>)}</ul></Card>
    <div style={{height:18}}/>
    <Card><h2>Latest verified supplier evidence</h2>{rows.length?<Table headers={['Supplier','Variant','Warehouse','Status','Qty','Delivery','Verified']} rows={rows.slice(0,150).map(o=>[o.link.supplier,o.link.variantGid,o.link.warehouse||'—',<Badge tone={o.status==='IN_STOCK'?'good':o.status==='OUT_OF_STOCK'?'bad':'warn'}>{o.status}</Badge>,o.quantity??'—',o.deliveryMaxDays??o.deliveryMinDays??'—',new Date(o.verifiedAt).toLocaleString()])}/>:<p>No matching supplier observations are stored. Missing evidence stays UNKNOWN; Shopify zero inventory alone is not treated as a dropship stockout.</p>}</Card>
    <div style={{height:18}}/>
    <Card><h2>Exceptions & findings</h2>{findings.length?<Table headers={['Severity','Code','Finding','Created']} rows={findings.slice(0,100).map(f=>[<Badge tone={/HIGH|CRITICAL/i.test(f.severity)?'bad':/MEDIUM|WARN/i.test(f.severity)?'warn':'neutral'}>{f.severity}</Badge>,f.code,f.message,new Date(f.createdAt).toLocaleString()])}/>:<p>No matching open supplier or fulfillment findings are stored.</p>}</Card>
  </Page>;
}
