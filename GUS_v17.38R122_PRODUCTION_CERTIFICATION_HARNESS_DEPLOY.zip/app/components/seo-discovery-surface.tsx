import { Link } from 'react-router';
import { Badge, Card, Grid, Metric, Page, Table } from './ui';

type Data={catalog:any[];seoFindings:any[];pending:number;competitors:any[];collections:any[];avgSeo:number|null;autoCount?:number;evidenceCount?:number};
function handlingTone(mode:string){return ['AUTO_FIXED','AUTO_PROCESSING','AUTO_ELIGIBLE'].includes(mode)?'good':mode==='EVIDENCE'?'bad':'warn';}
export function SeoDiscoverySurface({title,subtitle,data,focus,notes=[]}:{title:string;subtitle:string;data:Data;focus:string[];notes?:string[]}){
  const weak=data.catalog.filter(p=>p.seoScore!=null&&p.seoScore<80);
  const severe=data.seoFindings.filter(f=>/HIGH|CRITICAL/i.test(f.severity));
  return <Page title={title} subtitle={subtitle}>
    <div className="authority-toolbar">
      <Link className="authority-button authority-primary" to="/app/seo">SEO Command</Link>
      <Link className="authority-button" to="/app/seo-issues">SEO Issues</Link>
      <Link className="authority-button" to="/app/keywords-rankings">Keywords & Rankings</Link>
      <Link className="authority-button" to="/app/seo-competitors">Competitors</Link>
    </div>
    <Grid>
      <Metric label="Unique products observed" value={data.catalog.length}/>
      <Metric label="Average SEO score" value={data.avgSeo??'Not available'} detail="Only products with an evidence-backed score"/>
      <Metric label="Open SEO/discovery findings" value={data.seoFindings.length}/>
      <Metric label="High / critical findings" value={severe.length}/>
    </Grid>
    <div style={{height:18}}/>
    <Card><h2>Operating focus</h2><ul>{focus.map(x=><li key={x}>{x}</li>)}</ul>{notes.map(x=><p key={x}>{x}</p>)}<p><strong>Gus automation:</strong> {data.autoCount??0} items are auto-fix eligible/processing. {data.evidenceCount??0} need evidence before Gus may act. Gus will not invent missing product facts.</p></Card>
    <div style={{height:18}}/>
    <Card><h2>Current evidence</h2>
      {data.seoFindings.length?<Table headers={['Severity','Product','Code','Finding','Handling','Open']} rows={data.seoFindings.slice(0,120).map(f=>[<Badge tone={/HIGH|CRITICAL/i.test(f.severity)?'bad':/MEDIUM|WARN/i.test(f.severity)?'warn':'neutral'}>{f.severity}</Badge>,<><strong>{f.productTitle}</strong><br/><a href={f.productUrl} target="_blank" rel="noreferrer">Shopify product</a></>,f.code,f.message,<Badge tone={handlingTone(f.handlingMode) as any}>{f.handlingLabel}</Badge>,<Link to={`/app/findings?id=${f.id}`}>Issue details</Link>])}/>:<p>No matching open findings are stored yet. Gus should show unknown rather than inventing an issue.</p>}
    </Card>
    <div style={{height:18}}/>
    <Card><h2>Weak product SEO queue</h2>{weak.length?<Table headers={['Product','SEO score','Status','Captured']} rows={weak.slice(0,120).map(p=>[p.title,<Badge tone={(p.seoScore||0)>=60?'warn':'bad'}>{p.seoScore}</Badge>,p.status,new Date(p.capturedAt).toLocaleString()])}/>:<p>No product with a stored SEO score below 80 is currently in this snapshot.</p>}</Card>
  </Page>;
}
