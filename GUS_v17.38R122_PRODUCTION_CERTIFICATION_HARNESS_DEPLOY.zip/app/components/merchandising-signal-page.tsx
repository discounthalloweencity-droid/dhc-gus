import { Badge, Card, Grid, Metric, Page, Table } from "./ui";

type SignalRow={target:string;detail:string;source:string;priority?:string;status?:string};
type PlanRow={action:string;target:string;score:number;confidence:number;status:string;reason:string};
export function MerchandisingSignalPage({title,subtitle,metrics,signals,plans=[],note}:{title:string;subtitle:string;metrics:Array<{label:string;value:string|number;detail?:string}>;signals:SignalRow[];plans?:PlanRow[];note:string}){
 return <Page title={title} subtitle={subtitle}>
   <Grid>{metrics.map(m=><Metric key={m.label} label={m.label} value={m.value} detail={m.detail}/>)}</Grid>
   <div style={{height:18}}/>
   <Card><h2>Operating view</h2><p>{note}</p></Card>
   <div style={{height:18}}/>
   <Card><h2>Current merchandising signals</h2>{signals.length?<Table headers={["Target","Detail","Evidence","Priority","Status"]} rows={signals.map(r=>[
    r.target,r.detail,r.source,<Badge tone={r.priority==="HIGH"?"bad":r.priority==="MEDIUM"?"warn":"neutral"}>{r.priority||"NORMAL"}</Badge>,r.status||"OPEN"
   ])}/>:<p>No matching evidence-backed signals are currently open.</p>}</Card>
   {plans.length?<><div style={{height:18}}/><Card><h2>Merchandising plans</h2><Table headers={["Action","Target","Score","Confidence","Status","Reason"]} rows={plans.map(p=>[
    p.action,p.target,p.score,`${Math.round(p.confidence*100)}%`,<Badge tone={p.status==="APPLIED"?"good":p.status==="PROPOSED"?"warn":"neutral"}>{p.status}</Badge>,p.reason
   ])}/></Card></>:null}
 </Page>
}
