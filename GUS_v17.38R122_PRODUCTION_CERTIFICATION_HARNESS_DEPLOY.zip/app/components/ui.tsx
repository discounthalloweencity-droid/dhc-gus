import type { ReactNode } from "react";

export function Page({title,subtitle,children}:{title:string;subtitle?:string;children:ReactNode}) {
  return <main style={{maxWidth:1480,margin:"0 auto",padding:"28px 30px 70px"}}>
    <div style={{marginBottom:22}}><h1 style={{margin:0,fontSize:30}}>{title}</h1>{subtitle&&<p style={{margin:"7px 0 0",color:"#616161"}}>{subtitle}</p>}</div>
    {children}
  </main>;
}
export function Grid({children}:{children:ReactNode}) { return <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:14}}>{children}</div>; }
export function Card({children}:{children:ReactNode}) { return <section style={{background:"white",border:"1px solid #e3e3e3",borderRadius:12,padding:18,boxShadow:"0 1px 2px rgba(0,0,0,.04)"}}>{children}</section>; }
export function Metric({label,value,detail}:{label:string;value:string|number;detail?:string}) { return <Card><div style={{fontSize:13,color:"#616161"}}>{label}</div><div style={{fontSize:28,fontWeight:700,margin:"6px 0"}}>{value}</div>{detail&&<div style={{fontSize:12,color:"#777"}}>{detail}</div>}</Card>; }
export function Badge({children,tone="neutral"}:{children:ReactNode;tone?:"neutral"|"good"|"warn"|"bad"}) { const map={neutral:"#eef0f2",good:"#e5f4ea",warn:"#fff2d5",bad:"#ffe8e5"}; return <span style={{background:map[tone],padding:"3px 8px",borderRadius:999,fontSize:12,fontWeight:600}}>{children}</span>; }
export function Table({headers,rows}:{headers:string[];rows:ReactNode[][]}) { return <div style={{overflowX:"auto",background:"white",border:"1px solid #e3e3e3",borderRadius:12}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr>{headers.map(h=><th key={h} style={{textAlign:"left",fontSize:12,color:"#616161",padding:12,borderBottom:"1px solid #e3e3e3"}}>{h}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={i}>{r.map((c,j)=><td key={j} style={{padding:12,borderBottom:"1px solid #f1f1f1",fontSize:13,verticalAlign:"top"}}>{c}</td>)}</tr>)}</tbody></table></div>; }
