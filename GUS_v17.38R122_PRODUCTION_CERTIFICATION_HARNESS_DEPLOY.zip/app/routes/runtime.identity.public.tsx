// Stable production alias retained for deployment runbooks and smoke tests.
export {loader} from './runtime.identity';
