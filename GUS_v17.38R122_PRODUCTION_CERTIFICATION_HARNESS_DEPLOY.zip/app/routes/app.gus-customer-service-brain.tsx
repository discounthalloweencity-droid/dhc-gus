import type {LoaderFunctionArgs} from "react-router";
import {useLoaderData,Link} from "react-router";
import {authenticate} from "../shopify.server";
import {loadGusSurface} from "../services/gus-phase9.server";
import {GusPhase9Surface} from "../components/gus-phase9-surface";
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadGusSurface(session.shop,"customer-service-brain");}
export default function Surface(){const data=useLoaderData<typeof loader>();return <><GusPhase9Surface title="Customer-Service Brain" subtitle="Customer-service, support, returns, cancellation and fit knowledge available to Gus." data={data} mode="customer-service-brain"/><div style={{display:"flex",gap:12,flexWrap:"wrap",padding:"0 20px 24px"}}><Link to="/app/gus-concierge-health">Shopping Concierge Health →</Link><Link to="/app/gus-concierge-analytics">Shopping Concierge Analytics →</Link></div></>; }
