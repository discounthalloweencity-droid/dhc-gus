import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {useFetcher,useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {db} from '../db.server';
import {enqueueGusRequest,hasQueuedGusMessages,recoverQueuedGusMessages} from '../services/gus-chat-queue.server';
import {Page,Card,Badge} from '../components/ui';

import {safeAppAction} from '../services/safe-app-action.server';

function messageOf(error:unknown){return error instanceof Error?error.message:String(error);}

export async function loader({request}:LoaderFunctionArgs){
 const {session}=await authenticate.admin(request);
 try{
  const url=new URL(request.url);
  const convo=await db.gusConversation.findFirst({where:{shop:session.shop,status:'OPEN'},orderBy:{updatedAt:'desc'}});
  const messages=convo?await db.gusMessage.findMany({where:{conversationId:convo.id,shop:session.shop},orderBy:{createdAt:'asc'},take:url.searchParams.get('poll')==='1'?60:100}):[];
  recoverQueuedGusMessages(session.shop,messages);
  return {conversationId:convo?.id??null,messages,hasPending:hasQueuedGusMessages(messages),historyAvailable:true,historyWarning:null as string|null};
 }catch(error){
  console.warn('[gus-chat] conversation history unavailable; keeping live chat online',messageOf(error));
  return {conversationId:null,messages:[],hasPending:false,historyAvailable:false,historyWarning:'Conversation history is temporarily unavailable. Live Gus commands can still run.'};
 }
}

export async function action({request}:ActionFunctionArgs){return safeAppAction('gus',request,async()=>{
 const {session}=await authenticate.admin(request);
 const f=await request.formData();
 const message=String(f.get('message')||'').trim();
 const cid=Number(f.get('conversationId'));
 if(!message)return {ok:false,error:'Type a message for Gus.'};
 try{
  const queued=await enqueueGusRequest(session.shop,message,Number.isSafeInteger(cid)&&cid>0?cid:null);
  return {ok:true,queued:true,skipRevalidate:true,conversationId:queued.conversationId,message,historyWarning:null as string|null};
 }catch(error){
  console.error('[gus-chat] queue failed',messageOf(error));
  return {ok:false,skipRevalidate:true,error:`Gus could not queue that command: ${messageOf(error)}`};
 }
});}

export function shouldRevalidate({formMethod,defaultShouldRevalidate}:any){
 return formMethod&&String(formMethod).toUpperCase()!=='GET'?false:defaultShouldRevalidate;
}

export default function GusChat(){
 const initial=useLoaderData<typeof loader>();
 const sender=useFetcher<typeof action>();
 const replies=useFetcher<typeof loader>();
 const live=(replies.data??initial) as typeof initial;
 const actionData=sender.data;
 const busy=sender.state!=='idle';
 const conversationId=actionData?.ok?actionData.conversationId:live.conversationId;
 return <Page title="Talk to Gus" subtitle="Live store-side command interface for Discount Halloween City.">
  {!live.historyAvailable&&<div className="gus-flash gus-flash-bad"><strong>History recovery mode:</strong> {live.historyWarning}</div>}
  {actionData?.ok&&actionData.queued&&<div className="gus-flash gus-flash-good">Command queued. Gus is processing it in the background. Use Refresh replies when you want to pull the completed answer without navigating the Command Center.</div>}
  <div className="gus-chat-layout"><Card><div className="gus-chat-head"><div><h2>Gus</h2><p>Ask about live store status, pricing, SEO, suppliers, profit, changes or automation.</p></div><Badge tone={live.historyAvailable?'good':'warn'}>{live.historyAvailable?'CONNECTED':'LIVE / HISTORY DEGRADED'}</Badge></div>
  <div className="gus-chat-thread">{live.messages.length?live.messages.map(m=><div key={m.id} className={`gus-msg ${m.role==='USER'?'gus-msg-user':'gus-msg-gus'}`}><div className="gus-msg-role">{m.role==='USER'?'You':'Gus'}</div><div className="gus-msg-body">{m.content}</div></div>):<div className="gus-chat-empty"><strong>Gus is ready.</strong><p>Try “status”, “show pricing problems”, “check SEO”, “show profit”, “run Gus”, “scan catalog”, or “refresh executive priorities”.</p></div>}
  </div>
  <sender.Form method="post" className="gus-chat-form"><input type="hidden" name="conversationId" value={conversationId??''}/><textarea name="message" rows={3} maxLength={4000} placeholder="Tell Gus what you need…" required disabled={busy}/><button className="gus-run" type="submit" disabled={busy}>{busy?'Queuing…':'Send to Gus'}</button></sender.Form>{actionData&&!actionData.ok&&<div className="gus-flash gus-flash-bad">{actionData.error}</div>}
  <div style={{display:'flex',justifyContent:'flex-end',marginTop:10}}><button type="button" onClick={()=>replies.load('/app/gus?poll=1')} disabled={replies.state!=='idle'}>{replies.state==='idle'?'Refresh replies':'Refreshing…'}</button></div></Card>
  <aside className="gus-chat-side"><Card><h2>Quick commands</h2><p style={{marginTop:-6,fontSize:12,color:'#64748b'}}>Quick commands queue in the background and do not navigate or reload the full app shell.</p><div className="gus-command-chips">{['status','run Gus','show pricing problems','check SEO','check suppliers','show profit','what did you change?','refresh executive priorities','scan catalog'].map(x=><sender.Form method="post" key={x}><input type="hidden" name="conversationId" value={conversationId??''}/><input type="hidden" name="message" value={x}/><button type="submit" disabled={busy}>{x}</button></sender.Form>)}</div></Card><Card><h2>External bridge</h2><p>v0.16.50 includes a secured Gus bridge endpoint so an authorized external ChatGPT connector can query this same store-side brain later.</p><p><strong>Endpoint:</strong> /api/gus/bridge</p><p>Protected by GUS_BRIDGE_SECRET or the existing cron secret.</p></Card></aside></div>
 </Page>}
