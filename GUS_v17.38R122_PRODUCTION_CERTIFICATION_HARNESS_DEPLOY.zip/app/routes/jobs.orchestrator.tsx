import type {ActionFunctionArgs} from 'react-router';
import {runAutonomousHeartbeat} from '../services/runtime-orchestrator-pulse.server';
export async function action({request}:ActionFunctionArgs){
 const auth=request.headers.get('authorization')||'';
 if(!process.env.AUTHORITY_CRON_SECRET||auth!==`Bearer ${process.env.AUTHORITY_CRON_SECRET}`)return new Response('Unauthorized',{status:401});
 const shop=String(process.env.AUTHORITY_SHOP||'').trim().toLowerCase();if(!shop)return Response.json({ok:false,error:'AUTHORITY_SHOP missing'},{status:503});
 const result=await runAutonomousHeartbeat(shop,'EXTERNAL_CRON');
 return Response.json({ok:result.status!=='ERROR',browserRequired:false,coverage:'ALL_AUTONOMOUS_ENGINES_DUE',...result},{status:result.status==='ERROR'?503:200,headers:{'Cache-Control':'no-store'}});
}
