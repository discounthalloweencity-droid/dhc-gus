import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSupplierFulfillmentDashboard} from '../services/supplier-fulfillment-dashboard.server';
import {SupplierFulfillmentSurface} from '../components/supplier-fulfillment-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSupplierFulfillmentDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SupplierFulfillmentSurface title='Supplier Mapping' subtitle='Exact Shopify-variant-to-supplier mapping coverage and fulfillment ownership.' data={data} focus={['Every automated stock decision should resolve to the correct Shopify variant and supplier variant.','Flag products with partial mappings, duplicate supplier identities or unverified fulfillment ownership.','Never archive a product from incomplete supplier coverage.','Preserve supplier SKU, warehouse and destination-country context in mapping decisions.']}/>;}
