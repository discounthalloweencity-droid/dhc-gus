import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSupplierFulfillmentDashboard} from '../services/supplier-fulfillment-dashboard.server';
import {SupplierFulfillmentSurface} from '../components/supplier-fulfillment-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSupplierFulfillmentDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SupplierFulfillmentSurface title='Fulfillment Exceptions' subtitle='Orders and catalog conditions that require supplier, stock, mapping or shipping intervention.' data={data} focus={['Prioritize customer-impacting exceptions: unavailable ordered variants, supplier substitutions, mapping gaps and late-delivery risk.','Keep the original order selection visible while resolving supplier problems.','Escalate exceptions that cannot be resolved safely within Gus authority.','Write every corrective action to the existing audit and change history.']}/>;}
