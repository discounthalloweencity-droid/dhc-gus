import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData,Link} from 'react-router';
import {authenticate} from '../shopify.server';
import {autonomyControlPlaneSnapshot} from '../services/autonomous-control-plane.server';
import {Badge,Card,Grid,Metric,Page,Table} from '../components/ui';

export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return autonomyControlPlaneSnapshot(session.shop);}
const tone=(v:string)=>/HEALTHY|SUCCESS|ONLINE|RUNNING/i.test(v)?'good':/PAUSED|FAILED|DEAD|CRITICAL/i.test(v)?'bad':'warn';
export default function AutonomyControlPlane(){const d:any=useLoaderData<typeof loader>();return <Page title="Autonomy Control Plane" subtitle="Gus v0.16.50 — Always-on scheduler, priority queue, self-healing execution, dependency circuit breakers, measurement and exception-only ownership.">
 <Grid>
  <Metric label="Autonomy" value={d.automation?.running?'RUNNING':'STOPPED'} detail={d.automation?.running?'Continuous control loop enabled':'Use RUN / STOP to enable'}/>
  <Metric label="Scheduler" value={d.scheduler.healthy?'HEALTHY':'CHECK'} detail={d.scheduler.lastRun?`Last cycle ${new Date(d.scheduler.lastRun.startedAt).toLocaleString()}`:'No cycle recorded'}/>
  <Metric label="Dependency guard" value={d.incidents.state} detail={`${d.incidents.affectedSteps.length} engine steps affected`}/>
  <Metric label="Owner exceptions" value={d.counts.ownerApprovals+d.counts.ownerMissions} detail="Only consequential decisions should appear here"/>
 </Grid>
 <div style={{height:16}}/><Card><h2>Autonomous workload</h2><p>Gus continuously observes, diagnoses, prioritizes, acts, verifies, measures and learns. Safe work drains without owner approval. Repeated dependency failures pause only affected engines so a broken API cannot generate a feedback storm.</p><Grid><Metric label="Running" value={d.counts.active}/><Metric label="Queued / waiting" value={d.counts.queued}/><Metric label="Measuring" value={d.counts.measuring}/><Metric label="Auto-safe proposals" value={d.counts.autoSafe}/><Metric label="Approved actions" value={d.counts.approved}/><Metric label="Dead letter" value={d.counts.deadLetters}/></Grid></Card>
 <div style={{height:16}}/><Card><h2>24-hour proof</h2><Grid><Metric label="Verified changes" value={d.counts.verifiedChanges24h}/><Metric label="Rollbacks" value={d.counts.rollbacks24h}/><Metric label="Open findings" value={d.counts.openFindings}/><Metric label="Open runtime errors" value={d.counts.openErrors}/></Grid><p><Link to="/app/activity">Activity Log</Link> · <Link to="/app/seo-change-ledger">SEO Change Ledger</Link> · <Link to="/app/actions">Owner Exceptions</Link> · <Link to="/app/system-jobs">Jobs / Scheduler</Link></p></Card>
 <div style={{height:16}}/><Card><h2>Current prioritized missions</h2><Table headers={['Priority','Engine','State','Goal','Risk','Approval']} rows={[...d.active,...d.queued].slice(0,30).map((m:any)=>[m.priority,m.engine,<Badge tone={tone(m.state)}>{m.state}</Badge>,m.goal,m.riskLevel,m.approvalState])}/></Card>
 <div style={{height:16}}/><Card><h2>Measurement / learning</h2><Table headers={['Engine','State','Goal','Updated']} rows={d.measuring.map((m:any)=>[m.engine,<Badge tone="warn">{m.state}</Badge>,m.goal,new Date(m.updatedAt).toLocaleString()])}/></Card>
 <div style={{height:16}}/><Card><h2>Dead-letter / engineering recovery</h2>{d.deadLetters.length?<Table headers={['Engine','Goal','Retries','Updated']} rows={d.deadLetters.map((m:any)=>[m.engine,m.goal,`${m.retries}/${m.maxRetries}`,new Date(m.updatedAt).toLocaleString()])}/>:<p>No dead-letter missions.</p>}</Card>
 <div style={{height:16}}/><Card><h2>Dependency incidents</h2>{d.incidents.incidents.length?<Table headers={['State','Source','Occurrences','Affected steps','Last seen']} rows={d.incidents.incidents.map((x:any)=>[<Badge tone={tone(x.state)}>{x.state}</Badge>,x.source,x.occurrenceCount,x.steps.join(', '),new Date(x.lastSeenAt).toLocaleString()])}/>:<p><Badge tone="good">HEALTHY</Badge> No recent dependency circuit breakers are active.</p>}</Card>
 </Page>}
