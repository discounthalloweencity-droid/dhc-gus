import type { LoaderFunctionArgs } from "react-router";

function tokenFrom(request: Request) {
  return request.headers.get("x-dhc-bootstrap-token") || "";
}

export async function loader({ request }: LoaderFunctionArgs) {
  const expected = process.env.DHC_BOOTSTRAP_TOKEN || "";
  const supplied = tokenFrom(request);
  if (!expected || supplied !== expected) {
    return new Response("Unauthorized\n", { status: 401, headers: { "Cache-Control": "no-store" } });
  }

  const body = [
    "DHC Gus Production Runtime Diagnostic",
    `Generated: ${new Date().toISOString()}`,
    "Runtime: 0.16.50",
    "Status: READY",
    "Bootstrap handoff: complete",
    "The production runtime owns the port. Bootstrap-only install transcript is no longer live after successful handoff.",
    "If the app later reports an error, use System > Diagnostics and GoDaddy runtime logs.",
    "",
  ].join("\n");

  return new Response(body, {
    status: 200,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Content-Disposition": 'attachment; filename="GUS_INSTALL_LOG_SEND_TO_CHATGPT.txt"',
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
