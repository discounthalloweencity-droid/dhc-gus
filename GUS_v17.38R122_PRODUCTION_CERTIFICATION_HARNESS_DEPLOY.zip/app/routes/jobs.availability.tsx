import type {ActionFunctionArgs} from 'react-router';
import {unauthenticated} from '../shopify.server';
import {db} from '../db.server';
import {automationState} from '../services/automation-control.server';
import {scanAvailability} from '../services/availability.server';
import {captureAndRespond} from '../services/error-capture.server';
export async function action({request}:ActionFunctionArgs){
 const auth=request.headers.get('authorization')||'';
 if(!process.env.AUTHORITY_CRON_SECRET||auth!==`Bearer ${process.env.AUTHORITY_CRON_SECRET}`)return new Response('Unauthorized',{status:401});
 const shop=process.env.AUTHORITY_SHOP;if(!shop)return new Response('Store not configured',{status:503});
 try{
  const master=await automationState(shop);if(!master?.running)return Response.json({status:'STOPPED'});
  const control=await db.availabilityControl.findUnique({where:{shop}});if(!control?.running)return Response.json({status:'STOPPED'});
  const {admin}=await unauthenticated.admin(shop);
  const results=await scanAvailability(admin,shop,process.env.AUTHORITY_LIVE_WRITES_ENABLED==='true'&&control.autoArchive);
  return Response.json({status:'COMPLETE',scanned:results.length,results});
 }catch(error){return captureAndRespond(error,{shop,source:'SCHEDULED_JOB',route:'/jobs/availability',jobType:'AVAILABILITY_SCAN'});}
}
