import type { LoaderFunctionArgs } from "react-router";
import { redirect } from "react-router";

export async function loader({ request }: LoaderFunctionArgs) {
  const url = new URL(request.url);
  const target = new URL('/app', url.origin);
  for (const [key, value] of url.searchParams) target.searchParams.append(key, value);
  return redirect(target.pathname + target.search);
}

export default function LegacyCommandCenterEntry() { return null; }
