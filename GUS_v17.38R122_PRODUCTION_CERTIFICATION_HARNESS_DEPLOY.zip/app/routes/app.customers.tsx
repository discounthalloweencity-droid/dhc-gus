import type { LoaderFunctionArgs } from "react-router";
import { useLoaderData } from "react-router";
import { authenticate } from "../shopify.server";
import { customerCommandSnapshot } from "../services/customer-command.server";
import { Page, Card, Table, Badge } from "../components/ui";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  return customerCommandSnapshot(session.shop);
}
export default function Customers() {
  const d = useLoaderData<typeof loader>();
  const top = Object.entries(d.byIssue).sort((a,b)=>b[1]-a[1]).slice(0,8);
  return <Page title="Customer Dashboard" subtitle="Privacy-minimized customer operations across support, orders, and Gus conversations.">
    <div className="grid4">
      <Card><h3>Open support cases</h3><strong>{d.openCases.length}</strong></Card>
      <Card><h3>Order snapshots</h3><strong>{d.orderCount}</strong></Card>
      <Card><h3>Recent AOV</h3><strong>{d.avgOrderValue==null?'Unknown':`$${d.avgOrderValue.toFixed(2)}`}</strong></Card>
      <Card><h3>Gus conversations</h3><strong>{d.conversations}</strong></Card>
    </div>
    <Card><h2>Customer operating rules</h2><p>Customer trust comes first. Gus uses verified order evidence for order-specific help, avoids storing raw contact data in support cases, and does not infer individual browsing behavior or customer attributes that are not directly supported.</p></Card>
    <Table headers={['Issue type','Cases']} rows={top.map(([k,v])=>[k,v])}/>
    <Table headers={['Case','Order','Issue','Status','Priority','Created']} rows={d.cases.slice(0,25).map(c=>[c.caseKey,c.orderName||'—',c.issueType,<Badge tone={c.status==='OPEN'?'warn':'good'}>{c.status}</Badge>,c.priority,c.createdAt.toLocaleString()])}/>
  </Page>;
}
