import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='SEO Issues' subtitle='Central queue for SEO, discovery, indexing, metadata, schema and search-quality exceptions.' data={data} focus={['Consolidate SEO findings into a prioritized repair queue instead of silently applying broad uncontrolled edits.', 'Auto-fix only high-confidence reversible issues within Gus guardrails.', 'Escalate conflicts involving licensing, missing supplier truth, major URL changes or material revenue risk.', 'Keep before/after evidence and change history for every automated SEO repair.']}/>;}
