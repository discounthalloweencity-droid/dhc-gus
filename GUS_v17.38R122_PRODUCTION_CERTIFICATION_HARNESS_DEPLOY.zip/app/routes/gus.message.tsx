import type {ActionFunctionArgs} from 'react-router';
import {resolveGusStorefrontContext,gusCorsHeaders} from '../services/gus-storefront-auth.server';
import {handleGusMessage} from '../services/gus-concierge-api.server';
export async function action({request}:ActionFunctionArgs){try{const {admin,shop}=await resolveGusStorefrontContext(request);const input=await request.json();return Response.json(await handleGusMessage(admin,shop,input),{headers:gusCorsHeaders()});}catch(e:any){if(e instanceof Response)return e;return Response.json({ok:false,error:e?.message||'Message unavailable',fallback:{type:'SHOPIFY_SEARCH_OR_SUPPORT',search_url:'/search',support_url:'/apps/gus-support'}},{status:400,headers:gusCorsHeaders()});}}
