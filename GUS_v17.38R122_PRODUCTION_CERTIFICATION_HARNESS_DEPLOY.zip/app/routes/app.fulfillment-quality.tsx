import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {Form,useActionData,useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {safeAppAction} from '../services/safe-app-action.server';
import {latestFulfillmentProductQuality,runFulfillmentProductQuality} from '../services/fulfillment-product-quality.server';
import {Page,Card,Grid,Metric,Table,Badge} from '../components/ui';

export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return {latest:await latestFulfillmentProductQuality(session.shop)};}
export async function action({request}:ActionFunctionArgs){return safeAppAction('fulfillment-quality',request,async()=>{const {admin,session}=await authenticate.admin(request);return {ok:true,result:await runFulfillmentProductQuality(admin,session.shop,true)};});}
export default function FulfillmentQuality(){const d:any=useLoaderData<typeof loader>(),a:any=useActionData<typeof action>();const x=a?.result||d.latest?.details||{},products=x.products||[];return <Page title="Fulfillment Quality" subtitle="Finds long-lead products and archives only when repeated or verified evidence is strong enough. Runtime v0.16.50.">
  <Card><p>One bad shipment can trigger WATCH or DEPRIORITIZE. Automatic archive requires repeated severe operational evidence or verified supplier lead-time failure. If a reliable alternate source exists, Gus prefers re-sourcing.</p><Form method="post"><button type="submit">Run fulfillment quality now</button></Form></Card>
  <div style={{height:14}}/>
  <Grid><Metric label="Products scanned" value={x.productsScanned||0}/><Metric label="Auto-archive risk" value={x.counts?.AUTO_ARCHIVE||0}/><Metric label="Re-source" value={x.counts?.RESOURCE_CANDIDATE||0}/><Metric label="Archived" value={x.autoArchived||0}/></Grid>
  <div style={{height:14}}/>
  <Table headers={['Product','Supplier','Orders','Delayed','Severe','Median first scan','Decision','Action']} rows={products.map((p:any)=>[p.title,p.vendors?.join(', ')||'—',String(p.orders),String(p.delayedOrders),String(p.severeOrders),p.medianFirstScanHours==null?'—':`${Math.round(p.medianFirstScanHours)}h`,<Badge tone={p.decision==='AUTO_ARCHIVE'?'bad':['ARCHIVE_CANDIDATE','DEPRIORITIZE'].includes(p.decision)?'warn':'neutral'}>{p.decision}</Badge>,p.action||'—'])}/>
  <div style={{height:14}}/><Card><p>Historical window: {x.windowDays||60} days. Carrier tracking evidence: <strong>{x.trackingProviderConfigured?'enabled':'not configured'}</strong>.</p></Card>
</Page>;}
