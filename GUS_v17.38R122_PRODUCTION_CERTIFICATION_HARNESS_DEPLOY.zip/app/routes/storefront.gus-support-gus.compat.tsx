// Compatibility adapter for the historically deployed Shopify app-proxy target.
// Shopify storefront /apps/gus-support/gus/* may still forward to
// /storefront/gus-support/gus/* on an older installed app version.
// Reuse the canonical signed app-proxy handler; do not duplicate Gus logic.
export {loader, action} from './support-center-gus-proxy';
