import type { LoaderFunctionArgs } from "react-router";
import { useLoaderData } from "react-router";
import { authenticate } from "../shopify.server";
import { db } from "../db.server";
import { safePageData } from "../services/page-data-safety.server";
import { Badge, Page, Table } from "../components/ui";

export async function loader({request}:LoaderFunctionArgs){
  const {session}=await authenticate.admin(request);
  const rows=await safePageData("products","snapshots",db.productSnapshot.findMany({where:{shop:session.shop},orderBy:{capturedAt:"desc"},take:250}),[] as any[]);
  return {rows};
}
export default function Products(){const {rows}=useLoaderData<typeof loader>();return <Page title="Product Intelligence" subtitle="Latest variant-level profitability, shipping and SEO snapshots."><Table headers={["Product","Price","Recommended","Margin","Ship","SEO","Status"]} rows={rows.map(r=>[
  r.title,
  r.price==null?"—":`$${r.price.toFixed(2)}`,
  r.recommendedPrice==null?"—":`$${r.recommendedPrice.toFixed(2)}`,
  r.margin==null?"Unknown":<Badge tone={r.margin>=.30?"good":"bad"}>{(r.margin*100).toFixed(1)}%</Badge>,
  r.supplierShippingDays==null?<Badge tone="warn">Missing</Badge>:<Badge tone={r.supplierShippingDays<=12?"good":"bad"}>{r.supplierShippingDays}d</Badge>,
  r.seoScore??"—",
  r.status
])}/></Page>}
