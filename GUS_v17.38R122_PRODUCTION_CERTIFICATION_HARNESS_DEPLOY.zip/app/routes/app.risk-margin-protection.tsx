import type {LoaderFunctionArgs} from "react-router";
import {useLoaderData} from "react-router";
import {authenticate} from "../shopify.server";
import {loadRiskControl} from "../services/risk-control-phase11.server";
import {RiskControlPhase11Surface} from "../components/risk-control-phase11-surface";
import {Page} from "../components/ui";
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadRiskControl(session.shop,"margin");}
export default function Route(){const d=useLoaderData<typeof loader>();return <Page title="Margin Protection" subtitle="Profit guardrails using verified landed-cost evidence, minimum margin and DHC price floors."><RiskControlPhase11Surface d={d} mode="margin"/></Page>;}
