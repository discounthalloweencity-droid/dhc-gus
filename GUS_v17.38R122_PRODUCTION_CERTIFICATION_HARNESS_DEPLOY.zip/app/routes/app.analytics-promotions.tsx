import type {LoaderFunctionArgs} from "react-router";
import {useLoaderData} from "react-router";
import {authenticate} from "../shopify.server";
import {loadAnalyticsSurface} from "../services/analytics-phase10.server";
import {Page} from "../components/ui";
import {AnalyticsPhase10Surface} from "../components/analytics-phase10-surface";
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadAnalyticsSurface(session.shop,"promotions");}
export default function Route(){const d=useLoaderData<typeof loader>();return <Page title="Promotions" subtitle="Promotion and markdown analytics with observed attribution only."><AnalyticsPhase10Surface d={d} mode="promotions"/></Page>;}
