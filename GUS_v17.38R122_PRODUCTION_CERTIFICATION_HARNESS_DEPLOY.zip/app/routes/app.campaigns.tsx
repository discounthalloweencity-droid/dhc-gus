import type { LoaderFunctionArgs } from "react-router";
import { useLoaderData } from "react-router";
import { authenticate } from "../shopify.server";
import { marketingCommandSnapshot } from "../services/marketing-command.server";
import { Page } from "../components/ui";
import { MarketingGrowthSurface } from "../components/marketing-growth-surface";
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return marketingCommandSnapshot(session.shop);}
export default function Route(){const d=useLoaderData<typeof loader>();return <Page title="Campaigns" subtitle="Campaign operating view across paid media and promotion proposals."><MarketingGrowthSurface kind="campaigns" d={d}/></Page>;}
