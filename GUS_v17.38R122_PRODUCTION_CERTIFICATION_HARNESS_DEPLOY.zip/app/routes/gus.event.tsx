import type {ActionFunctionArgs} from 'react-router';
import {resolveGusStorefrontContext,gusCorsHeaders} from '../services/gus-storefront-auth.server';
import {handleGusEvent} from '../services/gus-concierge-api.server';
export async function action({request}:ActionFunctionArgs){try{const {shop}=await resolveGusStorefrontContext(request);const input=await request.json();return Response.json(await handleGusEvent(shop,input),{headers:gusCorsHeaders()});}catch(e:any){if(e instanceof Response)return e;return Response.json({ok:false,error:e?.message||'Event unavailable'},{status:400,headers:gusCorsHeaders()});}}
