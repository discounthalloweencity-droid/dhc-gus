import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {Form,useActionData,useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {strikeKeywordSnapshot} from '../services/strike-keyword.server';
import {runStrikeKeywordEngineCycle} from '../services/strike-keyword-engine.server';
import {strikeLearningSummary} from '../services/strike-keyword-learning.server';
import {Badge,Card,Grid,Metric,Page,Table} from '../components/ui';

import {safeAppAction} from '../services/safe-app-action.server';
import {createManualGrowthActionToken,manualGrowthActionContext} from '../services/manual-growth-action-auth.server';

export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);const [snapshot,learning]=await Promise.all([strikeKeywordSnapshot(session.shop),strikeLearningSummary(session.shop)]);return {...snapshot,learning,manualToken:createManualGrowthActionToken(session.shop,'/app/strike-keywords')};}
export async function action({request}:ActionFunctionArgs){return safeAppAction('strike-keywords',request,async()=>{const f=await request.clone().formData();const {admin,shop}=await manualGrowthActionContext(request,f,'/app/strike-keywords');const intent=String(f.get('intent')||'cycle');const opts=intent==='refresh'?{forceDiscovery:true,diagnosisLimit:2,attackLimit:0}:{forceDiscovery:false,diagnosisLimit:3,attackLimit:1};setImmediate(()=>{void runStrikeKeywordEngineCycle(admin,shop,opts).catch(error=>console.error('[strike-keyword] engine cycle failed',error instanceof Error?error.message:error));});return {ok:true,message:intent==='refresh'?'Strike discovery refresh queued.':'Strike engine cycle queued: diagnose → guard → safe attack/approval → cooldown/learn.'};});}
const fmt=(n:number|null|undefined,d=1)=>n==null?'—':Number(n).toLocaleString(undefined,{maximumFractionDigits:d});
const pct=(n:number|null|undefined)=>n==null?'—':`${(Number(n)*100).toFixed(2)}%`;
const tone=(status:string)=>status==='#1'||status==='TOP_3'||status==='DEFENDING'?'good':status==='REGRESSION'?'bad':status==='STALLED'?'warn':'neutral';
export default function StrikeKeywords(){const d=useLoaderData<typeof loader>(),a=useActionData<typeof action>();const targets=(d.missions||[]).map((m:any)=>({...m.evidence,missionId:m.id,missionState:m.state,opportunityScore:m.score,priority:m.priority,expectedValue:m.expectedValue,updatedAt:m.updatedAt}));const counts={total:targets.length,tierS:targets.filter((x:any)=>x.tier==='S').length,rapid:targets.filter((x:any)=>x.attackGroup==='RAPID_STRIKE').length,top3:targets.filter((x:any)=>['TOP_3','#1','DEFENDING'].includes(x.status)).length,diagnosed:targets.filter((x:any)=>x.diagnosis).length,cooldown:targets.filter((x:any)=>x.missionState==='COOLDOWN').length,blocked:targets.filter((x:any)=>String(x.nextAction||'').includes('REVIEW')||x.diagnosis?.technical?.status==='FAIL').length};return <Page title="Strike Keywords" subtitle="Full Strike Engine + SEO Domination: discover, diagnose, safely attack, build topical authority, measure, learn and defend commercially valuable organic rankings.">
 <div className="authority-toolbar" style={{display:'flex',gap:10,flexWrap:'wrap'}}><Form method="post"><input type="hidden" name="_gusManualToken" value={d.manualToken||''}/><button name="intent" value="cycle" className="authority-button authority-primary">Run Strike engine</button></Form><Form method="post"><input type="hidden" name="_gusManualToken" value={d.manualToken||''}/><button name="intent" value="refresh" className="authority-button">Refresh discovery only</button></Form></div>
 {a&&<div className={a.ok===false?"gus-flash gus-flash-bad":"gus-flash gus-flash-good"}>{a.ok===false?(a.error||a.message):a.message}</div>}
 <Grid><Metric label="Strike portfolio" value={counts.total}/><Metric label="Tier S · positions 4–10" value={counts.tierS}/><Metric label="Rapid strikes" value={counts.rapid}/><Metric label="Diagnosed" value={counts.diagnosed}/><Metric label="Top 3 / defend" value={counts.top3}/><Metric label="Cooldown" value={counts.cooldown}/></Grid>
 <div style={{height:16}}/><Card><h2>Execution guardrails</h2><p><Badge tone="good">EVIDENCE FIRST</Badge> Diagnosis is read-only. Store-changing metadata actions require a supported Shopify product/collection destination, technical certainty, intent fit, sufficient assortment, spam risk below the block threshold, before-state capture and readback-capable ActionProposal execution.</p><p>Safe reversible metadata writes run automatically when <code>AUTHORITY_LIVE_WRITES_ENABLED=true</code>, Shopify Autopilot is active, and Gus is in RUN mode. <code>GUS_SEO_AUTONOMOUS_WRITES_ENABLED=false</code> is the emergency kill switch. The older <code>GUS_STRIKE_AUTO_WRITES_ENABLED</code> setting is retained only for compatibility and no longer blocks the unified SEO autonomy policy. High-risk structural or external actions still require owner approval.</p><p>Top-3 targets enter <strong>DEFEND_LOCK</strong>. SERP/backlink evidence stays unavailable rather than fabricated when a live provider is not configured.</p><p>The same cycle now feeds Topical Domination, bounded technical crawling, indexation review, internal-authority mapping, content gaps, page experience, DHC CTR learning, organic revenue attribution, original-data assets and approval-gated digital PR. See <a href="/app/seo-domination">SEO Domination</a>.</p></Card>
 <div style={{height:16}}/><Card><h2>Strike portfolio</h2>{targets.length?<Table headers={['Keyword','Status','Tier','Position','7d / prior','Impressions','CTR','Preferred destination','Diagnosis','Difficulty / authority','Action / cooldown','Economics']} rows={targets.slice(0,100).map((x:any)=>[
   <div><strong>{x.query}</strong><div style={{fontSize:11,color:'#777'}}>{x.intent} · {x.diagnosis?.target?.type||'destination pending'}</div></div>,
   <div><Badge tone={tone(x.status)}>{x.status||'DISCOVERED'}</Badge><div style={{fontSize:11,color:'#777'}}>{x.missionState}</div></div>,
   <div><strong>{x.tier}</strong><div style={{fontSize:11,color:'#777'}}>{x.attackGroup}</div></div>,
   fmt(x.position),
   <div>{fmt(x.position7)} / {fmt(x.previous7)}<div style={{fontSize:11,color:'#777'}}>{x.momentum||'—'}</div></div>,
   fmt(x.impressions,0),pct(x.ctr),
   <a href={x.preferredPage} target="_blank" rel="noreferrer">Preferred destination ↗</a>,
   <div>{x.diagnosis?<><Badge tone={x.diagnosis.technical?.status==='FAIL'?'bad':x.diagnosis.technical?.status==='PASS'?'good':'warn'}>{x.diagnosis.technical?.status||'UNKNOWN'}</Badge><div style={{fontSize:11,color:'#777'}}>{x.diagnosis.intentFit} · SERP {x.diagnosis.serp?.state}</div></>:'Pending'}</div>,
   <div>{x.numberOneDifficulty==null?'—':`${fmt(x.numberOneDifficulty,0)}/100`}<div style={{fontSize:11,color:'#777'}}>{x.difficultyState||'PENDING'} · {x.authorityGap||'UNKNOWN'}</div></div>,
   <div><strong>{x.nextAction||'ANALYZE'}</strong><div style={{fontSize:11,color:'#777'}}>{x.missionState==='COOLDOWN'?'14–28 day measurement window':x.diagnosis?.internalAuthority?.orphanRisk?'internal-link risk detected':'guarded'}</div></div>,
   <div>{x.expectedValue==null?'Evidence incomplete':`Top-3 ≈ $${fmt(x.expectedValue,0)}`}<div style={{fontSize:11,color:'#777'}}>{x.knownMargin==null?'margin unknown':`${(x.knownMargin*100).toFixed(1)}% margin`}</div></div>
 ])}/>:<p>No Strike portfolio exists yet. Run Search Console discovery first.</p>}</Card>
 <div style={{height:16}}/><Card><h2>Winner / failure memory</h2>{d.learning?.length?<Table headers={['Keyword','Learning','Outcome']} rows={d.learning.slice(0,20).map((x:any)=>[x.query||`Mission ${x.missionId}`,x.lesson,x.outcome?.result||'—'])}/>:<p>No completed Strike experiments yet. Gus will populate this after guarded cooldown measurement.</p>}</Card>
 </Page>;}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
