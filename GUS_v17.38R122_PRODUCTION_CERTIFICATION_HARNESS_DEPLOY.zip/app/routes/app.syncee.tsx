import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSupplierFulfillmentDashboard} from '../services/supplier-fulfillment-dashboard.server';
import {SupplierFulfillmentSurface} from '../components/supplier-fulfillment-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSupplierFulfillmentDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SupplierFulfillmentSurface title='Syncee' subtitle='Syncee supplier operations for licensed and US-shipping inventory, mappings and fulfillment evidence.' data={data} focus={['Preserve licensed product identity and supplier provenance.','Keep Syncee stock, warehouse and delivery evidence variant-specific.','Use US-shipping advantage in merchandising only when the warehouse evidence supports it.','Do not infer availability from stale or missing feeds.']} supplier='SYNCEE'/>;}
