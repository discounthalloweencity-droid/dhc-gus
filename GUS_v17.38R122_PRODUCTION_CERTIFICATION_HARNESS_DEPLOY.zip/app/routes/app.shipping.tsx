import type {LoaderFunctionArgs} from 'react-router';
import {Link,useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {db} from '../db.server';
import {safePageData} from '../services/page-data-safety.server';
import {Badge,Grid,Metric,Page,Table} from '../components/ui';
export async function loader({request}:LoaderFunctionArgs){
  const {session}=await authenticate.admin(request);const shop=session.shop;
  const [links,slow,missing,obs]=await Promise.all([
    safePageData('shipping','supplier links',db.supplierVariantLink.count({where:{shop,enabled:true}}),0),
    safePageData('shipping','slow findings',db.finding.count({where:{shop,status:'OPEN',code:'SHIP_OVER_LIMIT'}}),0),
    safePageData('shipping','missing evidence',db.finding.count({where:{shop,status:'OPEN',code:'SHIP_EVIDENCE_MISSING'}}),0),
    safePageData('shipping','availability observations',db.availabilityObservation.findMany({where:{link:{is:{shop}}},include:{link:true},orderBy:{verifiedAt:'desc'},take:150}),[] as any[])
  ]);
  return {links,slow,missing,obs,adapters:{cj:!!process.env.CJ_ACCESS_TOKEN,dsers:!!process.env.DSERS_SUPPLIER_FEED_URL,aliexpressReplacement:!!process.env.ALIEXPRESS_REPLACEMENT_FEED_URL,syncee:!!process.env.SYNCEE_SUPPLIER_FEED_URL}};
}
export default function Shipping(){const d=useLoaderData<typeof loader>();return <Page title="Shipping & Suppliers" subtitle="Exact variant supplier mapping, stock evidence and customer-delivery risk intelligence. Shopify zero inventory is never treated as dropship stockout proof by itself."><div className="authority-toolbar"><Link className="authority-button authority-primary" to="/app">← Command Center</Link><Link className="authority-button" to="/app/suppliers">Supplier evidence</Link><Link className="authority-button" to="/app/availability">Availability decisions</Link></div><Grid><Metric label="Mapped supplier variants" value={d.links}/><Metric label="Slow shipping alerts" value={d.slow}/><Metric label="Missing ship evidence" value={d.missing}/><Metric label="Live adapters" value={[d.adapters.cj,d.adapters.dsers,d.adapters.syncee].filter(Boolean).length} detail={`CJ ${d.adapters.cj?'on':'off'} · DSers ${d.adapters.dsers?'on':'off'} · Syncee ${d.adapters.syncee?'on':'off'}`}/></Grid><div style={{height:18}}/><Table headers={['Supplier','Variant','Stock status','Qty','Delivery days','Verified']} rows={d.obs.map(o=>[o.link.supplier,o.link.variantGid,<Badge tone={o.status==='IN_STOCK'?'good':o.status==='OUT_OF_STOCK'?'bad':'warn'}>{o.status}</Badge>,o.quantity??'—',o.deliveryMaxDays??o.deliveryMinDays??'—',new Date(o.verifiedAt).toLocaleString()])}/></Page>}
