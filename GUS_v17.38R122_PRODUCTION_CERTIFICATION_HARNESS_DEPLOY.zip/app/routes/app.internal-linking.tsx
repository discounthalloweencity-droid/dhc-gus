import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='Internal Linking' subtitle='Internal-link architecture that moves authority and shoppers between products, collections, themes and evergreen content.' data={data} focus={['Build useful links from strong collection and content pages toward priority commercial pages.', 'Use contextual anchors that describe the destination rather than repetitive keyword stuffing.', 'Strengthen orphan and underlinked products without flooding every page with links.', 'Coordinate links with merchandising, Complete the Look, Spooky All Year and seasonal intent.']}/>;}
