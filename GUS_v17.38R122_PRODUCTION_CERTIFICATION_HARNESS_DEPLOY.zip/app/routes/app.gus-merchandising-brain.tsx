import type {LoaderFunctionArgs} from "react-router";
import {useLoaderData} from "react-router";
import {authenticate} from "../shopify.server";
import {loadGusSurface} from "../services/gus-phase9.server";
import {GusPhase9Surface} from "../components/gus-phase9-surface";
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadGusSurface(session.shop,"merch-brain");}
export default function Surface(){const data=useLoaderData<typeof loader>();return <GusPhase9Surface title="Merchandising Brain" subtitle="Merchandising, collection, conversion and assortment knowledge used by Gus." data={data} mode="merch-brain"/>;}
