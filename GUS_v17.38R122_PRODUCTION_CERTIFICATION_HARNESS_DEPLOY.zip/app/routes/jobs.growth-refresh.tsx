import type {LoaderFunctionArgs} from 'react-router';
import {automationState} from '../services/automation-control.server';
import {refreshGa4,refreshGa4Funnel,refreshGa4Lifecycle,refreshSearchConsole} from '../services/google-growth.server';

export async function loader({request}:LoaderFunctionArgs){
 const auth=request.headers.get('authorization')||'';
 if(!process.env.AUTHORITY_CRON_SECRET||auth!==`Bearer ${process.env.AUTHORITY_CRON_SECRET}`)throw new Response('Unauthorized',{status:401});
 const shop=process.env.AUTHORITY_SHOP;if(!shop)throw new Response('AUTHORITY_SHOP missing',{status:503});
 const state=await automationState(shop);
 if(!state?.running)return Response.json({status:'STOPPED'});
 // Evidence refresh is read-only and should not require AUTHORITY_LIVE_WRITES_ENABLED.
 const end=new Date();end.setUTCDate(end.getUTCDate()-1);const start=new Date(end);start.setUTCDate(start.getUTCDate()-27);const f=(d:Date)=>d.toISOString().slice(0,10);
 const [gsc,ga4,funnel,lifecycle]=await Promise.allSettled([refreshSearchConsole(shop,f(start),f(end)),refreshGa4(shop,f(start),f(end)),refreshGa4Funnel(shop,f(start),f(end)),refreshGa4Lifecycle(shop,f(start),f(end))]);
 return Response.json({shop,gsc:gsc.status==='fulfilled'?gsc.value:{error:String(gsc.reason?.message||gsc.reason)},ga4:ga4.status==='fulfilled'?ga4.value:{error:String(ga4.reason?.message||ga4.reason)},funnel:funnel.status==='fulfilled'?funnel.value:{error:String(funnel.reason?.message||funnel.reason)},lifecycle:lifecycle.status==='fulfilled'?lifecycle.value:{error:String(lifecycle.reason?.message||lifecycle.reason)}});
}
