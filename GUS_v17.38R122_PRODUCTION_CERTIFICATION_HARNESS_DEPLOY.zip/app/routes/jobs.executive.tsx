import type {ActionFunctionArgs} from 'react-router';
import {automationState} from '../services/automation-control.server';
import {refreshExecutivePlan} from '../services/executive.server';
import {captureAndRespond} from '../services/error-capture.server';
export async function action({request}:ActionFunctionArgs){
 const auth=request.headers.get('authorization')||''; if(!process.env.AUTHORITY_CRON_SECRET||auth!==`Bearer ${process.env.AUTHORITY_CRON_SECRET}`)return new Response('Unauthorized',{status:401});
 const shop=process.env.AUTHORITY_SHOP;if(!shop)return new Response('AUTHORITY_SHOP missing',{status:503});
 try{const master=await automationState(shop);if(!master?.running)return Response.json({status:'STOPPED'});return Response.json({status:'OK',...(await refreshExecutivePlan(shop))});}
 catch(error){return captureAndRespond(error,{shop,source:'SCHEDULED_JOB',route:'/jobs/executive',jobType:'EXECUTIVE_LOOP'});}
}
