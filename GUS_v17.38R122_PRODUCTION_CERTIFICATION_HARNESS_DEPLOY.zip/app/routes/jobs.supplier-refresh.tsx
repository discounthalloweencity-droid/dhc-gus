import type {ActionFunctionArgs} from 'react-router';
import {refreshAliExpressReplacementCandidates,refreshDsers,refreshSyncee} from '../services/supplier-adapters.server';
import {unauthenticated} from '../shopify.server';
import {db} from '../db.server';
import {automationState} from '../services/automation-control.server';
import {refreshCjAvailability} from '../services/supplier-feed.server';
import {captureAndRespond} from '../services/error-capture.server';
export async function action({request}:ActionFunctionArgs){
 const auth=request.headers.get('authorization')||'';
 if(!process.env.AUTHORITY_CRON_SECRET||auth!==`Bearer ${process.env.AUTHORITY_CRON_SECRET}`)return new Response('Unauthorized',{status:401});
 const shop=process.env.AUTHORITY_SHOP;if(!shop)return new Response('Store not configured',{status:503});
 try{
  const master=await automationState(shop);if(!master?.running)return Response.json({status:'STOPPED'});
  const control=await db.availabilityControl.findUnique({where:{shop}});if(!control?.running)return Response.json({status:'STOPPED'});
  const {admin}=await unauthenticated.admin(shop);
  const cj=await refreshCjAvailability(admin,shop);
  const adapters:any={};
  if(process.env.DSERS_SUPPLIER_FEED_URL)adapters.dsers=await refreshDsers(shop);
  if(process.env.ALIEXPRESS_REPLACEMENT_FEED_URL)adapters.aliexpressReplacements=await refreshAliExpressReplacementCandidates(shop);
  if(process.env.SYNCEE_SUPPLIER_FEED_URL)adapters.syncee=await refreshSyncee(shop);
  return Response.json({cj,adapters});
 }catch(error){return captureAndRespond(error,{shop,source:'SCHEDULED_JOB',route:'/jobs/supplier-refresh',jobType:'SUPPLIER_REFRESH'});}
}