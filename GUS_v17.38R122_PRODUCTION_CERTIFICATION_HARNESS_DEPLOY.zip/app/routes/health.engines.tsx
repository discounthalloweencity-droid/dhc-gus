import type {LoaderFunctionArgs} from 'react-router';
import {unauthenticated} from '../shopify.server';
import {runEngineCertificationLab} from '../services/engine-certification.server';
export async function loader({request}:LoaderFunctionArgs){
 const secret=process.env.GUS_HEALTH_TOKEN||process.env.AUTHORITY_CRON_SECRET;const auth=request.headers.get('authorization')||'';
 if(!secret||auth!==`Bearer ${secret}`)return new Response('Unauthorized',{status:401,headers:{'Cache-Control':'no-store'}});
 const shop=process.env.AUTHORITY_SHOP;if(!shop)return Response.json({ok:false,error:'AUTHORITY_SHOP missing'},{status:503,headers:{'Cache-Control':'no-store'}});
 const engineKey=new URL(request.url).searchParams.get('engine')||undefined;
 try{const {admin}=await unauthenticated.admin(shop);const report=await runEngineCertificationLab(admin,shop,{engineKey,persist:false,source:'HEALTH_ENGINE_CERT'});const failed=report.summary.FAILED>0;return Response.json({ok:!failed,...report},{status:failed?503:200,headers:{'Cache-Control':'no-store'}});}catch(e:any){return Response.json({ok:false,error:String(e?.message||e)},{status:503,headers:{'Cache-Control':'no-store'}});}
}
