import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='Collection SEO' subtitle='Collection-level search architecture, landing-page quality, hierarchy, intent coverage and internal discovery.' data={data} focus={['Map one clear shopper intent to each collection and prevent gender/category contamination.', 'Improve collection titles, descriptions, headings, product ordering and contextual internal links.', 'Avoid thin duplicate collections and competing pages targeting the same search intent.', 'Preserve merchandising quality while strengthening organic landing pages.']}/>;}
