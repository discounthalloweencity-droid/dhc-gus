import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='Search Console' subtitle='Google Search Console operating surface for clicks, impressions, CTR, queries, pages and indexing evidence.' data={data} focus={['Use Search Console as the source of truth for Google organic query/page performance when connected.', 'Separate ranking opportunity from traffic opportunity using impressions, position, CTR and conversion context.', 'Surface pages losing visibility and queries sitting near page-one thresholds.', 'Until Search Console evidence is connected, performance metrics remain unavailable rather than estimated.']}/>;}
