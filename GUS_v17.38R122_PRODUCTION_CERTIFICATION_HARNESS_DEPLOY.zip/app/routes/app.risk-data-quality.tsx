import type {LoaderFunctionArgs} from "react-router";
import {useLoaderData} from "react-router";
import {authenticate} from "../shopify.server";
import {loadRiskControl} from "../services/risk-control-phase11.server";
import {RiskControlPhase11Surface} from "../components/risk-control-phase11-surface";
import {Page} from "../components/ui";
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadRiskControl(session.shop,"data");}
export default function Route(){const d=useLoaderData<typeof loader>();return <Page title="Data Quality" subtitle="Evidence completeness for costs, supplier coverage and catalog decisions; unknown data remains unknown."><RiskControlPhase11Surface d={d} mode="data"/></Page>;}
