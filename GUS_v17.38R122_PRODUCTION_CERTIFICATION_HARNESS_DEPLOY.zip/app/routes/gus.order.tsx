import type {ActionFunctionArgs} from 'react-router';
import {resolveGusStorefrontContext,gusCorsHeaders} from '../services/gus-storefront-auth.server';
import {handleGusOrder} from '../services/gus-concierge-api.server';
export async function action({request}:ActionFunctionArgs){try{const {admin,shop}=await resolveGusStorefrontContext(request);const input=await request.json();return Response.json(await handleGusOrder(admin,shop,input),{headers:gusCorsHeaders()});}catch(e:any){if(e instanceof Response)return e;return Response.json({ok:false,error:e?.message||'Order help unavailable',fallback:{type:'CUSTOMER_SUPPORT',url:'/apps/gus-support'}},{status:400,headers:gusCorsHeaders()});}}
