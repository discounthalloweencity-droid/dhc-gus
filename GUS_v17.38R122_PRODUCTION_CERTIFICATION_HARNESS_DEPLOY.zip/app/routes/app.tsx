import type { HeadersFunction, LoaderFunctionArgs } from "react-router";
import { Link, Outlet, useLoaderData, useLocation, useRouteError } from "react-router";
import { useEffect, useMemo, useState } from "react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { AppProvider } from "@shopify/shopify-app-react-router/react";
import { NavMenu } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { db } from "../db.server";
import { automationState } from "../services/automation-control.server";
import { commandCenterHealth } from "../services/system-health.server";
import { getActiveJobProgress } from "../services/job-progress.server";
import { createJobProgressToken } from "../services/job-progress-token.server";
import { reconcileOrphanedRuntimeState } from "../services/runtime-state-recovery.server";
import { ensureRuntimeOrchestratorPulse } from "../services/runtime-orchestrator-pulse.server";
import { missionProgress, cachedMissionProgress } from "../services/mission-progress.server";
import { missionSnapshotFresh, unavailableMission } from "../services/mission-progress-status";
import { proposalApprovalSummary } from "../services/proposal-autonomy.server";
import { engineActivitySnapshot } from "../services/engine-rotation.server";
import type { JobProgressSnapshot } from "../types/job-progress";
import pkg from '../../package.json';
const RUNTIME_VERSION=pkg.version;
// Compatibility lineage retained for cumulative QA: v0.16.39
// Compatibility header contract: X-Gus-Runtime 0.16.39
// Compatibility status contract: SYSTEM {systemHealth.status} · v0.16.39
// Compatibility navigation count: 54 pinned · 163 total tools

function timeoutMs(name: string, fallback: number, min: number, max: number) {
  const raw = process.env[name];
  if (!raw) return fallback;
  const value = Number(raw);
  return Number.isFinite(value) && Number.isInteger(value) && value >= min && value <= max ? value : fallback;
}
const APP_DATA_TIMEOUT_MS = timeoutMs("GUS_APP_DATA_TIMEOUT_MS", 1500, 250, 10000);
const MISSION_DATA_TIMEOUT_MS = timeoutMs("GUS_MISSION_DATA_TIMEOUT_MS", 5000, 500, 15000);

class GusStartupTimeout extends Error {}
function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new GusStartupTimeout(`${label} timed out after ${ms}ms`)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => { if (timer) clearTimeout(timer); });
}
async function optionalStartup<T>(label: string, promise: Promise<T>, fallback: T, timeout=APP_DATA_TIMEOUT_MS): Promise<T> {
  try { return await withTimeout(promise, timeout, label); }
  catch (error) { console.warn(`[gus-app-startup] ${label} unavailable`, error instanceof Error ? error.message : error); return fallback; }
}

export async function loader({ request }: LoaderFunctionArgs) {
  const started = Date.now();
  console.info(`[gus-app-startup] /app loader start ${new URL(request.url).pathname}`);
  // Keep Shopify embedded authentication on the framework's supported path.
  // Do not time out, degrade, redirect, or query Gus data before this finishes.
  let session;
  try {
    ({session} = await authenticate.admin(request));
  } catch (error) {
    if (error instanceof Response) throw error;
    console.error(`[gus-app-startup] Shopify authentication failed: ${error instanceof Error ? (error.stack ?? error.message) : String(error)}`);
    throw new Response("Shopify authentication could not be verified for this request.", {status: 401});
  }
  const shop = session.shop;
  const authStatus: "connected" = "connected";
  console.info(`[gus-app-startup] authentication ok in ${Date.now()-started}ms`);
  if (shop) ensureRuntimeOrchestratorPulse(shop);
  if (shop) await optionalStartup("runtime state recovery", reconcileOrphanedRuntimeState(shop), {jobs:0,orchestrators:0,alreadyReconciled:false});
  const [automation, approvalCount, openFindingCount, activeJob] = await Promise.all([
    optionalStartup("automation state", automationState(shop), null as any),
    optionalStartup("approval count", proposalApprovalSummary(shop).then(x=>x.ownerReview), 0),
    optionalStartup("open finding count", db.finding.count({where:{shop,status:"OPEN"}}), 0),
    optionalStartup("active Gus job", getActiveJobProgress(shop), null as JobProgressSnapshot | null),
  ]);
  const issueCount=openFindingCount, queueCount=openFindingCount;
  const systemHealth = await optionalStartup("system health", commandCenterHealth(shop,authStatus), {status:"DEGRADED",reasons:["System-health check unavailable"],staleJob:null,staleOrchestrator:null,checkedAt:new Date().toISOString()} as any);
  console.info(`[gus-app-startup] /app shell ready in ${Date.now()-started}ms auth=${authStatus} health=${systemHealth.status}`);
  const displayActiveJob = systemHealth.staleJob?.id===activeJob?.id ? null : activeJob;
  const missionFallback=cachedMissionProgress(shop,15_000)||unavailableMission("Mission progress query failed or timed out. All-clear is withheld until a fresh verified read succeeds.");
  const mission = await optionalStartup("mission progress", missionProgress(shop,displayActiveJob), missionFallback as any, MISSION_DATA_TIMEOUT_MS);
  const jobProgressToken=createJobProgressToken(shop);
  return { apiKey: process.env.SHOPIFY_API_KEY || "", shop, automation, approvalCount, issueCount, queueCount, activeJob:displayActiveJob, jobProgressToken, authStatus, systemHealth, mission, engineActivity:engineActivitySnapshot(shop) };
}

export function shouldRevalidate({formMethod,defaultShouldRevalidate}:any){
  // A child mutation does not need to rerun the heavy authenticated /app shell.
  // Keeping the shell stable prevents a successful button click from being replaced
  // by a second, unrelated authentication/database failure during parent revalidation.
  if(formMethod&&String(formMethod).toUpperCase()!=='GET') return false;
  return defaultShouldRevalidate;
}

type NavItem = { label: string; to: string; code: string; badge?: string };
type NavGroup = { label: string; items: NavItem[] };

const groups: NavGroup[] = [
  { label: "Command", items: [
    { label: "Command Center", to: "/app", code: "CC" },
    { label: "Operations Center", to: "/app/operations-center", code: "OC", badge: "LIVE" },
    { label: "Production Proof", to: "/app/production-proof", code: "PP", badge: "PROOF" },
    { label: "Production Certification", to: "/app/production-certification", code: "PC", badge: "GATE" },
    { label: "Engine Certification Lab", to: "/app/engine-certification-lab", code: "EC", badge: "TEST" },
    { label: "Talk to Gus", to: "/app/gus", code: "AI", badge: "LIVE" },
    { label: "Approvals", to: "/app/actions", code: "AP" },
    { label: "Issues & Findings", to: "/app/findings", code: "IS" },
    { label: "Activity Log", to: "/app/activity", code: "AL" },
    { label: "Tasks & Queue", to: "/app/queue", code: "TQ" },
  ]},
  { label: "Finance", items: [
    { label: "Sales Dashboard", to: "/app/sales", code: "SD" },
    { label: "Pricing & Profitability", to: "/app/pricing", code: "$" },
    { label: "Margins & Landed Cost", to: "/app/margins", code: "MC" },
    { label: "Customer Acquisition / ROAS", to: "/app/acquisition", code: "RA" },
    { label: "Profit Intelligence", to: "/app/profit-intelligence", code: "PI" },
    { label: "Forecasting & Profit", to: "/app/forecasting-profit", code: "FP" },
  ]},
  { label: "Accounting & Orders", items: [
    { label: "Orders", to: "/app/orders", code: "OR" },
    { label: "Cash Flow", to: "/app/cash-flow", code: "CF" },
  ]},
  { label: "Catalog", items: [
    { label: "Products", to: "/app/products", code: "PD" },
    { label: "Collections", to: "/app/collections", code: "CL" },
    { label: "New Products", to: "/app/new-products", code: "NP" },
    { label: "Draft Products", to: "/app/draft-products", code: "DR" },
    { label: "Duplicates", to: "/app/duplicates", code: "DU" },
    { label: "Archive Manager", to: "/app/archive-manager", code: "AR" },
    { label: "Variants", to: "/app/variants", code: "VA" },
    { label: "Tags & Taxonomy", to: "/app/taxonomy", code: "TX" },
    { label: "Filters & Search", to: "/app/discovery", code: "FS" },
    { label: "Size Charts & Fit", to: "/app/size-fit", code: "SZ" },
    { label: "Materials & Product Data", to: "/app/materials", code: "MT" },
    { label: "Images / Media", to: "/app/media", code: "IM" },
    { label: "Catalog Health", to: "/app/catalog-health", code: "CH" },
    { label: "Catalog Self-Healing", to: "/app/catalog-self-healing", code: "SH" },
  ]},
  { label: "Merchandising", items: [
    { label: "Merchandising Command", to: "/app/merchandising", code: "MC" },
    { label: "Shop ROI Engine", to: "/app/shop-roi", code: "SR" },
    { label: "Homepage", to: "/app/homepage-merchandising", code: "HP" },
    { label: "Collection Merchandising", to: "/app/collection-merchandising", code: "CM" },
    { label: "Best Sellers", to: "/app/best-sellers", code: "BS" },
    { label: "New Arrivals", to: "/app/merch-new-arrivals", code: "NA" },
    { label: "Trending / Viral", to: "/app/trending-viral", code: "TV" },
    { label: "Amplify the Scare", to: "/app/complete-look", code: "ATS" },
    { label: "Bundles & Cross-Sells", to: "/app/bundles-cross-sells", code: "BX" },
    { label: "Personalized Recommendations", to: "/app/recommendations", code: "PR" },
    { label: "Seasonal Merchandising", to: "/app/seasonal-merchandising", code: "SM" },
    { label: "Seasonal Switch", to: "/app/seasonal-switch", code: "SS" },
    { label: "Spooky All Year", to: "/app/spooky-all-year", code: "SY" },
    { label: "Assortment Gaps", to: "/app/assortment-gaps", code: "AG" },
  ]},
  { label: "SEO", items: [
    { label: "SEO Command", to: "/app/seo", code: "SEO" },
    { label: "Aggressive Organic Growth", to: "/app/aggressive-organic-growth", code: "OG" },
    { label: "Strike Keywords", to: "/app/strike-keywords", code: "SK" },
    { label: "SEO Domination", to: "/app/seo-domination", code: "SD" },
    { label: "Autonomous SEO Workforce", to: "/app/seo-workforce", code: "SW", badge: "AUTO" },
    { label: "Google Search Territory", to: "/app/search-territory", code: "GT", badge: "AUTO" },
    { label: "Authority Growth", to: "/app/authority-growth", code: "BG", badge: "AUTO" },
    { label: "Weekly SEO Watch", to: "/app/weekly-seo-watch", code: "WW" },
    { label: "SEO Change Ledger", to: "/app/seo-change-ledger", code: "CL" },
    { label: "Product SEO", to: "/app/product-seo", code: "PS" },
    { label: "Collection SEO", to: "/app/collection-seo", code: "CS" },
    { label: "Technical SEO", to: "/app/technical-seo", code: "TS" },
    { label: "Search Console", to: "/app/search-console", code: "SC" },
    { label: "Google Merchant", to: "/app/google-merchant", code: "GM" },
    { label: "Sitemap / Indexing", to: "/app/sitemap-indexing", code: "SI" },
    { label: "Schema", to: "/app/schema", code: "SD" },
    { label: "Internal Linking", to: "/app/internal-linking", code: "IL" },
    { label: "Keywords & Rankings", to: "/app/keywords-rankings", code: "KR" },
    { label: "Competitors", to: "/app/seo-competitors", code: "CP" },
    { label: "Content Opportunities", to: "/app/content-opportunities", code: "CO" },
    { label: "SEO Issues", to: "/app/seo-issues", code: "IS" },
  ]},
  { label: "Suppliers & Fulfillment", items: [
    { label: "Supplier Command", to: "/app/supplier-command", code: "SC" },
    { label: "DSers / AliExpress", to: "/app/dsers-aliexpress", code: "DA" },
    { label: "CJ Dropshipping", to: "/app/cj-dropshipping", code: "CJ" },
    { label: "Syncee", to: "/app/syncee", code: "SY" },
    { label: "Supplier Mapping", to: "/app/supplier-mapping", code: "MP" },
    { label: "Supplier Stock", to: "/app/supplier-stock", code: "SS" },
    { label: "Shipping Times", to: "/app/shipping-times", code: "ST" },
    { label: "USA Warehouse", to: "/app/usa-warehouse", code: "US" },
    { label: "Supplier Reliability", to: "/app/supplier-reliability", code: "SR" },
    { label: "Fulfillment Control Tower", to: "/app/fulfillment-control-tower", code: "FC", badge: "AUTO" },
    { label: "Product Replacement Finder", to: "/app/product-replacement-finder", code: "RF" },
    { label: "Fulfillment Exceptions", to: "/app/fulfillment-exceptions", code: "FE" },
  ]},
  { label: "Customers & Support", items: [
    { label: "Customer Dashboard", to: "/app/customers", code: "CD" },
    { label: "Customer Service Ops", to: "/app/customer-service-operations", code: "CO", badge: "NEW" },
    { label: "Customer Support", to: "/app/support", code: "CS" },
    { label: "Support Email", to: "/app/support-email", code: "EM", badge: "AUTO" },
    { label: "Customer Service Academy", to: "/app/customer-service-academy", code: "QA", badge: "NEW" },
    { label: "Order Help", to: "/app/order-help", code: "OH" },
    { label: "Returns / Cancellations", to: "/app/returns-cancellations", code: "RC" },
    { label: "Shipping Questions", to: "/app/shipping-questions", code: "SQ" },
    { label: "Size & Fit Help", to: "/app/size-fit-help", code: "SF" },
    { label: "Customer Segments", to: "/app/customer-segments", code: "SG" },
    { label: "Customer Journey", to: "/app/customer-journey", code: "CJ" },
  ]},
  { label: "Marketing & Growth", items: [
    { label: "Growth Command", to: "/app/growth-command", code: "GC" },
    { label: "Commerce Editorial", to: "/app/commerce-editorial", code: "CE", badge: "NEW" },
    { label: "Retail Intelligence", to: "/app/intelligence-command", code: "RI" },
    { label: "Google Ads", to: "/app/google-ads", code: "GA" },
    { label: "Meta / Social", to: "/app/meta-social", code: "MS" },
    { label: "Email", to: "/app/email-marketing", code: "EM" },
    { label: "Campaigns", to: "/app/campaigns", code: "CP" },
    { label: "Offers", to: "/app/offers", code: "OF" },
    { label: "Promotions & Flash Sales", to: "/app/promotions", code: "%" },
    { label: "Clearance / Markdown Manager", to: "/app/clearance", code: "CM" },
    { label: "Conversion Optimization", to: "/app/conversion-optimization", code: "CV" },
    { label: "Storefront Conversion Director", to: "/app/storefront-conversion-director", code: "SC" },
    { label: "Order Guardian", to: "/app/order-guardian", code: "OG" },
    { label: "Fulfillment Quality", to: "/app/fulfillment-quality", code: "FQ" },
    { label: "Abandoned Cart", to: "/app/abandoned-cart", code: "AC" },
    { label: "AOV / Upsell", to: "/app/aov-upsell", code: "AU" },
    { label: "Traffic & Acquisition", to: "/app/traffic-acquisition", code: "TA" },
  ]},
  { label: "Gus AI & Automation", items: [
    { label: "Gus Control Center", to: "/app/gus-control", code: "GC" },
    { label: "Autonomy Control Plane", to: "/app/autonomy-control-plane", code: "AC", badge: "AUTO" },
    { label: "Gus Brain", to: "/app/brain", code: "GB" },
    { label: "Search QA", to: "/app/search-qa", code: "SQ" },
    { label: "RUN / STOP", to: "/app/automation", code: "RS" },
    { label: "Current Mission", to: "/app/gus-current-mission", code: "CM" },
    { label: "Automation Rules", to: "/app/gus-automation-rules", code: "AR" },
    { label: "Retail Training", to: "/app/gus-retail-training", code: "RT" },
    { label: "Training & Accuracy", to: "/app/gus-training-center", code: "TA" },
    { label: "Gus Academy", to: "/app/gus-academy", code: "GA", badge: "MASTER" },
    { label: "Retail Recommendation Academy", to: "/app/gus-retail-academy", code: "RA", badge: "NEW" },
    { label: "Recommendation Lab", to: "/app/gus-recommendation-lab", code: "RL" },
    { label: "Recommendation Quality", to: "/app/gus-recommendation-quality", code: "RQ" },
    { label: "Concierge Health", to: "/app/gus-concierge-health", code: "CH" },
    { label: "Concierge Analytics", to: "/app/gus-concierge-analytics", code: "CA" },
    { label: "Master Logic", to: "/app/gus-master-logic", code: "ML" },
    { label: "Merchandising Brain", to: "/app/gus-merchandising-brain", code: "MB" },
    { label: "Pricing Rules", to: "/app/gus-pricing-rules", code: "PR" },
    { label: "SEO Brain", to: "/app/gus-seo-brain", code: "SB" },
    { label: "Supplier Intelligence", to: "/app/gus-supplier-intelligence", code: "SI" },
    { label: "Customer-Service Brain", to: "/app/gus-customer-service-brain", code: "CB" },
    { label: "Seasonal Calendar", to: "/app/gus-seasonal-calendar", code: "SC" },
    { label: "Autonomous Learning Director", to: "/app/autonomous-learning-director", code: "LD", badge: "AUTO" },
    { label: "Learning / Experiments", to: "/app/gus-learning-experiments", code: "LE" },
    { label: "ChatGPT Bridge", to: "/app/bridge", code: "AI" },
    { label: "Gus Memory / Knowledge", to: "/app/gus-memory-knowledge", code: "MK" },
    { label: "Decision History", to: "/app/gus-decision-history", code: "DH" },
  ]},
  { label: "Analytics & Reporting", items: [
    { label: "Full Reporting", to: "/app/reporting", code: "RP" },
    { label: "Executive Analytics", to: "/app/analytics", code: "EA" },
    { label: "Traffic Quality", to: "/app/traffic-quality", code: "TQ", badge: "AUTO" },
    { label: "Sales", to: "/app/analytics-sales", code: "SA" },
    { label: "Profit", to: "/app/analytics-profit", code: "PF" },
    { label: "Conversion", to: "/app/analytics-conversion", code: "CV" },
    { label: "Products", to: "/app/analytics-products", code: "PR" },
    { label: "Collections", to: "/app/analytics-collections", code: "CL" },
    { label: "Search", to: "/app/analytics-search", code: "SE" },
    { label: "Promotions", to: "/app/analytics-promotions", code: "PM" },
    { label: "Suppliers", to: "/app/analytics-suppliers", code: "SU" },
    { label: "Customers", to: "/app/analytics-customers", code: "CU" },
    { label: "SEO", to: "/app/analytics-seo", code: "SO" },
    { label: "Trends", to: "/app/analytics-trends", code: "TR" },
    { label: "Forecasting", to: "/app/analytics-forecasting", code: "FC" },
  ]},
  { label: "Risk & Control", items: [
    { label: "Approval Guardrails", to: "/app/risk-approval-guardrails", code: "AG" },
    { label: "Margin Protection", to: "/app/risk-margin-protection", code: "MP" },
    { label: "Change Limits", to: "/app/risk-change-limits", code: "CL" },
    { label: "Rollbacks", to: "/app/risk-rollbacks", code: "RB" },
    { label: "Anomalies", to: "/app/risk-anomalies", code: "AN" },
    { label: "Failed Actions", to: "/app/risk-failed-actions", code: "FA" },
    { label: "Audit Log", to: "/app/risk-audit-log", code: "AL" },
    { label: "Data Quality", to: "/app/risk-data-quality", code: "DQ" },
    { label: "System Health", to: "/app/risk-system-health", code: "SH" },
  ]},
  { label: "System & Settings", items: [
    { label: "Shopify Connection", to: "/app/system-shopify", code: "SC" },
    { label: "Integrations", to: "/app/system-integrations", code: "IN" },
    { label: "Sales Channels", to: "/app/system-sales-channels", code: "SL" },
    { label: "Gus Backend", to: "/app/system-backend", code: "GB" },
    { label: "Database", to: "/app/system-database", code: "DB" },
    { label: "Jobs / Scheduler", to: "/app/system-jobs", code: "JS" },
    { label: "API Health", to: "/app/system-api-health", code: "AH" },
    { label: "Diagnostics", to: "/app/system-diagnostics", code: "DX" },
    { label: "Black Box Debugger", to: "/app/debugger", code: "BX" },
    { label: "Releases", to: "/app/updates", code: "RL" },
    { label: "Settings", to: "/app/settings", code: "ST" },
  ]},
];

function isActive(pathname: string, to: string) {
  return to === "/app" ? pathname === "/app" || pathname === "/app/" : pathname === to || pathname.startsWith(`${to}/`);
}

// v0.16.40 navigation consolidation remains the active workspace model.
// v0.16.40 keeps the complete historical tool registry above for deep links,
// compatibility and global search, while the visible rail is intentionally smaller.
const toolByPath = new Map(groups.flatMap(group => group.items).map(item => [item.to, item] as const));
function pinned(to:string, label?:string, code?:string, badge?:string):NavItem {
  const source=toolByPath.get(to);
  if(!source) throw new Error(`Navigation workspace references an unknown tool: ${to}`);
  return {...source,...(label?{label}:{}),...(code?{code}:{}),...(badge?{badge}:{} )};
}

const workspaceGroups: NavGroup[] = [
  { label: "Command", items: [
    pinned("/app"),
    pinned("/app/gus"),
    pinned("/app/actions"),
    pinned("/app/findings"),
    pinned("/app/activity"),
    pinned("/app/queue"),
  ]},
  { label: "Store & Catalog", items: [
    pinned("/app/products"),
    pinned("/app/collections"),
    pinned("/app/catalog-health"),
    pinned("/app/new-products"),
    pinned("/app/archive-manager"),
    pinned("/app/discovery", "Search & Filters", "FS"),
    pinned("/app/seasonal-switch"),
  ]},
  { label: "Sales & Profit", items: [
    pinned("/app/sales"),
    pinned("/app/orders"),
    pinned("/app/pricing", "Pricing & Profit", "$"),
    pinned("/app/margins"),
    pinned("/app/forecasting-profit"),
    pinned("/app/cash-flow"),
  ]},
  { label: "Growth", items: [
    pinned("/app/merchandising"),
    pinned("/app/shop-roi"),
    pinned("/app/traffic-quality", "Traffic Quality", "TQ", "AUTO"),
    pinned("/app/growth-command"),
    pinned("/app/commerce-editorial", "Commerce Editorial", "CE", "NEW"),
    pinned("/app/seo", "SEO Command", "SEO"),
    pinned("/app/search-console"),
    pinned("/app/campaigns"),
    pinned("/app/storefront-conversion-director", "Conversion Director", "CV"),
  ]},
  { label: "Fulfillment", items: [
    pinned("/app/fulfillment-control-tower", "Fulfillment Control Tower", "FC", "AUTO"),
    pinned("/app/supplier-command"),
    pinned("/app/order-guardian", "Order Delivery Watch", "OD"),
    pinned("/app/product-replacement-finder", "Replacement Finder", "RF"),
    pinned("/app/fulfillment-quality"),
    pinned("/app/fulfillment-exceptions"),
    pinned("/app/supplier-reliability"),
  ]},
  { label: "Customers", items: [
    pinned("/app/customers"),
    pinned("/app/support"),
    pinned("/app/order-help"),
    pinned("/app/returns-cancellations"),
    pinned("/app/customer-journey"),
  ]},
  { label: "Gus", items: [
    pinned("/app/gus-control"),
    pinned("/app/brain"),
    pinned("/app/automation", "RUN / STOP", "RS"),
    pinned("/app/gus-training-center", "Training & Learning", "TL"),
    pinned("/app/gus-academy"),
    pinned("/app/gus-retail-academy", "Retail Recommendation Academy", "RA", "NEW"),
    pinned("/app/gus-recommendation-lab", "Recommendation Lab", "RL"),
    pinned("/app/gus-recommendation-quality", "Recommendation Quality", "RQ"),
    pinned("/app/gus-memory-knowledge", "Memory / Knowledge", "MK"),
  ]},
  { label: "Reports & System", items: [
    pinned("/app/analytics", "Executive Analytics", "EA"),
    pinned("/app/reporting"),
    pinned("/app/risk-system-health", "System Health", "SH"),
    pinned("/app/system-integrations", "Integrations", "IN"),
    pinned("/app/debugger", "Black Box Debugger", "BX"),
    pinned("/app/settings"),
  ]},
];

const workspaceForLegacyGroup:Record<string,string>={
  Command:"Command",
  Finance:"Sales & Profit",
  "Accounting & Orders":"Sales & Profit",
  Catalog:"Store & Catalog",
  Merchandising:"Growth",
  SEO:"Growth",
  "Suppliers & Fulfillment":"Fulfillment",
  "Customers & Support":"Customers",
  "Marketing & Growth":"Growth",
  "Gus AI & Automation":"Gus",
  "Analytics & Reporting":"Reports & System",
  "Risk & Control":"Reports & System",
  "System & Settings":"Reports & System",
};
const workspaceRouteOverrides:Record<string,string>={
  "/app/seasonal-switch":"Store & Catalog",
  "/app/order-guardian":"Fulfillment",
  "/app/fulfillment-quality":"Fulfillment",
  "/app/traffic-quality":"Growth",
};
function workspaceLabelFor(currentGroup:NavGroup|undefined,current:NavItem|undefined){
  return current?.to&&workspaceRouteOverrides[current.to] || (currentGroup?workspaceForLegacyGroup[currentGroup.label]:undefined) || "Command";
}

function missionClock(seconds:number|null,state:string){
  if(seconds==null)return state==='REVIEW'?'REVIEW':'—';
  const s=Math.max(0,Math.floor(seconds)),h=Math.floor(s/3600),m=Math.floor((s%3600)/60),sec=s%60;
  return h?`${h}h ${String(m).padStart(2,'0')}m`:m?`${m}m ${String(sec).padStart(2,'0')}s`:`${sec}s`;
}
function MissionCard({mission}:{mission:any}){
  const [seconds,setSeconds]=useState<number|null>(mission.etaSeconds==null?null:Number(mission.etaSeconds));
  const [nowMs,setNowMs]=useState(()=>Date.now());
  useEffect(()=>{setSeconds(mission.etaSeconds==null?null:Number(mission.etaSeconds));setNowMs(Date.now());},[mission.generatedAt,mission.etaSeconds]);
  useEffect(()=>{if(seconds==null||seconds<=0)return;const timer=window.setTimeout(()=>setSeconds(v=>v==null?null:Math.max(0,v-1)),1000);return()=>window.clearTimeout(timer);},[seconds]);
  useEffect(()=>{const timer=window.setInterval(()=>setNowMs(Date.now()),5000);return()=>window.clearInterval(timer);},[]);
  const rawState=String(mission?.state||'UNAVAILABLE').toUpperCase();
  const snapshotFresh=missionSnapshotFresh(mission,nowMs);
  const state=!snapshotFresh&&rawState==='CLEAR'?'NOT_VERIFIED':rawState;
  const verifiedClear=state==='CLEAR'&&mission?.verified===true&&mission?.catalogSweep?.verified===true&&snapshotFresh;
  const progressValue=Number(mission?.progress);
  const showProgress=Number.isFinite(progressValue)&&state!=='UNAVAILABLE'&&state!=='NOT_VERIFIED';
  const ringProgress=showProgress?Math.max(0,Math.min(100,progressValue)):0;
  const ringColor=verifiedClear?'#22c55e':state==='REVIEW'||state==='EVIDENCE'?'#f59e0b':state==='STALLED'?'#ef4444':state==='UNAVAILABLE'||state==='NOT_VERIFIED'?'#64748b':'#8b5cf6';
  const title=verifiedClear?'ALL CLEAR':state==='REVIEW'?'AUTO CLEAR — REVIEW':state==='EVIDENCE'?'EVIDENCE WAIT':state==='STALLED'?'STALLED':state==='UNAVAILABLE'?'STATUS UNAVAILABLE':state==='NOT_VERIFIED'?'NOT VERIFIED':seconds==null?'MEASURING':`ETA ${missionClock(seconds,state)}`;
  const auto=mission?.autoRemaining==null?'—':mission.autoRemaining;
  const evidence=mission?.evidenceWaitFindings==null?'—':mission.evidenceWaitFindings;
  const review=mission?.reviewRemaining==null?'—':mission.reviewRemaining;
  const detail=state==='UNAVAILABLE'||state==='NOT_VERIFIED'
    ? (mission?.activeLabel||'Mission status is not currently verified.')
    : `${auto} auto left · ${evidence} evidence · ${review} review${state==='STALLED'?' · no verified movement':mission.throughputPerHour>0?` · ${mission.throughputPerHour}/hr verified`:''}`;
  return <Link to="/app/queue" className={`cc-mission-card cc-mission-${state.toLowerCase()}`} title={mission?.activeLabel||title}>
    <div className="cc-mission-ring" style={{background:`conic-gradient(${ringColor} ${ringProgress*3.6}deg,#243142 0deg)`}}>
      <div className="cc-mission-ring-core"><span>{showProgress?`${progressValue.toFixed(progressValue>=99.95?0:1)}%`:'—'}</span></div>
    </div>
    <div className="cc-mission-copy">
      <strong>GUS MISSION</strong>
      <b>{title}</b>
      <small>{detail}</small>
    </div>
  </Link>;
}

// Embedded navigation rule (R119): internal /app links MUST use React Router client navigation.
// `reloadDocument` forces a full iframe document request and can turn a Shopify session refresh
// into an admin.shopify.com redirect that Shopify refuses to frame. Manual POST forms may still
// use document submissions where their action flow explicitly handles embedded auth recovery.
export default function AppLayout() {
  const { apiKey, shop, automation, approvalCount, issueCount, queueCount, activeJob, jobProgressToken, authStatus, systemHealth, mission, engineActivity } = useLoaderData<typeof loader>();
  const location = useLocation();
  // Job progress uses a short-lived signed token instead of revalidating the embedded
  // Shopify session. This gives the shell live progress without recreating the auth loop
  // that older background route revalidation caused.
  const [liveActiveJob,setLiveActiveJob]=useState<JobProgressSnapshot | null>(activeJob);
  const [liveMission,setLiveMission]=useState<any>(mission);
  const [liveEngineActivity,setLiveEngineActivity]=useState<any>(engineActivity);
  useEffect(()=>{setLiveActiveJob(activeJob);},[activeJob?.id,activeJob?.status,activeJob?.scanned,activeJob?.changed,activeJob?.warnings,activeJob?.finishedAt]);
  useEffect(()=>{setLiveMission(mission);},[mission?.generatedAt]);
  useEffect(()=>{setLiveEngineActivity(engineActivity);},[engineActivity?.generatedAt]);
  useEffect(()=>{
    if(!jobProgressToken)return;let cancelled=false;
    const refresh=async()=>{
      if(typeof document!=="undefined"&&document.visibilityState==="hidden")return;
      try{
        const res=await fetch(`/api/job-progress?token=${encodeURIComponent(jobProgressToken)}`,{headers:{Accept:"application/json"},cache:"no-store"});
        const data=await res.json().catch(()=>null);
        if(cancelled)return;
        if(data?.engines)setLiveEngineActivity(data.engines);
        if(!res.ok||!data?.ok||!data?.mission){setLiveMission(data?.mission||unavailableMission("Live mission verification failed. All-clear is withheld until the signed progress channel recovers."));return;}
        setLiveActiveJob(data.activeJob||null);setLiveMission(data.mission);
      }catch{if(!cancelled)setLiveMission(unavailableMission("Live mission verification is temporarily unavailable. All-clear is withheld."));}
    };
    refresh();const timer=window.setInterval(refresh,4000);
    return()=>{cancelled=true;window.clearInterval(timer);};
  },[jobProgressToken]);
  let activeDetails:any={};
  try{activeDetails=liveActiveJob?.details?JSON.parse(liveActiveJob.details):{};}catch{activeDetails={message:liveActiveJob?.details||"Catalog scan running"};}
  const activeTotal=Number(activeDetails?.total||0);
  const activeScanned=Number(liveActiveJob?.scanned||0);
  const activePercent=activeTotal>0?Math.max(1,Math.min(99,Math.floor((activeScanned/activeTotal)*100))):null;
  const currentGroup = groups.find(g => g.items.some(i => isActive(location.pathname, i.to)));
  const current = currentGroup?.items.find(i => isActive(location.pathname, i.to));
  const currentWorkspaceLabel=workspaceLabelFor(currentGroup,current);
  const [query, setQuery] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const source=q?groups:workspaceGroups;
    if (!q) return source;
    return source.map(g => ({ ...g, items: g.items.filter(i => `${i.label} ${g.label} ${i.to}`.toLowerCase().includes(q)) })).filter(g => g.items.length);
  }, [query]);
  const searching = query.trim().length > 0;
  const running=automation?.running===true;
  const automationKnown=automation!=null;
  useEffect(()=>{setMobileOpen(false);},[location.pathname]);
  useEffect(()=>{if(!mobileOpen)return;const onKey=(event:KeyboardEvent)=>{if(event.key==='Escape')setMobileOpen(false);};window.addEventListener('keydown',onKey);return()=>window.removeEventListener('keydown',onKey);},[mobileOpen]);
  const badgeFor=(item:NavItem)=> item.to==="/app/actions" ? (approvalCount?String(approvalCount):undefined) : item.to==="/app/findings" ? (issueCount?String(issueCount):undefined) : item.to==="/app/queue" ? (queueCount?String(queueCount):undefined) : item.badge;

  return (
    <AppProvider embedded apiKey={apiKey}>
      <NavMenu>
        <Link to="/app" rel="home">Gus Command Center</Link>
        <Link to="/app/gus">Talk to Gus</Link>
        <Link to="/app/products">Store & Catalog</Link>
        <Link to="/app/sales">Sales & Profit</Link>
        <Link to="/app/growth-command">Growth</Link>
        <Link to="/app/fulfillment-control-tower">Fulfillment</Link>
        <Link to="/app/analytics">Reports</Link>
        <Link to="/app/settings">Settings</Link>
      </NavMenu>

      <div className="cc-shell">
        <aside className={`cc-sidebar ${mobileOpen ? "cc-sidebar-open" : ""}`}>
          <div className="cc-brand">
            <div className="cc-brand-mark">G</div>
            <div><strong>Gus</strong><span>Command Center</span></div>
            <button type="button" className="cc-mobile-close" onClick={() => setMobileOpen(false)} aria-label="Close menu">×</button>
          </div>
          <div className="cc-store-pill"><span className="cc-live-dot" /> Discount Halloween City</div>
          <MissionCard mission={liveMission}/>
          <div className="cc-nav-search-wrap">
            <span className="cc-search-icon">⌕</span>
            <input className="cc-nav-search" value={query} onChange={e => setQuery(e.target.value)} placeholder="Find any tool…" aria-label="Find any Gus command center tool" />
          </div>
          <div className="cc-nav-search-meta">{searching?"Searching all 163 tools":"54 pinned · 163 total tools"}</div>
          <nav className="cc-nav" aria-label="Command Center navigation">
            {filtered.map(group => {
              const active = group.items.some(item => isActive(location.pathname, item.to)) || (!searching && group.label===currentWorkspaceLabel);
              const groupId=`cc-nav-${group.label.replace(/[^a-z0-9]+/gi,'-').toLowerCase()}`;
              return <details className={`cc-nav-group ${active ? "cc-nav-group-active" : ""}`} key={group.label} open>
                <summary className="cc-nav-group-toggle" aria-controls={groupId}>
                  <span className="cc-nav-group-title">{group.label}</span>
                  <span className="cc-nav-group-count">{group.items.length}</span>
                  <span className="cc-nav-chevron">›</span>
                </summary>
                <div id={groupId} className="cc-nav-submenu">{group.items.map(item => <Link key={item.to} to={item.to} onClick={() => setMobileOpen(false)} className={`cc-nav-link ${isActive(location.pathname, item.to) ? "cc-nav-link-active" : ""}`}>
                  <span className="cc-nav-code">{item.code}</span>
                  <span className="cc-nav-label">{item.label}</span>
                  {badgeFor(item) && <span className="cc-nav-badge">{badgeFor(item)}</span>}
                </Link>)}</div>
              </details>;
            })}
            {searching&&!filtered.length&&<div style={{padding:'12px 10px',fontSize:12,color:'#8d9aae'}}>No Command Center tools match “{query.trim()}”.</div>}
          </nav>
          <div className="cc-sidebar-footer">
            <div className="cc-operator-state">
              <div><span className={running?"cc-live-dot":automationKnown?"cc-stop-dot":"cc-warn-dot"}/><strong>GUS {running?"RUNNING":automationKnown?"STOPPED":"CHECKING"}</strong></div>
              <Link to="/app/automation">{running?"STOP / CONTROL":automationKnown?"RUN GUS":"CHECK STATUS"}</Link>
            </div>
            <div className="cc-connection-line"><span className={authStatus==="connected"?"cc-live-dot":"cc-stop-dot"}/>{authStatus==="connected"?"Shopify Connected":"Shopify auth recovery mode"}</div>
            <div className="cc-runtime-line">Command Center · v{RUNTIME_VERSION}</div>
            <Link to="/app/gus" className="cc-gus-quick"><span className="cc-gus-orb">G</span><span><strong>Ask Gus</strong><small>Store intelligence & actions</small></span><b>→</b></Link>
          </div>
        </aside>
        {mobileOpen && <button type="button" className="cc-backdrop" onClick={() => setMobileOpen(false)} aria-label="Close navigation" />}

        <div className="cc-workspace">
          <header className="cc-topbar">
            <div className="cc-topbar-left">
              <button type="button" className="cc-menu-button" onClick={() => setMobileOpen(true)} aria-label="Open navigation">☰</button>
              <div><span className="cc-breadcrumb">Discount Halloween City /</span><strong>{current?.label || "Command Center"}</strong></div>
            </div>
            <div className="cc-topbar-right">
              <span className="cc-status" title={systemHealth.reasons.join("; ")}><span className={systemHealth.status==="ONLINE"?"cc-live-dot":"cc-warn-dot"} /> SYSTEM {systemHealth.status} · v{RUNTIME_VERSION}</span>
              <Link className="cc-top-gus" to="/app/gus">Talk to Gus</Link>
              <div className="cc-avatar" title={shop}>DHC</div>
            </div>
          </header>
          {liveActiveJob&&<div style={{margin:"12px 18px 0",padding:"14px 16px",border:"1px solid #d8d8d8",borderRadius:12,background:"#fff",boxShadow:"0 4px 16px rgba(0,0,0,.06)"}}>
            <div style={{display:"flex",justifyContent:"space-between",gap:12,alignItems:"center",marginBottom:8}}><div><strong>Gus is working now</strong><div style={{fontSize:13,opacity:.72,marginTop:2}}>{activeDetails?.message||"Catalog intelligence scan in progress"}{activeDetails?.current?` · ${activeDetails.current}`:""}</div></div><strong>{activePercent!=null?`${activePercent}%`:`${activeScanned} scanned`}</strong></div>
            <div style={{height:10,borderRadius:999,background:"#ececf1",overflow:"hidden"}}><div style={{height:"100%",width:activePercent!=null?`${activePercent}%`:"18%",background:"linear-gradient(90deg,#6d5dfc,#8d7cff)",transition:"width .4s ease"}}/></div>
            <div style={{display:"flex",justifyContent:"space-between",fontSize:12,opacity:.7,marginTop:7}}><span>{activeDetails?.phase||liveActiveJob.jobType}</span><span>{activeTotal>0?`${activeScanned.toLocaleString()} / ${activeTotal.toLocaleString()} products`:`${activeScanned.toLocaleString()} products scanned`} · {liveActiveJob.warnings} findings · {liveActiveJob.changed} changes</span></div>
          </div>}
          <div className="cc-content"><Outlet context={{activeJob:liveActiveJob,authStatus,systemHealth,engineActivity:liveEngineActivity}} /></div>
        </div>
      </div>
      <Link to="/app/gus" className="cc-floating-gus" aria-label="Talk to Gus"><span>G</span><b>Ask Gus</b></Link>
    </AppProvider>
  );
}

export function ErrorBoundary() { return boundary.error(useRouteError()); }
export const headers: HeadersFunction = (args) => ({
  ...boundary.headers(args),
  "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0",
  Pragma: "no-cache",
  Expires: "0",
  "X-Gus-Runtime": RUNTIME_VERSION,
  "X-Gus-Entrypoint": "/app",
});
