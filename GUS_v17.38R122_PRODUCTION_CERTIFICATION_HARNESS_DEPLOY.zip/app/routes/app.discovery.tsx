import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {db} from '../db.server';
import {Page,Table,Badge} from '../components/ui';
import {FILTER_FIELDS} from '../services/discovery-rules';
import {inspectFilterDefinitions} from '../services/filter-config.server';
export async function loader({request}:LoaderFunctionArgs){
 const {session,admin}=await authenticate.admin(request);
 const rows=await db.finding.findMany({where:{shop:session.shop,status:'OPEN',category:{in:['FILTERS','LICENSING','DISCOVERY']}},orderBy:{createdAt:'desc'},take:250});
 let filterConfig:any=null;try{filterConfig=await inspectFilterDefinitions(admin);}catch(e:any){filterConfig={error:String(e?.message||e)};}return {rows,filterConfig};
}
export default function Discovery(){const {rows,filterConfig}=useLoaderData<typeof loader>();return <Page title="Filters & Search Authority" subtitle="Verified catalog attributes, searchable metadata and protected licensing claims. Audit-first; no invented supplier facts."><p>Required filters vary by product type. Missing values and licensing evidence are sent to review. Shopify Search & Discovery filter configuration must be verified separately.</p><h3>Shopify metafield definitions</h3><p>{filterConfig?.error||filterConfig?.note}</p><p>Existing matching definitions: {filterConfig?.definitions?.length??"Unavailable"}. Missing candidate fields: {filterConfig?.missing?.join(", ")||"None detected"}.</p><p>Supported attributes: {FILTER_FIELDS.join(', ')}.</p><Table headers={['Product','Area','Issue','Severity','Action']} rows={rows.map(r=>[r.productGid.split('/').pop(),r.category,r.message,<Badge tone={r.severity==='HIGH'?'bad':'warn'}>{r.severity}</Badge>,r.proposed||'Review supplier evidence'])}/></Page>}
