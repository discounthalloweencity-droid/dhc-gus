// Compatibility adapter for the historically deployed Shopify app-proxy base.
// Reuse the canonical signed support-center handler and its Shopify app-proxy auth.
export {loader, action, default} from './support-center';
