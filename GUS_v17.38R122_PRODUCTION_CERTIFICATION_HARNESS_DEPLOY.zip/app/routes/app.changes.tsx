import type { LoaderFunctionArgs } from "react-router";
import { useLoaderData } from "react-router";
import { authenticate } from "../shopify.server";
import { db } from "../db.server";
import { safePageData } from "../services/page-data-safety.server";
import { Page, Table } from "../components/ui";
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);const rows=await safePageData("changes","history",db.changeLog.findMany({where:{shop:session.shop},orderBy:{createdAt:"desc"},take:500}),[] as any[]);return {rows};}
export default function Changes(){const {rows}=useLoaderData<typeof loader>();return <Page title="Change History" subtitle="Every Authority App write is recorded with before/after values and reason."><Table headers={["Action","Field","Before","After","Reason","When"]} rows={rows.map(r=>[r.action,r.field||"—",r.beforeValue||"—",r.afterValue||"—",r.reason,new Date(r.createdAt).toLocaleString()])}/></Page>}
