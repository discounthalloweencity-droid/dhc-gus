import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='Product SEO' subtitle='Product-level search optimization for titles, meta, taxonomy, structured discovery and shopper-intent alignment.' data={data} focus={['Protect searchable product names while removing supplier noise and unreadable marketplace phrasing.', 'Prioritize title, meta title, meta description, product copy, image context, taxonomy and filter eligibility.', 'Use verified product facts only; missing materials, dimensions, licensing or fit evidence remains unknown.', 'Keep product SEO changes compatible with conversion and merchandising rather than optimizing keywords in isolation.']}/>;}
