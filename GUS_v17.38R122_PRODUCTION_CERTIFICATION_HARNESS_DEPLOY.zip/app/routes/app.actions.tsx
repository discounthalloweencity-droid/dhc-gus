import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {useEffect,type CSSProperties} from 'react';
import {Form,useLoaderData,useActionData,useRevalidator} from 'react-router';
import {authenticate} from '../shopify.server';
import {db} from '../db.server';
import {approveAllPending,queueProposalApproval,scheduleApprovalQueueWorker,rejectProposal} from '../services/approval-queue.server';
import {Page,Table,Badge,Card} from '../components/ui';
import {proposalApprovalSummary} from '../services/proposal-autonomy.server';
import {classifyPendingProposal} from '../services/proposal-autonomy-rules';

import {safeAppAction} from '../services/safe-app-action.server';

export async function loader({request}:LoaderFunctionArgs){
  const {session}=await authenticate.admin(request);
  const shop=session.shop;
  const [rawRows,summary,approved,rejected]=await Promise.all([
    db.actionProposal.findMany({where:{shop},orderBy:{createdAt:'desc'},take:300}),
    proposalApprovalSummary(shop),
    db.actionProposal.count({where:{shop,status:'APPROVED'}}),
    db.actionProposal.count({where:{shop,status:'REJECTED'}}),
  ]);
  const rows=rawRows.filter(row=>row.status!=='PENDING'||classifyPendingProposal(row).lane==='OWNER_REVIEW').slice(0,150);
  if(approved>0)scheduleApprovalQueueWorker(shop,5000);
  return {rows,pending:summary.ownerReview,autonomousPending:summary.autoSafe,staleSafePending:summary.staleSafe,totalPending:summary.totalPending,approved,rejected};
}

export async function action({request}:ActionFunctionArgs){return safeAppAction('actions',request,async()=>{
  const {session}=await authenticate.admin(request);
  const shop=session.shop;
  const f=await request.formData();
  const intent=String(f.get('intent')||'');

  if(intent==='approve_all'){
    const result=await approveAllPending(shop);
    if(result.queued>0)scheduleApprovalQueueWorker(shop,5000);
    return {ok:true,skipRevalidate:true,message:result.count?`${result.count} pending approvals processed: ${result.queued} queued for guarded execution and ${result.manualHandoffs} communication handoff${result.manualHandoffs===1?'':'s'} recorded as owner-approved. No customer or supplier message is claimed sent unless a configured outbound workflow confirms it.`:'No pending approvals remained.'};
  }

  const id=Number(f.get('id'));
  if(!Number.isSafeInteger(id)||id<=0)return {error:'Invalid proposal.'};

  if(intent==='reject'){
    const result=await rejectProposal(shop,id);
    return result.count?{ok:true,skipRevalidate:true,message:'Proposal rejected. It will not be included in Approve all.'}:{error:'Proposal is already processing or no longer available.',skipRevalidate:true};
  }

  if(intent!=='approve')return {error:'Invalid action.',skipRevalidate:true};
  const queued=await queueProposalApproval(shop,id);
  if(!queued.count)return {error:'Proposal is already processing or no longer available.',skipRevalidate:true};
  if(!queued.manualHandoff)scheduleApprovalQueueWorker(shop,750);
  return {ok:true,skipRevalidate:true,message:queued.manualHandoff?'Communication handoff approved. Gus recorded the owner decision without falsely claiming a customer or supplier message was sent.':'Proposal approved and queued. Gus will apply it in the background without holding this page request open.'};
});}

export function shouldRevalidate({formMethod,defaultShouldRevalidate}:any){
  return formMethod&&String(formMethod).toUpperCase()!=='GET'?false:defaultShouldRevalidate;
}

const buttonBase:CSSProperties={
  minWidth:92,
  minHeight:38,
  padding:'9px 14px',
  borderRadius:9,
  border:'1px solid transparent',
  fontWeight:750,
  whiteSpace:'nowrap',
  lineHeight:1.1,
};

export default function Actions(){
  const {rows,pending,autonomousPending,staleSafePending,totalPending,approved,rejected}=useLoaderData<typeof loader>();
  const result=useActionData<typeof action>();
  const revalidator=useRevalidator();
  useEffect(()=>{if(result&&('message'in result||'error'in result)){const timer=window.setTimeout(()=>revalidator.revalidate(),900);return()=>window.clearTimeout(timer);}},[result]);
  return <Page title="Approval Queue" subtitle="Exception queue for high-risk changes. Routine reversible SEO is autonomous and verified by Shopify readback.">
    {result&&('error'in result)
      ?<div className="gus-flash gus-flash-bad" role="alert">{result.error}</div>
      :result&&'message'in result
        ?<div className="gus-flash gus-flash-good" role="status">{result.message}</div>
        :null}

    <Card>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:18,flexWrap:'wrap'}}>
        <div>
          <h2 style={{margin:'0 0 6px'}}>Bulk approval</h2>
          <p style={{margin:0,color:'#64748b',fontSize:13,maxWidth:760}}>
            Approve high-risk items that genuinely need owner judgment. Routine reversible SEO/catalog maintenance is autonomous and disappears from this exception queue after governed execution or stale-evidence supersession. Fulfillment contact/escalation approvals become auditable owner-approved handoffs; they are not sent through Shopify's mutation executor and are never reported as sent without provider confirmation. Anything you rejected stays REJECTED and is excluded.
          </p>
        </div>
        <Form method="post">
          <button
            name="intent"
            value="approve_all"
            disabled={pending===0}
            onClick={(event)=>{if(pending>0&&!window.confirm(`Approve all ${pending} pending proposals? Rejected items will remain excluded.`))event.preventDefault();}}
            style={{...buttonBase,minWidth:190,minHeight:46,background:pending?'#166534':'#e2e8f0',color:pending?'#fff':'#64748b',fontSize:14,borderColor:pending?'#14532d':'#cbd5e1'}}
          >
            ✓ Approve all pending ({pending})
          </button>
        </Form>
      </div>
      <div style={{display:'flex',gap:10,flexWrap:'wrap',marginTop:14,fontSize:12}}>
        <Badge tone={pending?'warn':'neutral'}>{pending} owner review</Badge>
        <Badge tone={autonomousPending?'good':'neutral'}>{autonomousPending} autonomous backlog</Badge>
        <Badge tone={staleSafePending?'neutral':'neutral'}>{staleSafePending} stale safe / superseding</Badge>
        <Badge tone={approved?'warn':'neutral'}>{approved} approved / processing</Badge>
        <Badge tone="neutral">{rejected} rejected</Badge><span style={{alignSelf:'center',color:'#64748b'}}>{totalPending} total pending proposals</span>
      </div>
    </Card>

    <div style={{height:18}}/>
    <Table headers={['Status','Action','Product / variant','Before','After','Reason','Review']} rows={rows.map(r=>[
      <Badge tone={r.status==='APPLIED'||r.status==='OWNER_APPROVED'?'good':r.status==='FAILED'?'bad':r.status==='REJECTED'?'neutral':r.status==='APPROVED'||r.status==='EXECUTING'?'warn':'neutral'}>{r.status}</Badge>,
      r.action,
      <><small>{r.productGid}</small><br/><small>{r.variantGid}</small></>,
      r.beforeValue,
      r.afterValue,
      r.reason,
      ['PENDING','APPROVED'].includes(r.status)
        ?<Form method="post" style={{display:'flex',gap:8,alignItems:'center',flexWrap:'nowrap'}}>
          <input type="hidden" name="id" value={r.id}/>
          {r.status==='PENDING'&&<button name="intent" value="approve" style={{...buttonBase,background:'#dcfce7',borderColor:'#86efac',color:'#166534'}}>✓ Approve</button>}
          <button name="intent" value="reject" style={{...buttonBase,background:'#fff1f2',borderColor:'#fecdd3',color:'#be123c'}}>✕ Reject</button>
        </Form>
        :'—'
    ])}/>
  </Page>;
}
