import type {ActionFunctionArgs} from 'react-router';
import {resolveGusStorefrontContext,gusCorsHeaders} from '../services/gus-storefront-auth.server';
import {handleGusSession} from '../services/gus-concierge-api.server';
export async function action({request}:ActionFunctionArgs){try{const {shop}=await resolveGusStorefrontContext(request);const input=await request.json().catch(()=>({}));return Response.json(await handleGusSession(shop,input),{headers:gusCorsHeaders()});}catch(e:any){if(e instanceof Response)return e;return Response.json({ok:false,error:e?.message||'Session unavailable',fallback:{type:'START_NEW_SESSION',endpoint:'/gus/session'}},{status:400,headers:gusCorsHeaders()});}}
