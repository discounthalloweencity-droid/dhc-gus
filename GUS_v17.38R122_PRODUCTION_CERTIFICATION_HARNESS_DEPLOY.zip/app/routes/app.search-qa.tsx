import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {Form,useActionData,useLoaderData,useNavigation} from 'react-router';
import {authenticate} from '../shopify.server';
import {DEFAULT_SEARCH_QA_QUERIES} from '../services/search-qa';
import {repairSearchQaFailure,runSearchQaRepairSuite} from '../services/search-qa-repair.server';
import {Badge,Card,Grid,Metric,Page,Table} from '../components/ui';

import {safeAppAction} from '../services/safe-app-action.server';

export async function loader({request}:LoaderFunctionArgs){
  const {session}=await authenticate.admin(request);
  return {shop:session.shop,defaultQueries:DEFAULT_SEARCH_QA_QUERIES};
}
export async function action({request}:ActionFunctionArgs){return safeAppAction('search-qa',request,async()=>{
  const {admin,session}=await authenticate.admin(request);
  const form=await request.formData();
  const mode=String(form.get('mode')||'single');
  try{
    if(mode==='suite')return {ok:true,mode,report:await runSearchQaRepairSuite(admin,session.shop,DEFAULT_SEARCH_QA_QUERIES)};
    const query=String(form.get('query')||'').trim();
    if(!query)return {ok:false,error:'Enter a shopper search phrase.'};
    const repair=await repairSearchQaFailure(admin,session.shop,query);
    return {ok:true,mode:'single',simulation:repair.after,repair};
  }catch(e:any){return {ok:false,error:String(e?.message||e)};}
});}
function tone(grade:string){return grade==='PASS'?'good':grade==='WARN'?'warn':'bad' as const;}
export default function SearchQaRoute(){
  const data=useLoaderData<typeof loader>();
  const actionData=useActionData<typeof action>() as any;
  const nav=useNavigation();
  const busy=nav.state!=='idle';
  const sims=actionData?.report?.simulations??(actionData?.simulation?[actionData.simulation]:[]);
  return <Page title="Gus Search QA" subtitle="Run live Shopify search QA. FAIL now triggers Gus closed-loop repair: diagnose, apply safe reversible catalog corrections, rerun the same search, and keep the issue open until PASS or a governed blocker is proven.">
    <Grid>
      <Metric label="Store" value={data.shop}/>
      <Metric label="QA query library" value={data.defaultQueries.length} detail="Core DHC shopper-intent scenarios"/>
      <Metric label="Search mode" value="AUTO REPAIR" detail="Live predictive search · safe writes only · reruns after repair"/>
    </Grid>
    <div style={{height:16}}/>
    <Card>
      <h2 style={{marginTop:0}}>Search simulator</h2>
      <Form method="post" style={{display:'flex',gap:10,flexWrap:'wrap',alignItems:'end'}}>
        <input type="hidden" name="mode" value="single"/>
        <label style={{display:'grid',gap:6,flex:'1 1 360px'}}>Shopper query<input name="query" defaultValue="women vampire costume" style={{padding:10,border:'1px solid #bbb',borderRadius:8,fontSize:16}}/></label>
        <button disabled={busy} style={{padding:'10px 16px',borderRadius:8,border:'1px solid #111',background:'#111',color:'white'}}>{busy?'Running…':'Search + auto repair'}</button>
      </Form>
      <Form method="post" style={{marginTop:12}}><input type="hidden" name="mode" value="suite"/><button disabled={busy} style={{padding:'10px 16px',borderRadius:8,border:'1px solid #999',background:'white'}}>{busy?'Running…':'Run QA suite + auto repair'}</button></Form>
      {actionData?.error&&<p style={{color:'#a00',fontWeight:600}}>{actionData.error}</p>}
    </Card>
    {actionData?.repair&&<><div style={{height:16}}/><Card><h2 style={{marginTop:0}}>Closed-loop repair</h2><p><Badge tone={actionData.repair.after?.grade==='PASS'?'good':actionData.repair.status==='IMPROVED'?'warn':'bad'}>{actionData.repair.status}</Badge> · Before {actionData.repair.before?.score}/100 → After {actionData.repair.after?.score}/100 · {actionData.repair.repairedCount||0} verified catalog write(s).</p>{actionData.repair.blocker&&<p><strong>Still open:</strong> {actionData.repair.blocker}</p>}{actionData.repair.actions?.length>0&&<div>{actionData.repair.actions.map((x:any,i:number)=><p key={i}><strong>{x.handle||'Unknown product'}</strong> · {x.status} · {x.reason}</p>)}</div>}</Card></>}
    {actionData?.report&&<><div style={{height:16}}/><Grid>
      <Metric label="Search health" value={`${actionData.report.score}/100`} detail={actionData.report.grade}/>
      <Metric label="Passed" value={actionData.report.passed}/>
      <Metric label="Failed" value={actionData.report.failed}/>
      <Metric label="Critical mismatches" value={actionData.report.criticalMismatches}/>
      <Metric label="Zero-result searches" value={actionData.report.zeroResults}/>
    </Grid></>}
    {sims.length>0&&<><div style={{height:16}}/><Table headers={['Query','Health','Grade','Top results / issues']} rows={sims.map((s:any)=>[
      s.query,
      `${s.score}/100`,
      <Badge tone={tone(s.grade)}>{s.grade}</Badge>,
      <div>{s.results.slice(0,5).map((r:any,i:number)=><div key={i} style={{marginBottom:8}}><strong>{i+1}. {r.product.title}</strong> — {r.score}/100 {r.issues.length?<span style={{color:'#8a2d1b'}}> · {r.issues.map((x:any)=>x.code).join(', ')}</span>:<span> · clean</span>}</div>)}</div>
    ])}/></>}
    {actionData?.report?.repairs?.length>0&&<><div style={{height:16}}/><Card><h2 style={{marginTop:0}}>Suite repair outcomes</h2>{actionData.report.repairs.filter((r:any)=>r.repairAttempted||r.status!=='PASS_ALREADY').map((r:any)=><p key={r.query}><strong>{r.query}</strong>: <Badge tone={r.after?.grade==='PASS'?'good':r.status==='IMPROVED'?'warn':'bad'}>{r.status}</Badge> · {r.before?.score}/100 → {r.after?.score}/100 · {r.repairedCount||0} write(s){r.blocker?` · ${r.blocker}`:''}</p>)}</Card></>}
    {actionData?.report?.errors?.length>0&&<><div style={{height:16}}/><Card><h2 style={{marginTop:0}}>Connection errors</h2>{actionData.report.errors.map((e:any)=><p key={e.query}><strong>{e.query}</strong>: {e.error}</p>)}</Card></>}
  </Page>;
}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
