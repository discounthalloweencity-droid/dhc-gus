import type {ActionFunctionArgs} from 'react-router';
import {verifyStorefrontRequest} from '../services/storefront-signing';
import {storefrontMerchandisingManifest} from '../services/storefront-merchandising.server';

export async function action({request}:ActionFunctionArgs){
 const secret=process.env.GUS_STOREFRONT_SHARED_SECRET;if(!secret)return new Response('Storefront bridge unavailable',{status:503});
 const body=await request.text();if(!verifyStorefrontRequest(request.headers.get('x-dhc-timestamp'),request.headers.get('x-dhc-signature'),body,secret))return new Response('Unauthorized',{status:401});
 const shop=process.env.AUTHORITY_SHOP;if(!shop)return new Response('Store unavailable',{status:503});
 try{return Response.json(await storefrontMerchandisingManifest(shop),{headers:{'cache-control':'private, max-age=300','access-control-allow-origin':process.env.STOREFRONT_ORIGIN||'https://www.discounthalloweencity.com'}});}catch(error){console.error('[gus-storefront-merch] manifest unavailable',error instanceof Error?error.message:error);return Response.json({error:'Merchandising manifest unavailable'},{status:503,headers:{'cache-control':'no-store'}});}
}
