import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='Content Opportunities' subtitle='Evidence-backed content pipeline for buying guides, seasonal pages, evergreen spooky topics and conversion-support content.' data={data} focus={['Create content only when it serves a real search/customer question and has a logical commercial destination.', 'Prioritize size/fit help, costume ideas, decorating guides, party planning, character/theme discovery and Spooky All Year intent.', 'Avoid mass-producing thin AI pages or doorway pages.', 'Every proposed article or guide should have target intent, supporting products/collections and internal-link plan.']}/>;}
