import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {Form,useActionData,useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {db} from '../db.server';
import {safeAppAction} from '../services/safe-app-action.server';
import {runCatalogSelfHealing,rollbackCatalogRepair} from '../services/catalog-self-healing.server';
import {runPdpTrustRepair} from '../services/pdp-trust-repair.server';
import {runDhcPdpExposureHardening} from '../services/dhc-pdp-exposure-hardening.server';
import {Badge,Card,Grid,Metric,Page,Table} from '../components/ui';

export async function loader({request}:LoaderFunctionArgs){
 const {session}=await authenticate.admin(request);const shop=session.shop;
 const [catalogJob,trustJob,exposureJob,plans,findings,changes,readiness]=await Promise.all([
  db.jobRun.findFirst({where:{shop,jobType:'CATALOG_SELF_HEAL'},orderBy:{startedAt:'desc'}}),
  db.jobRun.findFirst({where:{shop,jobType:'PDP_TRUST_REPAIR'},orderBy:{startedAt:'desc'}}),
  db.jobRun.findFirst({where:{shop,jobType:'DHC_PDP_EXPOSURE_HARDENING'},orderBy:{startedAt:'desc'}}),
  db.collectionOptimizationPlan.findMany({where:{shop,actionType:{in:['ADD_TAGS','REPAIR_TAGS','REMOVE_FROM_COLLECTION','PDP_CONTENT_REPAIR']},status:{in:['PROPOSED','APPLIED']}},orderBy:[{score:'desc'},{updatedAt:'desc'}],take:100}),
  db.finding.findMany({where:{shop,status:'OPEN',code:{in:['SUPPLIER_TITLE_NEEDS_EVIDENCE','PDP_DESCRIPTION_REVIEW','PDP_TRUST_PUBLIC_RENDER_STALE','PDP_TRUST_REPAIR_FAILED','STOREFRONT_AVAILABILITY_CONTRADICTION','PDP_PREMIUM_EXPOSURE_HOLD','PDP_MERCH_PROFILE_MISSING']}},orderBy:{createdAt:'desc'},take:100}),
  db.changeLog.findMany({where:{shop,action:{in:['TAGS_UPDATE','COLLECTION_MEMBERSHIP_REMOVE','PDP_CONTENT_REPAIR']}},orderBy:{createdAt:'desc'},take:50}),
  db.intelligenceSignal.findMany({where:{shop,signalType:'DHC_PDP_READINESS',entityType:'PRODUCT'},orderBy:[{score:'asc'},{updatedAt:'desc'}],take:100})
 ]);
 return {catalogJob,trustJob,exposureJob,plans,findings,changes,readiness};
}

export async function action({request}:ActionFunctionArgs){return safeAppAction('catalog-self-healing',request,async()=>{
 const {admin,session}=await authenticate.admin(request);const form=await request.formData();const intent=String(form.get('intent')||'');
 if(intent==='catalog'){setImmediate(()=>{void runCatalogSelfHealing(admin,session.shop,true).catch(error=>console.error('[catalog-self-heal] manual pass failed',error instanceof Error?error.message:error));});return {ok:true,message:'Catalog self-healing pass queued.'};}
 if(intent==='trust'){setImmediate(()=>{void runPdpTrustRepair(admin,session.shop,true).catch(error=>console.error('[pdp-trust] manual pass failed',error instanceof Error?error.message:error));});return {ok:true,message:'PDP trust repair pass queued.'};}
 if(intent==='exposure'){setImmediate(()=>{void runDhcPdpExposureHardening(admin,session.shop,true).catch(error=>console.error('[pdp-exposure] manual pass failed',error instanceof Error?error.message:error));});return {ok:true,message:'High-exposure PDP hardening pass queued.'};}
 if(intent==='rollback'){const id=Number(form.get('changeId'));if(!Number.isSafeInteger(id)||id<=0)return {ok:false,message:'Invalid rollback target.'};await rollbackCatalogRepair(admin,session.shop,id);return {ok:true,message:`Catalog repair ${id} rolled back and verified.`};}
 return {ok:false,message:'Unknown catalog self-healing action.'};
});}

const details=(row:any)=>{try{return row?.details?JSON.parse(row.details):{}}catch{return {}}};
export default function CatalogSelfHealing(){const d=useLoaderData<typeof loader>(),a=useActionData<typeof action>();const c=details(d.catalogJob),t=details(d.trustJob),e=details(d.exposureJob);const readiness=d.readiness.map((r:any)=>({...r,audit:(()=>{try{return JSON.parse(r.evidenceJson||'{}')}catch{return {}}})()}));return <Page title="Catalog Self-Healing & PDP Trust" subtitle="Controlled catalog repair for taxonomy contamination, wrong manual collection memberships, legacy supplier PDP content and customer-facing trust contradictions. Every autonomous write requires evidence, readback and rollback support.">
 <div className="authority-toolbar"><Form method="post"><button name="intent" value="catalog">Run catalog self-heal now</button></Form><Form method="post"><button name="intent" value="trust">Run PDP trust pass now</button></Form><Form method="post"><button name="intent" value="exposure">Harden high-exposure PDPs now</button></Form></div>
 {a?<div className={a.ok?'gus-flash gus-flash-good':'gus-flash gus-flash-bad'}>{a.message}</div>:null}
 <Grid><Metric label="Catalog self-heal" value={d.catalogJob?.status||'Not run'} detail={d.catalogJob?.finishedAt?new Date(d.catalogJob.finishedAt).toLocaleString():undefined}/><Metric label="Last products scanned" value={c.products??c.scanned??0}/><Metric label="Repairs applied" value={c.applied??d.catalogJob?.changed??0}/><Metric label="PDP trust" value={d.trustJob?.status||'Not run'}/><Metric label="Trust contradictions" value={t.contradictions??0}/><Metric label="PDP exposure gate" value={d.exposureJob?.status||'Not run'} detail={`${e.ready??0} ready · ${e.held??0} held`}/><Metric label="Open trust findings" value={d.findings.length}/></Grid>
 <div style={{height:16}}/><Card><h2>High-exposure PDP readiness</h2>{readiness.length?<Table headers={['Decision','Score','Exposure','Product','Blocking reasons']} rows={readiness.map((r:any)=>[<Badge tone={r.audit?.premiumEligible?'good':r.audit?.decision==='DO_NOT_PROMOTE'?'bad':'warn'}>{r.audit?.decision||r.metric||'UNKNOWN'}</Badge>,r.audit?.score??r.score??'—',`${r.audit?.exposure?.tier||'—'} · ${(r.audit?.exposure?.surfaces||[]).join(', ')}`,r.entityId||'—',(r.audit?.blockingCodes||r.audit?.issues?.map((x:any)=>x.code)||[]).join(', ')||'Ready'])}/>:<p>No R26 PDP readiness evidence has been generated yet.</p>}</Card>
 <div style={{height:16}}/><Card><h2>Self-healing plans</h2><Table headers={['Type','Target','Score','Confidence','Status','Reason']} rows={d.plans.map(p=>[p.actionType,p.collectionTitle||p.productGid||'—',p.score,`${Math.round(p.confidence*100)}%`,<Badge tone={p.status==='APPLIED'?'good':'warn'}>{p.status}</Badge>,p.reason])}/></Card>
 <div style={{height:16}}/><Card><h2>Trust findings requiring evidence or theme/channel diagnosis</h2>{d.findings.length?<Table headers={['Severity','Code','Product','Message']} rows={d.findings.map(f=>[<Badge tone={f.severity==='HIGH'?'bad':'warn'}>{f.severity}</Badge>,f.code,f.productGid||'—',f.message])}/>:<p>No open catalog/PDP trust findings in this view.</p>}</Card>
 <div style={{height:16}}/><Card><h2>Recent reversible repairs</h2>{d.changes.length?<Table headers={['Change','Action','Product','Created','Rollback']} rows={d.changes.map(c=>[c.id,c.action,c.productGid||'—',new Date(c.createdAt).toLocaleString(),c.reversible?<Form method="post"><input type="hidden" name="changeId" value={c.id}/><button name="intent" value="rollback">Rollback</button></Form>:<Badge tone="neutral">Closed</Badge>])}/>:<p>No catalog self-healing changes have been applied yet.</p>}</Card>
 </Page>}
