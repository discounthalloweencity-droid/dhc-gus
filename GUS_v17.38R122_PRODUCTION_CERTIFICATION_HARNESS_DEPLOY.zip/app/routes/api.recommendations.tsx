import type {ActionFunctionArgs} from 'react-router';
import {unauthenticated} from '../shopify.server';
import {previewRecommendations} from '../services/recommendations.server';
import {verifyStorefrontRequest} from '../services/storefront-signing';

export async function action({request}:ActionFunctionArgs){
 const secret=process.env.GUS_STOREFRONT_SHARED_SECRET;
 if(!secret)return new Response('Storefront bridge unavailable',{status:503});
 const body=await request.text();
 if(!verifyStorefrontRequest(request.headers.get('x-dhc-timestamp'),request.headers.get('x-dhc-signature'),body,secret))return new Response('Unauthorized',{status:401});
 const shop=process.env.AUTHORITY_SHOP;
 if(!shop)return new Response('Store unavailable',{status:503});
 let input:any;
 try{input=JSON.parse(body);}catch{return new Response('Malformed JSON body',{status:400});}
 if(!input||typeof input!=='object'||Array.isArray(input))return new Response('Invalid request body',{status:400});
 if(input.customerId||input.email||input.phone||input.name)return new Response('Personal identifiers are not accepted',{status:400});
 try{
  const {admin}=await unauthenticated.admin(shop);
  const result=await previewRecommendations(admin,shop,{...input,now:new Date().toISOString()});
  return Response.json({sectionTitle:result.sectionTitle,promptVersion:result.promptVersion,results:result.results.slice(0,5),close:result.close,generatedAt:result.generatedAt},{headers:{'cache-control':'private, max-age=60','access-control-allow-origin':process.env.STOREFRONT_ORIGIN||'https://www.discounthalloweencity.com'}});
 }catch(error){
  console.error('[gus-recommendations] recommendation service unavailable',error instanceof Error?error.message:error);
  return Response.json({error:'Recommendation service unavailable'},{status:503,headers:{'cache-control':'no-store'}});
 }
}
