import type { LoaderFunctionArgs } from "react-router";
import { useLoaderData } from "react-router";
import { authenticate } from "../shopify.server";
import { marketingCommandSnapshot } from "../services/marketing-command.server";
import { Page } from "../components/ui";
import { MarketingGrowthSurface } from "../components/marketing-growth-surface";
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return marketingCommandSnapshot(session.shop);}
export default function Route(){const d=useLoaderData<typeof loader>();return <Page title="Google Ads" subtitle="Paid search economics with evidence-backed spend and attribution."><MarketingGrowthSurface kind="google-ads" d={d}/></Page>;}
