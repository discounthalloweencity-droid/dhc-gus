import type {LoaderFunctionArgs} from "react-router";
import {Link,useLoaderData} from "react-router";
import {authenticate} from "../shopify.server";
import {debuggerSnapshot} from "../services/debugger.server";
import {buildDiagnosticBundle} from "../services/error-registry.server";
import pkg from "../../package.json";
import {Badge,Card,Grid,Metric,Page,Table} from "../components/ui";
import {DiagnosticDownload} from "../components/diagnostic-download";

export async function loader({request}:LoaderFunctionArgs){
 const {session}=await authenticate.admin(request); const url=new URL(request.url);
 if(url.searchParams.get("download")==="blackbox"){
  try{
   const bundle=await buildDiagnosticBundle(session.shop);
   const release=String((bundle as any)?.releaseVersion||pkg.version||"unknown");
   return new Response(JSON.stringify(bundle??{},null,2),{headers:{"Content-Type":"application/json","Content-Disposition":`attachment; filename=GUS_BLACK_BOX_${release}_${Date.now()}.json`,"Cache-Control":"no-store"}});
  }catch(error:any){
   // Diagnostics must fail open as an emergency bundle rather than turning the
   // debugger into a 503. The error text is intentionally bounded and contains
   // no request/session/token material.
   const message=String(error?.message||error||"Diagnostic bundle failure").slice(0,500);
   console.error("[gus-diagnostics] emergency Black Box fallback",message);
   const emergency={schemaVersion:2,generatedAt:new Date().toISOString(),shop:session.shop,releaseVersion:pkg.version,partial:true,warnings:[`Black Box bundle degraded: ${message}`],health:{runtime:true,database:false,diagnosticFallback:true},summary:{openErrors:null,historicalOpenErrors:null,totalOccurrences:null,topSources:[],productSnapshots:null,openFindings:null},errors:[],jobs:[],changes:[],releases:[],findings:[]};
   return new Response(JSON.stringify(emergency,null,2),{status:200,headers:{"Content-Type":"application/json","Content-Disposition":`attachment; filename=GUS_BLACK_BOX_${pkg.version}_EMERGENCY_${Date.now()}.json`,"Cache-Control":"no-store"}});
  }
 }
 return debuggerSnapshot(session.shop);
}
export default function Debugger(){const d=useLoaderData<typeof loader>();const tone=d.score>=90?"good":d.score>=70?"warn":"bad";return <Page title="Gus Black Box Debugger" subtitle="Live error registry, regression evidence, health scoring and updater-ready diagnostics.">
 <Grid><Metric label="System health" value={`${d.score}/100`}/><Metric label="Open bugs" value={d.open.length}/><Metric label="Recurring bugs" value={d.recurring.length}/><Metric label="Catalog evidence" value={d.snapshots}/></Grid><div style={{height:16}}/>
 <Card><p><Badge tone={tone}>{d.score>=90?"Healthy":d.score>=70?"Watch":"Needs attention"}</Badge> Runtime v{d.version} · DB {d.database?"reachable":"unavailable"} · Schema <Badge tone={d.schemaHealth?.status==="HEALTHY"?"good":"bad"}>{d.schemaHealth?.status||"UNKNOWN"}</Badge> · Gus {d.automation?.running?"RUNNING":"STOPPED"}</p>{d.schemaHealth?.missing?.length?<p><strong>Database schema gate:</strong> {d.schemaHealth.missing.length} required table{d.schemaHealth.missing.length===1?'':'s'} missing ({d.schemaHealth.missing.join(', ')}). Affected workers are paused before execution; run the reviewed additive production DB bootstrap to repair them.</p>:<p><strong>Database schema gate:</strong> all {d.schemaHealth?.required||0} required Prisma tables verified.</p>}<p>Black Box reconciliation: <strong>{d.reconciliation?.superseded||0}</strong> historical incident{d.reconciliation?.superseded===1?'':'s'} superseded from verified current-runtime recovery evidence. Historical records are retained for audit.</p><p><DiagnosticDownload url="?download=blackbox" label="Download updater-ready Black Box package"/></p><p style={{marginBottom:0,color:"#616161"}}>The package includes redacted error fingerprints, recurrence counts, release history, jobs, changes, catalog evidence and operating thresholds. Secrets and tokens are redacted.</p></Card><div style={{height:16}}/>
 <Card><h3>Highest-priority bugs</h3><Table headers={["Bug","Severity","Source","Message","Release","Hits","Last seen"]} rows={d.open.slice(0,25).map(e=>[<code>{e.errorKey}</code>,<Badge tone={e.severity==="FATAL"||e.severity==="ERROR"?"bad":e.severity==="WARN"?"warn":"neutral"}>{e.severity}</Badge>,e.source,e.message,e.releaseVersion,e.occurrenceCount,new Date(e.lastSeenAt).toLocaleString()])}/></Card><div style={{height:16}}/>
 <Card><h3>Regression / repetition watch</h3>{d.recurring.length? <Table headers={["Bug","Source","Occurrences","First seen","Last seen"]} rows={d.recurring.map(e=>[e.errorKey,e.source,e.occurrenceCount,new Date(e.firstSeenAt).toLocaleString(),new Date(e.lastSeenAt).toLocaleString()])}/>:<p>No recurring open failures detected.</p>}<p><Link to="/app/errors">Open full Error Registry →</Link></p></Card>
 </Page>}
