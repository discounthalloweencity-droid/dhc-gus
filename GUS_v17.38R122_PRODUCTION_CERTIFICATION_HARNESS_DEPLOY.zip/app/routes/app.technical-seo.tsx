import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='Technical SEO' subtitle='Technical search health for crawlability, canonicals, redirects, indexability, performance and duplicate-control signals.' data={data} focus={['Find crawl traps, broken internal routes, duplicate URLs, redirect chains and inconsistent canonical behavior.', 'Keep faceted navigation useful to shoppers without creating uncontrolled index bloat.', 'Treat Core Web Vitals and mobile rendering as conversion and SEO concerns.', 'Never claim a live crawl result unless an actual crawl or connected search source supports it.']}/>;}
