import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {Form,useActionData,useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {db} from '../db.server';
import {importFacts,validateFactInput,FACT_FIELDS,type FactInput} from '../services/facts.server';
import {Page,Card,Table} from '../components/ui';
import {variantOwnership} from '../services/shopify-api.server';
import {safeAppAction} from '../services/safe-app-action.server';

export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return {rows:await db.supplierFactRecord.findMany({where:{shop:session.shop},orderBy:{createdAt:'desc'},take:100}),factFields:FACT_FIELDS,adapters:{cj:!!process.env.CJ_ACCESS_TOKEN,dsers:!!process.env.DSERS_SUPPLIER_FEED_URL,aliexpressReplacement:!!process.env.ALIEXPRESS_REPLACEMENT_FEED_URL,syncee:!!process.env.SYNCEE_SUPPLIER_FEED_URL}};}
export async function action({request}:ActionFunctionArgs){return safeAppAction('suppliers',request,async()=>{
 const {session,admin}=await authenticate.admin(request);const f=await request.formData();
 try{
  const raw=String(f.get('facts')||'');if(raw.length>2000000)throw new Error('Import too large; use batches of up to 350 facts.');
  const rows=JSON.parse(raw);if(!Array.isArray(rows)||rows.length>350)throw new Error('Provide a JSON array of at most 350 facts.');
  // Validate the complete batch before touching the database.
  rows.forEach((r:FactInput)=>validateFactInput(r));
  const owners=await variantOwnership(admin,[...new Set(rows.map((r:FactInput)=>r.variantGid))]);
  if(owners.size!==new Set(rows.map((r:FactInput)=>r.variantGid)).size)throw new Error('One or more variants do not exist in this store. No facts imported.');
  const count=await importFacts(session.shop,rows);return {count};
 }catch(e:any){return {error:String(e?.message||e)};}
});}
export default function Suppliers(){const {rows,adapters,factFields}=useLoaderData<typeof loader>();const result=useActionData<typeof action>();return <Page title="Supplier Evidence" subtitle="Import verified, variant-specific supplier facts. No invented costs or delivery estimates.">
 <Card><h3>Live supplier adapters</h3><p>CJ: <strong>{adapters.cj?'Configured':'Not configured'}</strong> · DSers: <strong>{adapters.dsers?'Configured':'Not configured'}</strong> · Syncee: <strong>{adapters.syncee?'Configured':'Not configured'}</strong></p><p>DSers and Syncee use exact variant-mapped HTTPS evidence feeds. Missing provider access remains UNKNOWN; the app never treats Shopify zero inventory as supplier stockout proof.</p></Card><div style={{height:16}}/><Card><h3>Evidence import</h3><p>Use JSON arrays of up to 350 records. Each record requires a Shopify variant GID, field, value, source, reference and verification date. Supported fields: {factFields.join(', ')}. Shipping days must represent estimated customer delivery, not merely dispatch time.</p>
 <Form method="post"><textarea name="facts" rows={8} style={{width:'100%',fontFamily:'monospace'}} placeholder={JSON.stringify([{variantGid:'gid://shopify/ProductVariant/123456789',field:'shipping_days',value:10,source:'Supplier',reference:'Supplier listing / quote ID',verifiedAt:'2026-09-08T12:00:00Z',validUntil:'2026-09-15T12:00:00Z'}],null,2)}/><button type="submit">Validate and import</button></Form>
 {result&&('error'in result?<p role="alert">{result.error}</p>:<p>Imported {result.count} facts.</p>)}</Card>
 <Table headers={['Variant','Field','Value','Source','Reference','Verified','Expires']} rows={rows.map(r=>[r.variantGid,r.field,r.value,r.source,r.reference,r.verifiedAt.toISOString(),r.validUntil?.toISOString()||'No expiry'])}/>
 </Page>;}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
