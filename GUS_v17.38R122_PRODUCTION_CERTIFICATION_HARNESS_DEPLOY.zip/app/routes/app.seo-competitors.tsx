import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='Competitors' subtitle='Actions-first competitor intelligence: convert verified demand and competitor movement into DHC promotion, merchandising, PDP, Complete-the-Look, SEO, offer/price review or true gap review.' data={data} focus={['Start with what changed in customer demand, then use DHC inventory before sourcing.', 'Promote existing viable products and improve merchandising/PDP/Complete-the-Look before price or sourcing reactions.', 'Price review requires fresh like-for-like evidence and verified DHC economics; competitor evidence never auto-reprices.', 'Source only a genuinely unmatched, high-demand gap after licensing, delivery, supplier and margin review.', 'Use observed competitor pages as evidence; do not infer private traffic, revenue or conversion rates.']}/>;}
