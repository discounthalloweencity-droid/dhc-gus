// Compatibility lineage: 0.16.57-r31-dhc-seo-territories
// Previous cumulative hotfix: 0.16.57-r29-gus-builder-modes
import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {getDhcOfflineAdmin,DHC_CANONICAL_SHOP,DHC_OFFLINE_SESSION_ID,certifyDhcOfflineAdmin} from '../shopify.server';
import {answerStorefrontGus} from '../services/storefront-gus-ai.server';
import {ensureRequestDatabaseReady,isRuntimeInfrastructureError,resetRequestDatabaseReadiness} from '../services/runtime-database-readiness.server';

const CANONICAL_SHOP=()=>String(process.env.AUTHORITY_SHOP||'discount-halloween-city.myshopify.com').trim().toLowerCase();
const DEFAULT_ORIGINS=['https://www.discounthalloweencity.com','https://discounthalloweencity.com','https://discount-halloween-city.myshopify.com'];
const LIMIT_WINDOW_MS=10*60*1000;
const LIMIT_MAX=40;
const buckets=new Map<string,{count:number;resetAt:number}>();

function allowedOrigins(){
  const configured=String(process.env.STOREFRONT_ORIGIN||'').split(',').map(x=>x.trim()).filter(Boolean);
  return new Set([...DEFAULT_ORIGINS,...configured]);
}
function cors(request:Request){
  const origin=String(request.headers.get('origin')||'').trim();
  const allowed=allowedOrigins();
  const chosen=origin&&allowed.has(origin)?origin:DEFAULT_ORIGINS[0];
  return {
    'access-control-allow-origin':chosen,
    'access-control-allow-methods':'GET,POST,OPTIONS',
    'access-control-allow-headers':'content-type,accept',
    'cache-control':'no-store',
    'vary':'origin'
  };
}
function rejectOrigin(request:Request){
  const origin=String(request.headers.get('origin')||'').trim();
  if(!origin)return false;
  return !allowedOrigins().has(origin);
}
function clientKey(request:Request){
  const fwd=String(request.headers.get('x-forwarded-for')||'').split(',')[0].trim();
  const real=String(request.headers.get('x-real-ip')||'').trim();
  const ua=String(request.headers.get('user-agent')||'').slice(0,80);
  return `${fwd||real||'unknown'}|${ua}`;
}
function rateLimited(request:Request){
  const key=clientKey(request),now=Date.now(),prior=buckets.get(key);
  if(!prior||prior.resetAt<=now){buckets.set(key,{count:1,resetAt:now+LIMIT_WINDOW_MS});return false;}
  prior.count+=1;buckets.set(key,prior);return prior.count>LIMIT_MAX;
}
function safeJson(v:unknown,fallback:any){
  if(typeof v!=='string')return fallback;
  try{return JSON.parse(v)}catch{return fallback}
}
function clean(v:unknown,max=2200){return String(v??'').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim().slice(0,max)}
function orderSpecific(message:string){
  const q=message.toLowerCase();
  return /\b(?:my|an|the)\s+order\b|\border\s+(?:status|number|confirmation|issue|problem|help)\b|\btrack(?:ing)?\s+(?:(?:my|an|the)\s+)?order\b|\bwhere\s+is\s+(?:my|the)\s+(?:order|package)\b|\bcancel(?:lation)?\s+(?:my|an|the)?\s*order\b|\brefund\s+(?:status|pending|not received|never came)\b|\b(?:damaged|wrong|missing)\s+(?:item|package|order)\b|\bchange\s+(?:my\s+)?(?:shipping\s+)?address\b|\bcharged\s+twice\b|\bordered\s+twice\b/i.test(q);
}
async function input(request:Request){
  const ct=String(request.headers.get('content-type')||'').toLowerCase();
  if(ct.includes('application/json'))return await request.json().catch(()=>({}));
  const text=await request.text();
  const params=new URLSearchParams(text);const out:any={};for(const [k,v] of params.entries())out[k]=v;return out;
}
function response(payload:any,status:number,request:Request){return Response.json(payload,{status,headers:cors(request)});}

type DirectAdminState={admin:any;recovered:boolean;reason:string|null;validatedAt?:string;scopeCount?:number};

async function directAdmin(shop:string):Promise<DirectAdminState>{
  try{
    if(shop!==DHC_CANONICAL_SHOP)return {admin:null,recovered:false,reason:'OFFLINE_ADMIN_SHOP_MISMATCH'};
    const result:any=await getDhcOfflineAdmin();
    return {admin:result.admin,recovered:Boolean(result.state?.recoveredAlias),reason:null,validatedAt:result.state?.validatedAt,scopeCount:result.state?.scopeCount};
  }catch(error:any){
    const reason=String(error?.offlineAdminState?.reason||error?.message||'OFFLINE_ADMIN_SESSION_UNAVAILABLE').slice(0,600);
    console.warn('[gus-direct-chat] Certified canonical Shopify offline Admin unavailable; continuing in no-Admin shopper mode.',reason);
    return {admin:null,recovered:false,reason};
  }
}

function deterministicNoAdminReply(message:string){
  const q=message.toLowerCase();
  if(/\b(?:store location|physical store|retail store|nyc location|new york (?:city )?location|try (?:it|this|the costume) on|in-store|in store)\b/i.test(q))return "Discount Halloween City is an online retailer, so we don't have an NYC retail location or fitting room. If you send me the exact product name or link plus the size you need, I can help check the online listing and narrow down the best option.";
  if(q.includes('find my costume'))return 'Absolutely. Who is the costume for, what size do you need, what is your budget, and do you want scary, funny, classic, retro, or something else?';
  if(q.includes('complete my look'))return 'Tell me what costume or main piece you already have. I’ll help you finish the look with the right wig, makeup, prop, hat, gloves, or other accessories.';
  if(q.includes('help me decide'))return 'I can narrow it down quickly. Is this for an adult, kid, family/group, pet, or your home or yard—and about how much do you want to spend?';
  if(q.includes('ask gus anything'))return 'I’m here. Ask me about costumes, decorations, sizing, shipping, returns, or what would work best for your Halloween plan.';
  return 'I’m still here and can help. Tell me what you’re shopping for, who it is for, the size or space, your budget, and the Halloween style you want.';
}

async function noAdminAnswer(shop:string,message:string,history:any,pageContext:any,shopperProfile:any,reason:string|null){
  try{
    const result:any=await answerStorefrontGus(null,shop,{message,history,pageContext,shopperProfile});
    const reply=clean(result?.reply||'',2400)||deterministicNoAdminReply(message);
    return {
      ...result,
      ok:true,
      reply,
      degraded:true,
      catalogConnected:false,
      catalogMode:'NO_ADMIN_SESSION',
      transport:{mode:'DIRECT_RECOVERY',privateOrderData:false,selfHealing:true,degradedReason:reason||'OFFLINE_ADMIN_UNAVAILABLE'}
    };
  }catch(error){
    console.error('[gus-direct-chat] no-Admin conversational fallback failed',error instanceof Error?(error.stack||error.message):error);
    return {
      ok:true,
      reply:deterministicNoAdminReply(message),
      intent:'GENERAL',
      confidence:'LIMITED',
      products:[],
      aiConnected:false,
      degraded:true,
      catalogConnected:false,
      catalogMode:'NO_ADMIN_SESSION',
      transport:{mode:'DIRECT_RECOVERY',privateOrderData:false,selfHealing:true,degradedReason:reason||'OFFLINE_ADMIN_UNAVAILABLE'}
    };
  }
}

// Previous cumulative hotfix: 0.16.57-r21-dhc-brand-rules-engine
// Previous cumulative hotfix: 0.16.57-r22-dhc-merchandising-profiles
// Previous cumulative hotfix: 0.16.57-r23-dhc-signature-collections
// Previous cumulative hotfix: 0.16.57-r24-dynamic-merchandising-score
// Previous cumulative hotfix: 0.16.57-r25-support-email-communication-governance
// Previous cumulative hotfix: 0.16.57-r27-complete-look-graph
// Previous cumulative hotfix: 0.16.57-r28-gus-live-product-intelligence
// Previous cumulative hotfix: 0.16.57-r30-dhc-nostalgia-visual-system
// Previous cumulative hotfix: 0.16.57-r33-executive-retail-operating-dashboard
// Previous cumulative hotfix: 0.16.57-r34-storefront-chat-failsafe-recovery
// Previous cumulative hotfix: 0.16.57-r35-storefront-runtime-edge-recovery
// Previous cumulative hotfix: 0.16.57-r39-human-omnichannel-concierge
// Current cumulative hotfix: 0.16.57-r40-build-recovery-human-concierge
export async function loader({request}:LoaderFunctionArgs){
  if(rejectOrigin(request))return response({ok:false,error:'Origin not allowed',code:'GUS_DIRECT_ORIGIN_BLOCKED'},403,request);
  const offline:any=await certifyDhcOfflineAdmin({repairAlias:true}).catch((error:any)=>({ready:false,reason:String(error?.message||error)}));
  return response({ok:true,service:'Gus Storefront Direct Chat Recovery',runtime:'0.16.57',hotfix:'0.16.57-r40-build-recovery-human-concierge',previousCumulativeHotfix:'0.16.57-r39-human-omnichannel-concierge',mode:'non-sensitive-shopping-chat-only',selfHealing:true,noAdminConversationFallback:true,offlineAdmin:{ready:Boolean(offline?.ready),shop:DHC_CANONICAL_SHOP,sessionId:DHC_OFFLINE_SESSION_ID,reason:String(offline?.reason||''),validatedAt:offline?.validatedAt||null,scopeCount:Number(offline?.scopeCount||0),recoveredAlias:Boolean(offline?.recoveredAlias)}},200,request);
}

export async function action({request}:ActionFunctionArgs){
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors(request)});
  if(request.method!=='POST')return response({ok:false,error:'Method not allowed',code:'GUS_DIRECT_METHOD'},405,request);
  if(rejectOrigin(request))return response({ok:false,error:'Origin not allowed',code:'GUS_DIRECT_ORIGIN_BLOCKED'},403,request);
  if(rateLimited(request))return response({ok:false,error:'Gus is receiving too many requests. Please try again shortly.',code:'GUS_DIRECT_RATE_LIMIT'},429,request);
  const values:any=await input(request);
  const message=clean(values.message||values.summary||values.prompt||values.text||values.question||'',2000);
  if(!message)return response({ok:true,reply:'Tell me what you are shopping for and I’ll help.',intent:'EMPTY',confidence:'SUPPORTED',products:[],transport:{mode:'DIRECT_RECOVERY',privateOrderData:false,selfHealing:true}},200,request);

  // Direct recovery intentionally does not expose private order data. If the shopper
  // needs order-specific help, hand off to the secure support page rather than using
  // an unauthenticated browser fallback for protected data.
  if(orderSpecific(message)){
    return response({
      ok:true,
      reply:'I can help with that, but I need the secure customer-support flow before I access order-specific details. Use Customer Support and I’ll continue from there.',
      intent:'NEEDS_SUPPORT',confidence:'VERIFIED',needsSecureSupport:true,products:[],
      actions:[{type:'OPEN_SUPPORT',label:'Open Customer Support',url:'/pages/contact-us'}],
      transport:{mode:'DIRECT_RECOVERY',privateOrderData:false}
    },200,request);
  }

  const shop=CANONICAL_SHOP();
  const history=safeJson(values.history,[]),pageContext=safeJson(values.pageContext,{}),shopperProfile=safeJson(values.shopperProfile,{});
  const state=await directAdmin(shop);
  if(!state.admin)return response(await noAdminAnswer(shop,message,history,pageContext,shopperProfile,state.reason),200,request);

  try{
    const admin=state.admin;
    const result:any=await answerStorefrontGus(admin,shop,{message,history,pageContext,shopperProfile});
    return response({...result,catalogConnected:true,catalogMode:'SHOPIFY_ADMIN',transport:{mode:'DIRECT_RECOVERY',privateOrderData:false,selfHealing:true,adminRecovered:state.recovered,offlineAdminCertified:true,offlineAdminValidatedAt:state.validatedAt||null,offlineAdminScopeCount:Number(state.scopeCount||0)}},200,request);
  }catch(error:any){
    console.error('[gus-direct-chat] connected shopper answer failed; falling back without Admin dependency.',error?.stack||error?.message||error);
    return response(await noAdminAnswer(shop,message,history,pageContext,shopperProfile,'CONNECTED_ANSWER_FAILED'),200,request);
  }
}

// R26 compatibility lineage: 0.16.57-r26-pdp-exposure-hardening

// Visual doctrine: DHC-NOSTALGIA-VISUAL-SYSTEM-v1.0
