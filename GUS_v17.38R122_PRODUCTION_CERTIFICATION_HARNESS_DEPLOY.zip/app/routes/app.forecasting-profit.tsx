import type {LoaderFunctionArgs} from 'react-router';
import {Link,useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadForecastingProfit} from '../services/forecasting-profit.server';
import {Badge,Card,Grid,Metric,Page,Table} from '../components/ui';
const money=(n:number|null|undefined)=>n==null?'Not available':n.toLocaleString('en-US',{style:'currency',currency:'USD'});
export async function loader({request}:LoaderFunctionArgs){
 const {session}=await authenticate.admin(request);
 return loadForecastingProfit(session.shop);
}
export default function ForecastingProfit(){
 const d=useLoaderData<typeof loader>(),f=d.forecast;
 const annual=f.status==='READY'?f.scenarios.find(x=>x.name==='CURRENT_PACE')?.periods.find(x=>x.period==='ROLLING_12_MONTHS'):null;
 return <Page title="Forecasting & Profit" subtitle="Evidence-gated revenue and contribution scenarios. Missing or mixed inputs are withheld instead of guessed.">
  <div className="authority-toolbar"><Link to="/app/profit-intelligence">Profit intelligence</Link><Link to="/app/cash-flow">Cash flow</Link><Link to="/app/pricing">Pricing</Link></div>
  <Card><h2>Data and release status</h2>
   <p>Screen loaded {new Date(d.asOf).toLocaleString()}; this is not the source-data timestamp. Latest-source reconciliation and production validation are still required.</p>
   <p>{d.coverage.notes} {d.coverage.partial?'Read limit reached; sample may be incomplete.':''}</p>
  </Card><div style={{height:18}}/>
  <Grid>
   <Metric label="Forecast status" value={f.status==='READY'?'Scenario inputs validated':'Evidence required'}/>
   <Metric label="12-month net sales scenario" value={money(annual?.revenue)}/>
   <Metric label="12-month contribution after ads" value={money(annual?.netContribution)} detail="Not net profit; overhead and income tax excluded"/>
   <Metric label="Known contribution in sampled orders" value={money(d.profit.knownProfit)} detail={d.profit.ordersCosted+'/'+d.profit.ordersModeled+' distinct sampled orders costed; not a period total'}/>
  </Grid><div style={{height:18}}/>
  {f.status==='READY'?<>
   <Card><h2>Assumptions and scope</h2><p>{f.assumptions.note}</p>
    <p>Channel: {f.assumptions.channel}. Source captured: {f.assumptions.asOf}. Seasonal reference: {f.assumptions.seasonalReference}.</p>
    <p>Monthly seasonal weights: {f.assumptions.seasonalWeights.join(', ')}. Downside/upside apply 90%/110% traffic; neither implies measured price elasticity or a guaranteed growth rate.</p>
   </Card>
   <Table headers={['Scenario','Period','Start UTC','End UTC (exclusive)','Sessions','Orders','Net sales','Pre-ad contribution','Ads','After-ad contribution']}
    rows={f.scenarios.flatMap(s=>s.periods.map(p=>[s.label,p.period.replaceAll('_',' '),p.start.slice(0,10),p.endExclusive.slice(0,10),p.sessions,p.orders,money(p.revenue),money(p.grossProfit),money(p.adSpend),money(p.netContribution)]))}/>
  </>:<Card><h2>Forecast withheld</h2><ul>{f.evidence.missing.map(x=><li key={x}>{x}</li>)}</ul><p>Existing mixed-channel snapshots cannot certify these inputs automatically.</p></Card>}
  <div style={{height:18}}/><Card><h2>Price-increase review candidates</h2>
   <p>These are stored pricing candidates, not verified competitive recommendations. Profit lift is withheld until current costs, exact delivered competitor offers, configured fees, category floors and conversion evidence are checked. This page changes no prices.</p>
  </Card>
  <Table headers={['Product','Stored price','Stored candidate','Snapshot margin','Decision']}
   rows={d.opportunities.slice(0,100).map(x=>[x.title,money(x.price),money(x.recommendedPrice),x.margin==null?'Unknown':(x.margin*100).toFixed(1)+'%',<Badge tone="warn">{x.decision.status.replaceAll('_',' ')}</Badge>])}/>
  <div style={{height:18}}/><Card><h2>Evidence limits</h2>
   <p>Cash-flow reconciliation, channel-specific normalization, forecast accuracy history and live price testing remain separate gates. Missing functionality is not counted as a working engine.</p>
  </Card>
 </Page>;
}
