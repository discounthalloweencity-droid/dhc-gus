import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData,Link} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSales} from '../services/reporting.server';
import {Page,Card,Grid,Metric,Table,Badge} from '../components/ui';
import {RevenueChart} from '../components/charts';

const money=(n:number|null|undefined)=>n==null?'Not available':n.toLocaleString('en-US',{style:'currency',currency:'USD'});
const cleanError=(e:any)=>{
  const raw=String(e?.message||e||'Unknown Shopify reporting error');
  try{
    const parsed=JSON.parse(raw);
    if(Array.isArray(parsed))return parsed.map((x:any)=>x?.message||String(x)).filter(Boolean).join('; ').slice(0,600);
  }catch{}
  return raw.slice(0,600);
};

export async function loader({request}:LoaderFunctionArgs){
 const {admin,session}=await authenticate.admin(request);
 const n=Number(new URL(request.url).searchParams.get('days'));
 const days=[7,30,90].includes(n)?n:30;
 try{
  return {ok:true,...await loadSales(admin,session.shop,days),days,error:null};
 }catch(e:any){
  const error=cleanError(e);
  console.error('[gus-sales] Shopify reporting unavailable',{shop:session.shop,days,error});
  return {ok:false,days,error,asOf:new Date().toISOString(),truncated:false,coverage:'Shopify reporting is temporarily unavailable. Gus kept the Sales Dashboard online instead of treating the reporting error as an application failure.',orders:[],summary:{revenue:null,orders:0,refunds:null,contribution:null,contributionMargin:null,unknownCostOrders:0,products:[]}};
 }
}

export default function Sales(){
 const d=useLoaderData<typeof loader>(),s=d.summary;
 return <Page title="Sales Dashboard" subtitle="Revenue, orders, AOV, refunds and product sales performance from Shopify order data.">
  <div className="authority-toolbar">{[7,30,90].map(n=><Link key={n} className="authority-button" to={`/app/sales?days=${n}`}>{n} days</Link>)}</div>
  {!d.ok&&<div className="gus-flash gus-flash-bad"><strong>Shopify reporting unavailable.</strong><div>{d.error}</div><div>Gus kept this dashboard online. No store data was changed.</div></div>}
  <div className="authority-note">Data through {new Date(d.asOf).toLocaleString()}. {d.truncated?'Extraction is partial and requires more pagination. ':''}{d.coverage}</div>
  <Grid><Metric label="Customer revenue" value={money(s.revenue)}/><Metric label="Orders" value={s.orders}/><Metric label="AOV" value={s.orders&&s.revenue!=null?money(s.revenue/s.orders):'Not available'}/><Metric label="Refunds recorded" value={money(s.refunds)}/><Metric label="Estimated contribution" value={money(s.contribution)} detail={s.unknownCostOrders?'Cost coverage incomplete':'Before ads and unreconciled costs'}/><Metric label="Estimated margin" value={s.contributionMargin==null?'Not available':`${(s.contributionMargin*100).toFixed(1)}%`}/></Grid>
  <div style={{height:18}}/><Card><h2>Revenue trend</h2>{d.ok?<RevenueChart orders={d.orders} days={d.days}/>:<p>Revenue trend will appear automatically when Shopify reporting responds successfully.</p>}</Card>
  <div style={{height:18}}/><Table headers={['Product / variant','Units','Revenue','Known landed cost','Contribution','Coverage']} rows={[...s.products].sort((a:any,b:any)=>b.revenue-a.revenue).slice(0,100).map((p:any)=>[p.title,p.units,money(p.revenue),money(p.knownCost),money(p.unitContribution),<Badge tone={p.unknownUnits?'warn':'good'}>{p.unknownUnits?`${p.unknownUnits} units missing costs`:'Cost evidence present'}</Badge>])}/>
 </Page>
}
