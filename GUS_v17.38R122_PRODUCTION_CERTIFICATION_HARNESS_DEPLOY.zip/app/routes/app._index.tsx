// Compatibility prior visible marker: Runtime 0.16.39
import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { Form, Link, useActionData, useLoaderData, useOutletContext } from "react-router";
import { authenticate, unauthenticated } from "../shopify.server";
import { db } from "../db.server";
import { scanCatalog, reconcileCatalogJobs, requestCatalogStop } from "../services/scan.server";
import { automationState, setAutomationRunning } from "../services/automation-control.server";
import { liveWritesEnabled } from "../services/deployment-gates";
import { runGusOrchestrator } from "../services/orchestrator.server";
import { loadOperationsControl } from "../services/operations-control.server";
import { runAggressiveOrganicGrowth } from "../services/aggressive-organic-growth.server";
import { runStrikeKeywordEngineCycle } from "../services/strike-keyword-engine.server";
import { runShopRoiEngine } from "../services/shop-roi-engine.server";
import { runCatalogSelfHealing } from "../services/catalog-self-healing.server";
import { runPdpTrustRepair } from "../services/pdp-trust-repair.server";
import { runDailyNewProductIntake } from "../services/new-product-intake.server";
import { runWeeklyCollectionMaintenance } from "../services/weekly-collection-maintenance.server";
import { runWeeklySeoWatch } from "../services/weekly-seo-watch.server";
import { runRetailMissionWorker } from "../services/retail-mission-worker.server";
import { shopRoiMissionHandlers } from "../services/shop-roi-mission-worker.server";
import { runTrainingAccuracyEval } from '../services/training-center.server';
import { runTrainingLearningCycle } from '../services/training-learning.server';
import { runStorefrontConversionDirector } from '../services/storefront-conversion-director.server';
import { runOrderGuardian } from '../services/order-guardian.server';
import { runFulfillmentProductQuality } from '../services/fulfillment-product-quality.server';
import { runFulfillmentControlTower } from '../services/fulfillment-control-tower.server';
import { runCustomerServiceDirector } from '../services/customer-service-director.server';
import { actionRoiSummary, runActionRoiAttribution } from '../services/action-roi-attribution.server';
import { demandForecastSummary, runDemandAvailabilityForecast } from '../services/demand-availability-forecast.server';
import { operatorFeedbackSummary, recordOperatorFeedback } from '../services/operator-feedback.server';
import { goldenEvaluationSummary, runGoldenEvaluation } from '../services/golden-evaluation.server';
import { experimentSummary, createRetailExperiment, startRetailExperiment, evaluateRetailExperiment } from '../services/controlled-experiment.server';
import { supplierRiskSummary, runPredictiveSupplierRisk } from '../services/predictive-supplier-risk.server';
import { dynamicPricingSummary, runDynamicPricingOptimizer } from '../services/dynamic-pricing-optimizer.server';
import { retentionSummary, runCustomerRetentionIntelligence } from '../services/customer-retention-intelligence.server';
import { orderRiskSummary, runOrderRiskIntelligence } from '../services/order-risk-intelligence.server';
import { contentQualitySummary, runContentQualityEngine } from '../services/content-quality-engine.server';
import { basketBuilderSummary, runBasketBuilderIntelligence } from '../services/basket-builder-intelligence.server';
import { retailDirectorSummary, runAutonomousRetailDirector } from '../services/autonomous-retail-director.server';
import { closedLoopLearningSummary, runClosedLoopLearning } from '../services/closed-loop-learning.server';
import {turboCleanupState,setTurboCleanup} from '../services/turbo-cleanup-control.server';
import {throughputSnapshot} from '../services/high-throughput-worker-pool.server';
import {retailMissionConsumerSnapshot} from '../services/retail-mission-consumer.server';
import { continuousProductLearningSummary, runContinuousProductLearningDirector } from '../services/continuous-product-learning-director.server';
import { Badge, Card, Grid, Metric, Page, Table } from "../components/ui";
import type { JobProgressSnapshot } from "../types/job-progress";

import {safeAppAction} from '../services/safe-app-action.server';

const money=(n:number|null|undefined)=>n==null||!Number.isFinite(n)?"—":n.toLocaleString("en-US",{style:"currency",currency:"USD"});

export async function loader({request}:LoaderFunctionArgs) {
  // The parent /app route is the authentication gate. Keep the first dashboard paint
  // independent of Shopify API and database availability so embedded Shopify never
  // remains on “Building your app” while a dependency is slow or temporarily down.
  const shop = String(process.env.AUTHORITY_SHOP || "").trim().toLowerCase();
  const rawConcurrency=Number(process.env.GUS_DASHBOARD_DB_CONCURRENCY);
  const dashboardConcurrency=Number.isFinite(rawConcurrency)&&rawConcurrency>=1&&rawConcurrency<=8?Math.trunc(rawConcurrency):3;
  let dashboardActive=0;
  const dashboardWaiters:Array<()=>void>=[];
  const acquireDashboardSlot=async()=>{if(dashboardActive<dashboardConcurrency){dashboardActive++;return;}await new Promise<void>(resolve=>dashboardWaiters.push(resolve));dashboardActive++;};
  const releaseDashboardSlot=()=>{dashboardActive=Math.max(0,dashboardActive-1);const next=dashboardWaiters.shift();if(next)next();};
  const safe = async <T,>(label:string, task:()=>Promise<T>, fallback:T):Promise<T> => {
    await acquireDashboardSlot();
    try { return await task(); }
    catch(e:any) { console.warn(`[gus-dashboard] ${label} unavailable`,e?.message||e); return fallback; }
    finally { releaseDashboardSlot(); }
  };
  await safe("catalog job reconcile",()=>reconcileCatalogJobs(shop),null as any);
  const [automation,open,slow,margin,missingCost,pendingActions,lastJob,changes,recentChanges,supplierLinks,snapshots,activeJob,operations,inventoryProtectionJob,qualityProtectionJob,actionRoi,demandForecast,operatorFeedback,goldenEval,experiments,supplierRisk,dynamicPricing,retention,orderRisk,contentQuality,basketBuilder,retailDirector,closedLoop,continuousLearning,turbo,heartbeat] = await Promise.all([
    safe("automation",()=>automationState(shop),null as any),
    safe("open findings",()=>db.finding.count({where:{shop,status:"OPEN"}}),0),
    safe("shipping findings",()=>db.finding.count({where:{shop,status:"OPEN",code:"SHIP_OVER_LIMIT"}}),0),
    safe("margin findings",()=>db.finding.count({where:{shop,status:"OPEN",code:"MARGIN_LOW"}}),0),
    safe("cost findings",()=>db.finding.count({where:{shop,status:"OPEN",code:"COST_EVIDENCE_MISSING"}}),0),
    safe("pending actions",()=>db.actionProposal.count({where:{shop,status:"PENDING"}}),0),
    safe("last job",()=>db.jobRun.findFirst({where:{shop},orderBy:{startedAt:"desc"}}),null as any),
    safe("change count",()=>db.changeLog.count({where:{shop}}),0),
    safe("recent changes",()=>db.changeLog.findMany({where:{shop},orderBy:{createdAt:"desc"},take:8}),[] as any[]),
    safe("supplier links",()=>db.supplierVariantLink.count({where:{shop,enabled:true}}),0),
    safe("product snapshots",()=>db.productSnapshot.findMany({where:{shop},orderBy:{capturedAt:"desc"},take:250}),[] as any[]),
    safe("active catalog job",()=>db.jobRun.findFirst({where:{shop,jobType:"CATALOG_SCAN",status:"RUNNING"},orderBy:{startedAt:"desc"}}),null as any),
    safe("operations control",()=>loadOperationsControl(shop),null as any),
    safe("inventory protection",()=>db.jobRun.findFirst({where:{shop,jobType:"DAILY_INVENTORY_PROTECTION"},orderBy:{startedAt:"desc"}}),null as any),
    safe("quality protection",()=>db.jobRun.findFirst({where:{shop,jobType:"DAILY_PRODUCT_QUALITY_RISK"},orderBy:{startedAt:"desc"}}),null as any),
    safe("action ROI",()=>actionRoiSummary(shop),null as any),
    safe("demand forecast",()=>demandForecastSummary(shop),null as any),
    safe("operator feedback",()=>operatorFeedbackSummary(shop),null as any),
    safe("golden evaluation",()=>goldenEvaluationSummary(shop),null as any),
    safe("experiments",()=>experimentSummary(shop),null as any),
    safe("supplier risk",()=>supplierRiskSummary(shop),null as any),
    safe("dynamic pricing",()=>dynamicPricingSummary(shop),null as any),
    safe("retention",()=>retentionSummary(shop),null as any),
    safe("order risk",()=>orderRiskSummary(shop),null as any),
    safe("content quality",()=>contentQualitySummary(shop),null as any),
    safe("basket builder",()=>basketBuilderSummary(shop),null as any),
    safe("retail director",()=>retailDirectorSummary(shop),null as any),
    safe("closed loop",()=>closedLoopLearningSummary(shop),null as any),
    safe("continuous learning",()=>continuousProductLearningSummary(shop),null as any),
    safe("turbo cleanup state",()=>turboCleanupState(shop),{enabled:false,autoDisableWhenEmpty:true} as any),
    safe("autonomous heartbeat",()=>db.jobRun.findFirst({where:{shop,jobType:"AUTONOMOUS_HEARTBEAT"},orderBy:{startedAt:"desc"}}),null as any),
  ]);
  const uniqueProducts=new Set(snapshots.map((s:any)=>s.productGid)).size;
  const priced=snapshots.filter((s:any)=>s.margin!=null).length;
  const seoMeasured=snapshots.filter((s:any)=>s.seoScore!=null).length;
  const seoNeedsWork=snapshots.filter((s:any)=>s.seoScore!=null && s.seoScore<80).length;
  const consumer=await safe('retail consumer snapshot',()=>retailMissionConsumerSnapshot(shop),{state:'OFFLINE',reason:'SNAPSHOT_UNAVAILABLE',queued:0,claimableQueued:0,unhandledQueued:0,running:0,desiredConcurrency:0,itemsPerHour:0,etaHours:null,workerSlots:0,heartbeatAgeMs:null} as any);
  const throughput=consumer;
  const parseJob=(j:any)=>{if(!j)return null;let details:any={};try{details=j.details?JSON.parse(j.details):{}}catch{}return {status:j.status,startedAt:j.startedAt,finishedAt:j.finishedAt,scanned:j.scanned,changed:j.changed,warnings:j.warnings,details};};
  const heartbeatDetails=(()=>{try{return heartbeat?.details?JSON.parse(heartbeat.details):{}}catch{return {}}})();
  const heartbeatAgeMs=heartbeat?.startedAt?Date.now()-new Date(heartbeat.startedAt).getTime():null;
  return {shop,config:null,automation,operations,liveWrites:liveWritesEnabled(),open,slow,margin,missingCost,pendingActions,lastJob,activeJob,changes,recentChanges,supplierLinks,uniqueProducts,priced,seoMeasured,seoNeedsWork,inventoryProtection:parseJob(inventoryProtectionJob),qualityProtection:parseJob(qualityProtectionJob),actionRoi,demandForecast,operatorFeedback,goldenEval,experiments,supplierRisk,dynamicPricing,retention,orderRisk,contentQuality,basketBuilder,retailDirector,closedLoop,continuousLearning,turbo,throughput,consumer,heartbeat:heartbeat?{status:heartbeat.status,startedAt:heartbeat.startedAt,finishedAt:heartbeat.finishedAt,source:heartbeatDetails.source||null,ageMs:heartbeatAgeMs}:null,sales:null,salesError:"Live Shopify reporting loads after the Command Center opens."};
}


export async function action({request}:ActionFunctionArgs) {return safeAppAction('_index',request,async()=>{
  try{
    // safeAppAction may retry after a transient DB/session recovery. Never consume the
    // original Request body inside the retryable callback; clone it per attempt.
    const authRequest=request.clone();
    const formRequest=request.clone();
    const {admin,session} = await authenticate.admin(authRequest);
    const form=await formRequest.formData(); const intent=String(form.get("intent")||"");
    if(intent==="run"){ const state=await setAutomationRunning(session.shop,true); const cycle=state.running?await runGusOrchestrator(admin,session.shop,"MANUAL",{detached:true}):null; const proof=cycle&&"runId" in cycle?` Autonomous cycle #${cycle.runId} ${cycle.status==="ALREADY_RUNNING"?"is already running":"was queued immediately"}.`:""; return {ok:true,running:state.running,working:Boolean(cycle&&cycle.status!=="STOPPED"),runId:cycle&&"runId" in cycle?cycle.runId:null,message:state.running?`Gus is RUNNING.${proof} The 71-step auto engine rotation starts immediately and keeps every engine on an explicit server-side cadence, including organic growth, SEO, catalog, fulfillment, customer service, finance, and learning.`:"Gus is stopped."}; }
    if(intent==="turbo_on"){await setTurboCleanup(session.shop,true);const verified=await turboCleanupState(session.shop);if(!verified.enabled)throw new Error("Turbo state did not verify ON after write.");const cycle=await runGusOrchestrator(admin,session.shop,"MANUAL",{detached:true});return {ok:true,running:true,working:true,turboEnabled:true,message:`Turbo Cleanup ON. High-throughput cleanup will use spare capacity while inventory, orders, fulfillment and customer service retain priority.${cycle&&"runId" in cycle?` Cycle #${cycle.runId} queued.`:''}`};}
    if(intent==="turbo_off"){await setTurboCleanup(session.shop,false);return {ok:true,running:Boolean((await automationState(session.shop))?.running),working:false,turboEnabled:false,message:"Turbo Cleanup OFF. Gus returned to normal worker throughput."};}
    if(intent==="cycle"){const cycle=await runGusOrchestrator(admin,session.shop,"MANUAL",{detached:true});return {ok:true,running:true,working:cycle.status!=="STOPPED",message:cycle.status==="ALREADY_RUNNING"?`Full Gus cycle #${cycle.runId} is already running.`:cycle.status==="QUEUED"?`Full Gus cycle #${cycle.runId} queued.`:"Gus must be RUNNING before a cycle can start."};}
    const background=(label:string,work:()=>Promise<any>)=>{setImmediate(()=>{void work().catch((e:any)=>console.error(`[gus-operations] ${label} failed`,e?.message||e));});return {ok:true,running:true,working:true,message:`${label} queued. Refresh Command Center to see persisted RUNNING / COMPLETE status.`};};
    if(intent==="organic")return background("Organic growth cycle",()=>runAggressiveOrganicGrowth(admin,session.shop,true));
    if(intent==="strike")return background("Strike discovery",()=>runStrikeKeywordEngineCycle(admin,session.shop,{forceDiscovery:true,diagnosisLimit:2,attackLimit:0}));
    if(intent==="shop_roi")return background("Shop ROI pass",()=>runShopRoiEngine(admin,session.shop,true));
    if(intent==="catalog_self_heal")return background("Catalog self-healing pass",()=>runCatalogSelfHealing(admin,session.shop,true));
    if(intent==="pdp_trust")return background("PDP trust repair pass",()=>runPdpTrustRepair(admin,session.shop,true));
    if(intent==="new_products")return background("New-product intake",()=>runDailyNewProductIntake(admin,session.shop,true));
    if(intent==="collections")return background("Collection merchandising pass",()=>runWeeklyCollectionMaintenance(admin,session.shop,true));
    if(intent==="weekly_seo")return background("Weekly SEO watch",()=>runWeeklySeoWatch(session.shop,true));
    if(intent==="training_eval")return background("Gus expanded Gold Standard eval",()=>runTrainingAccuracyEval(session.shop,true));
    if(intent==="training_learning")return background("Gus training learning cycle",()=>runTrainingLearningCycle(session.shop,true));
    if(intent==="storefront_conversion")return background("Storefront conversion pass",()=>runStorefrontConversionDirector(admin,session.shop,true));
    if(intent==="order_guardian")return background("Order Guardian pass",()=>runOrderGuardian(admin,session.shop,true));
    if(intent==="fulfillment_quality")return background("Fulfillment product quality pass",()=>runFulfillmentProductQuality(admin,session.shop,true));
    if(intent==="fulfillment_control_tower")return background("Fulfillment Control Tower pass",()=>runFulfillmentControlTower(admin,session.shop,true));
    if(intent==="inventory_protection"){const {runDailyInventoryProtection}=await import("../services/inventory-protection.server");return background("Inventory protection pass",()=>runDailyInventoryProtection(admin,session.shop,true));}
    if(intent==="product_quality_risk"){const {runDailyProductQualityRisk}=await import("../services/product-quality-risk.server");return background("Product quality protection pass",()=>runDailyProductQualityRisk(admin,session.shop,true));}
    if(intent==="customer_service")return background("Customer Service Director pass",()=>runCustomerServiceDirector(session.shop,true));
    if(intent==="action_roi")return background("Action ROI attribution pass",()=>runActionRoiAttribution(admin,session.shop,true));
    if(intent==="demand_forecast")return background("Demand & availability forecast",()=>runDemandAvailabilityForecast(admin,session.shop,true));
    if(intent==="supplier_risk")return background("Predictive supplier risk",()=>runPredictiveSupplierRisk(session.shop,true));
    if(intent==="dynamic_pricing")return background("Dynamic pricing optimizer",()=>runDynamicPricingOptimizer(admin,session.shop,true));
    if(intent==="retention")return background("Customer retention intelligence",()=>runCustomerRetentionIntelligence(session.shop,true));
    if(intent==="order_risk")return background("Order risk intelligence",()=>runOrderRiskIntelligence(admin,session.shop,true));
    if(intent==="content_quality")return background("PDP content quality",()=>runContentQualityEngine(admin,session.shop,true));
    if(intent==="basket_builder")return background("Basket builder intelligence",()=>runBasketBuilderIntelligence(admin,session.shop,true));
    if(intent==="retail_director")return background("Autonomous retail director",()=>runAutonomousRetailDirector(session.shop,true));
    if(intent==="closed_loop")return background("Closed-loop learning",()=>runClosedLoopLearning(session.shop,true));
    if(intent==="continuous_learning")return background("Continuous product learning",()=>runContinuousProductLearningDirector(session.shop,true));
    if(intent==="golden_eval")return background("Golden-set evaluation",()=>runGoldenEvaluation(session.shop));
    if(intent==="experiment_create"){
      const targetId=String(form.get("targetId")||"").trim();if(!targetId)throw new Error("Experiment target required");
      const row=await createRetailExperiment(session.shop,{name:String(form.get("name")||"Merchandising experiment"),targetType:String(form.get("targetType")||"PRODUCT"),targetId,primaryMetric:String(form.get("primaryMetric")||"view_to_purchase"),control:{label:"CONTROL"},variant:{label:"VARIANT"},minSample:Number(form.get("minSample")||100),minDays:Number(form.get("minDays")||7),maxDays:Number(form.get("maxDays")||21),trafficSplit:.5,autoPromote:false,guardrails:["reversible change only","no price-floor violation","no out-of-stock promotion","no winner before minimum sample"]});
      return {ok:true,running:true,message:`Experiment #${row.id} created in DRAFT. Start it after the control and variant payloads are configured.`};
    }
    if(intent==="experiment_start"){const id=Number(form.get("experimentId"));await startRetailExperiment(session.shop,id);return {ok:true,running:true,message:`Experiment #${id} started.`};}
    if(intent==="experiment_evaluate"){const id=Number(form.get("experimentId"));const r=await evaluateRetailExperiment(session.shop,id);return {ok:true,running:true,message:`Experiment #${id}: ${r.result.status}${r.winner?` — ${r.winner} currently wins`:""}.`};}
    if(intent==="operator_feedback"){
      const targetType=String(form.get("targetType")||"CHANGE"),targetId=String(form.get("targetId")||""),verdict=String(form.get("verdict")||""),reasonCode=String(form.get("reasonCode")||""),note=String(form.get("note")||"");
      const feedback=await recordOperatorFeedback(session.shop,{targetType,targetId,verdict,reasonCode,note});
      return {ok:true,running:true,message:`Feedback recorded as ${feedback.verdict}. Gus will convert it into durable learning evidence on the next learning cycle.`};
    }
    if(intent==="mission_worker")return background("Retail mission worker",()=>runRetailMissionWorker(session.shop,shopRoiMissionHandlers(admin,session.shop),20));
    if(intent==="stop"){ await setAutomationRunning(session.shop,false); return {ok:true,running:false,message:"Gus stopped. New automated work is blocked."}; }
    if(intent==="stop_scan"){
      const stopped=await requestCatalogStop(session.shop);
      const state=await automationState(session.shop).catch(()=>null);
      return {ok:true,running:Boolean(state?.running),working:false,message:stopped.message};
    }
    if(intent==="scan"){
      const reconciled=await reconcileCatalogJobs(session.shop);
      if(reconciled?.status==="RUNNING"){const state=await automationState(session.shop);return {ok:true,running:Boolean(state?.running),working:true,message:"Catalog scan is already running in the background. Progress will keep updating across Command Center."};}
      const shop=session.shop;
      // Validate the stored offline Shopify session before claiming the worker started.
      const {admin:bgAdmin}=await unauthenticated.admin(shop);
      void scanCatalog(bgAdmin,shop,false).catch((e:any)=>console.error("[gus-background-scan] failed",e?.message||e));
      const state=await automationState(shop);
      return {ok:true,running:Boolean(state?.running),working:true,message:"Catalog worker launched. You can leave this page; progress and failures are persisted server-side."};
    }
    return {ok:false,message:"Unknown command."};
  }catch(e:any){
    if(e instanceof Response){
      if(e.status>=300&&e.status<400)throw e;
      console.error(`[gus-dashboard-action] HTTP ${e.status} command failure`);
      return {ok:false,message:e.status===401||e.status===403?"Shopify authorization is required before this control can run.":"The control plane is temporarily unavailable. Gus stayed online; retry this command in a moment."};
    }
    console.error("[gus-dashboard-action] command failed",e instanceof Error?(e.stack??e.message):String(e));
    return {ok:false,message:"Gus could not complete that command. Gus stayed online; check System Health and retry."};
  }
});}

export default function Dashboard(){
  const d=useLoaderData<typeof loader>();
  const result=useActionData<typeof action>();
  const outlet=useOutletContext<{activeJob:JobProgressSnapshot|null;authStatus:'connected'|'degraded';systemHealth:{status:'ONLINE'|'DEGRADED';reasons:string[]};engineActivity:any}>();
  const dashboardActiveJob=outlet.activeJob?.jobType==="CATALOG_SCAN"?outlet.activeJob:null;
  let jobDetails:any={}; try{jobDetails=dashboardActiveJob?.details?JSON.parse(dashboardActiveJob.details):{};}catch{}
  const jobTotal=Number(jobDetails.total||0), jobScanned=Number(dashboardActiveJob?.scanned||0);
  const jobPct=jobTotal>0?Math.min(99,Math.round(jobScanned/jobTotal*100)):(dashboardActiveJob?1:0);
  const databaseBusy=d.consumer?.reason==='DATABASE_POOL_BUSY';
  const running=(result as any)?.running ?? Boolean(d.automation?.running);
  const working=Boolean((result as any)?.working||dashboardActiveJob);
  const heroState=databaseBusy?'DEGRADED':working?'WORKING':running?'RUNNING':'STOPPED';
  const turboEnabled=(result as any)?.turboEnabled ?? Boolean(d.turbo?.enabled);
  const engineActivity=outlet.engineActivity||null;
  const engineRows:any[]=Array.isArray(engineActivity?.engines)?engineActivity.engines:[];
  const engineCycle=engineActivity?.cycle||{};
  const engineSummary=engineActivity?.summary||{};
  const currentEngine=engineRows.find((x:any)=>x.status==='RUNNING')||null;
  const cadenceLabel=(ms:number)=>{const mins=Math.max(1,Math.round(Number(ms||0)/60000));return mins<60?`${mins}m`:mins<1440?`${Math.round(mins/60)}h`:`${Math.round(mins/1440)}d`;};
  const timeLabel=(value:any)=>{if(!value)return '—';const x=String(value);return x.length>=19?`${x.slice(11,19)} UTC`:x;};
  const engineTone=(status:string)=>['COMPLETE','FRESH','CHECKED'].includes(status)?'engine-good':status==='RUNNING'?'engine-running':status==='ERROR'?'engine-error':status==='BLOCKED'?'engine-blocked':status==='DUE'||status==='WAITING'?'engine-due':'engine-neutral';
  const s = d.sales as {revenue:number;orders:number;contribution:number;unknownCostOrders:number}|null;
  const moduleCards:{title:string;status:string;metric:string;detail:string;to:string;tone:"neutral"|"good"|"warn"|"bad"}[]=[
    {title:"Pricing & Profitability",status:"LIVE",metric:d.margin?`${d.margin} margin alerts`:d.priced?`${d.priced} variants modeled`:"Ready to scan",detail:"Shipping-inclusive margin engine, big-box price ladder, costume floors and variant economics.",to:"/app/pricing",tone:d.margin?"warn":"good"},
    {title:"SEO & Catalog",status:"LIVE",metric:d.seoNeedsWork?`${d.seoNeedsWork} SEO opportunities`:d.seoMeasured?`${d.seoMeasured} SEO scores`:"Ready to scan",detail:"Titles, meta, taxonomy, search/filter audits and reversible catalog proposals.",to:"/app/seo",tone:d.seoNeedsWork?"warn":"good"},
    {title:"Shipping & Suppliers",status:"LIVE",metric:d.slow?`${d.slow} slow-ship alerts`:`${d.supplierLinks} mapped variants`,detail:"Supplier evidence, exact variant mapping, stock verification and delivery-risk detection.",to:"/app/shipping",tone:d.slow?"warn":"good"},
    {title:"Promotions",status:"LIVE",metric:"Margin guarded",detail:"Flash sales, clearance, cutoff protection and rollback-aware promotion controls.",to:"/app/promotions",tone:"good"},
    {title:"Personalization",status:"LIVE",metric:"Catalog gated",detail:"Browse-interest recommendations with stock, price and shipping evidence safeguards.",to:"/app/recommendations",tone:"good"},
    {title:"Customer Service Operations",status:"LIVE",metric:"One customer timeline",detail:"Email evidence, live Shopify order state, shipping, returns, sizing, and financial closure in one operations workspace.",to:"/app/customer-service-operations",tone:"good"},
    {title:"Retail Intelligence",status:"LIVE",metric:"Mission driven",detail:"Demand, anomalies, funnel, Merchant, competitor, authority, AI-discovery and lifecycle signals feeding one durable mission queue.",to:"/app/intelligence-command",tone:"good"},
  ];
  return <Page title="Gus Command Center" subtitle="Discount Halloween City · autonomous retail intelligence, profit protection and growth operations. · Runtime 0.17.31 R115"><style>{`
.turbo-panel{margin:18px 0;padding:22px;border:1px solid #334155;border-radius:16px;background:#071526;color:#e5eefb;box-shadow:0 0 0 1px rgba(34,197,94,.15)}
.turbo-top{display:flex;justify-content:space-between;gap:20px;align-items:center}.turbo-top h2{margin:4px 0;color:#4ade80}.turbo-top p{max-width:760px;color:#cbd5e1}
.turbo-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}.turbo-stats>div{background:#0b1d33;border:1px solid #243b55;border-radius:12px;padding:16px}.turbo-stats b{display:block;font-size:26px}.turbo-stats span{font-size:12px;color:#a9b7c8}
.turbo-meta{display:flex;flex-wrap:wrap;gap:20px;padding:12px;border-radius:10px;background:#0b1d33}.gus-degraded{color:#f59e0b}.gus-health-row{margin-top:14px;color:#86efac;font-size:13px}
.engine-panel{margin:18px 0;padding:22px;border:1px solid #2d3b50;border-radius:16px;background:linear-gradient(145deg,#07111f,#0b1728);color:#e8eef7;box-shadow:0 0 0 1px rgba(99,102,241,.12)}
.engine-head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px}.engine-head h2{margin:4px 0 6px;font-size:24px}.engine-head p{margin:0;color:#a9b7c8;max-width:840px}.engine-stats{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin:18px 0}.engine-stat{background:#0e2035;border:1px solid #263d59;border-radius:12px;padding:13px}.engine-stat b{display:block;font-size:22px;color:#fff}.engine-stat span{font-size:10px;letter-spacing:.04em;color:#91a2b7;text-transform:uppercase}.engine-current{display:grid;grid-template-columns:1.4fr .7fr .7fr;gap:10px;margin-bottom:12px}.engine-current>div{background:#0a1a2d;border:1px solid #263d59;border-radius:11px;padding:12px}.engine-current small{display:block;color:#7f91a7;font-size:9px;text-transform:uppercase;letter-spacing:.08em}.engine-current strong{display:block;margin-top:4px;color:#fff}.engine-phases{display:flex;gap:7px;flex-wrap:wrap;margin:0 0 12px}.engine-phase{padding:6px 8px;border-radius:999px;background:#111f31;border:1px solid #26384e;color:#aebdd0;font-size:9px}.engine-table-wrap{max-height:440px;overflow:auto;border:1px solid #26384e;border-radius:12px;background:#081522}.engine-table{width:100%;border-collapse:collapse;font-size:11px}.engine-table th{position:sticky;top:0;z-index:1;text-align:left;background:#0e1c2d;color:#8193a9;padding:10px;border-bottom:1px solid #26384e;text-transform:uppercase;font-size:9px;letter-spacing:.07em}.engine-table td{padding:9px 10px;border-bottom:1px solid #18283a;vertical-align:top}.engine-table tr:last-child td{border-bottom:0}.engine-name{font-weight:800;color:#eef4fb}.engine-sub{font-size:9px;color:#71849a;margin-top:2px}.engine-status{display:inline-flex;align-items:center;gap:5px;padding:3px 7px;border-radius:999px;font-size:9px;font-weight:900;white-space:nowrap}.engine-status:before{content:'';width:6px;height:6px;border-radius:50%;background:currentColor}.engine-good{color:#6ee7a2;background:rgba(34,197,94,.09)}.engine-running{color:#8b9cff;background:rgba(99,102,241,.15);box-shadow:0 0 14px rgba(99,102,241,.18)}.engine-error{color:#fca5a5;background:rgba(239,68,68,.12)}.engine-blocked{color:#fdba74;background:rgba(249,115,22,.11)}.engine-due{color:#fde68a;background:rgba(245,158,11,.1)}.engine-neutral{color:#a9b7c8;background:#162334}.engine-result{max-width:290px;color:#a9b7c8}.engine-result b{color:#dbe7f5}.engine-sequence-note{margin-top:10px;color:#8fa2b8;font-size:10px}
@media(max-width:900px){.engine-stats{grid-template-columns:repeat(2,1fr)}.engine-current{grid-template-columns:1fr}.engine-head{display:block}.engine-head form{margin-top:10px}}
@media(max-width:800px){.turbo-top{display:block}.turbo-stats{grid-template-columns:repeat(2,1fr)}.engine-table{min-width:760px}}
`}</style>
    <section className="gus-hero">
      <div><div className="gus-eyebrow">MASTER AI CONTROL</div><h2 className="gus-hero-title">Gus is <span className={databaseBusy?"gus-degraded":(running||working)?"gus-running":"gus-stopped"}>{heroState}</span></h2><p className="gus-hero-copy">{databaseBusy?"Database pool pressure detected. Gus is protecting the worker and retrying instead of falsely reporting STOPPED.":"Monitoring the store continuously. Inventory, orders and customer service retain priority while Gus processes safe catalog, SEO, margin and merchandising work."}</p><div className="gus-health-row">● Store &nbsp; ● Orders &nbsp; ● Inventory &nbsp; ● Customer Service &nbsp; ● Automations</div></div>
      <div className="gus-control-stack"><Link to="/app/gus" className="gus-talk">💬 Talk to Gus</Link><Form method="post" reloadDocument className="gus-control-row"><button className="gus-run" name="intent" value="run" disabled={running}>▶ RUN GUS</button><button className="gus-stop" name="intent" value="stop" disabled={!running}>■ STOP GUS</button><button className="gus-scan" name="intent" value="scan" disabled={Boolean(dashboardActiveJob)}>Run catalog scan</button>{dashboardActiveJob&&<button className="gus-stop" name="intent" value="stop_scan">■ STOP CATALOG</button>}</Form></div>
    </section>
    <section className="engine-panel">
      <div className="engine-head"><div><div className="gus-eyebrow">⚙ AUTO ENGINE ROTATION</div><h2>{running?(currentEngine?`${currentEngine.label} is running`:`${engineCycle.status||'READY'} · ${engineCycle.checked||0}/${engineCycle.total||engineRows.length||71} checked`):'Engine rotation paused'}</h2><p>Gus now follows one ordered engine sequence. Critical store protection runs first, then catalog, learning, fulfillment, organic growth/SEO, and production proof. Fresh engines are skipped without moving their cadence forward.</p></div><Form method="post"><button className="gus-run" name="intent" value="cycle" disabled={!running}>▶ Run rotation now</button></Form></div>
      <div className="engine-stats"><div className="engine-stat"><b>{engineCycle.position||0}/{engineCycle.total||engineRows.length||71}</b><span>Sequence position</span></div><div className="engine-stat"><b>{engineCycle.coveragePct??0}%</b><span>This cycle checked</span></div><div className="engine-stat"><b>{engineSummary.fresh??0}</b><span>Fresh / complete</span></div><div className="engine-stat"><b>{engineSummary.due??0}</b><span>Due / waiting</span></div><div className="engine-stat"><b>{(engineSummary.errors??0)+(engineSummary.blocked??0)}</b><span>Errors / blocked</span></div></div>
      <div className="engine-current"><div><small>Working now</small><strong>{currentEngine?.label|| (running?'Waiting for next scheduled cycle':'Gus is stopped')}</strong><div className="engine-sub">{currentEngine?.phase||engineCycle.currentPhase||'The next runtime pulse will resume the ordered sequence.'}</div></div><div><small>Next in sequence</small><strong>{engineCycle.nextLabel||'—'}</strong><div className="engine-sub">Every engine has an explicit cadence of 24h or less for its scheduler check.</div></div><div><small>Cycle</small><strong>{engineCycle.id?`#${engineCycle.id} · ${engineCycle.status}`:'Not started'}</strong><div className="engine-sub">Live view refreshes every 4 seconds through the signed progress channel.</div></div></div>
      <div className="engine-phases">{(engineActivity?.phases||[]).map((p:any)=><span className="engine-phase" key={p.phase}>{p.phase} · {p.checked}/{p.total}{p.errors?` · ${p.errors} err`:''}</span>)}</div>
      <div className="engine-table-wrap"><table className="engine-table"><thead><tr><th>#</th><th>Engine</th><th>Status</th><th>Cadence</th><th>Last check</th><th>What it did</th></tr></thead><tbody>{engineRows.map((e:any)=><tr key={e.key}><td>{e.index}</td><td><div className="engine-name">{e.label}</div><div className="engine-sub">{e.lane} · {e.phase}</div></td><td><span className={`engine-status ${engineTone(e.status)}`}>{e.status}</span></td><td>{cadenceLabel(e.cadenceMs)}</td><td>{timeLabel(e.lastCheckedAt||e.lastFinishedAt)}<div className="engine-sub">next {timeLabel(e.nextDueAt)}</div></td><td className="engine-result"><b>{e.lastResult||e.reason||'Waiting for first sequence'}</b>{(e.scanned||e.changed)?<div>{e.scanned?`${e.scanned} checked`:''}{e.scanned&&e.changed?' · ':''}{e.changed?`${e.changed} changed`:''}</div>:null}{e.error?<div style={{color:'#fca5a5'}}>{e.error}</div>:e.reason&&e.reason!=='FRESH'?<div>{e.reason}</div>:null}</td></tr>)}</tbody></table></div>
      <div className="engine-sequence-note">The schedule is server-side. Closing this browser does not stop the rotation. Heavy engines run only when due; the engine window shows FRESH when their current data is still inside its approved cadence.</div>
    </section>
    <section className="turbo-panel">
      <div className="turbo-top"><div><div className="gus-eyebrow">⚡ TURBO CLEANUP</div><h2>{turboEnabled?"AUTO MODE ACTIVE":"AUTO MODE STANDBY"}</h2><p>Automatically turns on when the cleanup queue builds or falls behind, then turns off when the automatic queue reaches zero. You can force it on manually at any time.</p></div><Form method="post"><button className={turboEnabled?"gus-stop":"gus-run"} name="intent" value={turboEnabled?"turbo_off":"turbo_on"}>{turboEnabled?"⚡ Turbo ON — Turn Off":"▶ Force Turbo On"}</button></Form></div>
      <div className="turbo-stats"><div><b>{databaseBusy&&d.throughput?.claimableQueued==null?"—":d.throughput?.claimableQueued??d.throughput?.queued??0}</b><span>Worker Queue</span></div><div><b>{databaseBusy&&d.throughput?.itemsPerHour==null?"—":d.throughput?.itemsPerHour??0}</b><span>Verified / Hour</span></div><div><b>{d.throughput?.etaHours==null?"—":`${d.throughput.etaHours}h`}</b><span>Estimated Time</span></div><div><b>{databaseBusy&&d.consumer?.workerSlots==null?"—":d.consumer?.workerSlots??d.throughput?.desiredConcurrency??0}</b><span>Target Workers</span></div></div>
      <div className="turbo-meta"><span>Mode: <b>{turboEnabled?"AUTO / TURBO":"AUTO / NORMAL"}</b></span><span>Worker service: <b>{d.consumer?.state??'UNKNOWN'}</b></span><span>Running missions: <b>{d.throughput?.running??0}</b></span><span>Last worker cycle: <b>{d.consumer?.heartbeatAgeMs==null?'Not proven':`${Math.max(0,Math.round(d.consumer.heartbeatAgeMs/1000))} sec ago`}</b></span><span>Server heartbeat: <b>{d.heartbeat?.ageMs==null?"Not proven":`${Math.max(0,Math.round(d.heartbeat.ageMs/60000))} min ago`}</b>{d.heartbeat?.source?` · ${d.heartbeat.source}`:""}</span><span>Browser required: <b>NO</b></span><span>Auto turn off: <b>Queue reaches zero</b></span>{d.throughput?.fault&&<span className="gus-stopped"><b>{d.throughput.fault}</b></span>}</div>
    </section>
    <div className="gus-safety"><strong>{turboEnabled?"✓ Auto Mode Active":"⚡ Auto Mode Monitoring"}</strong> · Gus automatically accelerates safe cleanup when backlog thresholds are reached and returns to normal when complete.</div>
    {result&&<div className={result.ok?"gus-flash gus-flash-good":"gus-flash gus-flash-bad"}>{result.message}</div>}
    {dashboardActiveJob&&<Card><div className="gus-card-head"><div><span className="gus-eyebrow">LIVE WORK</span><h2>Catalog scan · {jobPct}%</h2></div><Badge tone="warn">RUNNING</Badge></div><p><strong>{jobScanned}{jobTotal?` / ${jobTotal}`:''}</strong> products scanned · {dashboardActiveJob.warnings} findings · {dashboardActiveJob.changed} changes</p><progress value={jobPct} max="100" style={{width:'100%',height:18}}/><p>{jobDetails.message||'Working through the catalog'}{jobDetails.current?` · Now: ${jobDetails.current}`:''}</p><p style={{color:'#616161'}}>This job runs on the server. Background polling is disabled during recovery; refresh the page when you want the latest progress.</p></Card>}
    {!d.liveWrites&&<div className="gus-safety"><strong>Safety mode:</strong> Gus can run intelligence now. Store-changing automation remains protected by the production write gate until deployment/rollback validation is explicitly enabled.</div>}

    <div className="gus-section-head"><div><span className="gus-eyebrow">GUS VALUE CREATED / PROTECTED</span><h2>Closed-loop action measurement</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Measured actions" value={d.actionRoi?.measured??0} detail="Completed before/after measurement windows"/>
        <Metric label="Positive outcomes" value={d.actionRoi?.positive??0} detail="Measured actions with positive directional result"/>
        <Metric label="Negative outcomes" value={d.actionRoi?.negative??0} detail="Feeds future learning and rollback review"/>
        <Metric label="Protection actions" value={d.actionRoi?.protection??0} detail="Safety actions tracked separately from observed ROI"/>
        <Metric label="Attributable contribution" value={money(d.actionRoi?.attributableContribution)} detail="Directional observed estimate; not guaranteed causal"/>
        <Metric label="Confidence-weighted value" value={money(d.actionRoi?.confidenceWeightedContribution)} detail="Observed value discounted by attribution confidence"/>
      </Grid>
      <p style={{color:'#616161'}}>R45 separates measured commercial lift from protected value so Gus cannot claim revenue for an avoided bad order. Actions remain in MEASURING until their post-action window closes.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="action_roi">Run ROI attribution now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">LEARNING DIRECTOR</span><h2>Continuous product & job learning</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Training examples" value={d.continuousLearning?.latest?.scanned??0} detail="Outcome-linked examples reviewed"/>
        <Metric label="Jobs instrumented" value={d.continuousLearning?.details?.jobInstrumentation?.instrumented??0} detail="Completed jobs added to the learning loop"/>
        <Metric label="Windows closed" value={d.continuousLearning?.details?.closed?.windowsClosed??0} detail="7/14/30/60-day measurements completed"/>
        <Metric label="Recurring mistakes" value={d.continuousLearning?.details?.topRecurringMistakes?.length??0} detail="Top patterns Gus should practice"/>
        <Metric label="Golden gate" value={d.continuousLearning?.details?.promotionGate??'—'} detail="Learning promotion safety gate"/>
      </Grid>
      <p style={{color:'#616161'}}>Every instrumented touch follows observation → decision → action → measured outcome → training example. Weak evidence stays candidate-only; human corrections retain higher weight; golden-set regression blocks promotion.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="continuous_learning">Run learning director now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">AUTONOMOUS LEARNING</span><h2>Closed-loop outcome learning</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Work measured" value={d.closedLoop?.details?.workItemsEvaluated??0} detail="Completed executive actions evaluated"/>
        <Metric label="Positive lessons" value={d.closedLoop?.details?.positive??0} detail="Interventions with measured improvement"/>
        <Metric label="Negative lessons" value={d.closedLoop?.details?.negative??0} detail="Interventions Gus should de-emphasize"/>
        <Metric label="Need more evidence" value={d.closedLoop?.details?.insufficientEvidence??0} detail="No learning until evidence matures"/>
      </Grid>
      <p style={{color:'#616161'}}>R57 measures completed work, creates active lessons only when evidence is adequate, and feeds learned priority adjustments back into R56. Gus does not learn from missing baselines or immature samples.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="closed_loop">Run closed-loop learning now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">EXECUTIVE DIRECTOR</span><h2>What Gus should work on next</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Signals considered" value={d.retailDirector?.details?.signalsConsidered??0} detail="Cross-engine evidence reviewed"/>
        <Metric label="Priority focus" value={d.retailDirector?.details?.focusItems??0} detail="Highest-impact work selected"/>
        <Metric label="Executive queue" value={d.retailDirector?.details?.queuedToExecutive??0} detail="Items routed into governed execution"/>
      </Grid>
      <p style={{color:'#616161'}}>R56 ranks inventory, supplier, customer, loss prevention, PDP, pricing, basket-growth and experiment evidence by expected impact, confidence and urgency. Existing safety/human gates still control execution.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="retail_director">Run executive director now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">BASKET GROWTH</span><h2>Complete-the-Look intelligence</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Products evaluated" value={d.basketBuilder?.details?.productsEvaluated??0} detail="Available products checked"/>
        <Metric label="Anchors matched" value={d.basketBuilder?.details?.anchorsWithMatches??0} detail="Products with compatible add-ons"/>
        <Metric label="Basket edges" value={d.basketBuilder?.details?.compatibilityEdges??0} detail="Verified recommendation relationships"/>
      </Grid>
      <p style={{color:'#616161'}}>R55 connects costumes to wigs/makeup/props and decor to skeletons/graveyard/lighting using compatibility, audience, availability and delivery gates. It avoids generic cross-sells and does not force bundles.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="basket_builder">Build basket intelligence now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">PDP QUALITY</span><h2>Creative & product content quality</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Products scanned" value={d.contentQuality?.details?.productsScanned??0} detail="Active PDPs audited"/>
        <Metric label="Critical" value={d.contentQuality?.details?.critical??0} detail="Severe content gaps"/>
        <Metric label="High risk" value={d.contentQuality?.details?.high??0} detail="Material PDP-quality problems"/>
        <Metric label="Repair candidates" value={d.contentQuality?.details?.repairCandidates??0} detail="Products with actionable content issues"/>
      </Grid>
      <p style={{color:'#616161'}}>R54 checks supplier-style titles, thin descriptions, shipping contradictions, imagery/alt text, size-guide coverage and included-piece clarity. Missing facts become review items—Gus never invents product specifications.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="content_quality">Run content quality now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">LOSS PREVENTION</span><h2>Order risk intelligence</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Orders scanned" value={d.orderRisk?.details?.ordersScanned??0} detail="Recent orders evaluated"/>
        <Metric label="Manual review" value={d.orderRisk?.details?.manualReview??0} detail="Higher loss-risk orders"/>
        <Metric label="Watch" value={d.orderRisk?.details?.watch??0} detail="Moderate-risk orders"/>
      </Grid>
      <p style={{color:'#616161'}}>R53 is risk triage—not a fraud verdict. Gus does not automatically cancel, refund, void/capture payment, stop fulfillment, or accuse a customer. High-risk evidence is routed for human review.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="order_risk">Run order risk now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">CUSTOMER LIFECYCLE</span><h2>Retention & post-purchase intelligence</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Customer cohorts" value={d.retention?.details?.customerCohorts??0} detail="Privacy-minimized post-purchase groups"/>
        <Metric label="At risk" value={d.retention?.details?.atRisk??0} detail="Open support/return/quality risk"/>
        <Metric label="Review eligible" value={d.retention?.details?.reviewEligible??0} detail="Resolved clean experiences"/>
        <Metric label="Cross-sell eligible" value={d.retention?.details?.crossSellEligible??0} detail="Healthy post-purchase opportunities"/>
      </Grid>
      <p style={{color:'#616161'}}>R52 turns support, returns, exchanges, refunds and quality outcomes into customer-health signals. It does not automatically email or solicit reviews; outreach remains separately governed.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="retention">Run retention intelligence now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">PROFIT OPTIMIZATION</span><h2>Dynamic pricing & margin</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Variants analyzed" value={d.dynamicPricing?.details?.scannedVariants??0} detail="Active variants evaluated"/>
        <Metric label="Price experiments" value={d.dynamicPricing?.details?.experimentCandidates??0} detail="Controlled price-test candidates"/>
        <Metric label="Needs cost review" value={d.dynamicPricing?.details?.reviewRequired??0} detail="Missing/invalid verified economics"/>
      </Grid>
      <p style={{color:'#616161'}}>R51 protects the DHC costume/mask floors, 25% minimum margin and .97 presentation. It uses verified product + supplier shipping costs, demand and supply risk. Missing acquisition cost reduces confidence instead of being invented. Recommendations do not directly change Shopify prices.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="dynamic_pricing">Run pricing optimizer now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">SUPPLY RESILIENCE</span><h2>Predictive supplier risk</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Supplier links scored" value={d.supplierRisk?.details?.scannedLinks??0} detail="Variant-source relationships evaluated"/>
        <Metric label="High risk" value={d.supplierRisk?.details?.highRisk??0} detail="HIGH or CRITICAL supplier risk"/>
        <Metric label="Critical" value={d.supplierRisk?.details?.critical??0} detail="Strong evidence for source-pause review"/>
        <Metric label="Diversify" value={d.supplierRisk?.details?.diversificationRecommendations??0} detail="Backup-source recommendations"/>
      </Grid>
      <p style={{color:'#616161'}}>R50 combines availability history, delivery behavior, support/quality evidence, source redundancy, warehouse geography and Halloween urgency. It recommends diversification but does not silently switch fulfillment ownership.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="supplier_risk">Run supplier risk now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">CONTROLLED OPTIMIZATION</span><h2>Merchandising & PDP experiments</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Running" value={d.experiments?.running??0} detail="Controlled experiments collecting evidence"/>
        <Metric label="Complete" value={d.experiments?.complete??0} detail="Finished experiments"/>
        <Metric label="Drafts" value={d.experiments?.drafts??0} detail="Awaiting setup/start"/>
      </Grid>
      <p style={{color:'#616161'}}>R49 uses deterministic session assignment and a 95% winner threshold. It does not auto-promote storefront changes yet; a winner becomes verified evidence for the Learning Director and later promotion workflow.</p>
      <Form method="post" className="gus-control-row">
        <input name="name" placeholder="Experiment name" />
        <select name="targetType" defaultValue="PRODUCT"><option>PRODUCT</option><option>COLLECTION</option><option>SEARCH_QUERY</option></select>
        <input name="targetId" placeholder="Target product/collection/query" required />
        <select name="primaryMetric" defaultValue="view_to_purchase"><option value="view_to_purchase">Purchase rate</option><option value="view_to_cart">Add-to-cart rate</option></select>
        <input name="minSample" type="number" defaultValue="100" min="20" />
        <input name="minDays" type="number" defaultValue="7" min="1" />
        <input name="maxDays" type="number" defaultValue="21" min="2" />
        <button className="gus-scan" name="intent" value="experiment_create">Create experiment</button>
      </Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">RELEASE SAFETY LAB</span><h2>Golden-set evaluation</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Latest status" value={d.goldenEval?.latest?.status??"NOT RUN"} detail="PASS required for a clean evaluation"/>
        <Metric label="Accuracy" value={d.goldenEval?.latest?.score!=null?`${Math.round(d.goldenEval.latest.score*100)}%`:"—"} detail="Versioned critical-decision test set"/>
        <Metric label="Cases passed" value={d.goldenEval?.details?.passed??0} detail={`of ${d.goldenEval?.details?.total??0} golden cases`}/>
        <Metric label="Regressions" value={d.goldenEval?.details?.regression?1:0} detail="Compared with last passing run"/>
      </Grid>
      <p style={{color:'#616161'}}>The lab evaluates deterministic Gus decision rules independently of live Shopify writes. A regression produces a critical signal instead of being silently accepted.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="golden_eval">Run golden evaluation now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">HUMAN → GUS LEARNING</span><h2>Operator feedback loop</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Feedback decisions" value={d.operatorFeedback?.total??0} detail="Durable operator judgments"/>
        <Metric label="Correct" value={d.operatorFeedback?.correct??0} detail="Reinforces comparable decisions"/>
        <Metric label="Wrong" value={d.operatorFeedback?.wrong??0} detail="Creates corrective learning evidence"/>
        <Metric label="Too aggressive" value={d.operatorFeedback?.aggressive??0} detail="Tells Gus to raise evidence threshold"/>
        <Metric label="Too conservative" value={d.operatorFeedback?.conservative??0} detail="Tells Gus to increase sensitivity"/>
        <Metric label="Pending learning" value={d.operatorFeedback?.pending??0} detail="Awaiting next learning cycle"/>
      </Grid>
      <Form method="post" className="gus-control-row">
        <input name="targetId" placeholder="Change / mission / signal ID" required />
        <select name="targetType" defaultValue="CHANGE"><option>CHANGE</option><option>MISSION</option><option>SIGNAL</option><option>PRODUCT</option></select>
        <select name="verdict" defaultValue="CORRECT"><option>CORRECT</option><option>WRONG</option><option>TOO_AGGRESSIVE</option><option>TOO_CONSERVATIVE</option><option>UNDO_REQUESTED</option></select>
        <input name="reasonCode" placeholder="Reason (optional)" />
        <input name="note" placeholder="What Gus should learn" />
        <button className="gus-scan" name="intent" value="operator_feedback">Teach Gus</button>
      </Form>
      <p style={{color:'#616161'}}>Feedback becomes a 100%-confidence human intelligence signal and then durable BrainKnowledge. An UNDO_REQUESTED verdict is a learning/escalation signal only; it does not silently execute a rollback.</p>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">PREDICTIVE RETAIL</span><h2>Demand & availability forecast</h2></div></div>
    <Card>
      <Grid>
        <Metric label="Variants forecast" value={d.demandForecast?.details?.scannedVariants??0} detail="Active variants evaluated"/>
        <Metric label="High-risk stockouts" value={d.demandForecast?.details?.highRisk??0} detail="Forecast HIGH or CRITICAL"/>
        <Metric label="Critical" value={d.demandForecast?.details?.critical??0} detail="Immediate availability danger"/>
        <Metric label="Backup-source recommendations" value={d.demandForecast?.details?.backupSourceRecommendations??0} detail="Proactive re-source candidates"/>
        <Metric label="Days to Halloween" value={d.demandForecast?.details?.daysToHalloween??0} detail="Seasonal urgency input"/>
      </Grid>
      <p style={{color:'#616161'}}>Forecasting is advisory. It can trigger sourcing and merchandising work early, but Inventory Protection remains the authoritative engine for blocking or archiving products.</p>
      <Form method="post"><button className="gus-scan" name="intent" value="demand_forecast">Run demand forecast now</button></Form>
    </Card>

    <div className="gus-section-head"><div><span className="gus-eyebrow">DAILY PROTECTION</span><h2>Inventory & product quality</h2></div></div>
    <Grid>
      <Card>
        <div className="gus-card-head"><div><span className="gus-eyebrow">INVENTORY PROTECTION</span><h2>Daily sellability guard</h2></div><Badge tone={d.inventoryProtection?.status==="DONE"?"good":d.inventoryProtection?.status==="FAILED"?"bad":"neutral"}>{d.inventoryProtection?.status||"NOT RUN"}</Badge></div>
        <Grid>
          <Metric label="Products scanned" value={d.inventoryProtection?.details?.scannedProducts??d.inventoryProtection?.scanned??0} detail="Active products checked"/>
          <Metric label="Variants blocked" value={d.inventoryProtection?.details?.policiesFixed??0} detail="Zero-stock variants changed to DENY"/>
          <Metric label="Products archived" value={d.inventoryProtection?.details?.archived??0} detail="No safe sellable variants remained"/>
          <Metric label="Needs review" value={d.inventoryProtection?.details?.unknownProducts??0} detail="Inventory evidence incomplete or unknown"/>
        </Grid>
        <Form method="post"><button className="gus-scan" name="intent" value="inventory_protection">Run inventory protection now</button></Form>
      </Card>
      <Card>
        <div className="gus-card-head"><div><span className="gus-eyebrow">QUALITY PROTECTION</span><h2>Expectation-risk guard</h2></div><Badge tone={d.qualityProtection?.status==="DONE"?"good":d.qualityProtection?.status==="FAILED"?"bad":"neutral"}>{d.qualityProtection?.status||"NOT RUN"}</Badge></div>
        <Grid>
          <Metric label="Products scanned" value={d.qualityProtection?.details?.scanned??d.qualityProtection?.scanned??0} detail="Active products checked"/>
          <Metric label="Quality flags" value={d.qualityProtection?.details?.flagged??d.qualityProtection?.warnings??0} detail="Products with representation/quality risk"/>
          <Metric label="Products archived" value={d.qualityProtection?.details?.archived??0} detail="High-confidence quality risk removed"/>
          <Metric label="Review queue" value={(d.qualityProtection?.details?.examples||[]).filter((x:any)=>!x.archiveCandidate).length} detail="Lower-confidence findings retained for review"/>
        </Grid>
        <Form method="post"><button className="gus-scan" name="intent" value="product_quality_risk">Run quality protection now</button></Form>
      </Card>
    </Grid>

    <div className="gus-section-head"><div><span className="gus-eyebrow">OPERATIONS CONTROL</span><h2>Manual work queue</h2></div><Link to="/app/queue" reloadDocument>Open mission queue →</Link></div>
    <p style={{marginTop:-8,color:'#616161'}}>One board for every major manual start. Status comes from persisted jobs and missions, not from button-click optimism. Autonomous jobs still run on their normal cadence; these controls are for forcing a pass now.</p>
    {d.operations?<><Grid>
      <Metric label="Engines running" value={d.operations.summary.running} detail={d.operations.running?"Master automation RUNNING":"Master automation STOPPED"}/>
      <Metric label="Queued work" value={d.operations.summary.queued} detail="Persisted executable work waiting"/>
      <Metric label="Ready to run" value={d.operations.summary.ready} detail="Manual pass can be started now"/>
      <Metric label="Warning engines" value={d.operations.summary.warnings||0} detail={d.operations.summary.warnings?"Completed with warnings — inspect engine detail":"No warning engine state"}/><Metric label="Failed engines" value={d.operations.summary.failed} detail={d.operations.summary.failed?"Needs operator attention":"No failed engine state"}/>
      <Metric label="Pending approvals" value={d.operations.pendingApprovals} detail="Owner decision required only"/>
      <Metric label="Autonomous backlog" value={d.operations.autonomousPending||0} detail="Routine reversible proposals Gus drains automatically"/>
      <Metric label="Approved actions" value={d.operations.approvedActions} detail="Ready for approval worker"/>
    </Grid><div style={{height:14}}/>
    <Table headers={["Engine","State","Queue","Last run","Auto cadence","Manual control"]} rows={d.operations.rows.map((r:any)=>[
      <div><strong>{r.label}</strong><div style={{fontSize:11,color:'#777',marginTop:3}}>{r.description}</div><Link to={r.route} reloadDocument style={{fontSize:11}}>Open engine →</Link></div>,
      <Badge tone={r.state==='RUNNING'?'good':r.state==='FAILED'?'bad':r.state==='WARNING'||r.state==='QUEUED'||r.state==='READY'?'warn':'neutral'}>{r.state}</Badge>,
      r.queue||'—',
      r.lastStartedAt?<div>{new Date(r.lastStartedAt).toLocaleString()}<div style={{fontSize:11,color:'#777'}}>{r.detail}</div></div>:<span style={{color:'#777'}}>Not run yet</span>,
      r.cadence,
      <Form method="post" reloadDocument><button type="submit" className="authority-button authority-primary" name="intent" value={r.id}>{r.button}</button></Form>
    ])}/></>:<Card><p>Operations status is temporarily unavailable. Gus remains isolated from this dashboard failure.</p></Card>}
    {d.operations?.pendingApprovals>0&&<div className="gus-safety"><strong>{d.operations.pendingApprovals} high-risk actions need you.</strong> Routine reversible work is excluded from this number and drains automatically. <Link to="/app/actions">Review Approval Queue →</Link></div>}

    <div className="gus-section-head"><div><span className="gus-eyebrow">STORE PULSE</span><h2>What matters now</h2></div><Link to="/app/reporting">Open full reporting →</Link></div>
    <Grid>
      <Metric label="7-day revenue" value={s?money(s.revenue):"Unavailable"} detail={d.salesError?"Shopify reporting unavailable":`${s?.orders||0} orders retrieved`}/>
      <Metric label="Est. contribution" value={s?money(s.contribution):"—"} detail={s?.unknownCostOrders?`${s.unknownCostOrders} orders missing cost evidence`:"Before unreconciled ads/returns"}/>
      <Metric label="Open intelligence issues" value={d.open} detail={d.open?"Gus has work queued":"No open findings recorded"}/>
      <Metric label="Pending approvals" value={d.pendingActions} detail="Only actions that require review"/>
      <Metric label="Catalog products sampled" value={d.uniqueProducts} detail="Latest stored product snapshots"/>
      <Metric label="Recorded changes" value={d.changes} detail="Auditable change history"/>
    </Grid>

    <div className="gus-section-head"><div><span className="gus-eyebrow">OPERATING SYSTEM</span><h2>Working modules</h2></div><Link to="/app/modules">View technical registry →</Link></div>
    <div className="gus-module-grid">{moduleCards.map(m=><Link key={m.title} to={m.to} className="gus-module-card"><div className="gus-module-top"><span className="gus-module-icon">{m.title.charAt(0)}</span><Badge tone={m.tone}>{m.status}</Badge></div><h3>{m.title}</h3><div className="gus-module-metric">{m.metric}</div><p>{m.detail}</p><span className="gus-module-link">Open module →</span></Link>)}</div>

    <div className="gus-two-col">
      <Card><div className="gus-card-head"><div><span className="gus-eyebrow">PRIORITY QUEUE</span><h2>Gus attention required</h2></div><Link to="/app/findings">All issues →</Link></div><div className="gus-priority-list">
        <Link to="/app/pricing"><span>Margin below floor</span><strong>{d.margin}</strong></Link>
        <Link to="/app/shipping"><span>Shipping over 12 days</span><strong>{d.slow}</strong></Link>
        <Link to="/app/suppliers"><span>Missing cost evidence</span><strong>{d.missingCost}</strong></Link>
        <Link to="/app/actions"><span>Awaiting approval</span><strong>{d.pendingActions}</strong></Link>
      </div></Card>
      <Card><div className="gus-card-head"><div><span className="gus-eyebrow">SYSTEM HEALTH</span><h2>Live connections</h2></div><Link to="/app/readiness">Readiness →</Link></div><div className="gus-health-list">
        <div><span>Shopify authenticated</span><Badge tone={outlet.authStatus==='connected'?"good":"warn"}>{outlet.authStatus==='connected'?"CONNECTED":"DEGRADED"}</Badge></div>
        <div><span>Command Center health</span><Badge tone={outlet.systemHealth?.status==='ONLINE'?"good":"warn"}>{outlet.systemHealth?.status||"DEGRADED"}</Badge></div>
        <div><span>Supplier mappings</span><Badge tone={d.supplierLinks?"good":"warn"}>{d.supplierLinks?`${d.supplierLinks} ACTIVE`:"NEEDS DATA"}</Badge></div>
        <div><span>Production writes</span><Badge tone={d.liveWrites?"good":"warn"}>{d.liveWrites?"ENABLED":"PROTECTED"}</Badge></div>
      </div></Card>
    </div>

    <div className="gus-section-head"><div><span className="gus-eyebrow">ACTIVITY</span><h2>Recent Gus changes</h2></div><Link to="/app/changes">Full history →</Link></div>
    <Table headers={["When","Action","Reason","Reversible"]} rows={d.recentChanges.map(c=>[new Date(c.createdAt).toLocaleString(),c.action,c.reason,<Badge tone={c.reversible?"good":"neutral"}>{c.reversible?"YES":"NO"}</Badge>])}/>
    {d.lastJob&&<div className="gus-last-run">Last catalog job: <strong>{d.lastJob.status}</strong> · {d.lastJob.scanned} scanned · {d.lastJob.changed} changes · {d.lastJob.warnings} findings</div>}
  </Page>;
}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
