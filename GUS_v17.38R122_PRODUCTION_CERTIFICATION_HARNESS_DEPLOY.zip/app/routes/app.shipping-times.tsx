import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSupplierFulfillmentDashboard} from '../services/supplier-fulfillment-dashboard.server';
import {SupplierFulfillmentSurface} from '../components/supplier-fulfillment-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSupplierFulfillmentDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SupplierFulfillmentSurface title='Shipping Times' subtitle='Verified customer-delivery windows and shipping-risk monitoring by supplier and warehouse.' data={data} focus={['Shipping days represent estimated customer delivery, not merely supplier dispatch time.','Flag products beyond the configured delivery threshold or with missing shipping evidence.','Prefer faster verified routes when product identity, landed margin and reliability remain acceptable.','Do not promise customer delivery dates that supplier evidence cannot support.']}/>;}
