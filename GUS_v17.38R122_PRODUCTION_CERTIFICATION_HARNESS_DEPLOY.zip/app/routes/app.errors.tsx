import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { Form, useLoaderData } from "react-router";
import { authenticate } from "../shopify.server";
import { db } from "../db.server";
import { buildDiagnosticBundle } from "../services/error-registry.server";
import { Badge, Card, Grid, Metric, Page, Table } from "../components/ui";
import { DiagnosticDownload } from "../components/diagnostic-download";

import {safeAppAction} from '../services/safe-app-action.server';

export async function loader({request}:LoaderFunctionArgs){
 const {session}=await authenticate.admin(request);
 const url=new URL(request.url);
 if(url.searchParams.get("download")==="diagnostics"){
  const bundle=await buildDiagnosticBundle(session.shop);
  return new Response(JSON.stringify(bundle,null,2),{headers:{"Content-Type":"application/json","Content-Disposition":`attachment; filename=dhc-diagnostics-${Date.now()}.json`,"Cache-Control":"no-store"}});
 }
 const rows=await db.errorEvent.findMany({where:{shop:session.shop},orderBy:{lastSeenAt:"desc"},take:300});
 const counts={open:rows.filter(r=>r.status==="OPEN").length,fatal:rows.filter(r=>r.status==="OPEN"&&r.severity==="FATAL").length,occurrences:rows.reduce((n,r)=>n+r.occurrenceCount,0)};
 return {rows,counts};
}
export async function action({request}:ActionFunctionArgs){return safeAppAction('errors',request,async()=>{
 const {session}=await authenticate.admin(request); const fd=await request.formData(); const id=Number(fd.get("id")); const intent=String(fd.get("intent")||"");
 if(!Number.isSafeInteger(id))return new Response("Invalid id",{status:400});
 const row=await db.errorEvent.findFirst({where:{id,shop:session.shop}}); if(!row)return new Response("Not found",{status:404});
 if(intent==="ack")await db.errorEvent.update({where:{id},data:{status:"ACKNOWLEDGED",acknowledgedAt:new Date()}});
 else if(intent==="resolve")await db.errorEvent.update({where:{id},data:{status:"RESOLVED",resolvedAt:new Date(),resolution:String(fd.get("resolution")||"Resolved in update")}});
 else return new Response("Invalid intent",{status:400});
 return Response.redirect(new URL("/app/errors",request.url));
});}
export default function Errors(){const {rows,counts}=useLoaderData<typeof loader>();return <Page title="Error Registry" subtitle="One place for live-test failures, deduplicated by fingerprint and tied to the running release.">
 <Grid><Metric label="Open errors" value={counts.open}/><Metric label="Open fatal" value={counts.fatal}/><Metric label="Recorded occurrences" value={counts.occurrences}/></Grid>
 <div style={{height:16}}/><Card><DiagnosticDownload url="?download=diagnostics"/><p style={{marginBottom:0,color:"#616161"}}>Send this JSON with an error key such as DHC-AB12CD34. Secrets, tokens, cookies, and passwords are redacted before storage.</p></Card><div style={{height:16}}/>
 <Table headers={["ID","Severity","Source","Message","Release","Count","Status","Last seen","Action"]} rows={rows.map(r=>[
  <code>{r.errorKey}</code>,<Badge tone={r.severity==="FATAL"||r.severity==="ERROR"?"bad":r.severity==="WARN"?"warn":"neutral"}>{r.severity}</Badge>,r.source,r.message,r.releaseVersion,r.occurrenceCount,<Badge tone={r.status==="OPEN"?"bad":r.status==="RESOLVED"?"good":"warn"}>{r.status}</Badge>,new Date(r.lastSeenAt).toLocaleString(),
  <Form method="post"><input type="hidden" name="id" value={r.id}/>{r.status==="OPEN"?<button name="intent" value="ack">Acknowledge</button>:r.status!=="RESOLVED"?<button name="intent" value="resolve">Resolve</button>:"—"}</Form>
 ])}/></Page>}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
