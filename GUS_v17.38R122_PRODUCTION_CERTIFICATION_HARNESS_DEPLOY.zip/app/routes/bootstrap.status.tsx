import type { LoaderFunctionArgs } from "react-router";

export async function loader({ request }: LoaderFunctionArgs) {
  const now = new Date().toISOString();
  return Response.json(
    {
      status: "READY",
      runtimeTarget: "0.16.57",
      bootstrapVersion: "0.16.57",
      progress: 100,
      phase: "Production Gus runtime is active — bootstrap handoff complete",
      updatedAt: now,
      handedOff: true,
      recoveredBootstrap: false,
    },
    { headers: { "Cache-Control": "no-store" } },
  );
}
