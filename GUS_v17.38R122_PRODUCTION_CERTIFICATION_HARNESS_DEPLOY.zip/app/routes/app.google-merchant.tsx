import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='Google Merchant' subtitle='Merchant discovery readiness for product data quality, feed eligibility, disapprovals and organic shopping visibility.' data={data} focus={['Keep product identifiers, pricing, availability, shipping and landing-page facts consistent across Shopify and Merchant Center.', 'Flag disapprovals and mismatches without fabricating Google status.', 'Prioritize high-value products that are eligible to surface in free listings and Shopping campaigns.', 'Supplier stock evidence must not be confused with Google feed approval status.']}/>;}
