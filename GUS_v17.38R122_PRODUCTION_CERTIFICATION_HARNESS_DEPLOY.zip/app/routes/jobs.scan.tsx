import type { ActionFunctionArgs } from "react-router";
import { unauthenticated } from "../shopify.server";
import { automationState } from '../services/automation-control.server';
import { scanCatalog } from "../services/scan.server";
import {captureAndRespond} from '../services/error-capture.server';
import {analyzeKnowledgeGaps} from '../services/brain.server';
export async function action({request}:ActionFunctionArgs){
  const auth=request.headers.get("authorization")||"";
  if(!process.env.AUTHORITY_CRON_SECRET||auth!==`Bearer ${process.env.AUTHORITY_CRON_SECRET}`) return new Response("Unauthorized",{status:401});
  const body=await request.json().catch(()=>({}));
  const shop=String((body as any).shop||"");
  if(!/^([a-z0-9][a-z0-9-]*)\.myshopify\.com$/.test(shop)) return new Response("shop required",{status:400});
  if(shop!==process.env.AUTHORITY_SHOP) return new Response("Store not authorized for scheduled scanning",{status:403});
  try{
    const master=await automationState(shop);if(!master?.running)return Response.json({status:'STOPPED'});
    const {admin}=await unauthenticated.admin(shop);
    const result=await scanCatalog(admin,shop,false);
    const learning=await analyzeKnowledgeGaps(shop);
    return Response.json({...result,learning});
  }catch(error){return captureAndRespond(error,{shop,source:'SCHEDULED_JOB',route:'/jobs/scan',jobType:'CATALOG_SCAN'});}
}
