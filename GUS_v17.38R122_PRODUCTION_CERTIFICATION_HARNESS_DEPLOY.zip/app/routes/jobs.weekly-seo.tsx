import type {LoaderFunctionArgs} from 'react-router';
import {automationState} from '../services/automation-control.server';
import {runWeeklySeoWatch} from '../services/weekly-seo-watch.server';

export async function loader({request}:LoaderFunctionArgs){
 const auth=request.headers.get('authorization')||'';
 if(!process.env.AUTHORITY_CRON_SECRET||auth!==`Bearer ${process.env.AUTHORITY_CRON_SECRET}`)throw new Response('Unauthorized',{status:401});
 const shop=process.env.AUTHORITY_SHOP;if(!shop)throw new Response('AUTHORITY_SHOP missing',{status:503});
 const state=await automationState(shop);
 if(!state?.running)return Response.json({status:'STOPPED'});
 // SEO watch is intelligence-only. It must remain runnable while production write gates are protected.
 return Response.json(await runWeeklySeoWatch(shop,false));
}
export async function action(args:LoaderFunctionArgs){return loader(args)}
