import type {LoaderFunctionArgs} from 'react-router';
import {unauthenticated} from '../shopify.server';
import {productionProofSnapshot} from '../services/production-proof.server';
export async function loader({request}:LoaderFunctionArgs){
 const secret=process.env.GUS_HEALTH_TOKEN||process.env.AUTHORITY_CRON_SECRET;const auth=request.headers.get('authorization')||'';
 if(!secret||auth!==`Bearer ${secret}`)return new Response('Unauthorized',{status:401,headers:{'Cache-Control':'no-store'}});
 const shop=process.env.AUTHORITY_SHOP;if(!shop)return Response.json({ok:false,error:'AUTHORITY_SHOP missing'},{status:503,headers:{'Cache-Control':'no-store'}});
 try{const {admin}=await unauthenticated.admin(shop);const p=await productionProofSnapshot(admin,shop,{persist:false,source:'HEALTH_PROOF'});return Response.json({ok:p.evaluation.verdict==='WORKING'||p.evaluation.verdict==='DEGRADED'||p.evaluation.verdict==='NOT_PROVEN',release:p.release,capturedAt:p.capturedAt,verdict:p.evaluation.verdict,score:p.evaluation.score,checks:p.evaluation.checks,queue:p.queue,activity:p.activity,workers:p.workers,orchestrator:p.orchestrator,turbo:p.turbo,errors:p.errors,shopify:{connected:p.shopify.connected,error:p.shopify.error,readbacks:p.shopify.readbacks},dataSources:p.dataSources,persistence:p.persistence,previous:p.previous,delta:p.delta},{status:p.evaluation.verdict==='NOT_WORKING'||p.evaluation.verdict==='STALLED'?503:200,headers:{'Cache-Control':'no-store'}});}catch(e:any){return Response.json({ok:false,error:String(e?.message||e),verdict:'NOT_WORKING'},{status:503,headers:{'Cache-Control':'no-store'}});}
}
