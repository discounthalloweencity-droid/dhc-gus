import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData,Link} from 'react-router';
import {authenticate} from '../shopify.server';
import {db} from '../db.server';
import {deploymentReadiness} from '../services/deployment-gates';
import {safePageData} from '../services/page-data-safety.server';
import {Page,Card,Table,Badge} from '../components/ui';
import {connectionHealthSnapshot} from '../services/connection-health-director.server';
export async function loader({request}:LoaderFunctionArgs){
 const {session}=await authenticate.admin(request);
 const config=await safePageData('readiness','config',db.storeConfig.findUnique({where:{shop:session.shop}}),null as any);
 const env=deploymentReadiness();
 const [facts,quotes,scans]=await Promise.all([
  safePageData('readiness','supplier facts',db.supplierFactRecord.count({where:{shop:session.shop}}),0),
  safePageData('readiness','stock evidence',db.stockEvidence.count({where:{shop:session.shop}}),0),
  safePageData('readiness','recent jobs',db.jobRun.findMany({where:{shop:session.shop},orderBy:{startedAt:'desc'},take:5}),[] as any[])
 ]);
 const health=await connectionHealthSnapshot(session.shop);
 return {env,config,facts,quotes,scans,health};
}
export default function Readiness(){const d=useLoaderData<typeof loader>();return <Page title="Installation & data readiness" subtitle="Separate installed functionality, available evidence and production automation.">
 <div className="authority-note">A green health check does not certify the Shopify API, supplier feeds, Google integrations or financial reconciliation. Live writes remain locked until explicitly enabled on the host.</div>
 <Card><h2>Connection & data health</h2><Table headers={['Dependency','State','Impact / next action']} rows={d.health.connections.map(c=>[c.label,c.state,`${c.reason} ${c.affectedEngines.length?`Affected: ${c.affectedEngines.join(', ')}. `:''}${c.fix}`])}/></Card><div style={{height:16}}/>
 <Card><h2>Deployment gates</h2><Table headers={['Check','Status']} rows={[
 ['Required server configuration',d.env.configured?'Configured':'Missing: '+d.env.missing.join(', ')],
 ['Public HTTPS app URL',d.env.productionHost?'Configured':'Not configured'],
 ['Operator live-write lock',d.env.liveWritesEnabled?'Unlocked':'LOCKED'],
 ['Shopify authorization','Authenticated for this store'],
 ['Google Search Console',d.health.configuration.googleSearchConsole?'Configured':'Blocked / missing provider configuration'],
 ['Google Analytics 4',d.health.configuration.ga4?'Configured':'Blocked / missing GA4 auth/property'],
 ['CJ supplier adapter',d.health.configuration.cj?'Configured':'Connector code ready — credentials not configured'],
 ['DSers supplier feed',d.health.configuration.dsers?'Configured':'Connector code ready — feed URL not configured'],
 ['AliExpress replacement feed',d.health.configuration.aliexpressReplacement?'Configured':'Connector ready — replacement candidate feed not configured'],
 ['Syncee supplier feed',d.health.configuration.syncee?'Configured':'Connector code ready — feed URL not configured'],
 ['Carrier tracking evidence',d.health.configuration.tracking?'Configured':'Tracking provider not configured'],
 ['EasyPost return labels',d.health.configuration.easyPost?'Configured':'Return-label provider not configured'],
 ['OpenAI model assistance',d.health.configuration.openai?'Configured':'Model-assisted engines will use deterministic/degraded paths'],
 ['Backlink outreach provider',d.health.configuration.backlinkOutreach?'Configured':'Discovery/monitor only; automated outreach unavailable'],
 ['ChatGPT ↔ Gus bridge',d.health.configuration.bridge?'Ready':'Bridge/cron secret not derivable'],
 ['Verified supplier fact records',String(d.facts)],
 ['Verified stocking quote records',String(d.quotes)],
 ['Store operating mode',d.config?.mode||'Not configured']
 ]}/></Card><div style={{height:16}}/><Card><h2>Recent scans</h2><Table headers={['Started','Status','Scanned','Changes','Warnings']} rows={d.scans.map(r=>[new Date(r.startedAt).toLocaleString(),r.status,String(r.scanned),String(r.changed),String(r.warnings)])}/><p><Link to="/app/settings">Review rules →</Link></p></Card></Page>}
