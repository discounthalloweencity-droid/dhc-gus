import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='Schema' subtitle='Structured-data control for products, breadcrumbs, organization, offers and valid search-engine markup.' data={data} focus={['Ensure schema reflects visible page facts and does not invent ratings, reviews, stock, price or licensing.', 'Maintain valid Product and Offer relationships for sellable items and clean BreadcrumbList hierarchy.', 'Detect missing, contradictory or duplicated structured data from theme/app overlap.', 'Treat structured data as validation and eligibility infrastructure, not a guaranteed ranking boost.']}/>;}
