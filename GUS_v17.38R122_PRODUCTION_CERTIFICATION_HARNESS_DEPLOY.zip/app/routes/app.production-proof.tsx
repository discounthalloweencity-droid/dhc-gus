import type {LoaderFunctionArgs,ActionFunctionArgs} from 'react-router';
import {Form,useActionData,useLoaderData} from 'react-router';
import {useState} from 'react';
import {authenticate} from '../shopify.server';
import {latestProductionProof,productionProofSnapshot} from '../services/production-proof.server';
import {runGusOrchestrator} from '../services/orchestrator.server';

export async function loader({request}:LoaderFunctionArgs){
 const {admin,session}=await authenticate.admin(request);
 const live=await productionProofSnapshot(admin,session.shop,{persist:false,source:'PAGE_LOAD'});
 const latest=await latestProductionProof(session.shop);
 return {live,latest};
}
export async function action({request}:ActionFunctionArgs){
 const {admin,session}=await authenticate.admin(request);const fd=await request.formData();const intent=String(fd.get('intent')||'');
 if(intent==='audit')return {kind:'audit',proof:await productionProofSnapshot(admin,session.shop,{persist:true,source:'MANUAL'})};
 if(intent==='run-and-prove'){
  let run:any=null,runError:string|null=null;
  try{run=await runGusOrchestrator(admin,session.shop,'MANUAL',{detached:true});}catch(e:any){runError=String(e?.message||e).slice(0,500);}
  const proof=await productionProofSnapshot(admin,session.shop,{persist:true,source:'RUN_AND_PROVE_START'});
  return {kind:'run-and-prove',run,runError,proof,message:runError?`Gus run request failed: ${runError}. Production Proof still ran so the failure can be diagnosed.`:'Gus cycle requested. Re-run Production Proof after 5–15 minutes to measure real queue movement and completed work.'};
 }
 throw new Response('Unknown action',{status:400});
}
function tone(status:string){return status==='PASS'?'#067647':status==='FAIL'?'#b42318':status==='WARN'?'#b54708':'#475467'}
function verdictTone(v:string){return v==='WORKING'?'#067647':v==='NOT_WORKING'||v==='STALLED'?'#b42318':v==='STOPPED'?'#b54708':'#475467'}
export default function ProductionProof(){
 const {live,latest}=useLoaderData<typeof loader>() as any;const action=useActionData<typeof action>() as any;const d=action?.proof||live;const [copied,setCopied]=useState(false);
 const copy=async()=>{try{await navigator.clipboard.writeText(d.packet.prompt);setCopied(true);setTimeout(()=>setCopied(false),1800);}catch{setCopied(false)}};
 const prev=d.previous;const delta=prev?d.queue.pending-prev.pending:null;
 return <main style={{padding:24,maxWidth:1500,margin:'auto',fontFamily:'system-ui,sans-serif'}}>
  <div style={{display:'flex',justifyContent:'space-between',gap:16,alignItems:'flex-start',flexWrap:'wrap'}}><div><h1 style={{margin:0,fontSize:32}}>Production Proof</h1><p style={{maxWidth:850,color:'#667085'}}>Does Gus actually work? This page ignores optimistic dashboard labels and proves execution from queue movement, mission transitions, completed jobs, durable change evidence and live Shopify readback.</p></div><div style={{display:'flex',gap:8,flexWrap:'wrap'}}><Form method="post"><input type="hidden" name="intent" value="audit"/><button style={button(true)}>Run Production Proof</button></Form><Form method="post"><input type="hidden" name="intent" value="run-and-prove"/><button style={button(false)}>Run Gus + Start Proof Window</button></Form></div></div>
  {action?.message&&<div style={alert('#eff8ff','#175cd3')}>{action.message}</div>}
  <section style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))',gap:12,margin:'18px 0'}}>
   <Card label="Verdict" value={d.evaluation.verdict} color={verdictTone(d.evaluation.verdict)}/><Card label="Reality score" value={`${d.evaluation.score}/100`} color={verdictTone(d.evaluation.verdict)}/><Card label="Pending" value={String(d.queue.pending)}/><Card label="Queue delta" value={delta==null?'Baseline needed':`${delta>=0?'+':''}${delta}`}/><Card label="Completed / 60m" value={String(d.activity.completed60m)}/><Card label="Store changes / 60m" value={String(d.activity.changeLogs60m)}/><Card label="Shopify readbacks" value={`${d.shopify.readbacks.filter((x:any)=>x.status==='VERIFIED').length} verified`}/><Card label="Turbo" value={d.turbo.enabled?'ON':'OFF'}/>
  </section>
  {(d.evaluation.verdict==='NOT_WORKING'||d.evaluation.verdict==='STALLED')&&<div style={alert('#fef3f2','#b42318')}><strong>Do not trust green/ON labels elsewhere.</strong> Production Proof found runtime evidence that contradicts healthy operation. Use the failed checks and repair packet below.</div>}
  <h2>Independent checks</h2>
  <div style={{overflowX:'auto'}}><table style={table}><thead><tr><th style={th}>Check</th><th style={th}>Result</th><th style={th}>Observed proof</th><th style={th}>What it means</th><th style={th}>Code area</th></tr></thead><tbody>{d.evaluation.checks.map((x:any)=><tr key={x.key}><td style={td}><strong>{x.label}</strong></td><td style={{...td,fontWeight:800,color:tone(x.status)}}>{x.status}</td><td style={td}>{x.evidence}</td><td style={td}>{x.diagnosis}</td><td style={{...td,fontFamily:'monospace',fontSize:12}}>{x.codeArea}</td></tr>)}</tbody></table></div>
  <h2>Data source health — can the proof system trust what it is reading?</h2>
  <p style={{color:'#667085'}}>A failed source is shown as UNKNOWN/BROKEN, never converted to zero. Each source has its own timeout so one bad table or provider cannot take down this page.</p>
  <section style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',gap:12,marginBottom:12}}><Card label="Signals healthy" value={`${d.dataSources.summary.healthy}/${d.dataSources.summary.total}`}/><Card label="Critical signal failures" value={String(d.dataSources.summary.criticalFailed)} color={d.dataSources.summary.criticalFailed?'#b42318':'#067647'}/><Card label="Proof history" value={d.persistence.requested?(d.persistence.verified?'VERIFIED':'FAILED'):'READ ONLY'} color={d.persistence.requested&&!d.persistence.verified?'#b42318':'#067647'}/></section>
  <div style={{overflowX:'auto'}}><table style={table}><thead><tr><th style={th}>Signal</th><th style={th}>Critical</th><th style={th}>Status</th><th style={th}>Duration</th><th style={th}>Failure / timeout</th></tr></thead><tbody>{(d.dataSources.signals||[]).map((x:any)=><tr key={`${x.name}-${x.durationMs}`}><td style={{...td,fontFamily:'monospace',fontSize:12}}>{x.name}</td><td style={td}>{x.critical?'YES':'no'}</td><td style={{...td,fontWeight:800,color:x.ok?'#067647':'#b42318'}}>{x.ok?'OK':x.timedOut?'TIMEOUT':'FAILED'}</td><td style={td}>{x.durationMs} ms</td><td style={td}>{x.error||'—'}</td></tr>)}</tbody></table></div>
  {d.persistence.requested&&!d.persistence.verified&&<div style={alert('#fff6ed','#b54708')}><strong>Proof history is not trustworthy yet.</strong> {d.persistence.error||'The audit write could not be re-read.'} The current live checks still render, but queue-delta comparisons should not be trusted until this is fixed.</div>}
  <h2>Proof of actual work</h2>
  <section style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(300px,1fr))',gap:12}}>
   <Panel title="Queue / worker movement"><p>Pending: <b>{d.queue.pending}</b> · Running: <b>{d.queue.running}</b></p><p>Completed 15m: <b>{d.activity.completed15m}</b> · 60m: <b>{d.activity.completed60m}</b> · Failed 60m: <b>{d.activity.failed60m}</b></p><p>Mission transitions 60m: <b>{d.activity.missionEvents60m}</b></p><p>Oldest pending: <b>{d.queue.oldestPendingAt?new Date(d.queue.oldestPendingAt).toLocaleString():'none'}</b></p></Panel>
   <Panel title="Orchestrator / automation"><p>Automation: <b>{d.automationRunning?'RUNNING':'STOPPED'}</b></p><p>Latest orchestrator: <b>{d.orchestrator.status||'none'}</b></p><p>Started: <b>{d.orchestrator.startedAt?new Date(d.orchestrator.startedAt).toLocaleString():'never'}</b></p><p>Stale missions/jobs: <b>{d.workers.staleMissions} / {d.workers.staleJobs}</b></p></Panel>
   <Panel title="Live Shopify proof"><p>Connection: <b>{d.shopify.connected?'CONNECTED':'FAILED'}</b></p>{d.shopify.error&&<p style={{color:'#b42318'}}>{d.shopify.error}</p>}<p>Recent supported write readbacks:</p>{d.shopify.readbacks.length?d.shopify.readbacks.map((r:any)=><div key={r.changeId} style={{fontSize:12,marginBottom:5}}><b style={{color:r.status==='VERIFIED'?'#067647':r.status==='DRIFTED'?'#b42318':'#667085'}}>{r.status}</b> · change #{r.changeId} · {r.field}</div>):<p style={{color:'#667085'}}>No compatible recent product write to re-read.</p>}</Panel>
  </section>
  <h2>Engine reality — where the backlog actually is</h2>
  <div style={{overflowX:'auto'}}><table style={table}><thead><tr><th style={th}>Engine</th><th style={th}>Pending now</th><th style={th}>Running now</th><th style={th}>Completed 60m</th><th style={th}>Failed 60m</th><th style={th}>Reality</th></tr></thead><tbody>{(d.queue.engineReality||[]).slice(0,25).map((e:any)=><tr key={e.engine}><td style={td}><strong>{e.engine}</strong></td><td style={td}>{e.pending}</td><td style={td}>{e.running}</td><td style={td}>{e.completed60m}</td><td style={td}>{e.failed60m}</td><td style={{...td,fontWeight:700,color:e.pending>0&&e.running===0&&e.completed60m===0?'#b42318':'#067647'}}>{e.pending>0&&e.running===0&&e.completed60m===0?'NO OUTPUT':'MOVING / IDLE'}</td></tr>)}</tbody></table></div>
  <h2>Copy this to the coding AI when something fails</h2><p style={{color:'#667085'}}>This packet contains the observed runtime evidence and the exact code areas to trace. It is generated from failures, not from guessed causes.</p><button onClick={copy} style={button(true)}>{copied?'Copied':'Copy Repair Packet'}</button><pre style={{whiteSpace:'pre-wrap',background:'#101828',color:'#f2f4f7',padding:16,borderRadius:10,maxHeight:520,overflow:'auto'}}>{d.packet.prompt}</pre>
  <h2>Machine-readable runtime proof</h2><p style={{color:'#667085'}}>You can copy this JSON into ChatGPT and I can diagnose the live backend from the evidence without relying on a screenshot.</p><pre style={{whiteSpace:'pre-wrap',background:'#f8fafc',padding:16,border:'1px solid #eaecf0',borderRadius:10,maxHeight:420,overflow:'auto'}}>{JSON.stringify({release:d.release,capturedAt:d.capturedAt,evaluation:d.evaluation,dataSources:d.dataSources,persistence:d.persistence,queue:d.queue,activity:d.activity,workers:d.workers,orchestrator:d.orchestrator,turbo:d.turbo,errors:d.errors,shopify:{connected:d.shopify.connected,error:d.shopify.error,readbacks:d.shopify.readbacks},previous:d.previous,delta:d.delta},null,2)}</pre>
  <p style={{fontSize:12,color:'#667085'}}>Current release {d.release}. Latest persisted proof: {latest?.finishedAt?new Date(latest.finishedAt).toLocaleString():'none yet'}. A first snapshot establishes baseline; repeat after 5–15 minutes to prove whether counters are actually moving.</p>
 </main>;
}
const button=(primary:boolean)=>({border:'1px solid '+(primary?'#101828':'#98a2b3'),background:primary?'#101828':'white',color:primary?'white':'#101828',padding:'10px 13px',borderRadius:8,fontWeight:700,cursor:'pointer'} as const);
const alert=(background:string,color:string)=>({background,color,padding:12,borderRadius:10,margin:'12px 0',border:`1px solid ${color}22`} as const);
const table={width:'100%',borderCollapse:'collapse',background:'white',border:'1px solid #eaecf0'} as const;const th={textAlign:'left',padding:10,background:'#f9fafb',borderBottom:'1px solid #eaecf0',fontSize:12} as const;const td={padding:10,borderBottom:'1px solid #eaecf0',verticalAlign:'top',fontSize:13} as const;
function Card({label,value,color}:{label:string,value:string,color?:string}){return <div style={{border:'1px solid #eaecf0',borderRadius:12,padding:15,background:'white'}}><div style={{fontSize:12,color:'#667085'}}>{label}</div><div style={{fontSize:24,fontWeight:800,color:color||'#101828'}}>{value}</div></div>}
function Panel({title,children}:{title:string,children:any}){return <div style={{border:'1px solid #eaecf0',borderRadius:12,padding:16,background:'white'}}><h3 style={{marginTop:0}}>{title}</h3>{children}</div>}
