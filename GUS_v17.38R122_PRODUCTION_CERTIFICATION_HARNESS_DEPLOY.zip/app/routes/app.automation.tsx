import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {Form,useActionData,useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {automationState,setAutomationRunning} from '../services/automation-control.server';
import {liveWritesEnabled} from '../services/deployment-gates';
import {runGusOrchestrator} from '../services/orchestrator.server';
import {db} from '../db.server';
import {browserIndependentRuntimeSnapshot} from '../services/runtime-orchestrator-pulse.server';
import {Page,Card,Grid,Metric,Table,Badge} from '../components/ui';

import {safeAppAction} from '../services/safe-app-action.server';

function pulseMinutes(){
 const raw=Number(process.env.GUS_ORCHESTRATOR_INTERVAL_MS||300000);
 const ms=Number.isFinite(raw)&&raw>=60000?raw:300000;
 return Math.round(ms/60000);
}

export async function loader({request}:LoaderFunctionArgs){
 const {session}=await authenticate.admin(request);
 const [state,runs,runtimeProof]=await Promise.all([
  automationState(session.shop),
  db.gusOrchestratorRun.findMany({where:{shop:session.shop},orderBy:{startedAt:'desc'},take:20}),
  browserIndependentRuntimeSnapshot(session.shop),
 ]);
 return {state,unlocked:liveWritesEnabled(),runs,pulseMinutes:pulseMinutes(),runtimeProof};
}

export async function action({request}:ActionFunctionArgs){return safeAppAction('automation',request,async()=>{
 const {admin,session}=await authenticate.admin(request);
 const f=await request.formData();
 const intent=String(f.get('intent'));
 if(!['run','stop'].includes(intent))return {ok:false,message:'Invalid action.'};
 try{
  const state=await setAutomationRunning(session.shop,intent==='run');
  if(!state.running)return {ok:true,running:false,message:'Gus is stopped. New autonomous work is blocked.'};
  const cycle=await runGusOrchestrator(admin,session.shop,'MANUAL',{detached:true});
  const runId='runId' in cycle?cycle.runId:null;
  const detail=cycle.status==='ALREADY_RUNNING'?'An autonomous cycle was already active.':cycle.status==='QUEUED'?'A new autonomous cycle was queued immediately.':'Gus is running.';
  return {ok:true,running:true,runId,cycleStatus:cycle.status,message:`Gus is RUNNING. ${detail}${runId?` Cycle #${runId} is persisted in orchestrator history.`:''}`};
 }catch(e:any){return {ok:false,message:String(e?.message||e)};}
});}

export default function Automation(){
 const {state,unlocked,runs,pulseMinutes,runtimeProof}=useLoaderData<typeof loader>();
 const result=useActionData<typeof action>();
 const latest=runs[0];
 let latestPhase='—';
 if(latest?.summaryJson){try{latestPhase=String(JSON.parse(latest.summaryJson)?.phase||'—')}catch{}}
 return <Page title="Gus Automation" subtitle="RUN persists the master state, immediately queues an audited autonomous cycle, and keeps scheduled server pulses active.">
  <Grid>
   <Metric label="Master automation" value={state?.running?'RUNNING':'STOPPED'} detail={state?`Generation ${state.generation}`:'State unavailable'}/>
   <Metric label="Browser required" value="NO" detail="Browser is monitor/control only"/>
   <Metric label="Runtime cadence" value={`${pulseMinutes} min`} detail="Server-side orchestrator pulse"/>
   <Metric label="External heartbeat" value={runtimeProof.externalHeartbeatHealthy?'VERIFIED':runtimeProof.runtimeVariant==='PREVIEW'?'PREVIEW':'NOT PROVEN'} detail={runtimeProof.externalHeartbeatAt?`Last ${new Date(runtimeProof.externalHeartbeatAt).toLocaleString()}`:'No external scheduler heartbeat recorded'}/>
   <Metric label="Latest cycle" value={latest?`#${latest.id} · ${latest.status}`:'No cycle yet'} detail={latest?`${latest.trigger} · ${latestPhase}`:'Gus will create audited cycles automatically when the always-on runtime is healthy'}/>
   <Metric label="Production writes" value={unlocked?'ENABLED':'PROTECTED'} detail="Specialist guardrails remain authoritative"/>
  </Grid>
  <div style={{height:16}}/>
  <Card><h2>Automation control</h2><p>Gus is designed to run without this page open. The browser does not execute the engines; it only reads status and provides emergency controls. RUN persists the master state in MySQL. The published server pulse runs due engines, and an external heartbeat is the independent wake-up path if the hosting process sleeps or recycles.</p>
  {runtimeProof.runtimeVariant==='PREVIEW'?<div className="gus-flash gus-flash-bad">This session is on a PREVIEW runtime. Preview is not accepted as always-on production proof. Publish the build and point the external heartbeat at the published/custom-domain runtime.</div>:runtimeProof.externalHeartbeatHealthy?<div className="gus-flash gus-flash-good">Browser-independent execution is proven by a recent external heartbeat. You can close this browser and Gus continues operating.</div>:<div className="gus-flash gus-flash-bad">The code is browser-independent, but an external scheduler heartbeat has not been proven recently. If the host sleeps, in-process timers can pause. Configure the 5-minute external heartbeat before treating this as unattended 24/7 execution.</div>}<Form method="post" className="authority-toolbar"><button className="gus-run" name="intent" value="run" disabled={!!state?.running}>▶ RUN GUS</button><button className="gus-stop" name="intent" value="stop" disabled={!state?.running}>■ STOP</button></Form>{!unlocked&&<p>Production-changing writes are currently protected, but autonomous scans, analysis, prioritization, SEO watch, new-product intake, collection review and executive intelligence can still run.</p>}{result&&<div className={result.ok?'gus-flash gus-flash-good':'gus-flash gus-flash-bad'}>{result.message}</div>}</Card>
  <div style={{height:16}}/>
  <Card><h2>Autonomy proof / orchestrator history</h2><p>Every autonomous cycle is persisted here with its trigger, status, generation and completion time. Scheduled and externally-triggered cycles appear here automatically. A browser session is not required for execution.</p><Table headers={['Started','Run','Trigger','Status','Generation','Phase','Finished']} rows={runs.map(r=>{let phase='—';try{phase=String(JSON.parse(r.summaryJson||'{}')?.phase||'—')}catch{};return [r.startedAt.toLocaleString(),`#${r.id}`,r.trigger,<Badge tone={r.status==='COMPLETE'?'good':r.status==='FAILED'?'bad':'warn'}>{r.status}</Badge>,r.generation??'—',phase,r.finishedAt?.toLocaleString()||'—']})}/></Card>
 </Page>
}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
