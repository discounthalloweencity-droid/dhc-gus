import type { ActionFunctionArgs } from "react-router";
import { registerError } from "../services/error-registry.server";

function authorized(request:Request){
 const expected=process.env.DHC_ERROR_INGEST_KEY;
 const supplied=request.headers.get("authorization")?.replace(/^Bearer\s+/i,"");
 return Boolean(expected&&supplied&&expected===supplied);
}
export async function action({request}:ActionFunctionArgs){
 if(request.method!=="POST")return new Response("Method not allowed",{status:405});
 if(!authorized(request))return new Response("Unauthorized",{status:401});
 let body:any; try{body=await request.json();}catch{return new Response("Invalid JSON",{status:400});}
 if(!body?.shop||!body?.source||!body?.message)return new Response("shop, source and message are required",{status:400});
 const event=await registerError({shop:String(body.shop),source:String(body.source),message:String(body.message),severity:body.severity,
  stack:body.stack?String(body.stack):null,route:body.route?String(body.route):null,jobType:body.jobType?String(body.jobType):null,context:body.context});
 return Response.json({ok:true,errorKey:event.errorKey,occurrenceCount:event.occurrenceCount,status:event.status});
}
