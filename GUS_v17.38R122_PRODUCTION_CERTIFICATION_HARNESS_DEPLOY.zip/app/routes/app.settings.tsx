import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { Form, useActionData, useLoaderData } from "react-router";
import { authenticate } from "../shopify.server";
import { db } from "../db.server";
import { Card, Grid, Page } from "../components/ui";

import {safeAppAction} from '../services/safe-app-action.server';

const FALLBACK_CONFIG={
  mode:"AUDIT",targetMargin:.30,minimumMargin:.30,maxShippingDays:12,archiveSlowShipping:false,autoPricing:false,
  shippingChargeUnder:59,customerShippingCharge:6.99,shippingRevenueMode:"CONSERVATIVE",defaultPaymentPercent:.029,
  defaultPaymentFixed:.30,adultCostumeFloor:29.97,kidsCostumeFloor:19.97,latexMaskFloor:16.97,
};
type SettingsConfig=typeof FALLBACK_CONFIG;

function err(error:unknown){return error instanceof Error?(error.stack||error.message):String(error);}
function numberOr(value:unknown,fallback:number){const n=Number(value);return Number.isFinite(n)?n:fallback;}
function booleanOr(value:unknown,fallback:boolean){return typeof value==="boolean"?value:fallback;}
function normalizeConfig(row:any):SettingsConfig{
  const mode=["AUDIT","APPROVAL","AUTOPILOT"].includes(String(row?.mode))?String(row.mode):FALLBACK_CONFIG.mode;
  const shippingRevenueMode=["CONSERVATIVE","SINGLE_ITEM"].includes(String(row?.shippingRevenueMode))?String(row.shippingRevenueMode):FALLBACK_CONFIG.shippingRevenueMode;
  return {
    mode,
    targetMargin:numberOr(row?.targetMargin,FALLBACK_CONFIG.targetMargin),
    minimumMargin:numberOr(row?.minimumMargin,FALLBACK_CONFIG.minimumMargin),
    maxShippingDays:numberOr(row?.maxShippingDays,FALLBACK_CONFIG.maxShippingDays),
    archiveSlowShipping:booleanOr(row?.archiveSlowShipping,FALLBACK_CONFIG.archiveSlowShipping),
    autoPricing:booleanOr(row?.autoPricing,FALLBACK_CONFIG.autoPricing),
    shippingChargeUnder:numberOr(row?.shippingChargeUnder,FALLBACK_CONFIG.shippingChargeUnder),
    customerShippingCharge:numberOr(row?.customerShippingCharge,FALLBACK_CONFIG.customerShippingCharge),
    shippingRevenueMode,
    defaultPaymentPercent:numberOr(row?.defaultPaymentPercent,FALLBACK_CONFIG.defaultPaymentPercent),
    defaultPaymentFixed:numberOr(row?.defaultPaymentFixed,FALLBACK_CONFIG.defaultPaymentFixed),
    adultCostumeFloor:numberOr(row?.adultCostumeFloor,FALLBACK_CONFIG.adultCostumeFloor),
    kidsCostumeFloor:numberOr(row?.kidsCostumeFloor,FALLBACK_CONFIG.kidsCostumeFloor),
    latexMaskFloor:numberOr(row?.latexMaskFloor,FALLBACK_CONFIG.latexMaskFloor),
  };
}

async function settingsSession(request:Request){
  try{return (await authenticate.admin(request)).session;}
  catch(error){
    if(error instanceof Response)throw error;
    console.error('[gus-settings] authentication failed',err(error));
    throw new Response('Settings authentication is temporarily unavailable.',{status:503});
  }
}

export async function loader({request}:LoaderFunctionArgs){
  const session=await settingsSession(request);
  try{
    // Settings GET is read-only. Do not upsert during page rendering: a schema/database
    // write failure must never turn navigation to Settings into a 500.
    const row=await db.storeConfig.findUnique({where:{shop:session.shop}});
    return {
      config:normalizeConfig(row),
      configAvailable:true,
      warning:row?null:'No saved settings row exists yet. Safe defaults are shown; Save rules will initialize it.'
    };
  }catch(error){
    console.error('[gus-settings] StoreConfig read failed; rendering recovery defaults',err(error));
    return {
      config:FALLBACK_CONFIG,
      configAvailable:false,
      warning:'Settings storage is temporarily unavailable. Safe read-only defaults are shown; no database write was attempted.'
    };
  }
}

export async function action({request}:ActionFunctionArgs){return safeAppAction('settings',request,async()=>{
  const session=await settingsSession(request);
  let f:FormData;
  try{f=await request.formData();}
  catch(error){
    console.warn('[gus-settings] invalid form body',err(error));
    return new Response('Invalid settings request.',{status:400});
  }
  const b=(k:string)=>f.get(k)==="on";
  const n=(k:string, fallback:number)=>{const raw=f.get(k);const v=raw==null?NaN:Number(raw);return Number.isFinite(v)?v:fallback};
  if(!["AUDIT","APPROVAL","AUTOPILOT"].includes(String(f.get("mode")))) return new Response("Invalid mode",{status:400});
  const target=n("targetMargin",30)/100, minimum=n("minimumMargin",30)/100;
  const days=n("maxShippingDays",12), threshold=n("shippingChargeUnder",59), charge=n("customerShippingCharge",6.99);
  const percent=n("defaultPaymentPercent",2.9)/100, fixed=n("defaultPaymentFixed",.30);
  const floors=[n("adultCostumeFloor",29.97),n("kidsCostumeFloor",19.97),n("latexMaskFloor",16.97)];
  if(target<.30||target>=1||minimum<.30||minimum>target||!Number.isInteger(days)||days<1||days>12||threshold<0||charge<0||percent<0||percent>=.5||fixed<0||floors.some((v,i)=>v<[29.97,19.97,16.97][i]))return new Response("Rules must preserve the 30% margin and DHC price floors; shipping limit cannot exceed 12 days.",{status:400});
  if(!["CONSERVATIVE","SINGLE_ITEM"].includes(String(f.get("shippingRevenueMode"))))return new Response("Invalid shipping mode",{status:400});
  if(String(f.get("mode"))==='AUTOPILOT'&&process.env.AUTHORITY_LIVE_WRITES_ENABLED!=='true')return new Response("Deployment operator has not unlocked live writes.",{status:403});
  try{
    await db.storeConfig.upsert({
      where:{shop:session.shop},
      create:{
        shop:session.shop,
        mode:String(f.get("mode")||"APPROVAL"),
        targetMargin:target,
        minimumMargin:minimum,
        maxShippingDays:days,
        archiveSlowShipping:b("archiveSlowShipping")&&process.env.AUTHORITY_LIVE_WRITES_ENABLED==='true',
        autoPricing:b("autoPricing")&&process.env.AUTHORITY_LIVE_WRITES_ENABLED==='true',
        shippingChargeUnder:threshold,
        customerShippingCharge:charge,
        shippingRevenueMode:String(f.get("shippingRevenueMode")||"CONSERVATIVE"),
        defaultPaymentPercent:percent,
        defaultPaymentFixed:fixed,
        adultCostumeFloor:floors[0],
        kidsCostumeFloor:floors[1],
        latexMaskFloor:floors[2],
      },
      update:{
        mode:String(f.get("mode")||"APPROVAL"),
        targetMargin:target,
        minimumMargin:minimum,
        maxShippingDays:days,
        archiveSlowShipping:b("archiveSlowShipping")&&process.env.AUTHORITY_LIVE_WRITES_ENABLED==='true',
        autoPricing:b("autoPricing")&&process.env.AUTHORITY_LIVE_WRITES_ENABLED==='true',
        shippingChargeUnder:threshold,
        customerShippingCharge:charge,
        shippingRevenueMode:String(f.get("shippingRevenueMode")||"CONSERVATIVE"),
        defaultPaymentPercent:percent,
        defaultPaymentFixed:fixed,
        adultCostumeFloor:floors[0],
        kidsCostumeFloor:floors[1],
        latexMaskFloor:floors[2],
      }
    });
    return {ok:true,message:'Authority rules saved.'};
  }catch(error){
    console.error('[gus-settings] save failed',err(error));
    return {ok:false,message:'Settings could not be saved because storage is temporarily unavailable. No changes were applied.'};
  }
});}

function Field({label,name,defaultValue,step="0.01"}:{label:string;name:string;defaultValue:string|number;step?:string}){return <label style={{display:"grid",gap:5,fontSize:13,fontWeight:600}}>{label}<input name={name} type="number" step={step} defaultValue={defaultValue} style={input}/></label>}
export default function Settings(){
  const {config:c,configAvailable,warning}=useLoaderData<typeof loader>();
  const result=useActionData<typeof action>();
  return <Page title="Authority Rules" subtitle="The app starts conservatively. Enable automated writes only after reviewing audit results.">
    {warning&&<div className="gus-flash gus-flash-bad">{warning}</div>}
    {result&&<div className={result.ok?"gus-flash gus-flash-good":"gus-flash gus-flash-bad"}>{result.message}</div>}
    <div className="authority-note">Live writes are additionally locked by the deployment operator until installation and rollback testing are complete. The 30% margin and price floors cannot be lowered here.</div>
    <Form method="post">
      <Grid>
        <Card><h3>Operating mode</h3><label style={label}>Mode<select name="mode" defaultValue={c.mode} style={input}><option value="AUDIT">Audit only</option><option value="APPROVAL">Approval</option><option value="AUTOPILOT">Autopilot</option></select></label><label style={check}><input type="checkbox" name="archiveSlowShipping" defaultChecked={c.archiveSlowShipping}/> Auto-archive verified shipping &gt; limit</label><label style={check}><input type="checkbox" name="autoPricing" defaultChecked={c.autoPricing}/> Auto-apply safe price corrections</label></Card>
        <Card><h3>Shipping</h3><Field label="Maximum supplier delivery days" name="maxShippingDays" defaultValue={c.maxShippingDays} step="1"/><Field label="Free-shipping threshold ($)" name="shippingChargeUnder" defaultValue={c.shippingChargeUnder}/><Field label="Customer shipping below threshold ($)" name="customerShippingCharge" defaultValue={c.customerShippingCharge}/><label style={label}>Product-level shipping revenue assumption<select name="shippingRevenueMode" defaultValue={c.shippingRevenueMode} style={input}><option value="CONSERVATIVE">Conservative — count $0 customer shipping</option><option value="SINGLE_ITEM">Single-item — count configured shipping charge</option></select></label></Card>
        <Card><h3>Profitability</h3><Field label="Target margin (%)" name="targetMargin" defaultValue={(c.targetMargin*100).toFixed(1)}/><Field label="Minimum margin (%)" name="minimumMargin" defaultValue={(c.minimumMargin*100).toFixed(1)}/><Field label="Payment fee (%)" name="defaultPaymentPercent" defaultValue={(c.defaultPaymentPercent*100).toFixed(2)}/><Field label="Payment fixed fee ($)" name="defaultPaymentFixed" defaultValue={c.defaultPaymentFixed}/></Card>
        <Card><h3>Price floors</h3><Field label="Adult costume floor ($)" name="adultCostumeFloor" defaultValue={c.adultCostumeFloor}/><Field label="Kids costume floor ($)" name="kidsCostumeFloor" defaultValue={c.kidsCostumeFloor}/><Field label="Latex mask floor ($)" name="latexMaskFloor" defaultValue={c.latexMaskFloor}/><p style={{fontSize:12,color:"#616161"}}>Pricing uses the DHC .97 ladder: e.g. $41.97 → $39.97, $31.97 → $29.97, $47.97 → $44.97 when margin allows.</p></Card>
      </Grid>
      <div style={{marginTop:16}}><button type="submit" disabled={!configAvailable} style={{border:0,borderRadius:8,padding:"11px 16px",background:"#111",color:"white",fontWeight:700}}>{configAvailable?'Save rules':'Storage recovery required'}</button></div>
    </Form>
  </Page>
}
const input={padding:"9px 10px",border:"1px solid #c9c9c9",borderRadius:7,width:"100%",boxSizing:"border-box" as const};
const label={display:"grid",gap:5,fontSize:13,fontWeight:600,marginBottom:12};
const check={display:"flex",gap:8,alignItems:"center",fontSize:13,margin:"10px 0"};


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
