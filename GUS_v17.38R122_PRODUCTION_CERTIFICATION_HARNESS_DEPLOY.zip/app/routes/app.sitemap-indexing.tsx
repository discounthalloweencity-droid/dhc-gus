import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='Sitemap / Indexing' subtitle='Sitemap coverage, crawl priorities, index eligibility and canonical-page control.' data={data} focus={['Keep indexable product, collection and content URLs discoverable through clean sitemap and internal-link paths.', 'Identify URLs that should not compete in the index, including obsolete duplicates and low-value generated paths.', 'Track discovered, crawled and indexed states only from connected Google or crawl evidence.', 'Never infer that a page is indexed merely because it exists in Shopify.']}/>;}
