import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {Form,useActionData,useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {releaseSummary} from '../services/releases.server';
import {applyStagedUpdate,rollbackLatestUpdate,stageUpdatePackage,updaterDoctor,updaterState,refreshDurableUpdateStatus,publishDurableUpdate} from '../services/update-package.server';
import {Badge,Card,Grid,Metric,Page,Table} from '../components/ui';

import {safeAppAction} from '../services/safe-app-action.server';

export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);const summary=await releaseSummary(session.shop);return {...summary,doctor:updaterDoctor(),updater:updaterState()};}
export async function action({request}:ActionFunctionArgs){return safeAppAction('updates',request,async()=>{
 const {session}=await authenticate.admin(request);const fd=await request.formData();const intent=String(fd.get('intent')||'');
 try{
  if(intent==='stage'){
   const file=fd.get('updateZip');if(!(file instanceof File))return {ok:false,error:'Choose a DHC update ZIP.'};
   return {ok:true,result:await stageUpdatePackage(session.shop,file,String(fd.get('sha256')||''))};
  }
  if(intent==='apply')return {ok:true,result:await applyStagedUpdate(session.shop,String(fd.get('id')||''))};
  if(intent==='rollback')return {ok:true,result:await rollbackLatestUpdate(session.shop)};
  if(intent==='refresh-durable')return {ok:true,result:await refreshDurableUpdateStatus(session.shop)};
  if(intent==='publish-durable')return {ok:true,result:await publishDurableUpdate(session.shop)};
  return {ok:false,error:'Unknown update action.'};
 }catch(e){return {ok:false,error:e instanceof Error?e.message:'Update action failed'};}
});}

export default function Updates(){const data=useLoaderData<typeof loader>();const actionData=useActionData<typeof action>();const counts=new Map<string,number>();for(const g of data.errorGroups)if(g.status==='OPEN')counts.set(g.releaseVersion,(counts.get(g.releaseVersion)||0)+g._count._all);const staged=data.updater;
 return <Page title="Updates & Upgrade Import" subtitle="This Node.js app stays installed. Normal Gus fixes and features are delivered as versioned upgrade ZIPs through this page.">
  <Grid><Metric label="Running version" value={data.currentVersion}/><Metric label="Updater filesystem" value={data.doctor.writable?'READY':'BLOCKED'}/><Metric label="ZIP support" value={data.doctor.unzipAvailable?'READY':'MISSING'}/><Metric label="Automation during update" value="FORCED STOP"/><Metric label="Production DB" value={data.doctor.databaseProvider==='mysql'?'MYSQL READY':data.doctor.databaseProvider==='sqlite'?'SQLITE STAGING':'UNKNOWN'}/><Metric label="Durable updater" value={data.doctor.godaddyDurableUpdater?'GODADDY READY':'CONFIG NEEDED'}/></Grid><div style={{height:16}}/>
  <Card><h2>Permanent-install updater</h2><p><b>Policy:</b> normal updates do not require reinstalling the Shopify/Node app. The updater verifies the trusted ZIP checksum and every declared file, rejects unsafe paths, forces Master Stop, backs up changed files and the current production build, applies the update, generates Prisma, runs source/tests/rules/syntax/build verification, and requests a Node restart.</p><p>If verification fails, files and the previous build are restored automatically and Gus stays stopped. Database-changing releases are blocked unless a verified DB backup has been explicitly marked ready.</p><p><b>Permanent mode:</b> production updates should include a verified <code>godaddy-source.zip</code>. Gus submits that source through GoDaddy's Node Hosting API to Preview first, tracks the build, and only publishes after Preview succeeds. This makes the update survive GoDaddy restarts and later deployments.</p><p><b>Restart signal:</b> <code>{data.doctor.restartFile}</code></p></Card><div style={{height:16}}/>
  <Card><h2>1. Stage an upgrade ZIP</h2><p>Only upload an update built for <b>exactly {data.currentVersion}</b>. Paste the SHA-256 supplied with the update so corrupted or substituted packages are rejected before extraction.</p><Form method="post" encType="multipart/form-data"><input type="file" name="updateZip" accept=".zip,application/zip" required/><div style={{height:8}}/><input name="sha256" placeholder="64-character SHA-256" style={{width:'100%',maxWidth:700}} required/><div style={{height:8}}/><button name="intent" value="stage">Validate & stage update</button></Form></Card><div style={{height:16}}/>
  {staged?<Card><h2>2. Review staged update</h2><p><b>{staged.manifest.fromVersion} → {staged.manifest.targetVersion}</b> <Badge tone={staged.status==='FAILED'?'bad':staged.status==='INSTALLED'?'good':'warn'}>{staged.status}</Badge></p><p>{staged.manifest.notes||'No release notes supplied.'}</p><p>Files: {staged.manifest.files.length} · Deletes: {staged.manifest.deletes?.length||0} · DB migration: {staged.manifest.requiresDbMigration?'YES':'NO'} · Dependency install: {staged.manifest.requiresDependencyInstall?'YES':'NO'}</p><p><code>{staged.packageSha256}</code></p>{staged.error?<p><b>Last error:</b> {staged.error}</p>:null}<div style={{display:'flex',gap:8,flexWrap:'wrap'}}>{staged.status==='STAGED'?<Form method="post"><input type="hidden" name="id" value={staged.id}/><button name="intent" value="apply">Apply verified update</button></Form>:null}{staged.backupDir&&!staged.manifest.requiresDbMigration?<Form method="post"><button name="intent" value="rollback">Rollback latest update</button></Form>:null}{staged.manifest.godaddySource?<Form method="post"><button name="intent" value="refresh-durable">Refresh GoDaddy preview status</button></Form>:null}{staged.manifest.godaddySource?<Form method="post"><button name="intent" value="publish-durable">Publish verified preview</button></Form>:null}</div></Card>:null}
  {actionData?<><div style={{height:16}}/><Card><b>{actionData.ok?'Completed':'Blocked'}:</b> {actionData.ok?JSON.stringify(actionData.result):actionData.error}</Card></>:null}<div style={{height:16}}/>
  <Table headers={['Version','Channel','Status','Open errors','Installed/created']} rows={data.releases.map(r=>[r.version,r.channel,<Badge tone={r.status==='INSTALLED'?'good':r.status==='FAILED'?'bad':r.status==='STAGED'?'warn':'neutral'}>{r.status}</Badge>,counts.get(r.version)||0,new Date(r.createdAt).toLocaleString()])}/>
 </Page>;
}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
