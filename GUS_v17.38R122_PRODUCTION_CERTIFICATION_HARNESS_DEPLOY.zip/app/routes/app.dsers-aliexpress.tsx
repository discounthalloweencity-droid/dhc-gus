import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSupplierFulfillmentDashboard} from '../services/supplier-fulfillment-dashboard.server';
import {SupplierFulfillmentSurface} from '../components/supplier-fulfillment-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSupplierFulfillmentDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SupplierFulfillmentSurface title='DSers / AliExpress' subtitle='DSers and AliExpress supplier operations, mapped evidence, stock status and delivery risk.' data={data} focus={['Use exact mapped variants and supplier evidence rather than marketplace title similarity.','Flag expired listings, substitution risk, stock gaps and delivery-time deterioration.','Keep AliExpress account or appeal problems visible as fulfillment exceptions instead of silently remapping orders.','Replacement products must match the ordered product materially before they can be proposed.']} supplier='DSERS'/>;}
