import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { Form, Link, useActionData, useLoaderData } from "react-router";
import { authenticate, unauthenticated } from "../shopify.server";
import { db } from "../db.server";
import { safePageData } from "../services/page-data-safety.server";
import { Badge, Card, Grid, Metric, Page, Table } from "../components/ui";
import { runWeeklyCollectionMaintenance } from "../services/weekly-collection-maintenance.server";
import { runDailyNewProductIntake } from "../services/new-product-intake.server";
import { runWeeklySeoWatch } from "../services/weekly-seo-watch.server";
import { scanCatalog } from "../services/scan.server";

import {safeAppAction} from '../services/safe-app-action.server';

function parseDetails(raw:string|null|undefined){try{return raw?JSON.parse(raw):{};}catch{return {message:String(raw||"")};}}
function statusTone(status:string){return /COMPLETE|SUCCESS|DONE|STOPPED/i.test(status)?"good":/FAIL|ERROR|STALL/i.test(status)?"bad":"warn" as const;}
function jobMessage(job:any){const d=parseDetails(job.details);return String(d.message||d.error||d.reason||d.phase||"No failure detail was recorded by this historical run.");}
const RETRYABLE=new Set(["CATALOG_SCAN","WEEKLY_COLLECTION_MAINTENANCE","DAILY_NEW_PRODUCT_INTAKE","WEEKLY_SEO_WATCH"]);

async function runRetry(shop:string,jobType:string){
  if(jobType==="WEEKLY_SEO_WATCH")return runWeeklySeoWatch(shop,true);
  const {admin}=await unauthenticated.admin(shop);
  if(jobType==="WEEKLY_COLLECTION_MAINTENANCE")return runWeeklyCollectionMaintenance(admin,shop,true);
  if(jobType==="DAILY_NEW_PRODUCT_INTAKE")return runDailyNewProductIntake(admin,shop,true);
  if(jobType==="CATALOG_SCAN")return scanCatalog(admin,shop,false);
  throw new Error(`Job type ${jobType} is not retryable from Activity Log.`);
}

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const url=new URL(request.url);
  const showHistory=url.searchParams.get("history")==="1";
  const since=new Date(Date.now()-24*60*60*1000);
  const jobWhere:any={shop};if(!showHistory)jobWhere.startedAt={gte:since};
  const [changes, jobs, changeCount, jobCount] = await Promise.all([
    safePageData("activity","changes",db.changeLog.findMany({ where: { shop }, orderBy: { createdAt: "desc" }, take: 150 }),[] as any[]),
    safePageData("activity","jobs",db.jobRun.findMany({ where: jobWhere, orderBy: { startedAt: "desc" }, take: showHistory?150:75 }),[] as any[]),
    safePageData("activity","change count",db.changeLog.count({ where: { shop } }),0),
    safePageData("activity","job count",db.jobRun.count({ where: { shop } }),0),
  ]);
  const selectedId=Number(url.searchParams.get("job"));
  let selected=Number.isSafeInteger(selectedId)?jobs.find((j:any)=>j.id===selectedId)||null:null;
  if(!selected&&Number.isSafeInteger(selectedId))selected=await safePageData("activity","selected job",db.jobRun.findFirst({where:{id:selectedId,shop}}),null as any);
  return { changes, jobs, changeCount, jobCount, showHistory, selected:selected?{...selected,parsed:parseDetails(selected.details),message:jobMessage(selected)}:null };
}

export async function action({request}:ActionFunctionArgs){return safeAppAction('activity',request,async()=>{
  const {session}=await authenticate.admin(request);
  const fd=await request.formData();
  const intent=String(fd.get("intent")||"");
  const jobId=Number(fd.get("jobId"));
  if(intent!=="retry"||!Number.isSafeInteger(jobId))return {ok:false,error:"Invalid retry request."};
  const original=await db.jobRun.findFirst({where:{id:jobId,shop:session.shop}});
  if(!original)return {ok:false,error:"Job run was not found for this store."};
  if(!RETRYABLE.has(original.jobType))return {ok:false,error:`${original.jobType} cannot be retried from this screen.`};
  const shop=session.shop,jobType=original.jobType;
  setTimeout(()=>{void runRetry(shop,jobType).then(result=>console.info(`[gus-activity] retry ${jobType} completed`,result)).catch(error=>console.error(`[gus-activity] retry ${jobType} failed`,error instanceof Error?(error.stack||error.message):error));},0);
  return {ok:true,message:`${jobType} retry queued. Refresh in a few seconds to see the new run and its exact status.`};
});}

export default function ActivityLog() {
  const d = useLoaderData<typeof loader>();
  const a=useActionData<typeof action>();
  const reversible = d.changes.filter((c:any) => c.reversible).length;
  const failed=d.jobs.filter((j:any)=>/FAIL|ERROR|STALL/i.test(j.status)).length;
  return <Page title="Activity Log" subtitle="Current automation runs are actionable. Historical failures remain available for audit without dominating the default view.">
    {a&&<div className={`gus-flash ${a.ok?"gus-flash-good":"gus-flash-bad"}`}>{a.ok?a.message:a.error}</div>}
    <div className="authority-toolbar" style={{display:"flex",gap:10,flexWrap:"wrap",marginBottom:16}}>
      <Link className="authority-button authority-primary" to={d.showHistory?"/app/activity":"/app/activity?history=1"}>{d.showHistory?"Show last 24 hours":"Show full history"}</Link>
      <Link className="authority-button" to="/app/findings">Authority Issues</Link>
      <Link className="authority-button" to="/app/system-jobs">Jobs / Scheduler</Link>
    </div>
    <Grid>
      <Metric label="Recorded changes" value={d.changeCount} detail="Auditable store-change records" />
      <Metric label={d.showHistory?"Runs shown":"Runs in last 24h"} value={d.jobs.length} detail={`${failed} failed in this view`} />
      <Metric label="All automation runs" value={d.jobCount} detail="Historical audit count" />
      <Metric label="Recent reversible changes" value={reversible} detail="Within the latest change window" />
    </Grid>
    {d.selected&&<><div style={{height:18}}/><Card>
      <div style={{display:"flex",justifyContent:"space-between",gap:12,alignItems:"flex-start",flexWrap:"wrap"}}><div><div style={{fontSize:12,color:"#616161"}}>JOB RUN #{d.selected.id}</div><h2 style={{margin:"4px 0"}}>{d.selected.jobType}</h2></div><Badge tone={statusTone(d.selected.status)}>{d.selected.status}</Badge></div>
      <p><strong>What happened:</strong> {d.selected.message}</p>
      <Grid><Metric label="Scanned" value={d.selected.scanned}/><Metric label="Changed" value={d.selected.changed}/><Metric label="Warnings" value={d.selected.warnings}/><Metric label="Phase" value={d.selected.parsed.phase||"—"}/></Grid>
      <div className="authority-note" style={{marginTop:14}}>Started {new Date(d.selected.startedAt).toLocaleString()}{d.selected.finishedAt?` · Finished ${new Date(d.selected.finishedAt).toLocaleString()}`:" · Still active"}{d.selected.parsed.heartbeatAt?` · Last heartbeat ${new Date(d.selected.parsed.heartbeatAt).toLocaleString()}`:""}.</div>
      <div style={{display:"flex",gap:10,flexWrap:"wrap",marginTop:14}}>{/FAIL|ERROR|STALL/i.test(d.selected.status)&&RETRYABLE.has(d.selected.jobType)?<Form method="post"><input type="hidden" name="jobId" value={d.selected.id}/><button className="authority-button authority-primary" name="intent" value="retry">Retry this job</button></Form>:null}<Link className="authority-button" to={d.showHistory?"/app/activity?history=1":"/app/activity"}>Close details</Link></div>
    </Card></>}
    <div style={{height:18}} />
    <h2>Recent Gus changes</h2>
    <Table headers={["When","Action","Field","Reason","Source","Reversible"]} rows={d.changes.map((c:any)=>[
      new Date(c.createdAt).toLocaleString(), c.action, c.field || "—", c.reason, c.source,
      <Badge tone={c.reversible ? "good" : "neutral"}>{c.reversible ? "YES" : "NO"}</Badge>
    ])}/>
    <div style={{height:22}} />
    <h2>Automation runs</h2>
    {!d.showHistory&&<p style={{color:"#616161"}}>Showing the last 24 hours by default. Older FAILED rows are historical audit records, not proof that the current engine is still broken.</p>}
    <Table headers={["Started","Job","Status","Scanned","Changed","Warnings","Result / failure reason","Action"]} rows={d.jobs.map((j:any)=>[
      new Date(j.startedAt).toLocaleString(), <Link to={`?${d.showHistory?"history=1&":""}job=${j.id}`}>{j.jobType}</Link>,
      <Badge tone={statusTone(j.status)}>{j.status}</Badge>,
      j.scanned, j.changed, j.warnings,
      <span style={{maxWidth:360,display:"inline-block"}}>{jobMessage(j)}</span>,
      <Link className="authority-button" to={`?${d.showHistory?"history=1&":""}job=${j.id}`}>View</Link>
    ])}/>
  </Page>;
}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
