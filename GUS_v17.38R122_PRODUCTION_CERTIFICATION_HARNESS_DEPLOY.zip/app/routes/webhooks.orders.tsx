import type {ActionFunctionArgs} from "react-router";
import { authenticate } from "../shopify.server";
import { db } from "../db.server";
import { estimateOrderProfit } from "../services/profitability.server";
import {captureAndRespond,captureError} from '../services/error-capture.server';
import {assessOrderRisk} from '../services/fraud-risk.server';
import {requestAutonomousPulse} from "../services/runtime-orchestrator-pulse.server";
import {exchangeTrackingOrderFromWebhook,notifyExchangeTrackingForOrder} from "../services/support-exchange-tracking.server";

const amount=(value:unknown)=>{const n=Number(value);return Number.isFinite(n)&&n>=0?n:null;};
function customerShippingPaid(p:any){
 const direct=amount(p?.current_total_shipping_price_set?.shop_money?.amount)
   ?? amount(p?.total_shipping_price_set?.shop_money?.amount);
 if(direct!=null)return direct;
 if(Array.isArray(p?.shipping_lines)){
  return p.shipping_lines.reduce((sum:number,line:any)=>sum+(amount(line?.discounted_price)??amount(line?.price)??0),0);
 }
 return 0;
}

export async function action({request}:ActionFunctionArgs){
 let shop=process.env.AUTHORITY_SHOP||'unknown';
 try{
  const result=await authenticate.webhook(request);shop=result.shop;const p:any=result.payload;
  const merchandise=amount(p?.current_subtotal_price)??amount(p?.subtotal_price);
  const shipping=customerShippingPaid(p);
  const discounts=amount(p?.current_total_discounts)??amount(p?.total_discounts)??0;
  if(merchandise==null)return new Response("Invalid order merchandise total",{status:422});
  const collectedRevenue=merchandise+shipping;
  const est=estimateOrderProfit({merchandiseRevenueAfterDiscounts:merchandise,customerShippingPaid:shipping});
  const orderGid=p?.admin_graphql_api_id || (p?.id?`gid://shopify/Order/${p.id}`:"unknown");
  if(orderGid==='unknown')return new Response('Order identity unavailable',{status:422});

  // Idempotent by shop + order identity. Shopify retries/updates refresh the one current snapshot
  // instead of creating duplicate accounting rows. The schema enforces the same invariant.
  await db.orderProfitSnapshot.upsert({
   where:{shop_orderGid:{shop,orderGid}},
   create:{
    shop,orderGid,orderName:String(p?.name||p?.order_number||"Order"),grossRevenue:collectedRevenue,
    merchandiseRevenue:merchandise,customerShippingPaid:shipping,discounts,paymentFees:est.paymentFees,
    estimatedProfit:null,estimatedMargin:null,contributionBeforeAcquisition:null,contributionAfterAcquisition:null,
    fulfillmentRisk:"COST_DATA_NEEDED"
   },
   update:{
    orderName:String(p?.name||p?.order_number||"Order"),grossRevenue:collectedRevenue,
    merchandiseRevenue:merchandise,customerShippingPaid:shipping,discounts,paymentFees:est.paymentFees,
    capturedAt:new Date()
   }
  });
  await assessOrderRisk(shop,p);
  try{await notifyExchangeTrackingForOrder(shop,exchangeTrackingOrderFromWebhook(p));}
  catch(error){await captureError(error,{shop,source:'GUS_EXCHANGE_TRACKING_WEBHOOK',route:'/webhooks/orders',jobType:'EXCHANGE_TRACKING_NOTIFY'}).catch(()=>{});}
  requestAutonomousPulse(shop,250);
  return new Response();
 }catch(error){return captureAndRespond(error,{shop,source:'SHOPIFY_WEBHOOK',route:'/webhooks/orders',jobType:'ORDER_WEBHOOK'});}
}
