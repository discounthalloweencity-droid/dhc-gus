import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSupplierFulfillmentDashboard} from '../services/supplier-fulfillment-dashboard.server';
import {SupplierFulfillmentSurface} from '../components/supplier-fulfillment-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSupplierFulfillmentDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SupplierFulfillmentSurface title='Supplier Reliability' subtitle='Evidence-based supplier reliability, freshness, stock consistency and fulfillment-risk review.' data={data} focus={['Judge reliability from stored evidence, not supplier marketing claims.','Escalate repeated stale feeds, availability reversals, shipping deterioration and substitution failures.','Protect high-selling products by preferring reliable fulfillment when margin remains acceptable.','Keep insufficient-history suppliers marked as unknown rather than assigning a fabricated score.']}/>;}
