import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { Form, Link, useActionData, useLoaderData } from "react-router";
import { authenticate } from "../shopify.server";
import { db } from "../db.server";
import { safePageData } from "../services/page-data-safety.server";
import { Badge, Card, Grid, Metric, Page, Table } from "../components/ui";

import {safeAppAction} from '../services/safe-app-action.server';
import {classifyFindingAutonomy,relatedProposalActionsForFinding} from '../services/finding-autonomy-rules';

function csvCell(value:unknown){
  const s=String(value??"");
  return `"${s.replaceAll('"','""')}"`;
}
function shortGid(gid:string|null|undefined){return String(gid||"").split("/").pop()||"—";}
function operatorNextStep(row:any){
  const d=classifyFindingAutonomy(row);
  if(d.lane==='AUTO_FIX')return 'Gus is handling this automatically through the governed writer/specialist engine. No owner approval is required; the issue remains open until readback or a fresh scan verifies the repair.';
  if(d.lane==='AUTO_VERIFY')return 'Gus is investigating and rechecking this automatically. No owner approval is required unless the eventual repair becomes a genuinely high-impact change.';
  if(d.lane==='EVIDENCE_WAIT')return 'Gus is waiting for or refreshing objective evidence. Do not approve a guess; this will retry through connected evidence sources and remain unresolved until facts are available.';
  const text=`${row.category||''} ${row.code||''}`.toUpperCase();
  if(/PRICE|MARGIN|PROFIT|DISCOUNT/.test(text))return 'Owner review is required because this can materially change commercial policy, price, margin or profitability.';
  return 'Owner review is reserved for this high-impact exception because Gus does not yet have a governed reversible repair path.';
}
function shopAdminProductUrl(shop:string,productGid:string){
  const slug=shop.replace(/\.myshopify\.com$/i,"");
  return `https://admin.shopify.com/store/${encodeURIComponent(slug)}/products/${encodeURIComponent(shortGid(productGid))}`;
}

export async function loader({request}:LoaderFunctionArgs){
  const {session}=await authenticate.admin(request);
  const shop=session.shop;
  const url=new URL(request.url);
  const rows=await safePageData("findings","open findings",db.finding.findMany({where:{shop,status:"OPEN"},orderBy:{createdAt:"desc"},take:500}),[] as any[]);
  const gids=[...new Set(rows.map((r:any)=>r.productGid).filter(Boolean))];
  const [snapshots,proposals]=await Promise.all([
    gids.length?safePageData("findings","product titles",db.productSnapshot.findMany({where:{shop,productGid:{in:gids}},orderBy:{capturedAt:"desc"},take:5000}),[] as any[]):Promise.resolve([]),
    gids.length?safePageData("findings","related proposals",db.actionProposal.findMany({where:{shop,productGid:{in:gids},status:{in:["PENDING","APPROVED","FAILED"]}},orderBy:{updatedAt:"desc"},take:2000}),[] as any[]):Promise.resolve([]),
  ]);
  const latestTitle=new Map<string,string>();
  for(const s of snapshots as any[])if(!latestTitle.has(s.productGid))latestTitle.set(s.productGid,s.title);
  const proposalsByProduct=new Map<string,any[]>();
  for(const p of proposals as any[]){const list=proposalsByProduct.get(p.productGid)||[];list.push(p);proposalsByProduct.set(p.productGid,list);}
  const enriched=rows.map((r:any)=>{
    const relatedActions=relatedProposalActionsForFinding(r);
    const candidates=(proposalsByProduct.get(r.productGid)||[]).filter((p:any)=>!relatedActions.length||relatedActions.includes(String(p.action||'').toUpperCase()));
    const proposal=candidates.find((p:any)=>!r.variantGid||p.variantGid===r.variantGid)||candidates.find((p:any)=>!p.variantGid)||null;
    return ({
    ...r,
    productTitle:latestTitle.get(r.productGid)||null,
    productUrl:shopAdminProductUrl(shop,r.productGid),
    proposal,
    autonomy:classifyFindingAutonomy(r),
    nextStep:operatorNextStep(r),
  });});
  if(url.searchParams.get("export")==="csv"){
    const header=["id","severity","area","code","product_title","product_gid","variant_gid","message","proposed","proposal_status","next_step","created_at"];
    const lines=[header.join(","),...enriched.map((r:any)=>[
      r.id,r.severity,r.category,r.code,r.productTitle||"",r.productGid,r.variantGid||"",r.message,r.proposed||"",r.proposal?.status||"",r.nextStep,new Date(r.createdAt).toISOString()
    ].map(csvCell).join(","))];
    return new Response(lines.join("\n"),{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":`attachment; filename=dhc-authority-issues-${Date.now()}.csv`,"Cache-Control":"no-store"}});
  }
  const selectedId=Number(url.searchParams.get("id"));
  const selected=Number.isSafeInteger(selectedId)?enriched.find((r:any)=>r.id===selectedId)||null:null;
  const high=enriched.filter((r:any)=>r.severity==="HIGH"||r.severity==="CRITICAL").length;
  const withProposal=enriched.filter((r:any)=>r.proposal).length;
  const uniqueProducts=new Set(enriched.map((r:any)=>r.productGid)).size;
  const auto=enriched.filter((r:any)=>r.autonomy.lane==='AUTO_FIX'||r.autonomy.lane==='AUTO_VERIFY').length;
  const evidence=enriched.filter((r:any)=>r.autonomy.lane==='EVIDENCE_WAIT').length;
  const ownerReview=enriched.filter((r:any)=>r.autonomy.lane==='OWNER_REVIEW').length;
  return {rows:enriched,selected,metrics:{open:enriched.length,high,withProposal,uniqueProducts,auto,evidence,ownerReview}};
}

export async function action({request}:ActionFunctionArgs){return safeAppAction('findings',request,async()=>{
  const {session}=await authenticate.admin(request);
  const fd=await request.formData();
  const id=Number(fd.get("id"));
  const intent=String(fd.get("intent")||"");
  if(!Number.isSafeInteger(id))return {ok:false,error:"Invalid finding id."};
  const row=await db.finding.findFirst({where:{id,shop:session.shop}});
  if(!row)return {ok:false,error:"Finding was not found for this store."};
  if(intent!=="resolve")return {ok:false,error:"Unsupported finding action."};
  await db.finding.update({where:{id},data:{status:"RESOLVED",resolvedAt:new Date()}});
  return {ok:true,message:`${row.code} marked resolved.`};
});}

export default function Findings(){
  const {rows,selected,metrics}=useLoaderData<typeof loader>();
  const actionData=useActionData<typeof action>();
  return <Page title="Authority Issues" subtitle="Evidence-backed issue queue. Routine findings are self-resolving; owner review is reserved for genuinely high-impact exceptions.">
    {actionData&&<div className={`gus-flash ${actionData.ok?"gus-flash-good":"gus-flash-bad"}`}>{actionData.ok?actionData.message:actionData.error}</div>}
    <div className="authority-toolbar" style={{display:"flex",gap:10,flexWrap:"wrap",marginBottom:16}}>
      <Link className="authority-button authority-primary" to="?export=csv" reloadDocument>Export open issues CSV</Link>
      <Link className="authority-button" to="/app/actions">Open owner exception queue</Link>
      <Link className="authority-button" to="/app/activity">Automation activity</Link>
    </div>
    <Grid>
      <Metric label="Open issues" value={metrics.open}/>
      <Metric label="High / critical" value={metrics.high}/>
      <Metric label="Products affected" value={metrics.uniqueProducts}/>
      <Metric label="Gus autonomous" value={metrics.auto}/><Metric label="Waiting evidence" value={metrics.evidence}/><Metric label="Owner review" value={metrics.ownerReview}/>
    </Grid>
    {selected&&<><div style={{height:18}}/><Card>
      <div style={{display:"flex",justifyContent:"space-between",gap:14,flexWrap:"wrap",alignItems:"flex-start"}}>
        <div><div style={{fontSize:12,color:"#616161"}}>AUTHORITY ISSUE #{selected.id}</div><h2 style={{margin:"4px 0 8px"}}>{selected.code}</h2><p style={{margin:0}}>{selected.message}</p></div>
        <Badge tone={selected.severity==="HIGH"||selected.severity==="CRITICAL"?"bad":selected.severity==="MEDIUM"?"warn":"neutral"}>{selected.severity}</Badge>
      </div>
      <div style={{height:14}}/>
      <Grid>
        <Metric label="Product" value={selected.productTitle||`Product ${shortGid(selected.productGid)}`} detail={`Shopify ${shortGid(selected.productGid)}`}/>
        <Metric label="Variant" value={selected.variantGid?shortGid(selected.variantGid):"Product-level"}/>
        <Metric label="Area" value={selected.category}/>
        <Metric label="Handling" value={selected.autonomy.lane} detail={selected.autonomy.reason}/><Metric label="Proposal" value={selected.proposal?.status||"No linked proposal"} detail={selected.proposal?`${selected.proposal.action} proposal #${selected.proposal.id}`:undefined}/>
      </Grid>
      <div style={{height:14}}/><div className="authority-note"><strong>What to do:</strong> {selected.nextStep}{selected.proposed?<><br/><strong>Proposed:</strong> {selected.proposed}</>:null}</div>
      <div style={{display:"flex",gap:10,flexWrap:"wrap",marginTop:14}}>
        <a className="authority-button authority-primary" href={selected.productUrl} target="_blank" rel="noopener noreferrer">Open product in Shopify</a>
        {selected.proposal&&selected.autonomy.requiresOwner?<Link className="authority-button" to="/app/actions">Review owner exception</Link>:null}
        {selected.autonomy.requiresOwner?<Form method="post"><input type="hidden" name="id" value={selected.id}/><button className="authority-button" name="intent" value="resolve">Mark owner exception resolved</button></Form>:<span style={{alignSelf:"center",fontSize:12,color:"#64748b"}}>Gus closes this automatically after verified repair/readback.</span>}
        <Link className="authority-button" to="/app/findings">Close details</Link>
      </div>
    </Card></>}
    <div style={{height:18}}/>
    {!rows.length&&<div className="gus-flash gus-flash-good">No open authority issues are recorded. This means zero open findings in the database—not that a scan was skipped. Check Jobs / Scheduler for the last completed scan.</div>}
    <Table headers={["Severity","Product","Area","Issue","Gus handling","Lane","Created","Actions"]} rows={rows.map((r:any)=>[
      <Badge tone={r.severity==="HIGH"||r.severity==="CRITICAL"?"bad":r.severity==="MEDIUM"?"warn":"neutral"}>{r.severity}</Badge>,
      <><strong>{r.productTitle||`Product ${shortGid(r.productGid)}`}</strong><br/><span style={{color:"#616161",fontSize:12}}>{shortGid(r.productGid)}{r.variantGid?` · variant ${shortGid(r.variantGid)}`:""}</span></>,
      r.category,
      <><Link to={`?id=${r.id}`}><strong>{r.code}</strong></Link><br/><span style={{color:"#616161"}}>{r.message}</span>{r.proposed?<><br/><span style={{fontSize:12}}><strong>Proposed:</strong> {r.proposed}</span></>:null}</>,
      <span style={{maxWidth:300,display:"inline-block"}}>{r.nextStep}</span>,
      <Badge tone={r.autonomy.lane==="OWNER_REVIEW"?"warn":r.autonomy.lane==="EVIDENCE_WAIT"?"neutral":"good"}>{r.autonomy.lane}</Badge>,
      new Date(r.createdAt).toLocaleString(),
      <div style={{display:"flex",gap:6,flexWrap:"wrap"}}><Link className="authority-button" to={`?id=${r.id}`}>View</Link><a className="authority-button" href={r.productUrl} target="_blank" rel="noopener noreferrer">Shopify</a></div>
    ])}/>
  </Page>;
}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
