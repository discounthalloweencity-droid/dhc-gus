import pkg from '../../package.json';
export async function loader(){
  return Response.json(
    {status:'ok',service:'DHC Gus Command Center',release:pkg.version,proofEndpoint:'/health/proof'},
    {headers:{'Cache-Control':'no-store, max-age=0'}},
  );
}
