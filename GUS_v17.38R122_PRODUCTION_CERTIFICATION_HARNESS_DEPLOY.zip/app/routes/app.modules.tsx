import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {Page,Card,Table,Badge} from '../components/ui';
import {UNIFIED_MODULES,moduleSummary} from '../services/feature-registry';
import {authenticate} from '../shopify.server';
import {loadContinuousLearningDashboard} from '../services/continuous-learning-evolution.server';

export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return {evolution:await loadContinuousLearningDashboard(session.shop)};}

export default function Modules(){const s=moduleSummary(),{evolution}=useLoaderData<typeof loader>();return <Page title="Unified Gus Modules" subtitle="One application, one database, one Stop / Run control, one deployment. Gus can now request new capabilities when repeated job evidence proves a missing engine, connector or module is limiting him.">
 <Card><h2>Integration status</h2><p>{s.integrated} integrated, {s.partial} partially integrated, {s.external} external-dependency modules, across {s.total} tracked modules.</p><p>A module is marked integrated only when its code exists in this cumulative application. Live-provider testing is tracked separately from code integration.</p></Card>
 <div style={{height:16}}/><Card><h2>Gus capability-growth requests</h2><p>These are evidence-backed requests from Gus's learning loop. They are suggestions, not self-granted permissions: new credentials, external accounts, integrations and authority stay owner-controlled.</p>{evolution.capabilityWork.length?<Table headers={['Requested capability','Why','Recurring evidence','Priority','State']} rows={evolution.capabilityWork.map(w=>[w.title,w.evidence?.proposal?.benefit||w.objective,`${w.evidence?.occurrences||0} occurrences · ${w.evidence?.source||'runtime evidence'}`,w.priorityScore,<Badge tone="warn">{w.status}</Badge>])}/>:<p>No recurring capability gap currently meets Gus's threshold for requesting another engine, module or connector.</p>}</Card>
 <div style={{height:16}}/><Table headers={['Module','Status','In this app','Still required']} rows={UNIFIED_MODULES.map(m=>[m.name,<Badge tone={m.status==='INTEGRATED'?'good':m.status==='PARTIAL'?'warn':'bad'}>{m.status}</Badge>,m.capabilities.join(' • '),(m.remaining||[]).join(' • ')||'—'])}/>
 </Page>}
