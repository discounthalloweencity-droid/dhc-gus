import type {ActionFunctionArgs} from 'react-router';
import {resolveGusStorefrontContext,gusCorsHeaders} from '../services/gus-storefront-auth.server';
import {handleGusCart} from '../services/gus-concierge-api.server';
export async function action({request}:ActionFunctionArgs){try{const {admin,shop}=await resolveGusStorefrontContext(request);const input=await request.json();return Response.json(await handleGusCart(admin,shop,input),{headers:gusCorsHeaders()});}catch(e:any){if(e instanceof Response)return e;return Response.json({ok:false,error:e?.message||'Cart operation unavailable',fallback:{type:'STOREFRONT_CART',requires_customer_action:true}},{status:400,headers:gusCorsHeaders()});}}
