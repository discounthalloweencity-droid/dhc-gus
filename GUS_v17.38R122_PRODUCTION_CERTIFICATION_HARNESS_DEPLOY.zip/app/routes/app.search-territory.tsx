import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSearchTerritoryDashboard} from '../services/google-commerce-search-territory.server';
import {Badge,Card,Grid,Metric,Page,Table} from '../components/ui';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSearchTerritoryDashboard(session.shop);}
const pct=(x:any)=>x==null?'Unavailable':`${(Number(x)*100).toFixed(1)}%`;
const money=(x:any)=>x==null?'—':`$${Number(x).toLocaleString(undefined,{maximumFractionDigits:0})}`;
export default function SearchTerritory(){const d:any=useLoaderData<typeof loader>();return <Page title="Google Commerce & Search Territory" subtitle="Gus v0.16.50 — Google Commerce/Search Territory plus Academy-trained Merchant, crawl/index, cannibalization, variants, Images/Lens, reviews, SERP intelligence, organic economics and Quality Queue decisions.">
<Grid><Metric label="Organic Market Share" value={pct(d.organicMarketShare)} detail={d.organicMarketShare==null?'Requires verified competitor SERP provider evidence.':`${d.trackedQueries} tracked high-value searches`}/><Metric label="Organic revenue" value={money(d.revenue?.totals?.revenue)} detail={`Estimated profit ${money(d.revenue?.totals?.estimatedOrganicProfit)}`}/><Metric label="Merchant sync" value={d.merchant?.connector?.configured?(d.merchant?.connector?.autopilot?'AUTOPILOT':'CONNECTED'):'NOT CONFIGURED'} detail={`${d.merchant?.sync?.synced??0} synced in last workforce run`}/><Metric label="Google Quality Queue" value={d.quality?.count??0} detail={`${d.autoSafe} auto-safe · ${d.ownerExceptions} owner exceptions`}/></Grid>
<Card><h2>SEO resource allocation</h2><Table headers={['Workstream','Target share']} rows={Object.entries(d.allocation).map(([k,v]:any)=>[String(k).replace(/([A-Z])/g,' $1'),`${v}%`])}/></Card>
<Card><h2>Commerce ecosystem</h2><Table headers={['Layer','State','Evidence']} rows={[
 ['Merchant Center / Shopping',d.merchant?.connector?.configured?'ACTIVE':'WAITING',`${d.merchant?.catalog?.activeProducts??0} active products · ${d.merchant?.catalog?.eligible??0} eligible variants checked last batch · ${d.merchant?.merchantHealth?.provider?.issues??0} observed Merchant issues`],
 ['Crawl budget',d.crawl?.status||'WAITING',`${d.crawl?.riskyParameterUrls??0} risky parameter links · ${pct(d.crawl?.wasteShare)}`],
 ['Internal PageRank',d.rank?.status||'WAITING',`${d.rank?.pages??0} pages · ${d.rank?.internalLinksQueued??0} authority links queued`],
 ['Keyword winners',d.rank?.status||'WAITING',`${d.rank?.keywordWinners??0} query winners · ${d.rank?.cannibalizationConflicts??0} conflicts`],
 ['Google Images / Lens',d.images?.status||'WAITING',`${d.images?.images??0} images · ${d.images?.missingAlt??0} missing alt · ${d.images?.lowResolution??0} low-resolution`],
 ['DHC entity / trust',d.entity?.pass?'PASS':'NEEDS WORK',d.entity?.proof?.type||'No verified OnlineStore entity yet'],
 ['Review / UGC',d.reviews?.autopilotEnabled?'AUTOPILOT':'CONTROLLED',`${d.reviews?.eligible??0} eligible · ${d.reviews?.sent??0} sent last run`],
 ['Seasonal SEO',d.seasonal?.phase||'WAITING',d.seasonal?.priority||'No seasonal clock evidence'],
 ['Long-tail intent',d.longTail?.status||'WAITING',`${d.longTail?.longTailQueries??0} observed long-tail queries · ${d.longTail?.ownerCandidates??0} distinct landing-page candidates`],
 ['Competitor SERP',d.market?.status||'WAITING',d.market?.organicMarketShare==null?'Provider evidence unavailable':`Tracked visibility share ${pct(d.market.organicMarketShare)}`],
 ].map((r:any)=>[r[0],<Badge tone={/ACTIVE|PASS|OK|AUTOPILOT/.test(String(r[1]))?'good':/ERROR|FAIL/.test(String(r[1]))?'bad':'warn'}>{r[1]}</Badge>,r[2]])}/></Card>
<Card><h2>Highest-opportunity Google Quality Queue</h2>{d.qualityQueue?.length?<Table headers={['Score','Type','URL','Google evidence','Economics','Authority']} rows={d.qualityQueue.slice(0,60).map((x:any)=>[x.opportunityScore,x.type,<a href={x.url} target="_blank" rel="noreferrer">{String(x.url).replace(/^https?:\/\/[^/]+/,'').slice(0,70)}</a>,`${x.impressions} imp · pos ${x.position==null?'—':Number(x.position).toFixed(1)} · CTR ${pct(x.ctr)}`,`${money(x.revenue)} rev · ${money(x.estimatedProfit)} est. profit`,`${x.internalInbound} internal · ${x.backlinks} backlinks`])}/>:<p>No Google Quality Queue evidence yet.</p>}</Card>
<Card><h2>Operating rules</h2><p>Gus prioritizes collections and proven commercial opportunity rather than touching every URL equally. Low-risk feed synchronization, missing image alt, contextual internal links, Search Console measurement, Merchant monitoring and review requests can run under their explicit autopilot contracts. URL/redirect/canonical/noindex/robots changes, consolidation/deletion and new long-tail landing pages remain owner-reviewed.</p><p><strong>Organic Market Share is evidence-bound:</strong> Gus will show “Unavailable” rather than inventing competitor visibility when the SERP provider is not configured.</p></Card>
</Page>}
