import type { LoaderFunctionArgs } from "react-router";
import { useEffect } from "react";
import { useLoaderData } from "react-router";

export async function loader({ request }: LoaderFunctionArgs) {
  // GoDaddy probes the root with both HEAD and GET depending on deployment phase.
  // HEAD must be dependency-free and always return 200 once the router is serving.
  if (request.method === "HEAD") {
    return new Response(null, {
      status: 200,
      headers: {
        "Cache-Control": "no-store",
        "X-Gus-Runtime": "0.16.57",
        "X-Gus-Health": "ready",
      },
    });
  }

  // GET / must also remain HTTP 200 for platform health. Returning a server-side
  // 302 here made GoDaddy's Preview health ambiguous. Render a tiny entry page,
  // then move the human browser into /app on the client. Keep the share token.
  const url = new URL(request.url);
  const target = new URL("/app", url.origin);
  const shareToken = url.searchParams.get("airoShareToken");
  if (shareToken) target.searchParams.set("airoShareToken", shareToken);
  return {
    target: `${target.pathname}${target.search}`,
    runtime: "0.16.57",
  };
}

export default function Home() {
  const { target, runtime } = useLoaderData<typeof loader>();
  useEffect(() => {
    window.location.replace(target);
  }, [target]);

  return (
    <main style={{fontFamily:"system-ui,sans-serif",maxWidth:620,margin:"15vh auto",padding:24,lineHeight:1.5}}>
      <h1 style={{marginBottom:8}}>Gus Command Center</h1>
      <p>Opening Gus…</p>
      <p><a href={target}>Open Gus Command Center</a></p>
      <small>Runtime v{runtime}</small>
    </main>
  );
}
