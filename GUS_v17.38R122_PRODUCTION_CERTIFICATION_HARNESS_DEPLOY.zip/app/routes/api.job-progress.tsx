import type { LoaderFunctionArgs } from "react-router";
import { getActiveJobProgress } from "../services/job-progress.server";
import { verifyJobProgressToken } from "../services/job-progress-token.server";
import { missionProgress, cachedMissionProgress } from "../services/mission-progress.server";
import { unavailableMission } from "../services/mission-progress-status";
import { engineActivitySnapshot } from "../services/engine-rotation.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const url = new URL(request.url);
  const claims = verifyJobProgressToken(url.searchParams.get("token"));
  if (!claims) return Response.json({ ok: false, error: "Unauthorized", mission: unavailableMission("Mission progress token is invalid or expired. All-clear is withheld.") }, { status: 401, headers: { "Cache-Control": "no-store" } });
  let activeJob:any=null;
  try{
    activeJob = await getActiveJobProgress(claims.shop);
    const mission = await missionProgress(claims.shop, activeJob);
    return Response.json({ ok: true, activeJob, mission, engines:engineActivitySnapshot(claims.shop) }, { headers: { "Cache-Control": "no-store, max-age=0" } });
  }catch(error){
    console.warn('[gus-mission-progress] live verification unavailable',error instanceof Error?error.message:String(error));
    const cached=cachedMissionProgress(claims.shop,15_000);
    if(cached)return Response.json({ok:true,activeJob,mission:cached,engines:engineActivitySnapshot(claims.shop),cached:true,warning:"MISSION_PROGRESS_LIVE_READ_TRANSIENT"},{status:200,headers:{"Cache-Control":"no-store, max-age=0"}});
    return Response.json({ok:false,activeJob,mission:unavailableMission("Mission progress query failed. All-clear is withheld until the database and catalog evidence are verified."),engines:engineActivitySnapshot(claims.shop),error:"MISSION_PROGRESS_UNAVAILABLE"},{status:503,headers:{"Cache-Control":"no-store, max-age=0"}});
  }
}
