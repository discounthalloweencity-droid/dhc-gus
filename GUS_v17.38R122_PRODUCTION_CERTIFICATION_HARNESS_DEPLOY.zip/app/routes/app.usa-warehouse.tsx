import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSupplierFulfillmentDashboard} from '../services/supplier-fulfillment-dashboard.server';
import {SupplierFulfillmentSurface} from '../components/supplier-fulfillment-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSupplierFulfillmentDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SupplierFulfillmentSurface title='USA Warehouse' subtitle='US-warehouse coverage and evidence for faster-shipping assortment decisions.' data={data} focus={['Only show or merchandise a Ships from USA claim when current supplier warehouse evidence supports it.','Compare US warehouse stock depth, delivery speed and landed margin before prioritization.','Flag products that lost US inventory so badges and merchandising can be corrected.','Never infer US fulfillment from supplier name or product copy alone.']}/>;}
