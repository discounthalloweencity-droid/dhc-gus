import type {LoaderFunctionArgs} from "react-router";
import {useLoaderData} from "react-router";
import {authenticate} from "../shopify.server";
import {loadGusSurface} from "../services/gus-phase9.server";
import {GusPhase9Surface} from "../components/gus-phase9-surface";
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadGusSurface(session.shop,"decision-history");}
export default function Surface(){const data=useLoaderData<typeof loader>();return <GusPhase9Surface title="Decision History" subtitle="Persisted executive decision runs showing discovered, queued, auto-executed, escalated and blocked work." data={data} mode="decision-history"/>;}
