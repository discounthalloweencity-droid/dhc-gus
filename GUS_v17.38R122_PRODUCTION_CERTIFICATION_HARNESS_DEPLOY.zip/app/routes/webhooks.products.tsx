import type { ActionFunctionArgs } from "react-router";
import { authenticate } from "../shopify.server";
import { db } from "../db.server";
import {captureAndRespond} from '../services/error-capture.server';
import {requestAutonomousPulse} from "../services/runtime-orchestrator-pulse.server";
export async function action({request}:ActionFunctionArgs){
 let shop=process.env.AUTHORITY_SHOP||'unknown';
 try{
  const result=await authenticate.webhook(request);shop=result.shop;const {topic,payload}=result;
  const gid=(payload as any)?.admin_graphql_api_id || ((payload as any)?.id?`gid://shopify/Product/${(payload as any).id}`:null);
  if(gid)await db.finding.create({data:{shop,productGid:gid,category:"SYSTEM",severity:"LOW",code:"PRODUCT_CHANGED",message:`${topic}: product changed and should be included in the next Authority scan.`}});
  requestAutonomousPulse(shop,250);
  return new Response();
 }catch(error){return captureAndRespond(error,{shop,source:'SHOPIFY_WEBHOOK',route:'/webhooks/products',jobType:'PRODUCT_WEBHOOK'});}
}
