import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {Form,useActionData,useLoaderData} from 'react-router';
import {useState} from 'react';
import {authenticate} from '../shopify.server';
import {latestProductionCertification,runProductionCertification} from '../services/production-certification.server';

export async function loader({request}:LoaderFunctionArgs){
 const {session}=await authenticate.admin(request);
 return {
  latest:await latestProductionCertification(session.shop).catch(()=>null),
  canaryEnabled:process.env.GUS_CERTIFICATION_CANARY_ENABLED==='true',
  liveWrites:process.env.AUTHORITY_LIVE_WRITES_ENABLED==='true',
 };
}

export async function action({request}:ActionFunctionArgs){
 const {admin,session}=await authenticate.admin(request);
 const fd=await request.formData();
 const intent=String(fd.get('intent')||'read-only');
 if(intent==='read-only')return {report:await runProductionCertification(admin,session.shop,{persist:true,canary:false})};
 if(intent==='canary'){
  const confirm=String(fd.get('confirm')||'').trim();
  if(confirm!=='RUN SAFE CANARY')throw new Response('Type RUN SAFE CANARY to run reversible Shopify write tests.',{status:400});
  return {report:await runProductionCertification(admin,session.shop,{persist:true,canary:true})};
 }
 throw new Response('Unknown certification action',{status:400});
}

const tone=(s:string)=>s==='PASS'?'#067647':s==='WARN'?'#b54708':s==='FAIL'?'#b42318':s==='BLOCKED'?'#b42318':'#475467';

export default function ProductionCertification(){
 const d=useLoaderData<typeof loader>() as any;
 const a=useActionData<typeof action>() as any;
 const r=a?.report||d.latest?.report||null;
 const [copied,setCopied]=useState(false);
 const copy=async()=>{if(!r?.repairPacket)return;try{await navigator.clipboard.writeText(r.repairPacket);setCopied(true);setTimeout(()=>setCopied(false),1600)}catch{setCopied(false)}};
 return <main style={{padding:24,maxWidth:1600,margin:'auto',fontFamily:'system-ui,sans-serif'}}>
  <div style={{display:'flex',justifyContent:'space-between',gap:16,alignItems:'flex-start',flexWrap:'wrap'}}>
   <div><h1 style={{margin:0,fontSize:32}}>Production Certification</h1><p style={{maxWidth:980,color:'#667085'}}>This is the release gate. It combines artifact/build proof, database read/write/readback, live Shopify reads, runtime/orchestrator proof, engine certification, SEO certification, backlog checks and an optional reversible Shopify canary. Gus is not production-ready merely because tests or schedulers are green.</p></div>
   <Form method="post"><input type="hidden" name="intent" value="read-only"/><button style={button(true)}>Run Full Certification (No Store Writes)</button></Form>
  </div>
  <div style={notice}><b>Canary safety:</b> the write canary only runs when <code>GUS_CERTIFICATION_CANARY_ENABLED=true</code> and <code>AUTHORITY_LIVE_WRITES_ENABLED=true</code>. It uses a dedicated DRAFT product, an internal collection, and an UNPUBLISHED temporary article. Product/collection changes are read back and restored; the article is deleted.</div>
  {r&&<section style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))',gap:12,margin:'18px 0'}}>
   <Card label="Verdict" value={r.summary.verdict} color={r.summary.verdict==='READY'?'#067647':'#b42318'}/><Card label="Score" value={`${r.summary.score}/100`}/><Card label="Pass" value={`${r.summary.pass}/${r.summary.total}`} color="#067647"/><Card label="Critical failures" value={String(r.summary.criticalFailed)} color={r.summary.criticalFailed?'#b42318':'#067647'}/><Card label="Canary host gate" value={d.canaryEnabled&&d.liveWrites?'READY':'LOCKED'} color={d.canaryEnabled&&d.liveWrites?'#067647':'#b54708'}/>
  </section>}
  {r&&<><div style={{overflowX:'auto'}}><table style={table}><thead><tr><th style={th}>Category</th><th style={th}>Check</th><th style={th}>Critical</th><th style={th}>State</th><th style={th}>Evidence</th><th style={th}>Repair</th></tr></thead><tbody>{r.checks.map((x:any)=><tr key={x.key}><td style={td}>{x.category}</td><td style={td}><b>{x.label}</b></td><td style={td}>{x.critical?'YES':'no'}</td><td style={{...td,fontWeight:800,color:tone(x.state)}}>{x.state}</td><td style={td}>{x.evidence}{typeof x.durationMs==='number'?<div style={{fontSize:11,color:'#667085'}}>{x.durationMs} ms</div>:null}</td><td style={td}>{x.repair||'—'}</td></tr>)}</tbody></table></div><h2>Repair packet</h2><button onClick={copy} style={button(true)}>{copied?'Copied':'Copy Repair Packet'}</button><pre style={pre}>{r.repairPacket}</pre></>}
  <h2>Reversible Shopify canary</h2><p style={{color:'#667085'}}>Run this only during a deliberate certification window. It proves the exact product SEO/content writer, collection SEO/content writer, content-creation scope, readback and rollback behavior against Shopify—not mocks.</p>
  <Form method="post" style={{display:'flex',gap:8,flexWrap:'wrap',alignItems:'center'}}><input type="hidden" name="intent" value="canary"/><input name="confirm" placeholder="Type RUN SAFE CANARY" style={{padding:'10px 12px',minWidth:260,border:'1px solid #98a2b3',borderRadius:8}}/><button style={button(false)}>Run Full Certification + Canary</button></Form>
  <p style={{fontSize:12,color:'#667085'}}>Current release {r?.release||'not yet certified'}. Canary env: {d.canaryEnabled?'enabled':'disabled'} · live-write env: {d.liveWrites?'unlocked':'locked'}.</p>
 </main>;
}

const button=(primary:boolean)=>({border:'1px solid '+(primary?'#101828':'#98a2b3'),background:primary?'#101828':'white',color:primary?'white':'#101828',padding:'10px 13px',borderRadius:8,fontWeight:700,cursor:'pointer'} as const);
const notice={background:'#fffaeb',border:'1px solid #fedf89',padding:12,borderRadius:10,margin:'14px 0'} as const;
const table={width:'100%',borderCollapse:'collapse',background:'white',border:'1px solid #eaecf0'} as const;
const th={textAlign:'left',padding:10,background:'#f9fafb',borderBottom:'1px solid #eaecf0',fontSize:12} as const;
const td={padding:10,borderBottom:'1px solid #eaecf0',verticalAlign:'top',fontSize:13} as const;
const pre={whiteSpace:'pre-wrap',background:'#101828',color:'#f2f4f7',padding:16,borderRadius:10,maxHeight:520,overflow:'auto'} as const;
function Card({label,value,color}:{label:string,value:string,color?:string}){return <div style={{border:'1px solid #eaecf0',borderRadius:12,padding:15,background:'white'}}><div style={{fontSize:12,color:'#667085'}}>{label}</div><div style={{fontSize:24,fontWeight:800,color:color||'#101828'}}>{value}</div></div>}
