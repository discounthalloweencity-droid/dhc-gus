import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSupplierFulfillmentDashboard} from '../services/supplier-fulfillment-dashboard.server';
import {SupplierFulfillmentSurface} from '../components/supplier-fulfillment-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSupplierFulfillmentDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SupplierFulfillmentSurface title='Supplier Command' subtitle='Central supplier and fulfillment control for exact variant mapping, availability, delivery evidence and exceptions.' data={data} focus={['Use supplier-variant evidence as the source of truth for dropship availability; Shopify zero inventory alone never proves stockout.','Require exact mapping, fresh evidence and verified fulfillment ownership before automated availability actions.','Surface slow delivery, stale evidence, mapping gaps and supplier conflicts before they affect customers.','Keep destructive archive decisions behind the existing availability safety controls.']}/>;}
