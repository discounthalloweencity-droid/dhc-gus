import type {ActionFunctionArgs,LoaderFunctionArgs} from "react-router";
import {Form,Link,useActionData,useLoaderData} from "react-router";
import {authenticate} from "../shopify.server";
import {Page,Card,Badge} from "../components/ui";
import {gusBridgeSecret} from "../services/gus-chat.server";
import {safeAppAction} from '../services/safe-app-action.server';

export async function loader({request}:LoaderFunctionArgs){await authenticate.admin(request);const origin=new URL(request.url).origin;return {origin,ready:gusBridgeSecret().length>=32};}
export async function action({request}:ActionFunctionArgs){return safeAppAction('bridge',request,async()=>{await authenticate.admin(request);const f=await request.formData();if(f.get("intent")!=="reveal")return {error:"Invalid action."};const token=gusBridgeSecret();return token?{token}:{error:"No bridge secret is configured."};});}
export default function Bridge(){const d=useLoaderData<typeof loader>();const a=useActionData<typeof action>();return <Page title="ChatGPT ↔ Gus Bridge" subtitle="Connect an authorized external ChatGPT connector to the same Gus store-side brain."><div className="authority-toolbar"><Link className="authority-button authority-primary" to="/app/gus">← Talk to Gus</Link><a className="authority-button" href="/api/gus/openapi.json" target="_blank" rel="noreferrer">OpenAPI schema</a></div><Card><h2>Bridge status <Badge tone={d.ready?"good":"warn"}>{d.ready?"READY":"NEEDS SECRET"}</Badge></h2><p><strong>Endpoint:</strong> <code>{d.origin}/api/gus/bridge</code></p><p>The bridge uses Bearer authentication and cannot bypass Gus STOP, Shopify authentication, write gates, margin rules or approvals.</p><Form method="post"><button name="intent" value="reveal">Reveal connector token</button></Form>{a&&"token" in a?<div className="gus-secret"><strong>Connector token</strong><code>{a.token}</code><p>Copy only into a trusted connector configuration.</p></div>:a&&"error" in a?<div className="gus-flash gus-flash-bad">{a.error}</div>:null}</Card></Page>}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
