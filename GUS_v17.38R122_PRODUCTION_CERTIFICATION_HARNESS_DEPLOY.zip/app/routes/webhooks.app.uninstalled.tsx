import type { ActionFunctionArgs } from "react-router";
import { authenticate } from "../shopify.server";
import { db } from "../db.server";
export async function action({request}:ActionFunctionArgs){
  const {shop,session,topic}=await authenticate.webhook(request);
  console.log(`Received ${topic} webhook for ${shop}`);
  if(session){try{await db.session.deleteMany({where:{shop}});}catch(error){console.error("[gus-webhook] app/uninstalled session cleanup failed",error instanceof Error?(error.stack||error.message):error);}}
  return new Response();
}
