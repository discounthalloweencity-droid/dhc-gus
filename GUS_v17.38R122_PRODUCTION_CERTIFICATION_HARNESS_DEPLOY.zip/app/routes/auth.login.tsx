import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { login } from "../shopify.server";

// Shopify reserves /auth/login as the merchant login entry point.
// The React Router package requires shopify.login(request) here;
// Admin authentication belongs on the callback/splat auth route.
export async function loader({ request }: LoaderFunctionArgs) {
  return await login(request);
}

export async function action({ request }: ActionFunctionArgs) {
  return await login(request);
}

export default function AuthLogin() {
  return null;
}
