import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeoDiscoveryDashboard} from '../services/seo-discovery-dashboard.server';
import {SeoDiscoverySurface} from '../components/seo-discovery-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSeoDiscoveryDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SeoDiscoverySurface title='Keywords & Rankings' subtitle='Keyword portfolio, ranking movement, search intent, opportunity scoring and cannibalization control.' data={data} focus={['Track branded, category, character/theme, costume-type, decoration and evergreen spooky demand separately.', 'Prioritize queries where ranking gain can produce qualified revenue, not vanity traffic.', 'Detect multiple DHC pages competing for the same intent before creating more content.', 'Rankings require Search Console or verified external SERP evidence; absent evidence stays unavailable.']}/>;}
