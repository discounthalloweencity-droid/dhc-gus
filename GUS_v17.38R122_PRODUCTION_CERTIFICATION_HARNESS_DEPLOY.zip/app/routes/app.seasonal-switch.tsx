import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {Form,useActionData,useLoaderData,useNavigation} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSeasonalSwitch,runSeasonalSwitchMaintenance,setSeasonalSwitch} from '../services/seasonal-switch.server';
import {Badge,Card,Grid,Metric,Page,Table} from '../components/ui';

import {safeAppAction} from '../services/safe-app-action.server';

export async function loader({request}:LoaderFunctionArgs){const {admin,session}=await authenticate.admin(request);return loadSeasonalSwitch(admin,session.shop);}
export async function action({request}:ActionFunctionArgs){return safeAppAction('seasonal-switch',request,async()=>{const {admin,session}=await authenticate.admin(request);const f=await request.formData();try{const intent=String(f.get('intent')||'save');if(intent==='run'){const result=await runSeasonalSwitchMaintenance(admin,session.shop,{apply:true,limit:40});return {ok:true,message:result.status==='WAITING'?'Shopify asked Gus to slow down. Seasonal Switch is waiting safely and will retry automatically.':`Seasonal Switch ${result.mode||''} maintenance completed. ${Number((result as any).changed||0)} product status change(s) applied.`,result};}const saved=await setSeasonalSwitch(session.shop,{mode:String(f.get('mode')||'AUTO'),cutoffMonth:Number(f.get('cutoffMonth')||10),cutoffDay:Number(f.get('cutoffDay')||12),restoreMonth:Number(f.get('restoreMonth')||11),restoreDay:Number(f.get('restoreDay')||1)});return {ok:true,message:`Seasonal Switch saved as ${saved.seasonalSwitchMode}. Gus will enforce the cutoff automatically while automation is running; anything archived by Seasonal Switch is ledgered for post-Halloween restoration.`};}catch(e:any){return {ok:false,error:String(e?.message||e)};}});}

export default function SeasonalSwitch(){
 const d=useLoaderData<typeof loader>(),a=useActionData<typeof action>(),nav=useNavigation(),c=d.config,busy=nav.state!=='idle';
 return <Page title="Seasonal Switch" subtitle="Automatic Halloween delivery-risk control with a merchant override. Policy changes do not blindly archive catalog products.">
  {a&&<Card><p role="status">{a.ok?a.message:a.error}</p></Card>}
  <Grid>
   <Metric label="Configured mode" value={c.seasonalSwitchMode}/>
   <Metric label="Effective mode" value={d.effectiveMode}/>
   <Metric label="Verified US products" value={d.evidence.verifiedUsProducts}/>
   <Metric label="Seasonal archives pending restore" value={d.managed.archived}/>
   <Metric label="Seasonal archives restored" value={d.managed.restored}/>
   <Metric label="Verified US variants" value={d.evidence.verifiedUsVariants}/>
   <Metric label="US variants selling (30d)" value={d.evidence.salesAvailable?d.evidence.sellingUsVariants:'Not available'} detail={d.evidence.salesAvailable?`${d.evidence.units} units · $${d.evidence.revenue.toFixed(2)} revenue`:'Sales evidence unavailable'}/>
  </Grid>
  <div style={{height:16}}/>
  <Card><h2>Control</h2><Form method="post" style={{display:'grid',gap:12,maxWidth:760}}>
   <label>Mode <select name="mode" defaultValue={c.seasonalSwitchMode}><option value="AUTO">AUTO — use cutoff dates</option><option value="FULL_CATALOG">FULL CATALOG — manual override</option><option value="USA_ONLY">USA ONLY — manual override</option></select></label>
   <div style={{display:'grid',gridTemplateColumns:'repeat(4,minmax(120px,1fr))',gap:10}}>
    <label>Cutoff month<input name="cutoffMonth" type="number" min="1" max="12" defaultValue={c.seasonalCutoffMonth}/></label>
    <label>Cutoff day<input name="cutoffDay" type="number" min="1" max="31" defaultValue={c.seasonalCutoffDay}/></label>
    <label>Restore month<input name="restoreMonth" type="number" min="1" max="12" defaultValue={c.seasonalRestoreMonth}/></label>
    <label>Restore day<input name="restoreDay" type="number" min="1" max="31" defaultValue={c.seasonalRestoreDay}/></label>
   </div>
   <div style={{display:'flex',gap:10,flexWrap:'wrap'}}><button name="intent" value="save" disabled={busy}>{busy?'Saving…':'Save Seasonal Switch'}</button><button name="intent" value="run" disabled={busy}>{busy?'Working…':'Run Seasonal Switch now'}</button></div>
  </Form></Card>
  <div style={{height:16}}/>
  <Card><h2>Guardrails</h2><Table headers={['Rule','Status']} rows={[
   ['Default AUTO cutoff','October 12 → November 1 in the Shopify store time zone'],
   ['Unknown warehouse/origin','Not treated as USA'],
   ['Archive eligibility','Only complete verified non-US variant coverage; ambiguous origin is blocked'],
   ['Automatic restoration','Every Seasonal Switch archive is ledgered and restored when FULL CATALOG resumes'],
   ['Manual override',<Badge tone="good">Available</Badge>],
   ['Merchandising order in USA_ONLY','Trend / demand → DHC top sellers → remaining verified eligible inventory']
  ]}/><p><strong>Store time zone:</strong> {d.timeZone}. {d.timeZoneError?'Time-zone verification is temporarily unavailable; automatic writes fail closed until Shopify evidence returns.':''}</p><p>{d.note}</p></Card>
 </Page>;
}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
