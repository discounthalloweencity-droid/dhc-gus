// Previous cumulative hotfix: 0.16.57-r29-gus-builder-modes
import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {resolveGusStorefrontContext,requireGusAdmin,gusCorsHeaders} from '../services/gus-storefront-auth.server';
import {handleGusCart,handleGusEvent,handleGusImage,handleGusMessage,handleGusOrder,handleGusRecommend,handleGusRestore,handleGusSession} from '../services/gus-concierge-api.server';
async function gusInput(request:Request){const ct=String(request.headers.get('content-type')||'').toLowerCase();if(ct.includes('multipart/form-data')){const fd=await request.formData(),out:any={};for(const [k,v] of fd.entries())out[k]=v;return out;}return request.json().catch(()=>({}));}
function endpoint(request:Request){const p=new URL(request.url).pathname;const i=p.indexOf('/gus/');return i>=0?p.slice(i+5).replace(/^\/+|\/+$/g,''):'';}
function errorStatus(e:any){if(e instanceof Response&&Number(e.status)>=400)return Number(e.status);const m=String(e?.message||'').toLowerCase();if(m.includes('unauthorized')||m.includes('authentication failed'))return 401;if(m.includes('admin session')||m.includes('unavailable'))return 503;return 400;}
function gusJsonError(e:any){const status=errorStatus(e);const message=e instanceof Response?(status===401||status===403?'Gus storefront authentication failed.':'Gus proxy request failed.'):String(e?.message||'Gus proxy unavailable');return Response.json({ok:false,error:message,code:status===401?'GUS_PROXY_AUTH_FAILED':status===503?'GUS_ADMIN_SESSION_UNAVAILABLE':'GUS_PROXY_REQUEST_FAILED',fallback:{type:'SHOPIFY_SEARCH_OR_SUPPORT',search_url:'/search',support_url:'/apps/gus-support'}},{status,headers:gusCorsHeaders()});}
export async function loader({request}:LoaderFunctionArgs){try{const {shop}=await resolveGusStorefrontContext(request);const ep=endpoint(request);if(ep.startsWith('session/'))return Response.json(await handleGusRestore(shop,decodeURIComponent(ep.slice(8))),{headers:gusCorsHeaders()});return Response.json({ok:true,service:'Gus Shopping Concierge',runtime:'0.16.57',hotfix:'0.16.57-r34-storefront-chat-failsafe-recovery',previousCumulativeHotfix:'0.16.57-r33-executive-retail-operating-dashboard',previousHotfix:'0.16.57-r25-support-email-communication-governance',visualSystem:'DHC-NOSTALGIA-VISUAL-SYSTEM-v1.0',seoTerritories:'DHC-SEO-TERRITORIES-v1.0',proxyTargets:['/support-center','/storefront/gus-support'],contract:'DHC-GUS-V1055.1-PROXY-CONTRACT-1.0',endpoints:['session','message','recommend','image','cart','order','event']},{headers:gusCorsHeaders()});}catch(e:any){return gusJsonError(e);}}
export async function action({request}:ActionFunctionArgs){try{const ep=endpoint(request),ctx=await resolveGusStorefrontContext(request),input=await gusInput(request);let result:any;if(ep==='session')result=await handleGusSession(ctx.shop,input);else if(ep==='event')result=await handleGusEvent(ctx.shop,input);else {const admin=requireGusAdmin(ctx.admin);if(ep==='message')result=await handleGusMessage(admin,ctx.shop,input);else if(ep==='recommend')result=await handleGusRecommend(admin,ctx.shop,input);else if(ep==='image')result=await handleGusImage(admin,ctx.shop,input);else if(ep==='cart')result=await handleGusCart(admin,ctx.shop,input);else if(ep==='order')result=await handleGusOrder(admin,ctx.shop,input);else return Response.json({ok:false,error:'Unknown Gus endpoint',code:'GUS_ENDPOINT_NOT_FOUND'},{status:404,headers:gusCorsHeaders()});}return Response.json(result,{headers:gusCorsHeaders()});}catch(e:any){return gusJsonError(e);}}

// R16 dual-proxy compatibility: the same backend brain is additionally available through
// /support-center?gus_endpoint=* via gus-app-proxy-dispatch.server.ts. This canonical wildcard
// handler remains intact for v1055.1 and older regression contracts.
// Compatibility previous cumulative hotfix: 0.16.50-r5-app-proxy-json-auth-recovery
// Previous cumulative hotfix: 0.16.57-r16-dual-proxy-transport-recovery
// Previous cumulative hotfix: 0.16.57-r17-checkout-shipping-diagnostic
// Previous cumulative hotfix: 0.16.57-r19-dhc-brand-merch-operating-system
// Previous cumulative hotfix: 0.16.57-r20-storefront-direct-chat-recovery
// Previous cumulative hotfix: 0.16.57-r21-dhc-brand-rules-engine
// Previous cumulative hotfix: 0.16.57-r22-dhc-merchandising-profiles
// Previous cumulative hotfix: 0.16.57-r23-dhc-signature-collections
// Previous cumulative hotfix: 0.16.57-r24-dynamic-merchandising-score
// Previous cumulative hotfix: 0.16.57-r25-support-email-communication-governance
// Previous cumulative hotfix: 0.16.57-r27-complete-look-graph
// Previous cumulative hotfix: 0.16.57-r28-gus-live-product-intelligence
// Previous cumulative hotfix: 0.16.57-r30-dhc-nostalgia-visual-system
// Previous cumulative hotfix: 0.16.57-r31-dhc-seo-territories
// Previous cumulative hotfix: 0.16.57-r33-executive-retail-operating-dashboard
// Current cumulative hotfix: 0.16.57-r34-storefront-chat-failsafe-recovery

// R26 compatibility lineage: 0.16.57-r26-pdp-exposure-hardening
