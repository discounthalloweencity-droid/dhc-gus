import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { Form, Link, useActionData, useLoaderData } from "react-router";
import { authenticate } from "../shopify.server";
import { db } from "../db.server";
import { automationState } from "../services/automation-control.server";
import { safePageData } from "../services/page-data-safety.server";
import { Badge, Card, Grid, Metric, Page, Table } from "../components/ui";
import {proposalApprovalSummary} from "../services/proposal-autonomy.server";
import {classifyFindingAutonomy} from "../services/finding-autonomy-rules";
import {requestStopRetailMission} from "../services/retail-mission.server";

const OPEN_MISSION_STATES=['DISCOVERED','SCORED','QUEUED','WAITING','RUNNING','VERIFYING','COOLDOWN','MEASURING'];

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop=session.shop;
  const [automation, findings, approvalSummary, jobs, batches, missions] = await Promise.all([
    safePageData("queue","automation",automationState(shop),null as any),
    safePageData("queue","findings",db.finding.findMany({where:{shop,status:"OPEN"},orderBy:{createdAt:"asc"},take:250}),[] as any[]),
    safePageData("queue","approvals",proposalApprovalSummary(shop),{ownerReview:0,autoSafe:0,staleSafe:0,totalPending:0} as any),
    safePageData("queue","jobs",db.jobRun.findMany({where:{shop},orderBy:{startedAt:"desc"},take:50}),[] as any[]),
    safePageData("queue","batches",db.bulkBatch.findMany({where:{shop},orderBy:{createdAt:"desc"},take:50}),[] as any[]),
    safePageData("queue","missions",db.retailMission.findMany({where:{shop,state:{in:OPEN_MISSION_STATES}},orderBy:[{priority:"desc"},{updatedAt:"desc"}],take:100}),[] as any[]),
  ]);
  return {automation,findings,approvalSummary,jobs,batches,missions};
}

export async function action({request}:ActionFunctionArgs){
  const {session}=await authenticate.admin(request);
  const fd=await request.formData();
  const intent=String(fd.get('intent')||'');
  if(intent!=='stop-mission')return {ok:false,error:'Unsupported queue action.'};
  const id=Number(fd.get('missionId'));
  if(!Number.isSafeInteger(id))return {ok:false,error:'Invalid mission id.'};
  const mission=await db.retailMission.findFirst({where:{id,shop:session.shop}});
  if(!mission)return {ok:false,error:'Mission not found for this store.'};
  const updated=await requestStopRetailMission(id,'Operator stop requested from Tasks & Queue');
  return {ok:true,message:updated.state==='CANCELLED'?`Mission ${id} cancelled.`:`Stop requested for running mission ${id}; the worker will stop at its next checkpoint.`};
}

const priority=(severity:string)=>severity==="HIGH"?0:severity==="MEDIUM"?1:2;
export default function TaskQueue(){
  const d=useLoaderData<typeof loader>();
  const a=useActionData<typeof action>();
  const ordered=[...d.findings].sort((a,b)=>priority(a.severity)-priority(b.severity)||+new Date(a.createdAt)-+new Date(b.createdAt));
  const running=Boolean(d.automation?.running);
  return <Page title="Tasks & Queue" subtitle="What Gus is working on, what is waiting, and what comes next.">
    {a?<Card><p role="status"><strong>{a.ok?a.message:a.error}</strong></p></Card>:null}
    <Grid>
      <Metric label="Gus" value={running?"RUNNING":"STOPPED"} detail={running?"Autonomous queue processing enabled":"Queue is visible; autonomous processing is paused"}/>
      <Metric label="Open tasks" value={d.findings.length} detail="Catalog and operational findings"/>
      <Metric label="Active missions" value={d.missions.length} detail="Autonomous missions not yet terminal"/>
      <Metric label="Waiting approval" value={d.approvalSummary.ownerReview} detail="Only high-impact owner exceptions"/>
    </Grid>
    <div style={{height:18}}/>
    <Card><div style={{display:"flex",justifyContent:"space-between",gap:12,alignItems:"center"}}><div><h2 style={{marginBottom:4}}>Priority work queue</h2><p style={{margin:0}}>Highest-risk and oldest work is surfaced first.</p></div><Link to="/app/findings">Open all findings →</Link></div></Card>
    <div style={{height:12}}/>
    <Table headers={["Priority","Area","Task","Proposed action","Waiting since"]} rows={ordered.map(r=>[
      <Badge tone={r.severity==="HIGH"?"bad":r.severity==="MEDIUM"?"warn":"neutral"}>{r.severity}</Badge>,
      r.category,<><strong>{r.code}</strong><br/><span style={{color:"#667085"}}>{r.message}</span></>,(()=>{const a=classifyFindingAutonomy(r);return a.lane==='OWNER_REVIEW'?'Owner exception':a.lane==='EVIDENCE_WAIT'?'Gus gathering evidence':a.lane==='AUTO_FIX'?'Gus auto-fixing':'Gus verifying';})(),new Date(r.createdAt).toLocaleString()
    ])}/>
    <div style={{height:18}}/>
    <Card><h2>Autonomous missions</h2><p>Stop is immediate for queued/waiting work. A running worker receives a durable stop request and exits at its next governed checkpoint.</p><Table headers={["Mission","Engine","State","Priority","Updated","Control"]} rows={d.missions.map((m:any)=>[
      <><strong>#{m.id}</strong><br/><span style={{color:'#667085'}}>{m.goal}</span></>,m.engine,<Badge tone={m.state==='RUNNING'?'warn':'neutral'}>{m.stopRequestedAt?'STOP REQUESTED':m.state}</Badge>,m.priority,new Date(m.updatedAt).toLocaleString(),<Form method="post"><input type="hidden" name="intent" value="stop-mission"/><input type="hidden" name="missionId" value={m.id}/><button type="submit" disabled={Boolean(m.stopRequestedAt)}> {m.state==='RUNNING'?'Stop':'Cancel'} </button></Form>
    ])}/></Card>
    <div style={{height:18}}/>
    <Card><h2>Recent execution</h2><Table headers={["Job","Status","Scanned","Changed","Warnings","Started"]} rows={d.jobs.map(j=>[
      j.jobType,<Badge tone={j.status==="COMPLETED"||j.status==="SUCCESS"?"good":j.status==="FAILED"?"bad":"warn"}>{j.status}</Badge>,j.scanned,j.changed,j.warnings,new Date(j.startedAt).toLocaleString()
    ])}/></Card>
  </Page>;
}
