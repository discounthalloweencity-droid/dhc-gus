import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSupplierFulfillmentDashboard} from '../services/supplier-fulfillment-dashboard.server';
import {SupplierFulfillmentSurface} from '../components/supplier-fulfillment-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSupplierFulfillmentDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SupplierFulfillmentSurface title='Supplier Stock' subtitle='Current supplier-side stock evidence across mapped variants.' data={data} focus={['Prioritize fresh supplier observations over Shopify inventory for dropship stock truth.','Separate IN_STOCK, OUT_OF_STOCK and UNKNOWN; unknown must never be converted to out of stock.','Check all mapped fulfillment sources before a product-level archive decision.','Keep quantity and evidence freshness visible for high-volume products.']}/>;}
