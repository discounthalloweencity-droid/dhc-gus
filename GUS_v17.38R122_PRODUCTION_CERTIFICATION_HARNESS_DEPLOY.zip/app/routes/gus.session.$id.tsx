import type {LoaderFunctionArgs} from 'react-router';
import {resolveGusStorefrontContext,gusCorsHeaders} from '../services/gus-storefront-auth.server';
import {handleGusRestore} from '../services/gus-concierge-api.server';
export async function loader({request,params}:LoaderFunctionArgs){try{const {shop}=await resolveGusStorefrontContext(request);return Response.json(await handleGusRestore(shop,String(params.id||'')),{headers:gusCorsHeaders()});}catch(e:any){if(e instanceof Response)return e;return Response.json({ok:false,error:e?.message||'Session unavailable',fallback:{type:'START_NEW_SESSION',endpoint:'/gus/session'}},{status:404,headers:gusCorsHeaders()});}}
