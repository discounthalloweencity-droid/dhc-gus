import type {ActionFunctionArgs} from 'react-router';
import {verifyStorefrontRequest} from '../services/storefront-signing';
import {recordConversionEvent} from '../services/conversion-funnel.server';

export async function action({request}:ActionFunctionArgs){
  const secret=process.env.GUS_STOREFRONT_SHARED_SECRET;if(!secret)return new Response('Conversion bridge unavailable',{status:503});const body=await request.text();
  if(!verifyStorefrontRequest(request.headers.get('x-dhc-timestamp'),request.headers.get('x-dhc-signature'),body,secret))return new Response('Unauthorized',{status:401});
  const shop=process.env.AUTHORITY_SHOP;if(!shop)return new Response('Store unavailable',{status:503});let input:any;try{input=JSON.parse(body)}catch{return new Response('Malformed JSON body',{status:400})}
  try{const row=await recordConversionEvent(shop,input);return Response.json({ok:true,id:row.id,eventType:row.eventType},{headers:{'cache-control':'no-store','access-control-allow-origin':process.env.STOREFRONT_ORIGIN||'https://www.discounthalloweencity.com'}})}catch(error){return Response.json({ok:false,error:error instanceof Error?error.message:String(error)},{status:400,headers:{'cache-control':'no-store'}})}
}
