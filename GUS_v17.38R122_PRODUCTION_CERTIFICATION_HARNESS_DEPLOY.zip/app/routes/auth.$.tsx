import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { redirect } from "react-router";
import shopify from "../shopify.server";
import { clearPreviewReturnCookie, previewReturnPath } from "../lib/preview-auth.server";

async function handleShopifyAuth(request:Request){
  // Shopify auth callbacks and App Bridge session handoffs can arrive as GET or POST.
  // Always pass them through Shopify's native admin authenticator; never trust request
  // headers or client-provided shop identity as a substitute for signature/token checks.
  await shopify.authenticate.admin(request);
  const returnTo = previewReturnPath(request);
  if (returnTo) return redirect(returnTo,{headers:{"Set-Cookie":clearPreviewReturnCookie()}});
  return null;
}
export async function loader({request}:LoaderFunctionArgs){return handleShopifyAuth(request);}
export async function action({request}:ActionFunctionArgs){return handleShopifyAuth(request);}
export default function Auth(){return null;}
