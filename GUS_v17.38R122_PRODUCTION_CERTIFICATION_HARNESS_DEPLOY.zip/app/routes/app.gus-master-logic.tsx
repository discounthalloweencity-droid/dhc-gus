import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {DHC_COMMAND_CENTER_MASTER,DHC_COMMAND_CENTER_MASTER_VERSION} from '../knowledge/dhc-command-center-master-v4';
import {GUS_OPERATOR_DOCTRINE_VERSION} from '../knowledge/gus-operator-doctrine-v1';
import {Badge,Card,Grid,Metric,Page,Table} from '../components/ui';

export async function loader({request}:LoaderFunctionArgs){await authenticate.admin(request);const topics=[...new Set(DHC_COMMAND_CENTER_MASTER.map(r=>r.topic))];return {version:DHC_COMMAND_CENTER_MASTER_VERSION,doctrine:GUS_OPERATOR_DOCTRINE_VERSION,topics,rules:DHC_COMMAND_CENTER_MASTER};}
export default function GusMasterLogic(){const d=useLoaderData<typeof loader>();return <Page title="Gus Master Logic" subtitle="Authoritative operating rules used across pricing, profit, Shop merchandising, catalog, SEO, search, seasonal control, forecasting and QA.">
 <Grid><Metric label="Authority pack" value={d.version}/><Metric label="Operator doctrine" value={d.doctrine}/><Metric label="Rules" value={d.rules.length}/><Metric label="Domains" value={d.topics.length}/></Grid>
 <div style={{height:16}}/><Card><h2>Authority order</h2><p>Understand product → evidence → economics → shopper/search intent → smallest justified change → QA/read-back → audit/rollback. Newer master rules override older training when they conflict.</p></Card>
 <div style={{height:16}}/><Table headers={['Domain','Rule','Risk','Confidence']} rows={d.rules.map(r=>[r.topic,r.statement,<Badge tone={r.riskLevel==='HIGH'?'warn':'neutral'}>{r.riskLevel}</Badge>,`${Math.round(r.confidence*100)}%`])}/>
 </Page>;}
