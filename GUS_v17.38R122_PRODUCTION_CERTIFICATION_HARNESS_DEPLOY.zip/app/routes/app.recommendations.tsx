import type {ActionFunctionArgs} from 'react-router';
import {Form,useActionData} from 'react-router';
import {authenticate} from '../shopify.server';
import {previewRecommendations} from '../services/recommendations.server';
import {Page,Card,Table} from '../components/ui';
import {safeAppAction} from '../services/safe-app-action.server';

export async function action({request}:ActionFunctionArgs){return safeAppAction('recommendations',request,async()=>{
 const {admin,session}=await authenticate.admin(request);
 const f=await request.formData();
 if(f.get('consent')!=='on')return {error:'Explicit consent is required for this preview.'};
 const interests=String(f.get('interests')||'').split(',').map(s=>s.trim()).filter(Boolean);
 const price=String(f.get('maxPrice')||'').trim();
 const anchorProductId=String(f.get('anchorProductId')||'').trim()||null;
 const refinement=String(f.get('refinement')||'').trim()||null;
 if(price&&!/^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/.test(price))return {error:'Invalid maximum price.'};
 try{return await previewRecommendations(admin,session.shop,{consent:true,interests,anchorProductId,maxPrice:price?Number(price):null,limit:5,refinement:refinement as any,seasonalDeadline:f.get('seasonal')==='on'?'2026-10-30T23:59:59-06:00':null,now:new Date().toISOString()});}catch(e:any){return {error:String(e?.message||e)};}
});}
export default function Recommendations(){const data=useActionData<typeof action>();return <Page title="Amplify the Scare" subtitle="Private recommendation preview for accurate finishing pieces, family coordination and relevant add-on sales. No shopper tracking or storefront publishing from this screen."><Card><h2>Preview a Halloween look</h2><p>Start from the main costume or general theme. Gus favors 3–5 curated, complementary products instead of a long random list.</p><Form method="post"><label>Interests <input name="interests" maxLength={250} required placeholder="glamorous vampire, black red"/></label>{' '}<label>Anchor product GID (optional) <input name="anchorProductId" placeholder="gid://shopify/Product/..."/></label>{' '}<label>Maximum price ($) <input name="maxPrice" type="number" min="0" step="0.01"/></label><p><label>Refine <select name="refinement"><option value="">Standard</option><option value="MORE_SCARY">More scary</option><option value="KID_FRIENDLY">Kid-friendly only</option><option value="BUDGET">Budget</option><option value="FULL_FAMILY">Full family</option></select></label></p><p><label><input type="checkbox" name="seasonal"/> Require delivery by October 30</label></p><p><label><input type="checkbox" name="consent" required/> I consent to using these non-personal interests for this one-time preview.</label></p><button type="submit">Build Amplify the Scare set</button></Form></Card>{data&&('error'in data?<Card><p role="alert">{data.error}</p></Card>:<><Card><h2>{data.sectionTitle}</h2><p>{data.results.length} curated recommendations from {data.productsScanned} products and {data.variantsScanned} variants. {data.note}</p><p><b>{data.close}</b></p></Card><Table headers={['Product','Price','Why it fits','Sales-associate suggestion','Product page']} rows={data.results.map(r=>[r.title+' — '+r.variantTitle,`$${r.price.toFixed(2)}`,r.reasons.join('; '),r.salesPitch||'Relevant finishing piece',<a href={r.url} target="_blank" rel="noopener noreferrer">View product</a>])}/></>)}</Page>}


export function shouldRevalidate({formMethod,actionResult,defaultShouldRevalidate}:any){
  if(formMethod&&String(formMethod).toUpperCase()!=='GET'&&actionResult?.actionFailure) return false;
  return defaultShouldRevalidate;
}
