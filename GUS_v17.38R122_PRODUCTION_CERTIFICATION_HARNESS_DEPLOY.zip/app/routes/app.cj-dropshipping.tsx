import type {LoaderFunctionArgs} from 'react-router';
import {useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {loadSupplierFulfillmentDashboard} from '../services/supplier-fulfillment-dashboard.server';
import {SupplierFulfillmentSurface} from '../components/supplier-fulfillment-surface';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadSupplierFulfillmentDashboard(session.shop);}
export default function Route(){const data=useLoaderData<typeof loader>();return <SupplierFulfillmentSurface title='CJ Dropshipping' subtitle='CJ supplier mapping, stock, warehouse and shipping evidence for customer-safe fulfillment.' data={data} focus={['Prefer verified CJ variant and warehouse evidence and preserve the original customer selection.','Compare US and overseas warehouse fulfillment without inventing delivery dates.','Flag supplier substitutions that materially differ from the ordered product.','Use current CJ evidence before changing product availability.']} supplier='CJ'/>;}
