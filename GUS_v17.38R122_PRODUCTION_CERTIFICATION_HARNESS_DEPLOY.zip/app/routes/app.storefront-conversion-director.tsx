import type {ActionFunctionArgs,LoaderFunctionArgs} from 'react-router';
import {Form,useActionData,useLoaderData} from 'react-router';
import {authenticate} from '../shopify.server';
import {safeAppAction} from '../services/safe-app-action.server';
import {loadStorefrontConversionDirector,runStorefrontConversionDirector} from '../services/storefront-conversion-director.server';
import {Badge,Card,Grid,Metric,Page,Table} from '../components/ui';

const pct=(v:any)=>v==null?'—':`${(Number(v)*100).toFixed(1)}%`;
const tone=(v:string)=>v==='DONE'||v==='PASS'||v==='EXCELLENT'||v==='GOOD'?'good':v==='FAILED'||v==='ERROR'||v==='CRITICAL'?'bad':v==='WARN'||v==='NEEDS_WORK'?'warn':'neutral';
export async function loader({request}:LoaderFunctionArgs){const {session}=await authenticate.admin(request);return loadStorefrontConversionDirector(session.shop);}
export async function action({request}:ActionFunctionArgs){return safeAppAction('storefront-conversion-director',request,async()=>{const {admin,session}=await authenticate.admin(request);const result=await runStorefrontConversionDirector(admin,session.shop,true);return {ok:true,message:`Storefront Conversion Director ${result.status}.`,result};});}

export default function Screen(){const d=useLoaderData<typeof loader>();const a=useActionData<typeof action>() as any;const x:any=d.details||{};const search=x.search||{},funnel=x.funnel||{},cart=x.cartGap||{};return <Page title="Storefront Conversion Director" subtitle="Gus watches the live shopper journey from landing page and search through PDP, cart and conversion outcomes. Runtime v0.16.50.">
 {a?.message&&<Card><strong>{a.message}</strong></Card>}
 <div style={{display:'flex',gap:10,alignItems:'center',marginBottom:16,flexWrap:'wrap'}}><Form method="post"><button className="authority-button authority-primary" type="submit">Run live storefront pass now</button></Form><Badge tone={tone(d.job?.status||'IDLE')}>{d.job?.status||'NO RUN'}</Badge><span style={{fontSize:12,color:'#666'}}>Auto cadence: about {d.cadenceHours} hours · visual QA is structural unless browser-render evidence is configured.</span></div>
 <Grid>
  <Metric label="Storefront score" value={x.overallScore??'—'} detail="Live page + search + observed funnel evidence"/>
  <Metric label="Public pages checked" value={x.pagesChecked??0} detail={`${x.criticalPages??0} critical · ${x.highPages??0} high`}/>
  <Metric label="Search QA" value={search.score??'—'} detail={`${search.grade||'No evidence'} · ${search.zeroResults??0} zero-result tests`}/>
  <Metric label="Conversion events · 7d" value={d.events7d} detail={`Coverage: ${funnel.coverage||'UNAVAILABLE'}`}/>
  <Metric label="View → cart" value={pct(funnel.rates?.viewToCart)} detail="Observed events/GA4 when available"/>
  <Metric label="Cart → purchase" value={pct(funnel.rates?.cartToPurchase)} detail="Never substitutes missing evidence with zero"/>
  <Metric label="Below-$59 carts observed" value={cart.observedBelowThresholdCarts??0} detail={cart.averageGap==null?'No cart-subtotal evidence':`Average gap $${Number(cart.averageGap).toFixed(2)}`}/>
  <Metric label="$59 value paths" value={cart.activeValuePaths??0} detail="Relevant positive-contribution basket paths"/>
 </Grid>
 <div style={{height:16}}/>
 <Card><h2 style={{marginTop:0}}>Operating doctrine</h2><p style={{marginBottom:0}}>Gus treats the storefront as one connected journey: landing page → navigation/search → collection → PDP → Complete the Look → cart → $59 free-shipping threshold → checkout → order → contribution profit → learning. An Admin API write is not considered customer-facing proof until the public storefront is re-read. HTML checks do not claim pixel-level visual correctness.</p></Card>
 <div style={{height:16}}/>
 <h2>Live storefront issues</h2>
 <Table headers={['Severity','Surface','Issue','Evidence']} rows={d.signals.slice(0,40).map((s:any)=>[<Badge tone={s.severity==='CRITICAL'||s.severity==='HIGH'?'bad':s.severity==='WARN'?'warn':'neutral'}>{s.severity}</Badge>,`${s.entityType||'—'} · ${s.entityId||'—'}`,s.metric||s.signalType,<span style={{fontSize:12}}>{s.evidence?.issue?.message||s.evidence?.query||s.evidence?.metric||s.signalType}</span>])}/>
 <div style={{height:16}}/>
 <h2>Storefront plans</h2>
 <Table headers={['Plan','Target','Score','Confidence','Status','Purpose']} rows={d.plans.slice(0,30).map((p:any)=>[p.actionType,p.collectionTitle||p.productGid||'—',p.score,`${Math.round((p.confidence||0)*100)}%`,<Badge tone={p.status==='ACTIVE'?'good':'neutral'}>{p.status}</Badge>,p.reason])}/>
 <div style={{height:16}}/>
 <h2>PDP conversion friction</h2>
 <Table headers={['Product','Views','Adds','Purchases','View → cart','Issues']} rows={(x.productFriction||[]).slice(0,20).map((r:any)=>[r.productGid?.split('/').pop()||r.productGid,r.views,r.adds,r.purchases,pct(r.viewToCart),(r.issues||[]).join(', ')])}/>
 <div style={{height:16}}/>
 <h2>Observed search-to-sale</h2>
 <Table headers={['Query','Searches','Zero-result rate','Purchase rate','Status']} rows={(search.observedQueries||[]).map((r:any)=>[r.query,r.searches,pct(r.zeroRate),pct(r.purchaseRate),<Badge tone={r.status==='REPAIR'?'bad':r.status==='WATCH'?'warn':'good'}>{r.status}</Badge>])}/>
 </Page>}
