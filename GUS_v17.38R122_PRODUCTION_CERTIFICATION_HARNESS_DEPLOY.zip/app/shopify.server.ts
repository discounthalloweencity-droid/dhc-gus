import "@shopify/shopify-app-react-router/adapters/node";
import {
  ApiVersion,
  AppDistribution,
  shopifyApp,
} from "@shopify/shopify-app-react-router/server";
import { PrismaSessionStorage } from "@shopify/shopify-app-session-storage-prisma";
import { db } from "./db.server";
import { isGoDaddyPreviewRequest } from "./lib/request-mode.server";
import { previewAuthStartResponse } from "./lib/preview-auth.server";
import {ensureRequestDatabaseReady,isRuntimeInfrastructureError,resetRequestDatabaseReadiness} from "./services/runtime-database-readiness.server";

const shopify = shopifyApp({
  apiKey: process.env.SHOPIFY_API_KEY!,
  apiSecretKey: process.env.SHOPIFY_API_SECRET!,
  apiVersion: ApiVersion.July26,
  scopes: process.env.SCOPES?.split(","),
  appUrl: process.env.SHOPIFY_APP_URL!,
  authPathPrefix: "/auth",
  sessionStorage: new PrismaSessionStorage(db),
  distribution: AppDistribution.SingleMerchant,
  future: {},
});

export default shopify;
export const apiVersion = ApiVersion.July26;
export const addDocumentResponseHeaders = shopify.addDocumentResponseHeaders;
export const authenticate = {
  ...shopify.authenticate,
  admin: async (request: Request) => {
    let result;
    const authenticateOnce = async () => {
      if (isGoDaddyPreviewRequest(request)) {
        const authorityShop = String(process.env.AUTHORITY_SHOP || "").trim().toLowerCase();
        if (!authorityShop.endsWith(".myshopify.com")) {
          throw new Response("Preview shop is temporarily unavailable.", {status: 503});
        }
        try {
          return await shopify.unauthenticated.admin(authorityShop);
        } catch (error) {
          console.warn("[gus-preview-auth] Stored offline Shopify session unavailable; starting Shopify authorization", error);
          throw previewAuthStartResponse(request, authorityShop);
        }
      }
      // Production embedded Admin requests must use Shopify's native cryptographic
      // authenticate.admin flow exactly as the React Router integration expects.
      return await shopify.authenticate.admin(request);
    };

    try {
      result = await authenticateOnce();
    } catch (error) {
      // Only database/session-storage infrastructure failures get one bounded repair.
      // Shopify redirects/bootstrap Responses must pass through untouched.
      if (error instanceof Response) throw error;
      if (!isRuntimeInfrastructureError(error)) throw error;
      console.warn("[gus-auth] Shopify auth hit a session/database infrastructure error; running one bounded readiness repair and retry.", error);
      resetRequestDatabaseReadiness();
      await ensureRequestDatabaseReady({force:true});
      result = await authenticateOnce();
    }

    const normalizeShopDomain = (value: unknown) => String(value || "")
      .trim()
      .toLowerCase()
      .replace(/^https?:\/\//, "")
      .replace(/\/.*$/, "")
      .replace(/^[\'"]+|[\'"]+$/g, "")
      .replace(/\.$/, "");
    const CANONICAL_AUTHORITY_SHOP = "discount-halloween-city.myshopify.com";
    const LEGACY_AUTHORITY_SHOP = "discounthalloweencity.myshopify.com";
    const sessionShop = normalizeShopDomain(result.session.shop);
    const configuredAuthorityShop = normalizeShopDomain(process.env.AUTHORITY_SHOP);
    const authorityShop = (!configuredAuthorityShop||configuredAuthorityShop==='replace_with_shop_domain'||configuredAuthorityShop===LEGACY_AUTHORITY_SHOP)
      ? CANONICAL_AUTHORITY_SHOP
      : configuredAuthorityShop;
    const authorized = sessionShop === CANONICAL_AUTHORITY_SHOP && authorityShop === CANONICAL_AUTHORITY_SHOP;
    if (!authorized) {
      console.warn("[gus-auth] Store authorization mismatch", {sessionShop,configuredAuthorityShop,authorityShop,canonicalAuthorityShop:CANONICAL_AUTHORITY_SHOP});
      throw new Response("Store not authorized", {status:403});
    }
    return result;
  },
};
export const unauthenticated = shopify.unauthenticated;
export const login = shopify.login;
export const registerWebhooks = shopify.registerWebhooks;
export const sessionStorage = shopify.sessionStorage;


// v0.16.57-r37: restore Gus's durable single-store Shopify identity explicitly.
// `Session storage ready` only proves the table is reachable; it does not prove the
// canonical offline Admin token exists or can still authorize Shopify Admin API calls.
export const DHC_CANONICAL_SHOP = "discount-halloween-city.myshopify.com";
export const DHC_OFFLINE_SESSION_ID = `offline_${DHC_CANONICAL_SHOP}`;
const OFFLINE_CERT_TTL_MS = 60_000;
let offlineCertCache:any = null;
let offlineCertAt = 0;

function publishOfflineHealth(state:any){
  (globalThis as any).__gusOfflineAdminHealth = {
    ready:Boolean(state?.ready),
    shop:DHC_CANONICAL_SHOP,
    sessionId:DHC_OFFLINE_SESSION_ID,
    reason:String(state?.reason||''),
    validatedAt:state?.validatedAt||new Date().toISOString(),
    recoveredAlias:Boolean(state?.recoveredAlias),
    scopeCount:Number(state?.scopeCount||0),
  };
}

function normalizeShop(value:unknown){
  return String(value||"").trim().toLowerCase().replace(/^https?:\/\//,"").replace(/\/.*$/,"");
}

async function copySingleOfflineAliasIfSafe(){
  const exact=await db.session.findUnique({where:{id:DHC_OFFLINE_SESSION_ID}});
  if(exact?.accessToken)return {session:exact,recoveredAlias:false};

  const candidates=await db.session.findMany({
    where:{shop:DHC_CANONICAL_SHOP,isOnline:false},
  });
  const usable=candidates.filter((row:any)=>String(row?.accessToken||'').trim());
  if(usable.length!==1)return {session:exact||null,recoveredAlias:false};
  const row:any=usable[0];
  if(row.id===DHC_OFFLINE_SESSION_ID)return {session:row,recoveredAlias:false};

  // Safe recovery only: same canonical shop, explicitly offline, exactly one token-bearing
  // candidate. Keep the original row; create the framework-standard canonical alias.
  const recovered=await db.session.upsert({
    where:{id:DHC_OFFLINE_SESSION_ID},
    create:{
      id:DHC_OFFLINE_SESSION_ID,shop:DHC_CANONICAL_SHOP,state:String(row.state||''),isOnline:false,
      scope:row.scope??null,expires:row.expires??null,accessToken:row.accessToken,userId:row.userId??null,
      firstName:row.firstName??null,lastName:row.lastName??null,email:row.email??null,
      accountOwner:Boolean(row.accountOwner),locale:row.locale??null,collaborator:row.collaborator??false,
      emailVerified:row.emailVerified??false,
    },
    update:{},
  });
  console.warn(`[gus-offline-admin] Recovered canonical offline session alias ${DHC_OFFLINE_SESSION_ID} from the single existing offline session for ${DHC_CANONICAL_SHOP}.`);
  return {session:recovered,recoveredAlias:true};
}

async function validateOfflineAdminGraphql(admin:any){
  const response:any=await admin.graphql(`#graphql\nquery GusOfflineAdminCertification { shop { id myshopifyDomain name } }`);
  const text=await response.text();
  let json:any={};
  try{json=text?JSON.parse(text):{};}catch{throw new Error(`Offline Admin validation returned invalid JSON (HTTP ${Number(response?.status||0)||'unknown'}).`);}
  if(!response.ok||json?.errors?.length){
    const detail=Array.isArray(json?.errors)?json.errors.map((e:any)=>String(e?.message||'')).filter(Boolean).join(' | '):'';
    throw new Error(`Offline Admin validation failed${response?.status?` (HTTP ${response.status})`:''}${detail?`: ${detail}`:''}`);
  }
  const domain=normalizeShop(json?.data?.shop?.myshopifyDomain);
  if(domain!==DHC_CANONICAL_SHOP)throw new Error(`Offline Admin validation returned unexpected shop ${domain||'unknown'}.`);
  return {shopId:String(json?.data?.shop?.id||''),shopName:String(json?.data?.shop?.name||'')};
}

export async function certifyDhcOfflineAdmin(options:{force?:boolean;repairAlias?:boolean}={}){
  const now=Date.now();
  if(!options.force&&offlineCertCache?.ready&&now-offlineCertAt<OFFLINE_CERT_TTL_MS)return offlineCertCache;
  try{
    await ensureRequestDatabaseReady();
    let recoveredAlias=false;
    let session:any=await db.session.findUnique({where:{id:DHC_OFFLINE_SESSION_ID}});
    if((!session||!String(session.accessToken||'').trim())&&options.repairAlias!==false){
      const recovery=await copySingleOfflineAliasIfSafe();
      session=recovery.session;recoveredAlias=recovery.recoveredAlias;
    }
    if(!session){
      const state={ready:false,reason:'OFFLINE_SESSION_MISSING',shop:DHC_CANONICAL_SHOP,sessionId:DHC_OFFLINE_SESSION_ID,recoveredAlias,scopeCount:0,validatedAt:new Date().toISOString()};
      offlineCertCache=state;offlineCertAt=now;publishOfflineHealth(state);return state;
    }
    if(session.isOnline){
      const state={ready:false,reason:'CANONICAL_SESSION_IS_ONLINE',shop:DHC_CANONICAL_SHOP,sessionId:DHC_OFFLINE_SESSION_ID,recoveredAlias,scopeCount:0,validatedAt:new Date().toISOString()};
      offlineCertCache=state;offlineCertAt=now;publishOfflineHealth(state);return state;
    }
    if(normalizeShop(session.shop)!==DHC_CANONICAL_SHOP){
      const state={ready:false,reason:'OFFLINE_SESSION_SHOP_MISMATCH',shop:DHC_CANONICAL_SHOP,sessionId:DHC_OFFLINE_SESSION_ID,recoveredAlias,scopeCount:0,validatedAt:new Date().toISOString()};
      offlineCertCache=state;offlineCertAt=now;publishOfflineHealth(state);return state;
    }
    if(!String(session.accessToken||'').trim()){
      const state={ready:false,reason:'OFFLINE_ACCESS_TOKEN_MISSING',shop:DHC_CANONICAL_SHOP,sessionId:DHC_OFFLINE_SESSION_ID,recoveredAlias,scopeCount:0,validatedAt:new Date().toISOString()};
      offlineCertCache=state;offlineCertAt=now;publishOfflineHealth(state);return state;
    }
    const ctx:any=await shopify.unauthenticated.admin(DHC_CANONICAL_SHOP);
    const admin=ctx?.admin||null;
    if(!admin)throw new Error('Shopify unauthenticated.admin returned no Admin client.');
    const identity=await validateOfflineAdminGraphql(admin);
    const scopes=String(session.scope||'').split(',').map((v:string)=>v.trim()).filter(Boolean);
    const state={ready:true,reason:'READY',shop:DHC_CANONICAL_SHOP,sessionId:DHC_OFFLINE_SESSION_ID,recoveredAlias,scopeCount:scopes.length,validatedAt:new Date().toISOString(),admin,identity};
    offlineCertCache=state;offlineCertAt=now;publishOfflineHealth(state);
    return state;
  }catch(error){
    const reason=String(error instanceof Error?error.message:error||'OFFLINE_ADMIN_VALIDATION_FAILED').slice(0,600);
    const state={ready:false,reason,shop:DHC_CANONICAL_SHOP,sessionId:DHC_OFFLINE_SESSION_ID,recoveredAlias:false,scopeCount:0,validatedAt:new Date().toISOString()};
    offlineCertCache=state;offlineCertAt=now;publishOfflineHealth(state);
    return state;
  }
}

export async function getDhcOfflineAdmin(options:{force?:boolean}={}){
  const state:any=await certifyDhcOfflineAdmin({force:Boolean(options.force),repairAlias:true});
  if(!state.ready||!state.admin){
    const error:any=new Error(`Gus canonical Shopify offline Admin is unavailable: ${state.reason||'unknown reason'}`);
    error.code='GUS_OFFLINE_ADMIN_UNAVAILABLE';error.offlineAdminState=state;throw error;
  }
  return {admin:state.admin,shop:DHC_CANONICAL_SHOP,state};
}

// v0.16.57-r1: arm the canonical single-merchant autonomous control loop as soon as
// the production server bundle is loaded. Previously the shop was registered only
// after /app was opened or a webhook arrived, so a cold restart could leave daily
// learning idle indefinitely. The deferred dynamic import avoids a circular module
// initialization while reusing the global single-flight timer guard in the pulse service.
if (process.env.NODE_ENV !== "test") {
  const configuredStartupShop=String(process.env.AUTHORITY_SHOP||'').trim().toLowerCase();
  if(!configuredStartupShop||configuredStartupShop==='replace_with_shop_domain'||configuredStartupShop==='discounthalloweencity.myshopify.com')process.env.AUTHORITY_SHOP=DHC_CANONICAL_SHOP;
  const startupAuthorityShop = DHC_CANONICAL_SHOP;
  if (startupAuthorityShop.endsWith(".myshopify.com")) {
    setImmediate(() => {
      void Promise.all([import("./services/runtime-orchestrator-pulse.server"),import("./services/database-schema-health.server")])
        .then(async ([pulse,schema]) => {
          const health=await schema.databaseSchemaHealth(true);
          await schema.reconcileDatabaseSchemaIncident(startupAuthorityShop,health).catch(()=>{});
          if(health.status!=="HEALTHY")console.warn(`[gus-schema] startup database schema ${health.status}; missing tables: ${health.missing.join(', ')||'unavailable'}. Affected workers will remain paused until additive schema repair completes.`);

          const certifyAndArm=async()=>{
            const offline:any=await certifyDhcOfflineAdmin({force:true,repairAlias:true});
            if(offline.ready){
              console.info(`[gus-offline-admin] GUS_OFFLINE_ADMIN_READY=true shop=${DHC_CANONICAL_SHOP} session=${DHC_OFFLINE_SESSION_ID} scopes=${offline.scopeCount} recoveredAlias=${offline.recoveredAlias?'true':'false'}.`);
              const control=await import('./services/automation-control.server');
              await control.ensureAlwaysOnAutomation(DHC_CANONICAL_SHOP).catch(error=>console.error('[gus-control-plane] always-on state recovery failed',error instanceof Error?(error.stack||error.message):error));
              pulse.ensureRuntimeOrchestratorPulse(DHC_CANONICAL_SHOP);
              void pulse.runAutonomousHeartbeat(DHC_CANONICAL_SHOP,'COLD_START').catch(()=>{});
              return;
            }
            console.error(`[gus-offline-admin] GUS_OFFLINE_ADMIN_READY=false shop=${DHC_CANONICAL_SHOP} session=${DHC_OFFLINE_SESSION_ID} reason=${offline.reason}. Reopen DHC Command Center to renew Shopify authorization if the token is missing or rejected.`);
            const timer=setTimeout(()=>void certifyAndArm().catch(error=>console.error('[gus-offline-admin] certification retry failed',error instanceof Error?(error.stack||error.message):error)),60_000);
            timer.unref?.();
          };
          await certifyAndArm();
        })
        .catch((error) => console.error("[gus-control-plane] cold-start autonomous loop arm failed", error instanceof Error ? (error.stack || error.message) : error));
    });
  }
}
