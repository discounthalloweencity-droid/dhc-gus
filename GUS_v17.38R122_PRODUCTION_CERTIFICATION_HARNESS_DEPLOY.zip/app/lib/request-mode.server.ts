export function isGoDaddyPreviewRequest(request: Request) {
  const url = new URL(request.url);
  const host = url.hostname.toLowerCase();
  return host.includes('.preview.') && host.endsWith('.airoapp.ai');
}
