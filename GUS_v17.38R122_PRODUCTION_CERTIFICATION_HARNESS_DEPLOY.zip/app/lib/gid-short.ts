export function gidShort(value?: string | null): string {
  if (!value) return "—";
  const parts = value.split("/");
  return parts[parts.length - 1] || value;
}
