const RETURN_COOKIE = "dhc_preview_return";

export function previewAuthStartResponse(request: Request, shop: string) {
  const url = new URL(request.url);
  const host = url.hostname.toLowerCase();
  if (!(host.includes(".preview.") && host.endsWith(".airoapp.ai"))) {
    throw new Error("Preview auth bootstrap is only allowed on the GoDaddy Preview host.");
  }
  const authUrl = new URL("/auth/login", url.origin);
  authUrl.searchParams.set("shop", shop);
  const shareToken = url.searchParams.get("airoShareToken");
  if (shareToken) authUrl.searchParams.set("airoShareToken", shareToken);
  const returnTo = url.pathname + url.search;
  const cookie = `${RETURN_COOKIE}=${encodeURIComponent(returnTo)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=600`;
  return new Response(null, { status: 302, headers: { Location: authUrl.toString(), "Set-Cookie": cookie } });
}

export function previewReturnPath(request: Request) {
  const raw = request.headers.get("cookie") || "";
  const match = raw.match(new RegExp(`(?:^|;\\s*)${RETURN_COOKIE}=([^;]+)`));
  if (!match) return null;
  let value = "";
  try { value = decodeURIComponent(match[1]); } catch { return null; }
  if (!value.startsWith("/app")) return null;
  return value;
}

export function clearPreviewReturnCookie() {
  return `${RETURN_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;
}
