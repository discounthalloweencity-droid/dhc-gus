import type { EntryContext } from "react-router";
import { ServerRouter } from "react-router";
import { renderToReadableStream } from "react-dom/server";
import { addDocumentResponseHeaders } from "./shopify.server";

function formatServerError(error: unknown) {
  if (error instanceof Error) return error.stack ?? `${error.name}: ${error.message}`;
  try { return JSON.stringify(error); } catch { return String(error); }
}

export function handleError(error: unknown, { request }: { request: Request }) {
  console.error(`[gus-ssr] ${request.method} ${request.url}: ${formatServerError(error)}`);
}

export default async function handleRequest(
  request: Request,
  responseStatusCode: number,
  responseHeaders: Headers,
  routerContext: EntryContext,
) {
  try {
    addDocumentResponseHeaders(request, responseHeaders);
    const body = await renderToReadableStream(
      <ServerRouter context={routerContext} url={request.url} />,
    );

    responseHeaders.set("Content-Type", "text/html; charset=utf-8");

    return new Response(body, {
      headers: responseHeaders,
      status: responseStatusCode,
    });
  } catch (error) {
    handleError(error, { request });
    return new Response(
      "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Gus Command Center</title></head><body><main><h1>Gus Command Center</h1><p>We could not complete this request.</p><p><a href=\"/app\">Return to Gus</a></p></main></body></html>",
      { status: 503, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store", "Retry-After": "5" } },
    );
  }
}
