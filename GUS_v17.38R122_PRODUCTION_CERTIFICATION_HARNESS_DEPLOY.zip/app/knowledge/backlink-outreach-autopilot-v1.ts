export const BACKLINK_OUTREACH_AUTOPILOT_VERSION='DHC-BACKLINK-OUTREACH-AUTOPILOT-1.0';
const r=(id:string,statement:string,riskLevel:'LOW'|'MEDIUM'|'HIGH'='MEDIUM',freshness='REVERIFY_WEEKLY')=>({id,topic:'BACKLINK_OUTREACH_AUTOPILOT',statement,confidence:.998,riskLevel,freshness,sources:['DHC Backlink Growth Phase 2 safe contract','Google Search spam policies'],tags:['seo','backlinks','outreach','autopilot','safety']});
export const BACKLINK_OUTREACH_AUTOPILOT_TRAINING=[
 r('boa-01','Phase 2 is an explicit safe contract that supersedes the general committed-outreach owner gate only for high-confidence, uncompensated, relevant earned-media backlink outreach executed by the Backlink Growth Agent.','HIGH','DURABLE'),
 r('boa-02','Automatic sending requires Backlink Autopilot ON, Gus RUNNING, a configured outreach provider, quality score at least 78, topical relevance at least 70, editorial context at least 60, spam risk at most 20, a verified contact, and a verified HTTPS DHC destination.','HIGH','DURABLE'),
 r('boa-03','Use a strict daily send cap. Default to five messages per UTC day and never allow the software cap above twelve without a future reviewed contract.','HIGH','DURABLE'),
 r('boa-04','Send one personalized initial contact and no more than two spaced follow-ups. Do not continue after reply, rejection, bounce, unsubscribe, earned link, or closed status.','HIGH','DURABLE'),
 r('boa-05','Every automatic message must preserve editorial freedom: no placement is required and the publisher should link only if the resource genuinely improves the article.','HIGH','DURABLE'),
 r('boa-06','Never auto-negotiate payment, product exchange, required followed links, reciprocal-link commitments, sponsored placement, or any arrangement intended to purchase ranking credit.','HIGH','DURABLE'),
 r('boa-07','A link monitor must verify source URL, destination, anchor and rel/sponsored/nofollow evidence when available, and update the prospect pipeline to LINK_EARNED or LINK_LOST rather than trusting an outreach response.','MEDIUM'),
 r('boa-08','For earned links, measure the destination in Search Console at 7, 14 and 28 days using equal pre/post windows. Record observed movement as correlation only and never claim the backlink alone caused ranking changes.','MEDIUM'),
 r('boa-09','If the outreach provider or Search Console is not configured, remain honestly NOT_CONFIGURED/DRAFT_ONLY rather than fabricating sends, replies, links or ranking outcomes.','HIGH','DURABLE'),
] as const;
