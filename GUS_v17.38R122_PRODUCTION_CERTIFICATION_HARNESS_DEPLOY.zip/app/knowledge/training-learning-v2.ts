import {TAXONOMY_GOLD_STANDARD as BASE_TAXONOMY,CTL_GOLD_STANDARD as BASE_CTL,FILTER_GOLD_STANDARD as BASE_FILTER} from './merchandising-accuracy-v1.ts';

export const TRAINING_LEARNING_VERSION='DHC-TRAINING-LEARNING-2.0';

const themes=['Vampire','Witch','Pirate','Skeleton','Zombie','Clown','Ghost','Pumpkin','Devil','Angel'];
const accessoryTypes=[
  ['Hat','Hat'],['Mask','Mask'],['Gloves','Gloves'],['Makeup Kit','Makeup'],
] as const;

const taxonomyGenerated:any[]=[];
for(const theme of themes){
  taxonomyGenerated.push({id:`women-${theme}-costume`.toLowerCase(),title:`Women's ${theme} Costume`,kind:'COSTUME',audience:'WOMEN',collection:"Women's Costumes"});
  taxonomyGenerated.push({id:`women-${theme}-dress`.toLowerCase(),title:`Women ${theme} Dress`,kind:'COSTUME',audience:'WOMEN',collection:"Women's Costumes"});
  taxonomyGenerated.push({id:`men-${theme}-costume`.toLowerCase(),title:`Men's ${theme} Costume`,kind:'COSTUME',audience:'MEN',collection:"Men's Costumes"});
  taxonomyGenerated.push({id:`men-${theme}-outfit`.toLowerCase(),title:`Men ${theme} Outfit`,kind:'COSTUME',audience:'MEN',collection:"Men's Costumes"});
  taxonomyGenerated.push({id:`kids-${theme}-costume`.toLowerCase(),title:`Kids ${theme} Costume`,kind:'COSTUME',audience:'KIDS',collection:'Kids Costumes'});
  taxonomyGenerated.push({id:`child-${theme}-jumpsuit`.toLowerCase(),title:`Child ${theme} Jumpsuit`,kind:'COSTUME',audience:'KIDS',collection:'Kids Costumes'});
  taxonomyGenerated.push({id:`${theme}-mask`.toLowerCase(),title:`${theme} Latex Full Face Mask`,kind:'MASK',audience:'NONE',collection:'Masks'});
  taxonomyGenerated.push({id:`${theme}-fangs`.toLowerCase(),title:`${theme} Fake Teeth Fangs`,kind:'FANGS_TEETH',audience:'NONE',collection:'Accessories & Props'});
  taxonomyGenerated.push({id:`${theme}-wig`.toLowerCase(),title:`${theme} Wig Hairpiece`,kind:'WIG',audience:'NONE',collection:'Wigs'});
  taxonomyGenerated.push({id:`${theme}-makeup`.toLowerCase(),title:`${theme} Face Paint Makeup Kit`,kind:'MAKEUP',audience:'NONE',collection:'Makeup & FX'});
}
for(const theme of themes.slice(0,8))taxonomyGenerated.push({id:`${theme}-prop`.toLowerCase(),title:`${theme} Sword Prop`,kind:'PROP',audience:'NONE',collection:'Accessories & Props'});

const ctlGenerated:any[]=[];
for(let i=0;i<themes.length;i++){
 const theme=themes[i],other=themes[(i+1)%themes.length];
 for(const [suffix] of accessoryTypes)ctlGenerated.push({id:`ctl-${theme}-${suffix}`.toLowerCase().replace(/\s+/g,'-'),anchor:{title:`${theme} Costume`,tags:[theme]},candidate:{title:`${theme} ${suffix}`,tags:[theme,suffix]},eligible:true});
 ctlGenerated.push({id:`ctl-${theme}-mismatch-mask`.toLowerCase(),anchor:{title:`${theme} Costume`,tags:[theme]},candidate:{title:`${other} Mask`,tags:[other,'Mask']},eligible:false});
 ctlGenerated.push({id:`ctl-${theme}-mismatch-gloves`.toLowerCase(),anchor:{title:`${theme} Costume`,tags:[theme]},candidate:{title:`${other} Gloves`,tags:[other,'Gloves']},eligible:false});
 ctlGenerated.push({id:`ctl-${theme}-second-costume`.toLowerCase(),anchor:{title:`Women ${theme} Costume`,tags:[theme,'Women']},candidate:{title:`Men ${theme} Costume`,tags:[theme,'Men']},eligible:false});
 ctlGenerated.push({id:`ctl-${theme}-kids-adult`.toLowerCase(),anchor:{title:`Kids ${theme} Costume`,tags:[theme,'Kids']},candidate:{title:`Adult Women ${theme} Hat`,tags:[theme,'Women','Hat']},eligible:false});
 ctlGenerated.push({id:`ctl-${theme}-family`.toLowerCase(),anchor:{title:`Women ${theme} Costume`,tags:[theme,'Women']},candidate:{title:`Kids ${theme} Costume`,tags:[theme,'Kids','Family']},refinement:'FULL_FAMILY',eligible:true});
}

const filterGenerated:any[]=[];
for(let n=80;n<=180;n+=10){
 filterGenerated.push({id:`raw-${n}`,field:'size',value:String(n),status:'BLOCK',canonical:null});
 filterGenerated.push({id:`raw-${n}-cm`,field:'size',value:`${n}cm`,status:'BLOCK',canonical:null});
}
for(const v of ['XS','S','M','L','XL','2XL','3XL','4XL','One Size','2T','3T','4T','7Y','8Y','9-10Y'])filterGenerated.push({id:`canonical-${v}`.toLowerCase().replace(/\s+/g,'-'),field:'size',value:v,status:'CANONICAL',canonical:v});
for(const [value,canonical] of [['small','S'],['medium','M'],['large','L'],['XXL','2XL'],['XXXL','3XL'],['2X','2XL'],['3X','3XL'],['OSFM','One Size'],['one-size','One Size']] as const)filterGenerated.push({id:`norm-size-${value}`.toLowerCase(),field:'size',value,status:'NORMALIZE',canonical});
for(const [value,canonical] of [['female','Women'],['woman','Women'],['lady','Women'],['male','Men'],['man','Men'],['child','Kids'],['children','Kids'],['youth','Kids']] as const)filterGenerated.push({id:`norm-aud-${value}`,field:'audience',value,status:'NORMALIZE',canonical});
for(const [value,canonical] of [['children','Kids'],['youth','Kids'],['toddlers','Toddler'],['babies','Baby'],['infants','Baby'],['adults','Adult'],['teens','Teen']] as const)filterGenerated.push({id:`norm-age-${value}`,field:'age_group',value,status:'NORMALIZE',canonical});
for(const v of ['China Size S','China Size XL','Asian Size M','Asian Size 2XL','CN Size L','Chinese Size XL','大码','儿童码'])filterGenerated.push({id:`blocked-${filterGenerated.length}`,field:'size',value:v,status:'BLOCK',canonical:null});

function dedupe<T extends {id:string}>(rows:T[]):T[]{const seen=new Set<string>();return rows.filter(r=>!seen.has(r.id)&&(seen.add(r.id),true));}
export const TAXONOMY_GOLD_STANDARD_V2=dedupe([...BASE_TAXONOMY,...taxonomyGenerated]);
export const CTL_GOLD_STANDARD_V2=dedupe([...BASE_CTL,...ctlGenerated]);
export const FILTER_GOLD_STANDARD_V2=dedupe([...BASE_FILTER,...filterGenerated]);
export const GOLD_STANDARD_V2_CASES=TAXONOMY_GOLD_STANDARD_V2.length+CTL_GOLD_STANDARD_V2.length+FILTER_GOLD_STANDARD_V2.length;

export const TRAINING_LEARNING_DOCTRINE=[
 'Merchant corrections and verified rollbacks become reusable DHC training evidence with before, wrong decision, corrected decision, reason and rollback context.',
 'Execution success and business success are separate. Every terminal Retail Mission receives an execution outcome label; measured conversion/profit outcomes may later supersede it.',
 'High confidence may execute inside guardrails; medium confidence gathers evidence; low confidence enters the uncertainty queue and must not guess.',
 'Repeated corrections against the same action, field or taxonomy rule increase review priority and lower autonomous confidence until the rule is revalidated.',
 'Gold Standard regressions are release blocking. Expanded cases must remain within DHC truth, audience, pricing, filter and Complete-the-Look guardrails.',
] as const;

export const TRAINING_LEARNING_RULES=[
 {id:'correction-memory-v2',topic:'RETAIL_TRAINING',statement:TRAINING_LEARNING_DOCTRINE[0],confidence:.99,riskLevel:'MEDIUM',freshness:'DURABLE',sources:['DHC owner corrections','verified rollback history'],tags:['training','corrections']},
 {id:'outcome-separation-v2',topic:'RETAIL_TRAINING',statement:TRAINING_LEARNING_DOCTRINE[1],confidence:.99,riskLevel:'HIGH',freshness:'DURABLE',sources:['DHC learning doctrine'],tags:['training','outcomes']},
 {id:'confidence-calibration-v2',topic:'RETAIL_TRAINING',statement:TRAINING_LEARNING_DOCTRINE[2],confidence:.99,riskLevel:'HIGH',freshness:'DURABLE',sources:['DHC autonomy doctrine'],tags:['training','confidence']},
 {id:'repeat-error-priority-v2',topic:'RETAIL_TRAINING',statement:TRAINING_LEARNING_DOCTRINE[3],confidence:.98,riskLevel:'MEDIUM',freshness:'REVERIFY_WEEKLY',sources:['DHC correction history'],tags:['training','errors']},
 {id:'expanded-gold-standard-v2',topic:'RETAIL_TRAINING',statement:TRAINING_LEARNING_DOCTRINE[4],confidence:.99,riskLevel:'HIGH',freshness:'DURABLE',sources:['DHC Gold Standard v2'],tags:['training','gold-standard']},
] as const;

