export const BACKLINK_GROWTH_AGENT_VERSION='DHC-BACKLINK-GROWTH-AGENT-1.0';
const r=(id:string,statement:string,riskLevel:'LOW'|'MEDIUM'|'HIGH'='MEDIUM',freshness='REVERIFY_WEEKLY')=>({id,topic:'BACKLINK_AUTHORITY_GROWTH',statement,confidence:.995,riskLevel,freshness,sources:['DHC Backlink Growth Agent','Google Search spam policies','DHC SEO operating doctrine'],tags:['seo','authority','backlinks','digital-pr']});
export const BACKLINK_GROWTH_AGENT_TRAINING=[
 r('bg-01','Authority growth is a quality pipeline, not a backlink-count contest. Prefer relevant editorial links that can send real shoppers and reinforce a strong DHC destination.'),
 r('bg-02','Prioritize Family/Group Costumes, Kids Costumes, Witch/Gothic, Outdoor Halloween, Masks, Animatronics and useful Halloween 2026 guides when destination quality is strong.'),
 r('bg-03','Run daily discovery for Halloween publishers, costume roundups, family/parenting sites, party resources, haunted-attraction resources, gothic/cosplay publications, local media, community organizations and journalists publishing relevant Halloween coverage.'),
 r('bg-04','Competitor backlink-gap research should identify legitimate sites linking to relevant competitors but not DHC, then rank targets by topical fit and editorial value rather than imitating suspicious competitor links.'),
 r('bg-05','Unlinked brand mentions are high-confidence opportunities because the publisher already knows DHC. Ask only for a helpful editorial link; never pressure or misrepresent the relationship.'),
 r('bg-06','Broken-link replacement is allowed only when DHC has a genuinely equivalent live resource. Never substitute an unrelated sales page merely to obtain a backlink.'),
 r('bg-07','Build and improve link-worthy assets from supportable information: costume trends, family planning, sizing, outdoor decorating, nostalgia, party planning and legitimate aggregated store/search data.'),
 r('bg-08','Outreach drafts must reference the actual article or publisher context and the genuinely relevant DHC resource. Avoid mass templates and fabricated personalization.'),
 r('bg-09','Track every prospect through Discovered, Qualified, Draft Ready, Contacted, Follow-up, Replied, Link Earned, Rejected, Closed and Link Lost states.'),
 r('bg-10','Score opportunity quality primarily from topical relevance, real organic visibility/audience, editorial context, page quality, referral potential and destination fit; spam risk must materially reduce the score.'),
 r('bg-11','Never use PBNs, bulk/Fiverr backlink packages, link farms, mass directories, automated forum/comment links, injected links, fake guest-post networks, excessive reciprocal linking, hidden paid followed links or required followed links in exchange for products/services.','HIGH','DURABLE'),
 r('bg-12','Sponsored or compensated coverage must preserve editorial freedom and use appropriate sponsored/nofollow qualification where required. Never buy ranking credit.','HIGH','DURABLE'),
 r('bg-13','Do not require a followed backlink in exchange for a free costume or other product. Product seeding may support a legitimate independent review only when editorial freedom is preserved and compensation is handled appropriately.','HIGH','DURABLE'),
 r('bg-14','The initial authority-growth goal is 5–15 genuinely relevant new referring domains per month. This is a planning target, not a guaranteed result.'),
 r('bg-15','Measure earned-link events against destination-page Search Console impressions, clicks, CTR, average position and query footprint over later windows. Record correlation honestly and never claim a backlink caused ranking movement without adequate evidence.'),
] as const;
