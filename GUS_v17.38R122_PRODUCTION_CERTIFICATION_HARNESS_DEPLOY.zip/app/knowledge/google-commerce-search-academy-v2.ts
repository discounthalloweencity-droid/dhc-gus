export const GOOGLE_COMMERCE_SEARCH_ACADEMY_VERSION='DHC-GOOGLE-COMMERCE-SEARCH-ACADEMY-2.0';

type Risk='LOW'|'MEDIUM'|'HIGH';
type Rule={id:string;topic:string;statement:string;confidence:number;riskLevel:Risk;freshness:string;sources:string[];tags:string[]};
const r=(id:string,topic:string,statement:string,riskLevel:Risk='MEDIUM',freshness='DURABLE'):Rule=>({id,topic,statement,confidence:.999,riskLevel,freshness,sources:['DHC Google Commerce & Search Academy v2.0','DHC current operating policy','verified runtime contracts through v0.16.50'],tags:['google-commerce-academy',topic.toLowerCase()]});

export const GOOGLE_COMMERCE_SEARCH_ACADEMY_TRAINING=[
 r('merchant-01','MERCHANT_FEED_JUDGMENT','A Merchant product-input acknowledgement proves only that Google accepted the API request; approval, disapproval, limitation and issue status require current Merchant evidence.','HIGH','REVERIFY_DAILY'),
 r('merchant-02','MERCHANT_FEED_JUDGMENT','Never invent GTIN, MPN, brand, item condition, shipping promise, return label, availability, price or image data to improve feed completeness.','HIGH'),
 r('merchant-03','MERCHANT_FEED_JUDGMENT','Do not treat Shopify vendor/supplier as consumer brand unless a verified brand field or licensed identity proves it.','HIGH'),
 r('merchant-04','MERCHANT_FEED_JUDGMENT','Merchant writes must be bounded, resumable and against the explicitly configured account/data source. Never mass-delete Merchant products autonomously.','HIGH'),
 r('merchant-05','MERCHANT_FEED_JUDGMENT','Feed title, selected variant, image, price, currency and availability must agree with the landing page. Mismatch is a quality defect requiring verification or repair.','HIGH','REVERIFY_DAILY'),
 r('merchant-06','MERCHANT_FEED_JUDGMENT','Missing optional identifiers remain missing; missing required evidence creates an evidence-wait or product-quality task, not fabricated data.','HIGH'),
 r('merchant-07','MERCHANT_FEED_JUDGMENT','Shopping titles may differ from storefront SEO titles when they remain truthful, variant-specific and grounded in the same verified product facts.','MEDIUM'),
 r('merchant-08','MERCHANT_FEED_JUDGMENT','Supplier-contaminated storefront identity must be repaired or governed before a materially cleaner Merchant title is allowed to create a contradictory product identity.','MEDIUM'),

 r('crawl-01','CRAWL_INDEX_SAFETY','Detect and quantify crawl waste from sort, tracking, search, currency, country and faceted parameters before proposing controls.','HIGH','REVERIFY_DAILY'),
 r('crawl-02','CRAWL_INDEX_SAFETY','Variant parameters are not automatically crawl waste; preserve legitimate variant UX and canonical behavior.','HIGH'),
 r('crawl-03','CRAWL_INDEX_SAFETY','Robots, canonical, noindex, redirects, URL deletion and mass index controls remain owner-reviewed structural changes.','HIGH'),
 r('crawl-04','CRAWL_INDEX_SAFETY','Never block a high-value collection or product merely because it contains a parameter or resembles another URL. Use intent, canonical and index evidence.','HIGH'),
 r('crawl-05','CRAWL_INDEX_SAFETY','Diagnosis and queueing are autonomous; destructive crawl/index execution is not.','HIGH'),

 r('cannibal-01','CANNIBALIZATION_JUDGMENT','Maintain a Query → Preferred URL ledger using observed Google evidence and page intent.','HIGH','REVERIFY_DAILY'),
 r('cannibal-02','CANNIBALIZATION_JUDGMENT','When collection, PDP and guide target different legitimate intents, differentiate them rather than forcing consolidation.','HIGH'),
 r('cannibal-03','CANNIBALIZATION_JUDGMENT','When multiple pages compete for one commercial query, strengthen the best legitimate destination with internal authority and clearer intent before destructive consolidation.','HIGH'),
 r('cannibal-04','CANNIBALIZATION_JUDGMENT','True duplicate consolidation, redirects, deletion, canonical changes and noindex remain owner-reviewed even when cannibalization is proven.','HIGH'),
 r('cannibal-05','CANNIBALIZATION_JUDGMENT','If the winning URL is ambiguous or evidence conflicts, gather more evidence instead of guessing.','HIGH'),

 r('variant-01','VARIANT_CATALOG_TRUTH','Variant URL, selected image, price, availability, visible stock state, schema and cart selection must agree.','HIGH','REVERIFY_DAILY'),
 r('variant-02','VARIANT_CATALOG_TRUTH','Use ProductGroup/hasVariant/variesBy only from verified Shopify variant structure. Never manufacture variant families.','HIGH'),
 r('variant-03','VARIANT_CATALOG_TRUTH','Missing GTIN or SKU evidence must not be invented to make ProductGroup or Merchant data appear complete.','HIGH'),
 r('variant-04','VARIANT_CATALOG_TRUTH','Semantic option reordering is acceptable when selectable option names and values remain equivalent; true value-set mismatch fails closed.','HIGH'),
 r('variant-05','VARIANT_CATALOG_TRUTH','A stock contradiction between Shopify and the public PDP is an immediate QA defect and must be verified before Search/Shopping claims are trusted.','HIGH'),
 r('variant-06','VARIANT_CATALOG_TRUTH','A single Shopify Default Title variant has no shopper-selectable option to prove. Verify the base PDP price, availability and schema rather than creating a false variant-selection failure.','HIGH'),

 r('image-01','IMAGE_LENS_JUDGMENT','Missing alt text may be filled only from verified product identity through the governed writer; existing non-empty alt is not blindly overwritten.','HIGH'),
 r('image-02','IMAGE_LENS_JUDGMENT','Do not reupload or rename live product media solely to chase filename SEO without a controlled media migration plan.','HIGH'),
 r('image-03','IMAGE_LENS_JUDGMENT','Never infer costume color, material, character, gender or included pieces from an image when catalog evidence does not verify them.','HIGH'),
 r('image-04','IMAGE_LENS_JUDGMENT','Image quality, resolution, surrounding context, structured-data identity and correct variant selection matter together; alt text alone is not an image strategy.','MEDIUM'),

 r('entity-01','ENTITY_TRUST_JUDGMENT','DHC should expose one consistent verified OnlineStore/Organization identity across name, URL, logo, contact, policies and social identities.','HIGH'),
 r('entity-02','ENTITY_TRUST_JUDGMENT','Do not stack duplicate or contradictory Organization/OnlineStore schema blocks. Inspect existing theme/app schema before publishing changes.','HIGH'),
 r('entity-03','ENTITY_TRUST_JUDGMENT','Unknown social, contact or policy identifiers remain unknown until verified.','HIGH'),
 r('entity-04','ENTITY_TRUST_JUDGMENT','Theme-level entity/schema changes are governed structural work unless an explicit bounded writer proves safe ownership and rollback.','HIGH'),

 r('review-01','REVIEW_INTEGRITY','Only genuine product-linked reviews from real customers may influence visible ratings or Review structured data.','HIGH'),
 r('review-02','REVIEW_INTEGRITY','Never fabricate ratings, review counts, testimonials or customer identities.','HIGH'),
 r('review-03','REVIEW_INTEGRITY','Post-purchase review requests must ask for honest feedback without positive-review steering or sentiment-conditioned incentives.','HIGH'),
 r('review-04','REVIEW_INTEGRITY','Automatic review requests require verified fulfilled/paid/non-cancelled order evidence, a bounded waiting window, deduplication and daily limits.','HIGH'),
 r('review-05','REVIEW_INTEGRITY','If order or product linkage is uncertain, wait for evidence instead of sending the request.','HIGH'),

 r('seasonal-01','SEASONAL_RETAIL_JUDGMENT','January–May emphasizes evergreen authority, cleanup, durable guides and entity/catalog quality.','MEDIUM'),
 r('seasonal-02','SEASONAL_RETAIL_JUDGMENT','June–July emphasizes collection architecture, freshness, Merchant readiness and seasonal inventory structure before demand spikes.','MEDIUM'),
 r('seasonal-03','SEASONAL_RETAIL_JUDGMENT','August emphasizes trend discovery, content refresh, image authority and early transactional opportunity.','MEDIUM'),
 r('seasonal-04','SEASONAL_RETAIL_JUDGMENT','September–October emphasizes transactional queries, inventory truth, delivery deadlines, CTR, Merchant coverage and profitable near-winner pages.','MEDIUM'),
 r('seasonal-05','SEASONAL_RETAIL_JUDGMENT','November emphasizes clearance plus evergreen spooky transition; December emphasizes lessons learned and next-season foundation.','MEDIUM'),

 r('longtail-01','LONG_TAIL_JUDGMENT','A new long-tail landing page requires observed demand, distinct intent, enough matching inventory and a differentiated destination.','HIGH'),
 r('longtail-02','LONG_TAIL_JUDGMENT','Do not generate thin pages for every character × age × gender × style combination. Strengthen an existing page when intent is not distinct.','HIGH'),
 r('longtail-03','LONG_TAIL_JUDGMENT','New public landing-page creation remains owner-reviewed even when the opportunity is valid.','HIGH'),
 r('longtail-04','LONG_TAIL_JUDGMENT','Zero or tiny demand plus weak inventory is not a programmatic SEO opportunity.','HIGH'),

 r('serp-01','SERP_INTELLIGENCE_JUDGMENT','Competitor SERP gaps require observed provider evidence; no provider means unavailable, not guessed rankings or gaps.','HIGH','REVERIFY_WEEKLY'),
 r('serp-02','SERP_INTELLIGENCE_JUDGMENT','Compare page type, product depth, internal linking, reviews, FAQs, images, guides, structured data and backlink evidence without blindly copying competitors.','MEDIUM'),
 r('serp-03','SERP_INTELLIGENCE_JUDGMENT','Private competitor traffic, conversion and revenue are unknown unless authoritative evidence exists.','HIGH'),

 r('measure-01','MEASUREMENT_DISCIPLINE','Deployment success is not ranking success. Measure Search Console and commerce outcomes after recrawl and sufficient time.','HIGH'),
 r('measure-02','MEASUREMENT_DISCIPLINE','Record URL, query, change, date, previous metrics and 7/14/28-day observed outcomes for meaningful SEO changes.','HIGH','REVERIFY_DAILY'),
 r('measure-03','MEASUREMENT_DISCIPLINE','Label sparse or conflicting post-change evidence INCONCLUSIVE rather than forcing a win/loss narrative.','HIGH'),
 r('measure-04','MEASUREMENT_DISCIPLINE','A measured regression on a reversible governed change may trigger rollback or revision; structural changes remain governed.','HIGH'),
 r('measure-05','MEASUREMENT_DISCIPLINE','Correlation after a backlink, title or schema change is not automatic proof of causality.','HIGH'),

 r('economics-01','ORGANIC_ECONOMICS_JUDGMENT','Join query/page visibility to landing-page commerce evidence and verified contribution economics; do not invent exact query-to-order attribution.','HIGH'),
 r('economics-02','ORGANIC_ECONOMICS_JUDGMENT','Modeled organic profit must be labeled modeled and must use verified contribution assumptions with missing costs disclosed.','HIGH'),
 r('economics-03','ORGANIC_ECONOMICS_JUDGMENT','Prefer 100 profitable commercial visits over 1,000 low-value visits when evidence supports the economic difference.','MEDIUM'),
 r('economics-04','ORGANIC_ECONOMICS_JUDGMENT','SEO may not override DHC price floors, margin protection, fulfillment truth or customer policy to improve ranking or feed eligibility.','HIGH'),

 r('queue-01','QUALITY_QUEUE_JUDGMENT','The Google Quality Queue prioritizes index value, impressions, positions 4–20, CTR, revenue/profit, content/schema/image quality, inventory, duplicate risk, internal authority, backlinks and seasonality.','HIGH','REVERIFY_DAILY'),
 r('queue-02','QUALITY_QUEUE_JUDGMENT','High-impression collections and profitable near-winners outrank zero-signal catalog cleanup when capacity is constrained.','MEDIUM'),
 r('queue-03','QUALITY_QUEUE_JUDGMENT','Use the strategic effort allocation as a portfolio target rather than forcing each individual cycle to hit exact percentages.','MEDIUM'),

 r('market-01','MARKET_SHARE_JUDGMENT','Organic Market Share requires verified tracked-SERP evidence for the commercially important query set.','HIGH','REVERIFY_WEEKLY'),
 r('market-02','MARKET_SHARE_JUDGMENT','If SERP provider evidence is unavailable, Organic Market Share is unavailable; never estimate a competitive share from Search Console alone.','HIGH'),
 r('market-03','MARKET_SHARE_JUDGMENT','Track DHC position, impressions, clicks, CTR, ranking URL, observed competitors ahead, landing-page economics and trend for the priority query set.','MEDIUM'),

 r('backlink-01','BACKLINK_SEO_JUDGMENT','Backlink outreach should prioritize commercially valuable pages with real near-winner opportunity rather than random domain acquisition.','HIGH'),
 r('backlink-02','BACKLINK_SEO_JUDGMENT','Reject PBNs, paid followed links, mass directories, forum/comment spam, injected links, fake guest-post networks and product-for-required-followed-link schemes.','HIGH'),
 r('backlink-03','BACKLINK_SEO_JUDGMENT','Legitimate editorial links are measured for relevance, referral potential and observed Search Console movement, not merely counted.','MEDIUM'),

 r('fact-01','UNSUPPORTED_FACT_INVENTION','Unsupported fact invention tolerance is zero across Merchant, schema, SEO copy, product facts, reviews, competitor data, shipping, returns and profit.','HIGH'),
 r('fact-02','UNSUPPORTED_FACT_INVENTION','When evidence is absent, choose WAIT_FOR_EVIDENCE or an explicit unknown state instead of filling the gap with plausible text.','HIGH'),
 r('fact-03','UNSUPPORTED_FACT_INVENTION','Verified live evidence outranks stale cached evidence; conflicting sources block certainty until reconciled.','HIGH'),

 r('academy-01','COMMERCE_ACADEMY','The Google Commerce & Search Academy runs scenario drills daily and records failures by domain rather than hiding hard failures inside an average score.','HIGH','REVERIFY_DAILY'),
 r('academy-02','COMMERCE_ACADEMY','Minimum targets: Merchant/feed ≥98%, crawl/index safety 100%, cannibalization ≥95%, variant truth ≥98%, backlink safety 100%, review integrity 100%, profit-rule adherence 100%, unsupported-fact invention 0.','HIGH','REVERIFY_DAILY'),
 r('academy-03','COMMERCE_ACADEMY','Owner corrections, Merchant failures, Search regressions, review-policy blocks, false approvals and rollback evidence become training examples without weakening hard guardrails.','HIGH','REVERIFY_DAILY'),
 r('academy-04','COMMERCE_ACADEMY','Training assertions must validate the meaning of a safety rule rather than depend on one exact sentence; equivalent safe wording must not create a false regression.','HIGH','REVERIFY_DAILY'),
 r('academy-05','COMMERCE_ACADEMY','Repeated provider throttles or worker failures require bounded backoff and visible retry state. Gus must not hammer Shopify every control-plane pulse.','HIGH','REVERIFY_DAILY'),
] as const;
