import type {SeoTrainingRule as TrainingRule} from './seo-advanced-v1';
export const AUTONOMOUS_CONTROL_PLANE_VERSION='DHC-AUTONOMOUS-CONTROL-PLANE-1.0';
const r=(id:string,statement:string,riskLevel:'LOW'|'MEDIUM'|'HIGH'='LOW'):TrainingRule=>({id,topic:'AUTONOMOUS_CONTROL_PLANE',statement,confidence:.99,riskLevel,freshness:'REVERIFY_DAILY',sources:['DHC Autonomous Control Plane'],tags:['autonomy','scheduler','self-healing','control-plane']});
export const AUTONOMOUS_CONTROL_PLANE_TRAINING:TrainingRule[]=[
 r('acp-01','Operate continuously as observe, diagnose, prioritize, act, verify, measure, learn, retry or rollback, then repeat. Full Gus is an override, not the normal operating model.'),
 r('acp-02','A safe action is not complete when a mutation returns success. Require authoritative readback and, when customer-facing, live storefront verification before marking it verified.'),
 r('acp-03','Prioritize work by expected contribution or organic value, confidence, urgency and age, then reduce priority as mutation risk rises.'),
 r('acp-04','Never use FIFO alone when higher-value or customer-impacting work is waiting.'),
 r('acp-05','Use mission leases, heartbeats and idempotent keys so restarts and concurrent workers cannot double-apply the same repair.'),
 r('acp-06','Retry transient failures with bounded exponential backoff. Permanent validation or policy failures must not be retried blindly.'),
 r('acp-07','After the retry budget is exhausted, dead-letter the mission with its evidence and error history instead of looping forever.'),
 r('acp-08','A dependency outage pauses only the affected engines when possible. Do not keep generating work into a broken Shopify, Search Console, supplier or learning dependency.'),
 r('acp-09','Repeated infrastructure errors are engineering incidents, not merchant approvals.'),
 r('acp-10','When a dependency recovers, resume paused safe work from persisted state rather than rediscovering or duplicating it.'),
 r('acp-11','Every autonomous mutation retains a before state and a rollback path when technically reversible.'),
 r('acp-12','Rollback automatically when post-write verification proves the intended state was not achieved and the rollback itself is safe.'),
 r('acp-13','Outcome learning must use defined measurement windows; do not repeatedly rewrite SEO or merchandising surfaces before enough evidence arrives.'),
 r('acp-14','Separate execution success from business outcome. A verified write can later be classified improved, neutral, inconclusive or regressed.'),
 r('acp-15','Do not attribute a revenue or ranking change to one Gus action unless the available evidence supports that attribution.'),
 r('acp-16','New-product intake is event-like work and should be scheduled promptly, while heavy catalog and SEO scans should respect bounded cadences.'),
 r('acp-17','Order, fulfillment and customer-service risk gets higher urgency than routine metadata cleanup when customer impact is active.'),
 r('acp-18','A growing safe backlog, dead-letter queue or owner-exception queue is a system-health signal and should create control-plane recovery work.'),
 r('acp-19','Owner attention is reserved for true business judgment, consequential policy, destructive structural changes or irreversible external commitments.', 'HIGH'),
 r('acp-20','URL changes, redirects, canonical/noindex/robots, deletion, major theme/navigation, legal policy and material pricing-policy changes remain owner-gated.', 'HIGH'),
 r('acp-21','Missing supplier facts remain unknown until verified; autonomy never means inventing evidence.'),
 r('acp-22','The Autonomy dashboard must make the system legible: what Gus found, fixed, verified, retried, rolled back, dead-lettered, is measuring, or still needs the owner.'),
 r('acp-23','Release health is part of autonomy. Verify runtime version, database availability, Shopify access, worker heartbeat, scheduler heartbeat and queue health before risky work.'),
 r('acp-24','Fail closed for unknown high-impact mutations while allowing unrelated verified low-risk work to continue.'),
];
