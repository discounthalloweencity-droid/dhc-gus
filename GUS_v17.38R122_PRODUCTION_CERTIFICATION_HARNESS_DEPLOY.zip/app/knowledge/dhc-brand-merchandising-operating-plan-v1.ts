export const DHC_BRAND_MERCH_OPERATING_PLAN_VERSION='DHC-BRAND-MERCH-OPERATING-PLAN-v1.0';

export const DHC_BRAND_MERCH_SUPERSESSION={
  release:'0.16.57-r19',
  authority:'OWNER_APPROVED_CURRENT_BRAND_MERCHANDISING_DOCTRINE',
  rule:'When an older merchandising, SEO, competitive-intelligence, storefront-shopping, or brand interpretation conflicts with this owner-approved plan, use this plan. Preserve newer hard runtime safety contracts, verified product truth, legal/licensing constraints, pricing floors, margin guardrails, delivery/source verification, rollback/readback requirements, and governed financial/customer actions.',
  preserves:['verified product truth','legal and licensing truth','pricing floors','margin guardrails','delivery and sourcing evidence','customer privacy and support governance','runtime safety and rollback'],
} as const;

export const DHC_EDITORIAL_MERCH_HIERARCHY=[
  'Trending Now',
  'Family & Group Halloween',
  'Kids Halloween',
  'Gothic, Witch & Vampire',
  'Outdoor Halloween Under $100',
  'Big Scares Under $150',
  'Skeleton & Graveyard',
  'Retro Halloween',
  'Cute Spooky',
  'Complete the Look',
] as const;

export const DHC_SEO_TERRITORIES=[
  'Halloween Costumes',
  'Kids Halloween Costumes',
  'Family Halloween Costumes',
  'Group Halloween Costumes',
  'Halloween Decorations',
  'Outdoor Halloween Decorations',
  'Halloween Animatronics',
  'Halloween Masks',
  'Halloween Accessories',
  'Gothic/Witch Halloween',
  'Skeleton & Graveyard Decorations',
  'Retro Halloween',
  'Pet Halloween Costumes',
] as const;

export const DHC_TREND_TRANSLATIONS={
  'k-pop hit':'Stage Warriors / Fantasy Idols',
  'popular gothic show':'Gothic Family / Dark Academy',
  'viral horror character':'Classic Horror / Creepy Clowns',
  'major fantasy movie':'Mythical Warriors / Witches / Medieval Fantasy',
} as const;

export const DHC_BRAND_FLYWHEEL='Nostalgia attracts them → Trends bring them in → Value earns the click → Gus helps them shop → Complete-the-Look grows the basket → Reliable fulfillment earns trust → SEO brings them back without paying for every visit.';

export function editorialMerchPriority(title:string){
  const t=String(title||'').toLowerCase().replace(/[^a-z0-9$]+/g,' ').replace(/\s+/g,' ').trim();
  if(/\btrending\b/.test(t))return 1;
  if(/\bfamily\b|\bgroup\b|\bcouples\b|\bsiblings\b|parent child|family pet/.test(t))return 2;
  if(/\bkids?\b|\bchildren\b/.test(t))return 3;
  if(/\bgothic\b|\bwitch\b|\bvampire\b|dark academy/.test(t))return 4;
  if(/outdoor.*(?:under )?\$?100|(?:under )?\$?100.*outdoor/.test(t))return 5;
  if(/big scares?.*(?:under )?\$?150|(?:under )?\$?150.*big scares?/.test(t))return 6;
  if(/\bskeleton\b|\bgraveyard\b|\btombstone\b/.test(t))return 7;
  if(/\bretro\b|\bnostalgi|\b1980s?\b|\b1990s?\b/.test(t))return 8;
  if(/cute spooky/.test(t))return 9;
  if(/complete (?:the )?look/.test(t))return 10;
  return 999;
}

export function competitiveDemandResponse(hasExistingMatch:boolean){
  return hasExistingMatch?'PROMOTE_EXISTING':'DEMAND_GAP_REVIEW';
}

type Risk='LOW'|'MEDIUM'|'HIGH';
type Rule={id:string;topic:string;statement:string;confidence:number;riskLevel:Risk;freshness:string;sources:string[];tags:string[]};
const r=(id:string,topic:string,statement:string,riskLevel:Risk='MEDIUM',freshness='DURABLE'):Rule=>({id,topic,statement,confidence:.999,riskLevel,freshness,sources:['Discount Halloween City Brand & Merchandising Operating Plan','Owner-approved current DHC doctrine','Gus v0.16.57 R19'],tags:['dhc-brand-merch-operating-plan',topic.toLowerCase()]});

export const DHC_BRAND_MERCH_OPERATING_PLAN=[
 r('brand-01','BRAND_CONSTITUTION','Discount Halloween City is the affordable Halloween destination that makes Halloween feel fun again. Build a recognizable DHC retail identity rather than a generic dropshipping catalog.','HIGH'),
 r('brand-02','BRAND_CONSTITUTION','Use competitors to identify changing consumer demand, never to copy another retailer’s identity. Interpret demand through DHC nostalgia, value, family shopping, affordable spectacle, Complete-the-Look and Gus.','HIGH'),
 r('brand-03','BRAND_CONSTITUTION','The customer experience should feel like a modern online version of walking into a great Halloween store as a kid: exciting, slightly spooky, colorful, discoverable and fun, while remaining professionally merchandised.','MEDIUM'),
 r('brand-04','BRAND_PROTECTION','Before a future merchandising, SEO, sourcing or storefront change, ask whether it makes Discount Halloween City more recognizable as DHC. Reject changes that merely add products, keywords or clutter without strengthening the brand or customer mission.','HIGH'),

 r('merch-01','EDITORIAL_MERCHANDISING','Use the owner-approved editorial merchandising hierarchy in order: Trending Now; Family & Group Halloween; Kids Halloween; Gothic, Witch & Vampire; Outdoor Halloween Under $100; Big Scares Under $150; Skeleton & Graveyard; Retro Halloween; Cute Spooky; Complete the Look.','HIGH'),
 r('merch-02','EDITORIAL_MERCHANDISING','Traditional Men, Women, Kids, Masks, Decorations, Accessories and similar departments remain important navigation. The editorial hierarchy is the DHC shopping-mission layer above those conventional categories.','MEDIUM'),
 r('merch-03','FAMILY_SHOPPING','Family and group shopping is a signature DHC strength. Support Couples, Groups of 3, Groups of 4, Groups of 5+, Family, Family + Pet, Parent + Child and Siblings when catalog depth permits.','HIGH'),
 r('merch-04','FAMILY_SHOPPING','Integrate pet costumes into a Family + Pet shopping path in addition to keeping useful pet navigation. Gus may coordinate a family from compatible individual products rather than requiring an exact packaged family costume.','MEDIUM'),

 r('trend-01','TREND_MERCHANDISING','Never redesign DHC around one viral franchise, celebrity, meme, movie, game or television property. Trends are traffic accelerators inside the permanent DHC merchandising system.','HIGH','REVERIFY_DAILY'),
 r('trend-02','TREND_MERCHANDISING','When licensing cannot be verified, do not use protected character or franchise names and do not imply official licensing. Translate demand into accurate generic DHC-owned themes instead.','HIGH'),
 r('trend-03','TREND_MERCHANDISING','Use durable theme translations such as K-pop hit → Stage Warriors / Fantasy Idols; popular gothic show → Gothic Family / Dark Academy; viral horror character → Classic Horror / Creepy Clowns; major fantasy movie → Mythical Warriors / Witches / Medieval Fantasy.','MEDIUM','REVERIFY_SEASONALLY'),

 r('visual-01','NOSTALGIA_VISUAL_BRAND','Nostalgia is the visual brand. Favor 1980s/1990s Halloween atmosphere such as neighborhood trick-or-treating, porch pumpkins, old masks, homemade costumes, flash photography, fall evenings, vintage Halloween parties, retro retail Halloween and childhood Halloween excitement.','MEDIUM'),
 r('visual-02','NOSTALGIA_VISUAL_BRAND','Do not make the commerce experience look old. Imagery may be nostalgic while navigation, search, filters, product cards, checkout, Gus and mobile UX remain clean, modern and contemporary.','HIGH'),

 r('pdp-01','PRODUCT_PRESENTATION','No customer-facing product should look copied directly from a supplier feed. Remove supplier wording, foreign-market terminology, keyword stuffing, meaningless names and obvious marketplace boilerplate while preserving verified product identity.','HIGH'),
 r('pdp-02','PRODUCT_PRESENTATION','Where useful, write customer-facing titles as Who + recognizable theme or product + Halloween intent. Natural shopper language outranks supplier phrasing.','MEDIUM'),
 r('pdp-03','PRODUCT_PRESENTATION','Important PDPs should clearly communicate what the item is, who it is for, what is included, available sizes/options, fit where applicable, verified material, current inventory, realistic delivery information, return information and complementary products. Never invent specifications.','HIGH'),

 r('price-01','VALUE_ARCHITECTURE','Present DHC like a large value retailer without turning it into a permanent clearance store. Preserve established costume floors and margin safeguards.','HIGH'),
 r('price-02','VALUE_ARCHITECTURE','Use recognizable value ladders such as Under $25, Under $50, Under $100 and Big Scares Under $150, with .97 big-box price presentation where appropriate.','MEDIUM'),
 r('price-03','VALUE_ARCHITECTURE','Do not blindly lower a price because a competitor is cheaper. Compare delivered customer value including shipping, product completeness and delivery speed. The goal is obvious value, not the lowest sticker price on every SKU.','HIGH','REVERIFY_DAILY'),

 r('basket-01','BASKET_BUILDING','Build major costume journeys as Costume → Wig → Makeup → Prop → Gloves/Hat → compatible Pet/Family item when real catalog evidence supports the relationship. Gus should actively help assemble the look.','MEDIUM'),
 r('basket-02','BASKET_BUILDING','Build décor journeys as anchor item → complementary scene pieces, for example Skeleton → Tombstones → Lighting → Fog → Hanging décor. Sell scenes and outcomes, not isolated items.','MEDIUM'),
 r('basket-03','BASKET_BUILDING','Complete the Look should evolve into a recommendation system based on real product relationships rather than a giant undifferentiated accessory collection. Helpfully growing baskets above the current free-shipping threshold is a secondary outcome, never a reason to recommend irrelevant items.','HIGH'),

 r('outdoor-01','OUTDOOR_MERCHANDISING','DHC should own affordable spectacle rather than trying to become the $300–$500 giant-animatronic retailer. Develop Outdoor Under $50, Outdoor Under $100, Big Scares Under $150 and Build a Haunted Yard shopping missions.','HIGH'),
 r('outdoor-02','OUTDOOR_MERCHANDISING','Merchandise outdoor products as scenes: a skeleton shopper should see relevant tombstones, lighting, fog and props when available and compatible.','MEDIUM'),

 r('season-01','SEASONAL_MERCHANDISING','The backend seasonal switch is the source of truth. Before the cutoff, rank the full catalog using demand, profitability, inventory confidence and delivery performance. At the cutoff, progressively prioritize verified USA-shipping inventory.','HIGH','REVERIFY_DAILY'),
 r('season-02','SEASONAL_MERCHANDISING','Never infer USA fulfillment from a US plug, American sizing, product wording or supplier title. Products with uncertain sourcing are flagged rather than represented as fast USA fulfillment.','HIGH'),
 r('season-03','SEASONAL_MERCHANDISING','As Halloween approaches, increase the ranking weight of delivery confidence so products with weak or uncertain arrival evidence do not displace safer choices.','HIGH','REVERIFY_DAILY'),

 r('gus-01','GUS_SHOPPING_EXPERT','Gus is DHC’s Halloween shopping expert, search engine, stylist, scene builder, customer-service agent and merchandising assistant—not merely a support bot.','HIGH'),
 r('gus-02','GUS_SHOPPING_EXPERT','For shopping missions, Gus should use real available products and return useful product cards with pictures, price, relevant variants and evidence-grounded delivery information, then guide the shopper toward a purchase without inventing facts.','HIGH'),
 r('gus-03','GUS_SHOPPING_EXPERT','Gus should be able to solve missions such as a family of five under a budget, something scary for a child of a stated age, a haunted-yard scene under a budget, completing a witch costume, or matching a pet to a family look by coordinating current catalog products.','MEDIUM'),

 r('seo-01','SEO_TERRITORY','Build organic authority around permanent DHC commercial territories: Halloween Costumes; Kids Halloween Costumes; Family Halloween Costumes; Group Halloween Costumes; Halloween Decorations; Outdoor Halloween Decorations; Halloween Animatronics; Halloween Masks; Halloween Accessories; Gothic/Witch Halloween; Skeleton & Graveyard Decorations; Retro Halloween; Pet Halloween Costumes.','HIGH'),
 r('seo-02','SEO_TERRITORY','Do not generate thousands of near-identical SEO pages. Support permanent commercial territories with genuinely useful editorial content and strong internal pathways.','HIGH'),
 r('seo-03','SEO_TERRITORY','Trend articles and seasonal editorial content should feed authority and shoppers into permanent DHC commercial collections rather than becoming isolated content islands.','MEDIUM'),

 r('competitive-01','COMPETITIVE_DEMAND','Every weekly competitive review starts with: What changed in customer demand? Then choose among promoting inventory DHC already owns, reorganizing a collection, improving a PDP, building a Complete-the-Look relationship, creating useful SEO content, adjusting price/offer positioning, or sourcing a genuinely missing category.','HIGH','REVERIFY_WEEKLY'),
 r('competitive-02','COMPETITIVE_DEMAND','Do not respond to every trend or competitor signal by importing more products. Use existing DHC inventory first; a true unmatched demand gap is a review signal, not an automatic sourcing command.','HIGH','REVERIFY_WEEKLY'),

 r('flywheel-01','DHC_GROWTH_FLYWHEEL','Operate the DHC growth model as: Nostalgia attracts them → Trends bring them in → Value earns the click → Gus helps them shop → Complete-the-Look grows the basket → Reliable fulfillment earns trust → SEO brings them back without paying for every visit.','HIGH'),
];
