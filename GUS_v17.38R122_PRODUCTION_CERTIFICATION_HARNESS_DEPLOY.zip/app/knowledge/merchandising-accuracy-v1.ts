import type {SeoTrainingRule as TrainingRule} from './seo-advanced-v1';
export const MERCHANDISING_ACCURACY_TRAINING_VERSION='DHC-MERCH-ACCURACY-1.0';
export const MERCHANDISING_ACCURACY_TRAINING:TrainingRule[]=[
{id:'gold-standard',topic:'RETAIL_TRAINING',statement:'Treat verified DHC gold-standard examples as release-blocking regression tests for taxonomy, Complete the Look and filter accuracy. A new rule must not reduce gold-standard accuracy.',confidence:.99,riskLevel:'MEDIUM',freshness:'DURABLE',sources:['DHC merchant corrections','DHC public-store QA'],tags:['training','gold-standard']},
{id:'ctl-relevance-first',topic:'CTL_RELEVANCE',statement:'Complete the Look must optimize relevance before profit. Profit, popularity, trend status or free-shipping progress may only rank candidates that already pass strict complement relevance and audience safety gates.',confidence:.99,riskLevel:'HIGH',freshness:'DURABLE',sources:['DHC merchandising doctrine'],tags:['ctl','relevance','profit']},
{id:'ctl-fewer-better',topic:'CTL_RELEVANCE',statement:'Returning one or two strong Complete the Look matches is better than filling every slot with weak products. Empty is acceptable when evidence is insufficient.',confidence:.99,riskLevel:'LOW',freshness:'DURABLE',sources:['DHC merchandising doctrine'],tags:['ctl','precision']},
{id:'ctl-slot-diversity',topic:'CTL_RELEVANCE',statement:'Do not fill Complete the Look with duplicate functional slots. Prefer one best mask, one best fangs/teeth item, one wig, one makeup/FX item, one prop, etc., unless verified basket history proves a multi-item same-slot combination is useful.',confidence:.99,riskLevel:'LOW',freshness:'DURABLE',sources:['DHC merchandising doctrine'],tags:['ctl','slot-fill']},
{id:'ctl-mask-vs-fangs',topic:'CTL_TAXONOMY',statement:'Masks and fangs/teeth are separate Complete the Look slots. Fangs/teeth are accessories and must never be used as evidence that a product belongs in the Masks category.',confidence:.99,riskLevel:'MEDIUM',freshness:'DURABLE',sources:['DHC catalog correction'],tags:['ctl','masks','accessories']},
{id:'ctl-theme-proof',topic:'CTL_RELEVANCE',statement:'When a core item has a verified theme/character, require a matching theme/character, a strongly compatible functional relationship, or strong observed co-purchase evidence. Generic accessory status alone is not enough.',confidence:.99,riskLevel:'MEDIUM',freshness:'DURABLE',sources:['DHC CTL strategy'],tags:['ctl','theme']},
{id:'ctl-audience-proof',topic:'CTL_RELEVANCE',statement:'Reject adult-only or audience-conflicting Complete the Look candidates for kids. Reject second primary costumes unless the shopper explicitly asks for family/couple coordination.',confidence:.99,riskLevel:'HIGH',freshness:'DURABLE',sources:['DHC CTL strategy'],tags:['ctl','audience']},
{id:'ctl-price-harmony',topic:'CTL_RELEVANCE',statement:'For ordinary accessory add-ons, prefer prices proportionate to the anchor item. A high-priced add-on needs stronger relevance or observed co-purchase evidence; price should never rescue weak relevance.',confidence:.98,riskLevel:'LOW',freshness:'REVERIFY_MONTHLY',sources:['DHC CTL strategy'],tags:['ctl','price']},
{id:'ctl-outcome-learning',topic:'CTL_LEARNING',statement:'Learn Complete the Look from impression-to-attach, purchase, conversion, contribution-profit and rollback outcomes. Clicks alone are not proof of a good pairing.',confidence:.99,riskLevel:'MEDIUM',freshness:'REVERIFY_WEEKLY',sources:['DHC analytics doctrine'],tags:['ctl','learning']},
{id:'filter-canonical',topic:'FILTERS_SEARCH',statement:'Customer-facing filters must use a canonical DHC vocabulary so equivalent values do not fragment into duplicates such as female/woman/women or XXL/2XL.',confidence:.99,riskLevel:'LOW',freshness:'DURABLE',sources:['DHC filter standard'],tags:['filters','canonical']},
{id:'filter-raw-size',topic:'FILTERS_SEARCH',statement:'Bare supplier clothing sizes such as 100/110/120/130/140/150/160 must not be published as customer-facing US size filters unless a verified supplier measurement/age mapping supports the conversion.',confidence:.99,riskLevel:'HIGH',freshness:'DURABLE',sources:['DHC sizing correction'],tags:['filters','size','truth']},
{id:'filter-no-guess',topic:'FILTERS_SEARCH',statement:'If Gus cannot prove a US size conversion, remove or suppress the dirty filter value and create an evidence-needed item. Never manufacture S/M/L or age mappings from supplier numbers alone.',confidence:.99,riskLevel:'HIGH',freshness:'DURABLE',sources:['DHC sizing policy'],tags:['filters','size','evidence']},
{id:'filter-audience-consistency',topic:'FILTERS_SEARCH',statement:'Audience, gender and age-group filters must agree with verified product intent. Conflicting Women/Kids/Men values are a blocking data-quality defect, not a harmless synonym.',confidence:.99,riskLevel:'HIGH',freshness:'DURABLE',sources:['DHC taxonomy standard'],tags:['filters','audience']},
{id:'filter-foreign-copy',topic:'FILTERS_SEARCH',statement:'Supplier-language artifacts, foreign-language option text and China/Asian-size labeling must not leak into shopper-facing filters. Preserve source evidence privately while publishing only verified customer-friendly values.',confidence:.99,riskLevel:'MEDIUM',freshness:'DURABLE',sources:['DHC catalog standard'],tags:['filters','supplier-copy']},
{id:'filter-postwrite-verify',topic:'FILTERS_SEARCH',statement:'A filter cleanup is not complete until Gus re-reads Shopify and the live collection/filter surface and confirms the dirty value disappeared without removing valid variants.',confidence:.99,riskLevel:'HIGH',freshness:'DURABLE',sources:['DHC closed-loop QA'],tags:['filters','verification']},
{id:'confidence-calibration',topic:'RETAIL_TRAINING',statement:'High-confidence deterministic matches may execute inside guardrails. Medium confidence must gather more evidence. Low confidence must remain blocked or enter training review; uncertainty is not permission to guess.',confidence:.99,riskLevel:'HIGH',freshness:'DURABLE',sources:['DHC autonomy doctrine'],tags:['training','confidence']},
{id:'merchant-correction-memory',topic:'RETAIL_TRAINING',statement:'Every verified merchant correction should become reusable evidence: original facts, Gus decision, corrected decision, reason, outcome and whether the prior action was rolled back.',confidence:.99,riskLevel:'MEDIUM',freshness:'DURABLE',sources:['DHC learning doctrine'],tags:['training','feedback']},
{id:'regression-block',topic:'RETAIL_TRAINING',statement:'If a new classifier or merchandising change lowers gold-standard accuracy below its threshold, mark the training evaluation failed and do not treat the affected rule set as production-ready.',confidence:.99,riskLevel:'HIGH',freshness:'DURABLE',sources:['DHC release QA'],tags:['training','regression']},
];

export type TaxonomyGoldCase={id:string;title:string;tags?:string[];productType?:string;kind:string;audience:string;collection:string};
export const TAXONOMY_GOLD_STANDARD:TaxonomyGoldCase[]=[
{id:'women-ladybug',title:"Women's Ladybug Costume Dress",kind:'COSTUME',audience:'WOMEN',collection:"Women's Costumes"},
{id:'kids-fangs',title:'Kids Vampire Fangs Fake Teeth',kind:'FANGS_TEETH',audience:'KIDS',collection:'Accessories & Props'},
{id:'zombie-mask',title:'Latex Zombie Full Face Mask',kind:'MASK',audience:'NONE',collection:'Masks'},
{id:'witch-wig',title:'Long Black Witch Wig',kind:'WIG',audience:'NONE',collection:'Wigs'},
{id:'blood-makeup',title:'Vampire Fake Blood Makeup Kit',kind:'MAKEUP',audience:'NONE',collection:'Makeup & FX'},
{id:'men-pirate',title:"Men's Pirate Captain Costume",kind:'COSTUME',audience:'MEN',collection:"Men's Costumes"},
{id:'kids-police',title:'Kids Police Officer Costume',kind:'COSTUME',audience:'KIDS',collection:'Kids Costumes'},
{id:'skeleton-gloves',title:'Skeleton Bone Gloves',kind:'PROP',audience:'NONE',collection:'Accessories & Props'},
{id:'women-witch',title:'Women Witch Costume Set',kind:'COSTUME',audience:'WOMEN',collection:"Women's Costumes"},
{id:'mask-not-teeth',title:'Blue LED Halloween Face Mask',kind:'MASK',audience:'NONE',collection:'Masks'},
];

export type CtlGoldCase={id:string;anchor:{title:string;tags?:string[]};candidate:{title:string;tags?:string[]};refinement?:'MORE_SCARY'|'KID_FRIENDLY'|'BUDGET'|'FULL_FAMILY';eligible:boolean};
export const CTL_GOLD_STANDARD:CtlGoldCase[]=[
{id:'vampire-cape',anchor:{title:'Women Vampire Costume',tags:['Vampire','Women']},candidate:{title:'Black Vampire Cape',tags:['Vampire','Cape']},eligible:true},
{id:'vampire-fangs',anchor:{title:'Women Vampire Costume',tags:['Vampire','Women']},candidate:{title:'Vampire Fangs Fake Teeth',tags:['Vampire','Fangs']},eligible:true},
{id:'vampire-clown',anchor:{title:'Women Vampire Costume',tags:['Vampire','Women']},candidate:{title:'Funny Clown Nose',tags:['Clown','Funny']},eligible:false},
{id:'kids-witch-adult',anchor:{title:'Kids Witch Costume',tags:['Witch','Kids']},candidate:{title:'Adult Only Sexy Witch Accessory',tags:['Witch','Adult Only']},refinement:'KID_FRIENDLY',eligible:false},
{id:'second-costume',anchor:{title:'Women Vampire Costume',tags:['Vampire','Women']},candidate:{title:'Men Vampire Costume',tags:['Vampire','Men']},eligible:false},
{id:'family-costume',anchor:{title:'Women Vampire Costume',tags:['Vampire','Women']},candidate:{title:'Kids Vampire Costume',tags:['Vampire','Kids','Family']},refinement:'FULL_FAMILY',eligible:true},
{id:'skeleton-gloves',anchor:{title:'Skeleton Costume',tags:['Skeleton']},candidate:{title:'Skeleton Bone Gloves',tags:['Skeleton','Gloves']},eligible:true},
{id:'pirate-sword',anchor:{title:'Pirate Captain Costume',tags:['Pirate']},candidate:{title:'Pirate Sword Prop',tags:['Pirate','Prop']},eligible:true},
{id:'princess-skull-mask',anchor:{title:'Princess Costume',tags:['Princess']},candidate:{title:'Scary Skull Mask',tags:['Skeleton','Scary']},eligible:false},
{id:'witch-hat',anchor:{title:'Classic Witch Costume',tags:['Witch']},candidate:{title:'Black Witch Hat',tags:['Witch','Hat']},eligible:true},
{id:'kids-witch-womens-hat',anchor:{title:'Kids Witch Costume',tags:['Witch','Kids']},candidate:{title:"Women's Witch Hat",tags:['Witch','Women','Hat']},eligible:false},
{id:'women-vampire-mens-hat',anchor:{title:'Women Vampire Costume',tags:['Vampire','Women']},candidate:{title:"Men's Vampire Hat",tags:['Vampire','Men','Hat']},eligible:false},
{id:'men-vampire-unisex-cape',anchor:{title:'Men Vampire Costume',tags:['Vampire','Men']},candidate:{title:'Unisex Vampire Cape',tags:['Vampire','Unisex','Cape']},eligible:true},
];

export type FilterGoldCase={id:string;field:string;value:string;status:'CANONICAL'|'NORMALIZE'|'BLOCK';canonical?:string|null};
export const FILTER_GOLD_STANDARD:FilterGoldCase[]=[
{id:'raw100',field:'size',value:'100',status:'BLOCK',canonical:null},
{id:'raw160',field:'size',value:'160',status:'BLOCK',canonical:null},
{id:'xxl',field:'size',value:'XXL',status:'NORMALIZE',canonical:'2XL'},
{id:'3xl',field:'size',value:'3XL',status:'CANONICAL',canonical:'3XL'},
{id:'female',field:'audience',value:'female',status:'NORMALIZE',canonical:'Women'},
{id:'women',field:'audience',value:'Women',status:'CANONICAL',canonical:'Women'},
{id:'child',field:'age_group',value:'child',status:'NORMALIZE',canonical:'Kids'},
{id:'toddler',field:'age_group',value:'Toddler',status:'CANONICAL',canonical:'Toddler'},
{id:'foreign',field:'size',value:'大码',status:'BLOCK',canonical:null},
{id:'china-size',field:'size',value:'China Size L',status:'BLOCK',canonical:null},
{id:'raw110cm',field:'size',value:'110cm',status:'BLOCK',canonical:null},
{id:'age-range',field:'size',value:'9-10Y',status:'CANONICAL',canonical:'9-10Y'},
{id:'toddler-2t',field:'size',value:'2T',status:'CANONICAL',canonical:'2T'},
{id:'asian-size',field:'size',value:'Asian Size XL',status:'BLOCK',canonical:null},
];
