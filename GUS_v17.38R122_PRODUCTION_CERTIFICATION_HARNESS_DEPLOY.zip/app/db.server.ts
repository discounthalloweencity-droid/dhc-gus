import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as typeof globalThis & { __dhcPrisma?: PrismaClient };

// One Prisma pool per Node process in every environment. The production build can
// load server chunks through more than one module path; keeping the client on
// globalThis prevents accidental duplicate pools from exhausting managed MySQL.
export const db = globalForPrisma.__dhcPrisma ?? (globalForPrisma.__dhcPrisma = new PrismaClient());
