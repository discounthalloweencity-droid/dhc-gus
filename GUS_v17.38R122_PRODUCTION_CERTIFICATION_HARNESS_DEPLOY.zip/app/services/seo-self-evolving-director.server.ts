import {db} from '../db.server';
import {runAutonomousLearningDirector} from './autonomous-learning-director.server';
import {runSeoExperimentLab,loadSeoExperimentLab} from './seo-experiment-lab.server';

const SOURCE='SEO_SELF_EVOLVING_DIRECTOR', DAY=86400000;
const parse=(v:any,f:any={})=>{try{return typeof v==='string'?JSON.parse(v):v??f}catch{return f}};
const clamp=(n:number,a=0,b=1)=>Math.max(a,Math.min(b,n));

export const SEO_EVOLUTION_DOCTRINE={
 mission:'Continuously improve DHC organic discovery using measured evidence, SEO-specific time-series experiments, institutional memory and safe adaptation. Optimize for qualified traffic and revenue; never manufacture certainty or rankings.',
 hierarchy:['OBSERVE','DIAGNOSE','HYPOTHESIZE','EXECUTE_REVERSIBLY','MEASURE_7_14_28_60_90','LEARN','PROMOTE_OR_REJECT','DEFEND'],
 evidence:['Google Search Console','verified crawl/indexation evidence','DHC conversion and revenue evidence','verified backlink proof','catalog/inventory evidence','SEO before/after outcomes with matched reference pages when available','documented search-engine guidance'],
 safeguards:['no ranking guarantees','no randomized SEO variants for crawlers/visitors','no automated Google scraping','no link spam/PBNs/paid ranking manipulation','no scaled thin AI content','no doorway pages','no fake reviews/experience/data','no destructive URL migration without approval','do not rewrite winning pages without evidence'],
 learning:'A tactic becomes reusable DHC knowledge only after repeated mature checkpoints support it. Failed tactics are retained as negative knowledge so Gus does not repeat them blindly.',
 research:'External SEO guidance is candidate knowledge, not truth. Prefer primary search-engine documentation; compare with DHC evidence; test reversible tactics before broad adoption.'
};

function seoLesson(x:any){const r=parse(x.resultJson,{}),c=parse(x.controlJson,{}),v=parse(x.variantJson,{}),ev=r.seoEvaluation||{};const ptype=(()=>{try{const p=new URL(x.targetId).pathname;return p.startsWith('/products/')?'PRODUCT':p.startsWith('/collections/')?'COLLECTION':p.startsWith('/blogs/')?'BLOG':p==='/'?'HOME':'OTHER';}catch{return 'OTHER'}})();const query=String(v?.workResult?.query||v?.workEvidence?.query||v?.workEvidence?.primaryQuery||'').trim()||null;return {id:x.id,name:x.name,page:x.targetId,status:x.status,classification:String(ev.classification||'OBSERVE'),confidence:Number(ev.confidence||0),score:Number(ev.averageScore||0),measurements:Array.isArray(r.measurements)?r.measurements:[],context:{actionType:c.actionType||v?.workResult?.actionType||null,targetType:ptype,targetPage:x.targetId,pageType:ptype,query,changeId:c.changeId||null,sourceWorkItemId:c.sourceWorkItemId||null,matchedControlPage:c.matchedControlPage||null,change:v.change||null}};}

async function retireOpposite(shop:string,keys:string[]){for(const knowledgeKey of keys){const rows=await db.brainKnowledge.findMany({where:{shop,knowledgeKey,status:'ACTIVE'}});for(const r of rows)await db.brainKnowledge.update({where:{id:r.id},data:{status:'RETIRED',retiredAt:new Date()}}).catch(()=>{});}}
async function persistLesson(shop:string,lesson:any,positive:boolean){const key=positive?`SEO_TACTIC_WIN:${lesson.id}`:`SEO_TACTIC_REJECT:${lesson.id}`;const opposite=positive?`SEO_TACTIC_REJECT:${lesson.id}`:`SEO_TACTIC_WIN:${lesson.id}`;await retireOpposite(shop,[opposite]);const statement=positive?`DHC SEO evidence supports reusing the treatment pattern from “${lesson.name}” on materially similar pages. The page showed repeated mature improvement checkpoints with ${Math.round(lesson.confidence*100)}% observational confidence. Reuse cautiously and keep measuring; this is DHC-specific evidence, not a universal ranking rule.`:`Do not broadly repeat the SEO treatment pattern from “${lesson.name}” on similar pages without a new reason to test it. DHC measurement showed regression or repeated negative mature checkpoints. Preserve this negative lesson and prefer alternative tactics.`;const prior=await db.brainKnowledge.findFirst({where:{shop,knowledgeKey:key,version:1}});const evidence={experimentId:lesson.id,classification:lesson.classification,confidence:lesson.confidence,score:lesson.score,context:lesson.context,measurements:lesson.measurements.map((m:any)=>({windowDays:m.windowDays,evaluation:m.evaluation,periods:m.periods}))};if(prior){await db.brainKnowledge.update({where:{id:prior.id},data:{statement,evidenceJson:JSON.stringify(evidence),confidence:clamp(lesson.confidence),status:'ACTIVE',activatedAt:prior.activatedAt||new Date(),retiredAt:null}});return prior.id;}const row=await db.brainKnowledge.create({data:{shop,knowledgeKey:key,topic:positive?'SEO_EXPERIMENT_LEARNING':'SEO_NEGATIVE_LEARNING',statement,evidenceJson:JSON.stringify(evidence),source:SOURCE,confidence:clamp(lesson.confidence),status:'ACTIVE',version:1,activatedAt:new Date()}});return row.id;}

export async function runSeoSelfEvolvingDirector(shop:string,force=false){
 const last=await db.growthEvidence.findFirst({where:{shop,source:SOURCE},orderBy:{importedAt:'desc'}});
 if(!force&&last&&Date.now()-last.importedAt.getTime()<DAY)return {status:'NOT_DUE',lastRun:last.importedAt};
 const seoLab=await runSeoExperimentLab(shop,force);
 const learning=await runAutonomousLearningDirector(shop,force);
 const since120=new Date(Date.now()-120*DAY);
 const [experiments,signals,work,knowledge]=await Promise.all([
  db.retailExperiment.findMany({where:{shop,createdAt:{gte:since120}},orderBy:{createdAt:'desc'},take:500}),
  db.intelligenceSignal.findMany({where:{shop,observedAt:{gte:since120},OR:[{signalType:{contains:'SEO'}},{source:{contains:'SEO'}},{signalType:{contains:'BACKLINK'}},{source:{contains:'BACKLINK'}}]},orderBy:{observedAt:'desc'},take:500}),
  db.executiveWorkItem.findMany({where:{shop,domain:'SEO'},orderBy:{updatedAt:'desc'},take:400}),
  db.brainKnowledge.findMany({where:{shop,status:{in:['ACTIVE','CANDIDATE']},OR:[{topic:{contains:'SEO'}},{topic:{contains:'SEARCH'}},{topic:{contains:'BACKLINK'}}]},orderBy:{createdAt:'desc'},take:300})
 ]);
 const lessons=experiments.filter(x=>String(x.experimentKey||'').startsWith('SEOEXP:')).map(seoLesson);
 const winners=lessons.filter(x=>x.classification==='PROMOTE'&&x.confidence>=.65),failed=lessons.filter(x=>x.classification==='REJECT'&&x.confidence>=.55);
 const active=work.filter(x=>!['COMPLETED','FAILED','CANCELLED','ROLLED_BACK','DISMISSED'].includes(String(x.status))),completed=work.filter(x=>['COMPLETED','VERIFIED'].includes(String(x.status)));
 const highSignals=signals.filter(x=>['HIGH','CRITICAL'].includes(String(x.severity)));
 const matureCheckpoints=lessons.reduce((n,x)=>n+x.measurements.filter((m:any)=>Number(m.windowDays)>=28&&!m.error).length,0);
 const confidence=clamp((Math.min(1,matureCheckpoints/20)*.35)+(Math.min(1,signals.length/100)*.15)+(Math.min(1,knowledge.length/50)*.20)+(Math.min(1,completed.length/50)*.20)+(Math.min(1,lessons.length/20)*.10));
 const maturity=confidence>=.85?'ADAPTIVE':confidence>=.60?'LEARNING':confidence>=.35?'OBSERVING':'BOOTSTRAPPING';
 const promoted:any[]=[];for(const w of winners.slice(0,30)){await persistLesson(shop,w,true);promoted.push({experimentId:w.id,name:w.name,confidence:w.confidence,score:w.score,page:w.page,actionType:w.context.actionType});}
 const negative:any[]=[];for(const f of failed.slice(0,30)){await persistLesson(shop,f,false);negative.push({experimentId:f.id,name:f.name,confidence:f.confidence,score:f.score,page:f.page,actionType:f.context.actionType});}
 const snapshot={status:'DONE',observedAt:new Date().toISOString(),maturity,confidence,doctrine:SEO_EVOLUTION_DOCTRINE,seoLab,learningStatus:(learning as any)?.status||'UNKNOWN',counts:{seoExperiments:lessons.length,runningSeoExperiments:lessons.filter(x=>x.status==='RUNNING').length,completedSeoExperiments:lessons.filter(x=>x.status==='COMPLETE').length,matureCheckpoints,verifiedWins:winners.length,rejectedTreatments:failed.length,seoSignals:signals.length,highSignals:highSignals.length,activeSeoWork:active.length,completedSeoWork:completed.length,seoKnowledge:knowledge.length,promotedLessons:promoted.length,negativeLessons:negative.length},promoted,negative,nextFocus:highSignals.slice(0,15).map(x=>({type:x.signalType,entity:x.entityId,metric:x.metric,severity:x.severity,score:x.score,confidence:x.confidence})),rule:'SEO learning is measured with time-based GSC windows and optional matched reference pages. Gus never uses visitor-level randomized SEO variants, and it never converts correlation into universal causal truth.'};
 await db.growthEvidence.create({data:{shop,source:SOURCE,reference:snapshot.observedAt,rowsJson:JSON.stringify(snapshot)}});
 return snapshot;
}

export async function loadSeoSelfEvolvingDirector(shop:string){
 const row=await db.growthEvidence.findFirst({where:{shop,source:SOURCE},orderBy:{importedAt:'desc'}}),d=parse(row?.rowsJson,{}),lab=await loadSeoExperimentLab(shop);
 const learned=await db.brainKnowledge.count({where:{shop,source:SOURCE,status:'ACTIVE'}});
 return {status:d.status||'WAITING',observedAt:row?.importedAt||null,maturity:d.maturity||'BOOTSTRAPPING',confidence:Number(d.confidence||0),counts:{...(d.counts||{}),runningExperiments:lab.counts.running,completedExperiments:lab.experiments.filter((x:any)=>x.status==='COMPLETE').length,learnedSeoRules:learned,promote:lab.counts.promote,reject:lab.counts.reject},experiments:lab.experiments,promoted:d.promoted||[],negative:d.negative||[],nextFocus:d.nextFocus||[],doctrine:SEO_EVOLUTION_DOCTRINE};
}
