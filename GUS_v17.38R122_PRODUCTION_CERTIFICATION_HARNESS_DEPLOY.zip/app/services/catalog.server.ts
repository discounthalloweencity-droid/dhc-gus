export function auditCatalog(title: string, tags: string[], productType?: string | null) {
  const text = `${title} ${tags.join(" ")} ${productType || ""}`.toLowerCase();
  const findings: Array<{code:string;severity:string;message:string}> = [];
  const women = /\b(women|woman|female|ladies)\b/.test(text);
  const men = /\b(men|man|male|mens)\b/.test(text);
  const kids = /\b(kids|kid|child|children|youth|toddler|boy|girl)\b/.test(text);
  if (women && men) findings.push({code:"GENDER_CONFLICT",severity:"HIGH",message:"Product appears tagged/classified for both Men and Women."});
  if (kids && (women || men) && !/family|matching/.test(text)) findings.push({code:"AGE_CONFLICT",severity:"MEDIUM",message:"Product contains both child and adult audience signals."});
  if (/cm\b|centimeter/.test(text)) findings.push({code:"METRIC_SIZE_SIGNAL",severity:"LOW",message:"Metric sizing language detected; verify shopper-facing US sizing."});
  return findings;
}
