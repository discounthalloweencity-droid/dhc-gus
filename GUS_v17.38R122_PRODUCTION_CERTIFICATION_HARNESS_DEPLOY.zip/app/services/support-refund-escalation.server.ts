import {db} from '../db.server';
import {sendSupportEmail} from './support-email-outbound.server';
import {loadSupportMailboxConfigPrivate,supportInternalAddress} from './support-email-config.server';
import {persistIntelligenceSignal} from './intelligence-signal.server';
import {assignSupportPersona,supportPersonaByKey,supportSignature} from './customer-service-persona';

const clean=(v:unknown,max=1000)=>String(v??'').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim().slice(0,max);
const money=(amount:any,currency='USD')=>{const n=Number(amount);return Number.isFinite(n)?`${currency} ${n.toFixed(2)}`:'Verify refundable amount in Shopify';};
const parse=(v:any)=>{try{return JSON.parse(String(v||'{}'));}catch{return {};}};

function subjectFromInbound(content:string|undefined|null,orderName:string){const m=String(content||'').match(/^Subject:\s*(.+)$/m);return m?.[1]?`Re: ${m[1].replace(/^Re:\s*/i,'').trim()}`:`Refund update — ${orderName}`;}
function addBusinessDays(start:Date,days:number){const d=new Date(start);let left=Math.max(0,Math.floor(days));while(left>0){d.setDate(d.getDate()+1);const day=d.getDay();if(day!==0&&day!==6)left--;}return d;}
export function businessDaysElapsed(start:Date,end=new Date()){let d=new Date(start);d.setHours(0,0,0,0);const target=new Date(end);target.setHours(0,0,0,0);let n=0;while(d<target){d.setDate(d.getDate()+1);const day=d.getDay();if(day!==0&&day!==6)n++;if(n>1000)break;}return n;}

async function emailThreadContext(shop:string,caseKey:string){
 const row=await db.gusMessage.findFirst({where:{shop,intent:'SUPPORT_EMAIL_STATE',actionJson:{contains:`\"caseKey\":\"${caseKey}\"`}},orderBy:{createdAt:'desc'}}).catch(()=>null);
 if(!row)return {conversationId:null as number|null,state:{} as any,persona:assignSupportPersona(shop,caseKey),threadId:null as string|null,replyToMessageId:null as string|null,subject:null as string|null};
 const state=parse(row.actionJson)?.emailCaseState||{};
 const inbound=await db.gusMessage.findFirst({where:{shop,conversationId:row.conversationId,intent:'SUPPORT_EMAIL_INBOUND'},orderBy:{createdAt:'desc'}}).catch(()=>null);
 const meta=parse(inbound?.actionJson);
 return {conversationId:row.conversationId,state,persona:supportPersonaByKey(state.supportAgentKey)||assignSupportPersona(shop,caseKey),threadId:meta?.threadId||null,replyToMessageId:meta?.messageId||null,subject:inbound?.content||null};
}
async function saveRefundThreadState(shop:string,ctx:any,next:any,content:string){if(!ctx.conversationId)return;await db.gusMessage.create({data:{conversationId:ctx.conversationId,shop,role:'STATE',intent:'SUPPORT_EMAIL_STATE',content,actionJson:JSON.stringify({emailCaseState:{...ctx.state,...next},version:'DHC-CSD-EMAIL-1.1'})}});}
function customerRefundConfirmation(orderName:string,persona:any,minDays:number,maxDays:number){return `Hi there,\n\nYour refund for ${orderName} has been approved and submitted back to the original payment method.\n\nPlease allow ${minDays}–${maxDays} business days for the credit to appear. Your bank or payment provider controls the final posting time, so it may show sooner. If it still hasn’t appeared after ${maxDays} business days, reply directly to this email and I’ll reopen the case and escalate it for you—you won’t need to start over.\n\n${supportSignature(persona)}`;}

export async function escalateSupportRefund(shop:string,c:any,verified:any,reason:string){
 const order=verified.order;
 const amount=c.issueType==='CANCEL'?money(order?.total?.amount,order?.total?.currencyCode||'USD'):'Verify the exact affected-item refundable amount in Shopify';
 const to=await supportInternalAddress(shop);
 const subject=`REFUND ESCALATION — ${order.name} — ${c.caseKey}`;
 const message=`Refund escalation from Gus Customer Service Director\n\nOrder: ${order.name}\nCase: ${c.caseKey}\nIssue: ${c.issueType}\nReason: ${clean(reason,500)}\nVerified refund guidance: ${amount} to the original payment method\n\nAction required:\n1. Open ${order.name} in Shopify.\n2. Confirm the order or affected item has not already been refunded.\n3. Verify Shopify's calculated refundable amount before submitting.\n4. Process the eligible refund to the original payment method.\n5. Return to Gus Customer Service Director and click Refund Approved / Submitted only after Shopify confirms the refund submission.\n\nThis escalation does not itself move money.`;
 const outbound=await sendSupportEmail(shop,to,subject,message,{caseKey:c.caseKey,orderName:order.name,kind:'INTERNAL_REFUND_ESCALATION'});
 const updated=await db.supportCase.update({where:{id:c.id},data:{status:'OWNER_ACTION_REQUIRED',resolvedAt:null,summary:`${clean(c.summary,1300)}\nREFUND_ESCALATED: ${clean(reason,500)} | ${amount}`.slice(0,2000)}});
 await persistIntelligenceSignal(shop,{source:'CUSTOMER_SERVICE_DIRECTOR',signalType:'REFUND_ESCALATION',entityType:'SUPPORT_CASE',entityId:c.caseKey,metric:'REFUND_ESCALATED',score:100,confidence:1,severity:'HIGH',evidence:{caseKey:c.caseKey,orderName:order.name,reason:clean(reason,500),amount,internalEmailSent:Boolean(outbound?.sent)},dedupeParts:['REFUND_ESCALATION',c.caseKey,String(Date.now()).slice(0,-5)]});
 return {case:updated,outbound,amount};
}

export async function markSupportRefundCompleted(shop:string,c:any,verified:any,customerEmail:string){
 const order=verified.order;
 const amount=c.issueType==='CANCEL'?money(order?.total?.amount,order?.total?.currencyCode||'USD'):'Shopify-confirmed eligible refund amount';
 const config=await loadSupportMailboxConfigPrivate(shop).catch(()=>null);
 const minDays=Math.max(1,Number(config?.refundEtaMinBusinessDays||5));const maxDays=Math.max(minDays,Number(config?.refundEtaMaxBusinessDays||10));
 const ctx=await emailThreadContext(shop,c.caseKey);const approvedAt=new Date();const expectedBy=addBusinessDays(approvedAt,maxDays);
 const message=customerRefundConfirmation(order.name,ctx.persona,minDays,maxDays);
 const customerOutbound=await sendSupportEmail(shop,customerEmail,subjectFromInbound(ctx.subject,order.name),message,{caseKey:c.caseKey,orderName:order.name,kind:'REFUND_APPROVED_CUSTOMER_NOTICE',threadId:ctx.threadId,replyToMessageId:ctx.replyToMessageId,supportAgent:ctx.persona.name});
 if(!customerOutbound?.sent){
  const updated=await db.supportCase.update({where:{id:c.id},data:{status:'OWNER_ACTION_REQUIRED',resolvedAt:null,summary:`${clean(c.summary,1450)}\nREFUND_APPROVED_NOTIFICATION_FAILED: Shopify refund confirmed, customer email was not confirmed sent.`.slice(0,2000)}});
  await persistIntelligenceSignal(shop,{source:'CUSTOMER_SERVICE_DIRECTOR',signalType:'REFUND_FOLLOWUP',entityType:'SUPPORT_CASE',entityId:c.caseKey,metric:'REFUND_APPROVED_NOTICE_FAILED',score:100,confidence:1,severity:'HIGH',evidence:{caseKey:c.caseKey,orderName:order.name,amount,provider:customerOutbound?.provider||'UNKNOWN'},dedupeParts:['REFUND_APPROVED_NOTICE_FAILED',c.caseKey,String(Date.now()).slice(0,-5)]});
  return {case:updated,amount,customerOutbound,notified:false,refundEtaMinBusinessDays:minDays,refundEtaMaxBusinessDays:maxDays};
 }
 const updated=await db.supportCase.update({where:{id:c.id},data:{status:'RESOLVED',resolvedAt:approvedAt,summary:`${clean(c.summary,1320)}\nREFUND_APPROVED_CUSTOMER_NOTIFIED: ${amount} | expected ${minDays}-${maxDays} business days | ${approvedAt.toISOString()}`.slice(0,2000)}});
 await saveRefundThreadState(shop,ctx,{caseKey:c.caseKey,orderName:order.name,lastResolution:'REFUND_APPROVED_CUSTOMER_NOTIFIED',supportAgentKey:ctx.persona.key,refundApprovedAt:approvedAt.toISOString(),refundExpectedBy:expectedBy.toISOString(),refundEtaMinBusinessDays:minDays,refundEtaMaxBusinessDays:maxDays,refundFollowupEscalationSent:false},'Refund approved/submitted; customer notified and refund follow-up window started.');
 await persistIntelligenceSignal(shop,{source:'CUSTOMER_SERVICE_DIRECTOR',signalType:'REFUND_FOLLOWUP',entityType:'SUPPORT_CASE',entityId:c.caseKey,metric:'REFUND_APPROVED_CUSTOMER_NOTIFIED',score:100,confidence:1,severity:'INFO',evidence:{caseKey:c.caseKey,orderName:order.name,amount,staffConfirmed:true,customerNotified:true,refundEtaMinBusinessDays:minDays,refundEtaMaxBusinessDays:maxDays,expectedBy:expectedBy.toISOString(),supportAgent:ctx.persona.name},dedupeParts:['REFUND_APPROVED_CUSTOMER_NOTIFIED',c.caseKey,approvedAt.toISOString().slice(0,10)]});
 return {case:updated,amount,customerOutbound,notified:true,refundEtaMinBusinessDays:minDays,refundEtaMaxBusinessDays:maxDays,expectedBy};
}

export async function escalateMissingRefundFollowup(shop:string,c:any,verified:any,customerEmail:string,priorState:any){
 const order=verified.order;const amount=c.issueType==='CANCEL'?money(order?.total?.amount,order?.total?.currencyCode||'USD'):'Verify the exact affected-item refundable amount in Shopify';const to=await supportInternalAddress(shop);
 const approvedAt=String(priorState?.refundApprovedAt||'unknown');const maxDays=Number(priorState?.refundEtaMaxBusinessDays||10);
 const subject=`REFUND NOT RECEIVED — ESCALATION — ${order.name} — ${c.caseKey}`;
 const message=`Refund receipt follow-up escalation\n\nOrder: ${order.name}\nCase: ${c.caseKey}\nCustomer: ${customerEmail}\nPreviously approved/submitted: ${approvedAt}\nExpected posting window: up to ${maxDays} business days\nRefund guidance: ${amount}\n\nCustomer reports the refund has still not appeared after the expected window.\n\nAction required:\n1. Verify the Shopify refund transaction and processor status.\n2. Confirm the refund was submitted to the correct original payment method.\n3. If the transaction failed, stalled, or was reversed, correct/reissue it as permitted.\n4. Update case ${c.caseKey} with the processor/refund reference and outcome.\n5. Click Refund Approved / Submitted again only after a valid refund submission is confirmed.\n\nDo not ask the customer to restart the case.`;
 const outbound=await sendSupportEmail(shop,to,subject,message,{caseKey:c.caseKey,orderName:order.name,kind:'INTERNAL_REFUND_NOT_RECEIVED_ESCALATION'});
 const updated=await db.supportCase.update({where:{id:c.id},data:{status:'OWNER_ACTION_REQUIRED',resolvedAt:null,summary:`${clean(c.summary,1300)}\nREFUND_NOT_RECEIVED_ESCALATED: customer reported missing refund after expected window | ${amount}`.slice(0,2000)}});
 await persistIntelligenceSignal(shop,{source:'CUSTOMER_SERVICE_EMAIL',signalType:'REFUND_FOLLOWUP',entityType:'SUPPORT_CASE',entityId:c.caseKey,metric:'REFUND_NOT_RECEIVED_ESCALATED',score:100,confidence:1,severity:'CRITICAL',evidence:{caseKey:c.caseKey,orderName:order.name,amount,approvedAt,maxDays,internalEmailSent:Boolean(outbound?.sent)},dedupeParts:['REFUND_NOT_RECEIVED_ESCALATED',c.caseKey,String(Date.now()).slice(0,-5)]});
 return {case:updated,outbound,amount};
}
