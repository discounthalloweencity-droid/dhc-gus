import {graphqlData} from './shopify-api.server.ts';

export const PRODUCT_SIZING_INTELLIGENCE_VERSION='DHC-PRODUCT-SIZING-1.0-R85';

export type ProductSizingCandidate={
 id:string;title:string;handle:string;url:string;score:number;availableSizes:string[];allSizes:string[];priceFrom:number|null;
};
export type ProductSizingResult={
 version:string;
 status:'EXACT_WITH_MEASUREMENTS'|'EXACT_WITHOUT_MEASUREMENTS'|'AMBIGUOUS'|'NO_MATCH';
 confidence:number;
 product:ProductSizingCandidate|null;
 candidates:ProductSizingCandidate[];
 measurementLines:string[];
 measurementSource:string|null;
 availableSizes:string[];
 allSizes:string[];
 outOfStockSizes:string[];
 fitNotes:string[];
 evidenceWarnings:string[];
 needsCatalogEvidence:boolean;
};

const SEARCH_QUERY=`#graphql query GusProductSizingSearch($query:String!){products(first:10,query:$query,sortKey:RELEVANCE){nodes{id title handle status productType vendor totalInventory variants(first:100){nodes{id title price availableForSale inventoryQuantity selectedOptions{name value}}}}}}`;
const PRODUCT_DETAIL_QUERY=`#graphql query GusProductSizingDetail($id:ID!){product(id:$id){id title handle status productType vendor descriptionHtml options{name values} variants(first:100){nodes{id title price availableForSale inventoryQuantity selectedOptions{name value}}} sizeChart:metafield(namespace:"custom",key:"size_chart"){key type value} sizeGuide:metafield(namespace:"custom",key:"size_guide"){key type value} fitGuide:metafield(namespace:"custom",key:"fit_guide"){key type value} measurements:metafield(namespace:"custom",key:"measurements"){key type value} sizing:metafield(namespace:"custom",key:"sizing"){key type value} sizeAndFit:metafield(namespace:"custom",key:"size_and_fit"){key type value}}}`;

const genericWords=new Set(['women','womens','woman','men','mens','man','adult','kid','kids','child','children','costume','costumes','halloween','jumpsuit','jumpsuits','dress','dresses','outfit','outfits','set','sets','size','sizes','sizing','guide','chart','fit','measurement','measurements','please','hello','thanks','thank','wondering','what','which','your','the','for','with','about','specifically','looking','need','want','product','link','im','ive','id','my','our','we','us','is','are','do','does','did','this','that','it','its','of','to','an','as','can','could']);
function clean(v:unknown,max=6000){return String(v??'').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim().slice(0,max);}
function normalize(v:unknown){return clean(v,1000).toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g,' ').trim();}
function tokens(v:unknown){return [...new Set((normalize(v).match(/[a-z0-9]{2,}/g)||[]).filter(x=>!genericWords.has(x)))];}
function productHandleFromText(text:string){
 const m=String(text||'').match(/(?:https?:\/\/(?:www\.)?discounthalloweencity\.com)?\/products\/([a-z0-9][a-z0-9-]*)/i);return m?m[1].toLowerCase():null;
}
function queryTerms(text:string){
 const noUrls=String(text||'').replace(/https?:\/\/\S+/gi,' ');const specific=tokens(noUrls);if(specific.length)return specific.slice(0,6);
 return [...new Set((normalize(noUrls).match(/[a-z0-9]{3,}/g)||[]).filter(x=>!['please','hello','thanks','thank','wondering','what','which','your','the','for','with','about','specifically','looking','need','want','size','sizing','guide','chart','measurements'].includes(x)))].slice(0,6);
}
function sizeValues(variants:any[],availableOnly:boolean){
 const vals:string[]=[];for(const v of variants||[]){const available=v?.availableForSale===true&&(v?.inventoryQuantity==null||Number(v.inventoryQuantity)!==0);if(availableOnly&&!available)continue;for(const o of v?.selectedOptions||[])if(/\b(size|sizing|age)\b/i.test(String(o?.name||''))){const value=clean(o?.value,80);if(value&&!vals.some(x=>x.toLowerCase()===value.toLowerCase()))vals.push(value);}}
 return vals;
}
function candidateFromProduct(p:any,text:string,forcedHandle:string|null):ProductSizingCandidate{
 const customer=tokens(text),title=normalize(p?.title||''),handleText=normalize(String(p?.handle||'').replace(/-/g,' ')),type=normalize(p?.productType||''),variantText=normalize((p?.variants?.nodes||[]).map((v:any)=>v?.title||'').join(' '));let score=0;
 if(forcedHandle&&String(p?.handle||'').toLowerCase()===forcedHandle)score=1;
 else if(customer.length){const tokenScores=customer.map(t=>title.includes(t)?1:variantText.includes(t)?.85:handleText.includes(t)?.70:type.includes(t)?.50:0);score=tokenScores.reduce((a,b)=>a+b,0)/tokenScores.length;
  const input=normalize(text);if(/\b(?:women|womens|woman|female|lady|ladies)\b/.test(input)&&/\b(?:women|womens|woman|female|lady|ladies)\b/.test(`${title} ${type}`))score+=.18;
  if(/\b(?:men|mens|man|male)\b/.test(input)&&/\b(?:men|mens|man|male)\b/.test(`${title} ${type}`))score+=.18;
  if(/\b(?:kids|kid|child|children|boy|girl)\b/.test(input)&&/\b(?:kids|kid|child|children|boy|girl)\b/.test(`${title} ${type}`))score+=.15;
  if(/\b(?:jumpsuit|bodysuit|zentai)\b/.test(input)&&/\b(?:jumpsuit|bodysuit|zentai)\b/.test(`${title} ${handleText}`))score+=.08;
  score=Math.min(1,score);
 }
 const variants=p?.variants?.nodes||[];const prices=variants.map((v:any)=>Number(v.price)).filter((n:number)=>Number.isFinite(n)&&n>=0);
 return {id:String(p?.id||''),title:clean(p?.title,200),handle:String(p?.handle||''),url:`https://discounthalloweencity.com/products/${encodeURIComponent(String(p?.handle||''))}`,score:Number(score.toFixed(3)),availableSizes:sizeValues(variants,true),allSizes:sizeValues(variants,false),priceFrom:prices.length?Math.min(...prices):null};
}
function htmlDecode(s:string){return s.replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&quot;/gi,'"').replace(/&#39;|&apos;/gi,"'").replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&#(\d+);/g,(_,n)=>{const x=Number(n);return Number.isFinite(x)&&x>0&&x<=0x10ffff?String.fromCodePoint(x):_;});}
export function sizingHtmlToLines(html:string){
 let s=String(html||'');s=s.replace(/<\s*(?:br|\/p|\/div|\/li|\/tr|h[1-6])\b[^>]*>/gi,'\n').replace(/<\s*(?:td|th)\b[^>]*>/gi,' | ').replace(/<[^>]+>/g,' ');s=htmlDecode(s).replace(/\r/g,'\n');
 return s.split(/\n+/).map(x=>x.replace(/\s*\|\s*/g,' | ').replace(/\s+/g,' ').trim().replace(/^\|\s*|\s*\|$/g,'')).filter(Boolean);
}
function flattenJson(value:any,prefix='',depth=0):string[]{if(depth>5)return[];if(value==null)return[];if(typeof value==='string'||typeof value==='number'||typeof value==='boolean')return [`${prefix?`${prefix}: `:''}${String(value)}`];if(Array.isArray(value))return value.flatMap((v,i)=>flattenJson(v,prefix||String(i+1),depth+1));if(typeof value==='object')return Object.entries(value).flatMap(([k,v])=>flattenJson(v,prefix?`${prefix} ${k}`:k,depth+1));return[];}
function valueLines(value:string){const raw=String(value||'').trim();if(!raw)return[];if(/^[\[{]/.test(raw)){try{return flattenJson(JSON.parse(raw)).map(x=>clean(x,500)).filter(Boolean);}catch{}}return sizingHtmlToLines(raw);}
function cmFriendly(line:string){
 let out=String(line||'');
 out=out.replace(/(\d+(?:\.\d+)?)\s*(?:-|–|—|to)\s*(\d+(?:\.\d+)?)\s*cm\b/gi,(_,a,b)=>{const x=Number(a),y=Number(b);return `${a}-${b} cm (${(x/2.54).toFixed(1)}-${(y/2.54).toFixed(1)} in)`;});
 out=out.replace(/(?<![\d.-])(\d+(?:\.\d+)?)\s*cm\b/gi,(_,a)=>`${a} cm (${(Number(a)/2.54).toFixed(1)} in)`);
 return out;
}
function measurementish(line:string){const s=String(line||'');const hasMeasure=/\b(bust|chest|waist|hip|hips|height|length|shoulder|sleeve|inseam|torso|thigh|weight|fit|measurement|size)\b/i.test(s);const sizeRow=/^(?:xs|s|m|l|xl|xxl|xxxl|2xl|3xl|4xl|5xl|one size)\b/i.test(s);const hasNumeric=/\d/.test(s);const hasUnit=/\b(?:cm|mm|in|inch|inches|lb|lbs|kg)\b|["”]/i.test(s);return hasNumeric&&hasUnit&&(hasMeasure||sizeRow);}
function fitNote(line:string){return /\b(?:runs? (?:small|large)|slim fit|loose fit|relaxed fit|stretch|elastic|recommend(?:ed)?|choose|between sizes|true to size|fit note)\b/i.test(line)&&line.length<=320;}
export function extractProductSizingEvidence(product:any){
 const sources:Array<{label:string;lines:string[]}>=[];for(const [label,mf] of [['Size chart',product?.sizeChart],['Size guide',product?.sizeGuide],['Fit guide',product?.fitGuide],['Measurements',product?.measurements],['Sizing',product?.sizing],['Size and fit',product?.sizeAndFit]] as any[]){if(mf?.value)sources.push({label,lines:valueLines(mf.value)});}if(product?.descriptionHtml)sources.push({label:'Product description',lines:sizingHtmlToLines(product.descriptionHtml)});
 const measurements:string[]=[];const notes:string[]=[];let source:string|null=null;for(const entry of sources){for(const line of entry.lines){if(measurementish(line)){const v=cmFriendly(clean(line,500));if(!measurements.some(x=>x.toLowerCase()===v.toLowerCase())){measurements.push(v);if(!source)source=entry.label;}}else if(fitNote(line)){const v=clean(line,320);if(!notes.some(x=>x.toLowerCase()===v.toLowerCase()))notes.push(v);}}}
 return {measurementLines:measurements.slice(0,14),fitNotes:notes.slice(0,6),measurementSource:source};
}
export function isProductSizingQuestion(text:string){return /\b(?:size guide|size chart|sizing|measurements?|bust|chest|waist|hips?|inseam|height|what size|which size|size options)\b/i.test(String(text||''));}

async function productCandidates(admin:any,text:string){
 const handle=productHandleFromText(text);const terms=queryTerms(text);const attempts=handle?[`handle:${handle}`]:[terms.slice(0,5).join(' '),terms.slice(0,3).join(' '),terms[0]||''].filter((x,i,a)=>x&&a.indexOf(x)===i);let rows:any[]=[];
 for(const q of attempts){const data:any=await graphqlData(admin,SEARCH_QUERY,{query:`status:active ${q}`.trim()}).catch(()=>null);rows=(data?.products?.nodes||[]).filter((p:any)=>p?.status==='ACTIVE');if(rows.length)break;}
 const candidates=rows.map(p=>candidateFromProduct(p,text,handle)).filter(x=>x.id&&x.handle).sort((a,b)=>b.score-a.score||a.title.localeCompare(b.title));return {handle,candidates};
}
export async function productSizingIntelligence(admin:any,text:string):Promise<ProductSizingResult>{
 const found=await productCandidates(admin,text);const top=found.candidates[0]||null,second=found.candidates[1]||null;const exact=Boolean(top&&(found.handle?top.score===1:(top.score>=.72&&(!second||top.score-second.score>=.10||top.score>=.90))));
 if(!top)return {version:PRODUCT_SIZING_INTELLIGENCE_VERSION,status:'NO_MATCH',confidence:0,product:null,candidates:[],measurementLines:[],measurementSource:null,availableSizes:[],allSizes:[],outOfStockSizes:[],fitNotes:[],evidenceWarnings:['No live product match was found from the customer wording.'],needsCatalogEvidence:false};
 if(!exact)return {version:PRODUCT_SIZING_INTELLIGENCE_VERSION,status:'AMBIGUOUS',confidence:top.score,product:null,candidates:found.candidates.slice(0,4),measurementLines:[],measurementSource:null,availableSizes:[],allSizes:[],outOfStockSizes:[],fitNotes:[],evidenceWarnings:['Multiple live products are plausible; exact product confirmation is required before quoting measurements.'],needsCatalogEvidence:false};
 const data:any=await graphqlData(admin,PRODUCT_DETAIL_QUERY,{id:top.id}).catch(()=>null);const p=data?.product;if(!p?.id)return {version:PRODUCT_SIZING_INTELLIGENCE_VERSION,status:'AMBIGUOUS',confidence:top.score,product:null,candidates:found.candidates.slice(0,4),measurementLines:[],measurementSource:null,availableSizes:[],allSizes:[],outOfStockSizes:[],fitNotes:[],evidenceWarnings:['Exact product detail readback failed; measurements were not quoted.'],needsCatalogEvidence:false};
 const variants=p.variants?.nodes||[],available=sizeValues(variants,true),all=sizeValues(variants,false);const out=all.filter((s:string)=>!available.some((a:string)=>a.toLowerCase()===s.toLowerCase()));const evidence=extractProductSizingEvidence(p);const product={...candidateFromProduct(p,text,found.handle),score:top.score,availableSizes:available,allSizes:all};const warnings:string[]=[];if(!evidence.measurementLines.length)warnings.push('The exact live listing does not currently expose verified product-specific body measurements in the recognized size/fit fields or description.');if(!available.length)warnings.push('No currently purchasable size values were verified for the exact product.');
 return {version:PRODUCT_SIZING_INTELLIGENCE_VERSION,status:evidence.measurementLines.length?'EXACT_WITH_MEASUREMENTS':'EXACT_WITHOUT_MEASUREMENTS',confidence:found.handle?1:Math.max(.85,top.score),product,candidates:[product],measurementLines:evidence.measurementLines,measurementSource:evidence.measurementSource,availableSizes:available,allSizes:all,outOfStockSizes:out,fitNotes:evidence.fitNotes,evidenceWarnings:warnings,needsCatalogEvidence:!evidence.measurementLines.length};
}

export function productSizingReply(result:ProductSizingResult){
 if(result.status==='NO_MATCH')return `I want to give you the exact size information rather than a generic chart. I couldn't confidently identify the product from this message. Please send the exact product name or paste the Discount Halloween City product link, and I'll check the live listing and its product-specific measurements.`;
 if(result.status==='AMBIGUOUS'){
  const lines=result.candidates.slice(0,4).map((p,i)=>`${i+1}. ${p.title}${p.availableSizes.length?` — available sizes: ${p.availableSizes.join(', ')}`:''}\n${p.url}`).join('\n\n');return `I found more than one live product that could match, and I don't want to quote the wrong size chart. Which of these are you looking at?\n\n${lines}`;
 }
 const p=result.product!;const sizes=result.availableSizes.length?`Currently available sizes: ${result.availableSizes.join(', ')}.`:'I could not verify a currently available size selection from the live listing.';const link=`Product: ${p.url}`;
 if(result.status==='EXACT_WITH_MEASUREMENTS'){
  const chart=result.measurementLines.map(x=>`• ${x}`).join('\n');const fit=result.fitNotes.length?`\n\nVerified fit notes:\n${result.fitNotes.map(x=>`• ${x}`).join('\n')}`:'';return `I found the exact live listing: ${p.title}.\n\n${sizes}\n\nHere is the product-specific size/fit information currently stored on that listing${result.measurementSource?` (${result.measurementSource})`:''}:\n${chart}${fit}\n\n${link}\n\nThese are the measurements from this product's listing, not a generic women's size chart. If you send your height, bust/chest, waist, and hips, I can compare them directly with this chart.`;
 }
 return `I found the exact live listing: ${p.title}.\n\n${sizes}\n\nThe listing does not currently contain verified product-specific body measurements that I can safely quote, so I don't want to substitute a generic size chart and risk steering you to the wrong size.\n\n${link}\n\nIf you send your height, bust/chest, waist, and hips, I can keep the question tied to this exact product while the size-chart evidence is corrected.`;
}
