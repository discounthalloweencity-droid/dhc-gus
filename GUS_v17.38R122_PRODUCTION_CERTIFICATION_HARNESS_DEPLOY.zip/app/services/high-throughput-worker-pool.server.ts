import {db} from '../db.server';
import {automationState} from './automation-control.server';
import {runRetailMissionWorker} from './retail-mission-worker.server';
import {turboCleanupState,maybeAutoDisableTurbo,reconcileAutoTurbo} from './turbo-cleanup-control.server';
import {shopifyCapacitySnapshot} from './shopify-capacity-telemetry.server';
import {capacityBand} from './shopify-capacity-rules';
import {desiredConcurrency,workerBatchSize,etaHours,operationalFault,type ThroughputMode} from './high-throughput-worker-rules';

const TURBO_ENGINES=/CATALOG|NORMAL|QUALITY|TAXON|PDP/i;
export async function throughputSnapshot(shop:string,mode:ThroughputMode='NORMAL',claimableEngines:readonly string[]=[]){
 const since=new Date(Date.now()-60*60_000);
 const [states,recent,claimableQueued]=await Promise.all([
  db.retailMission.groupBy({by:['state'],where:{shop},_count:{_all:true}}),
  db.retailMission.findMany({where:{shop,finishedAt:{gte:since}},select:{state:true,startedAt:true,finishedAt:true},take:5000}),
  claimableEngines.length?db.retailMission.count({where:{shop,state:'QUEUED',engine:{in:[...claimableEngines]}}}):Promise.resolve(0)
 ]);
 const counts=Object.fromEntries(states.map(x=>[x.state,x._count._all]));const queued=Number(counts.QUEUED||0)+Number(counts.SCORED||0)+Number(counts.DISCOVERED||0);const running=Number(counts.RUNNING||0);
 const done=recent.filter(x=>['SUCCESS','PARTIAL'].includes(x.state)).length,failed=recent.filter(x=>['FAILED','DEAD_LETTER'].includes(x.state)).length;const rate=done+failed?failed/(done+failed):0;
 const actionable=claimableEngines.length?claimableQueued:queued;const capacity=shopifyCapacitySnapshot();const concurrency=desiredConcurrency({mode,queued:actionable,running,recentFailureRate:rate,throttled:capacity.throttled,capacityPct:capacity.observedAt?capacity.availablePct:undefined});const iph=done;return {mode,queued,claimableQueued:actionable,unhandledQueued:Math.max(0,queued-actionable),running,completedLastHour:done,failedLastHour:failed,recentFailureRate:Math.round(rate*1000)/1000,desiredConcurrency:concurrency,batchSize:workerBatchSize(concurrency),itemsPerHour:iph,etaHours:etaHours(actionable,iph),fault:operationalFault({queued:actionable,running,mode}),shopifyCapacity:{...capacity,band:capacityBand(capacity.availablePct,capacity.throttled)}};
}
export async function runHighThroughputPool(shop:string,handlers:Record<string,any>,mode?:ThroughputMode){
 let control=await turboCleanupState(shop);
 const registered=Object.keys(handlers);
 const pre=await throughputSnapshot(shop,control.enabled?'TURBO_CLEANUP':'NORMAL',registered);control=await reconcileAutoTurbo(shop,{queued:pre.claimableQueued,itemsPerHour:pre.itemsPerHour,running:pre.running});
 const effectiveMode:ThroughputMode=mode??(control.enabled?'TURBO_CLEANUP':'NORMAL');
 const master=await automationState(shop);if(!master?.running)return {status:'STOPPED'};
 const snap=await throughputSnapshot(shop,effectiveMode,registered);await maybeAutoDisableTurbo(shop,snap.claimableQueued);const eligible=effectiveMode==='TURBO_CLEANUP'?registered.filter(x=>TURBO_ENGINES.test(x)):registered;
 // Safety/customer handlers remain available in turbo; cleanup receives spare capacity, never exclusive capacity.
 const safety=registered.filter(x=>/INVENTORY|ORDER|FULFILL|CUSTOMER|RISK/i.test(x));
 const engines=[...new Set([...safety,...eligible])];const selected=Object.fromEntries(engines.filter(k=>handlers[k]).map(k=>[k,handlers[k]]));
 if(!Object.keys(selected).length)return {status:'NO_REGISTERED_HANDLERS',...snap};
 const result=await runRetailMissionWorker(shop,selected,snap.batchSize,snap.desiredConcurrency);
 return {status:'DONE',...snap,...result,workerSlots:snap.desiredConcurrency};
}
