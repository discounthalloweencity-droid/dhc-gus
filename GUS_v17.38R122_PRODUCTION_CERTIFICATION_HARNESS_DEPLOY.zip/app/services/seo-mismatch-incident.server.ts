import {db} from '../db.server';
import pkg from '../../package.json';
import {globalSeoMismatchCircuit,SEO_MISMATCH_HISTORY_MS} from './seo-write-circuit-rules';

const CIRCUIT_MESSAGE='SEO write circuit open after verified Shopify readback mismatch';
const LEGACY_MESSAGE='SEO mismatch';

function mismatchWhere(shop:string){
 return {shop,action:{in:['SEO','COLLECTION_SEO'] as any},status:'FAILED',updatedAt:{gte:new Date(Date.now()-SEO_MISMATCH_HISTORY_MS)},OR:[{error:{contains:'SEO mismatch'}},{error:{contains:'SEO_READBACK_MISMATCH'}}]};
}

function safeJson(value:any){try{return JSON.stringify(value).slice(0,16000);}catch{return JSON.stringify({unserializable:true});}}

export async function reconcileSeoMismatchRegistry(shop:string,extraContext:Record<string,unknown>={}){
 const rows:any[]=await db.actionProposal.findMany({where:mismatchWhere(shop) as any,orderBy:{updatedAt:'desc'},take:500}).catch(()=>[] as any[]);
 const circuit=globalSeoMismatchCircuit(rows,Date.now());
 const legacy=await db.errorEvent.findMany({where:{shop,status:{in:['OPEN','ACKNOWLEDGED']},source:'ACTION_EXECUTION',message:{contains:LEGACY_MESSAGE}},take:50}).catch(()=>[] as any[]);
 if(legacy.length){
  await db.errorEvent.updateMany({where:{id:{in:legacy.map((x:any)=>x.id)},shop},data:{status:'SUPERSEDED',resolvedAt:new Date(),resolution:'0.16.57 R15 consolidated repeated Shopify SEO readback mismatches into one bounded SEO_WRITE_CIRCUIT incident. Per-target failures remain in ActionProposal history for audit and quarantine.'}}).catch(()=>{});
 }
 const existing=await db.errorEvent.findFirst({where:{shop,source:'SEO_WRITE_CIRCUIT',message:CIRCUIT_MESSAGE},orderBy:{lastSeenAt:'desc'}}).catch(()=>null);
 if(!circuit.open){
  if(existing&&existing.status!=='RESOLVED')await db.errorEvent.update({where:{id:existing.id},data:{status:'RESOLVED',resolvedAt:new Date(),resolution:`Runtime ${pkg.version} verified the global SEO mismatch hold is no longer active. Failed target proposals remain quarantined individually and are not replayed blindly.`,lastSeenAt:new Date()}}).catch(()=>{});
  return {status:'CLOSED' as const,count:rows.length,uniqueTargets:new Set(rows.map(r=>`${r.action}:${r.productGid}`)).size,holdUntil:circuit.holdUntil};
 }
 const uniqueTargets=new Set(rows.map(r=>`${r.action}:${r.productGid}`));
 const context={
  policy:'ONE_INCIDENT_BOUNDED_RETRY',
  failedProposals:rows.length,
  uniqueTargets:uniqueTargets.size,
  holdMs:circuit.holdMs,
  holdUntil:circuit.holdUntil?.toISOString()||null,
  newestProposalIds:rows.slice(0,20).map(r=>r.id),
  newestTargets:rows.slice(0,20).map(r=>({action:r.action,productGid:r.productGid,updatedAt:r.updatedAt,error:String(r.error||'').slice(0,500)})),
  behavior:'Pause new autonomous SEO writes during the global hold; keep individual failed targets quarantined; perform late Shopify readback before any retry; do not increment Black Box occurrence count for each polling cycle.',
  ...extraContext
 };
 if(existing){
  await db.errorEvent.update({where:{id:existing.id},data:{severity:'ERROR',contextJson:safeJson(context),releaseVersion:pkg.version,status:'OPEN',resolvedAt:null,resolution:null,lastSeenAt:new Date()}}).catch(()=>{});
 }else{
  const {registerError}=await import('./error-registry.server');
  await registerError({shop,source:'SEO_WRITE_CIRCUIT',route:'/app/actions',message:CIRCUIT_MESSAGE,severity:'ERROR',context}).catch(()=>null);
 }
 return {status:'OPEN' as const,count:rows.length,uniqueTargets:uniqueTargets.size,holdUntil:circuit.holdUntil,holdMs:circuit.holdMs};
}

export async function recordSeoMismatchIncident(shop:string,context:Record<string,unknown>={}){
 return reconcileSeoMismatchRegistry(shop,context);
}
