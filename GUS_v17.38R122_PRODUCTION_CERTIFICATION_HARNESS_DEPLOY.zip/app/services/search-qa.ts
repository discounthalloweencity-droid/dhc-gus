export type SearchQaProduct={
  title:string;
  productType?:string|null;
  vendor?:string|null;
  tags?:string[]|string|null;
  handle?:string|null;
  url?:string|null;
  available?:boolean|null;
};

export type SearchQaIssue={code:string;severity:'critical'|'warning';message:string};
export type SearchQaResult={product:SearchQaProduct;score:number;issues:SearchQaIssue[]};
export type SearchQaSimulation={query:string;score:number;grade:'PASS'|'WARN'|'FAIL';results:SearchQaResult[];criticalCount:number;warningCount:number;zeroResults:boolean};

const normalize=(v:unknown)=>String(v??'').toLowerCase().replace(/[’']/g,'').replace(/[^a-z0-9+]+/g,' ').trim();
const terms=(v:unknown)=>normalize(v).split(/\s+/).filter(Boolean);
const unique=<T,>(xs:T[])=>[...new Set(xs)];

const AUDIENCE_GROUPS:Record<string,string[]>= {
  women:['women','womens','woman','female','ladies','lady'],
  men:['men','mens','man','male'],
  girls:['girl','girls'],
  boys:['boy','boys'],
  kids:['kid','kids','child','children','childrens','youth'],
  toddler:['toddler','toddlers'],
  baby:['baby','infant','newborn'],
  plus:['plus size','plus','extended size','curvy'],
};
const PRODUCT_TYPES:Record<string,string[]>= {
  costume:['costume','costumes','cosplay','outfit','dress'],
  mask:['mask','masks'],
  wig:['wig','wigs','hair'],
  decoration:['decor','decoration','decorations','yard','home decor'],
  inflatable:['inflatable','inflatables'],
  animatronic:['animatronic','animatronics'],
  skeleton:['skeleton','skeletons','skull','skulls'],
  prop:['prop','props','weapon','weapons'],
  accessory:['accessory','accessories','makeup','glove','gloves','hat','hats','cape','capes','teeth','fangs'],
};
const THEMES=['witch','vampire','ninja','clown','pirate','zombie','ghost','skeleton','reaper','grim reaper','pumpkin','werewolf','monster','devil','angel','fairy','princess','cowboy','cowgirl','police','firefighter','doctor','nurse','cat','bat','spider','michael myers','myers','beetlejuice','kpop','gothic','goth','tarot','graveyard'];

function fieldText(p:SearchQaProduct){
  const tags=Array.isArray(p.tags)?p.tags.join(' '):String(p.tags??'');
  return normalize([p.title,p.productType,p.vendor,tags,p.handle].filter(Boolean).join(' '));
}
function matchedKeys(query:string,groups:Record<string,string[]>) {
  const q=` ${normalize(query)} `;
  return Object.entries(groups).filter(([,values])=>values.some(v=>q.includes(` ${normalize(v)} `))).map(([k])=>k);
}
function inferredTheme(query:string){
  const q=` ${normalize(query)} `;
  return THEMES.filter(x=>q.includes(` ${normalize(x)} `));
}
function audienceFlags(text:string){
  const has=(k:string)=>(AUDIENCE_GROUPS[k]||[]).some(v=>` ${text} `.includes(` ${normalize(v)} `));
  return {has,women:has('women'),men:has('men'),girls:has('girls'),boys:has('boys'),kids:has('kids'),toddler:has('toddler'),baby:has('baby')};
}
function audienceCompatible(wanted:string[], text:string){
  const f=audienceFlags(text);
  // Inclusive products are compatible with a specific shopper audience. "Boys & Girls"
  // should never fail a boys query merely because the product also serves girls.
  if(wanted.includes('women')&&f.women)return true;
  if(wanted.includes('men')&&f.men)return true;
  if(wanted.includes('girls')&&(f.girls||f.kids))return true;
  if(wanted.includes('boys')&&(f.boys||f.kids))return true;
  if(wanted.includes('kids')&&(f.kids||f.girls||f.boys||f.toddler))return true;
  if(wanted.includes('toddler')&&(f.toddler||f.kids))return true;
  if(wanted.includes('baby')&&f.baby)return true;
  if(wanted.includes('plus')&&/\bplus(?:\s+size)?\b/.test(text))return true;
  return false;
}
function conflictsAudience(wanted:string[], text:string){
  const f=audienceFlags(text);
  // Exact/inclusive target evidence wins over opposite-audience tokens.
  if(audienceCompatible(wanted,text))return false;
  const adultWanted=wanted.includes('women')||wanted.includes('men');
  const childWanted=wanted.some(x=>['girls','boys','kids','toddler','baby'].includes(x));
  if(wanted.includes('women')&&f.men)return true;
  if(wanted.includes('men')&&f.women)return true;
  if(wanted.includes('girls')&&(f.boys||f.men))return true;
  if(wanted.includes('boys')&&(f.girls||f.women))return true;
  if(adultWanted&&(f.kids||f.toddler||f.baby||f.girls||f.boys))return true;
  if(childWanted&&(f.women||f.men))return true;
  return false;
}

export function gradeSearchResult(query:string,product:SearchQaProduct,index=0):SearchQaResult{
  const qTerms=unique(terms(query).filter(x=>x.length>1));
  const text=fieldText(product);
  const wantedAudiences=matchedKeys(query,AUDIENCE_GROUPS);
  const wantedTypes=matchedKeys(query,PRODUCT_TYPES);
  const wantedThemes=inferredTheme(query);
  const issues:SearchQaIssue[]=[];
  let score=42;

  const overlap=qTerms.filter(t=>` ${text} `.includes(` ${t} `)).length;
  score+=Math.min(30,overlap*8);
  score+=Math.max(0,10-index);

  if(wantedAudiences.length){
    if(conflictsAudience(wantedAudiences,text)){
      score-=50;issues.push({code:'AUDIENCE_MISMATCH',severity:'critical',message:'Result conflicts with shopper gender/age intent.'});
    } else if(audienceCompatible(wantedAudiences,text)) score+=10;
  }

  if(wantedTypes.length){
    const typeMatch=wantedTypes.some(k=>(PRODUCT_TYPES[k]||[]).some(v=>` ${text} `.includes(` ${normalize(v)} `)));
    if(typeMatch) score+=14;
    else {score-=30;issues.push({code:'PRODUCT_TYPE_MISMATCH',severity:'critical',message:'Result does not match the requested product type.'});}
  }

  if(wantedThemes.length){
    const themeMatch=wantedThemes.some(v=>` ${text} `.includes(` ${normalize(v)} `));
    if(themeMatch) score+=12;
    else {score-=20;issues.push({code:'THEME_MISMATCH',severity:'warning',message:'Result is weak for the requested theme/character.'});}
  }

  if(product.available===false){score-=35;issues.push({code:'UNAVAILABLE',severity:'critical',message:'Unavailable product surfaced in shopper search.'});}
  if(overlap===0){score-=22;issues.push({code:'LOW_TOKEN_RELEVANCE',severity:'warning',message:'Title/type/tags have no meaningful query-token overlap.'});}
  score=Math.max(0,Math.min(100,Math.round(score)));
  return {product,score,issues};
}

export function gradeSearchSimulation(query:string,products:SearchQaProduct[]):SearchQaSimulation{
  if(!products.length)return {query,score:0,grade:'FAIL',results:[],criticalCount:1,warningCount:0,zeroResults:true};
  const results=products.slice(0,20).map((p,i)=>gradeSearchResult(query,p,i));
  const weighted=results.reduce((sum,r,i)=>sum+r.score*(1/Math.sqrt(i+1)),0);
  const weights=results.reduce((sum,_,i)=>sum+(1/Math.sqrt(i+1)),0);
  const score=Math.round(weighted/weights);
  const criticalCount=results.flatMap(r=>r.issues).filter(i=>i.severity==='critical').length;
  const warningCount=results.flatMap(r=>r.issues).filter(i=>i.severity==='warning').length;
  const topCritical=results.slice(0,5).some(r=>r.issues.some(i=>i.severity==='critical'));
  const grade=score>=80&&!topCritical?'PASS':score>=60&&!topCritical?'WARN':'FAIL';
  return {query,score,grade,results,criticalCount,warningCount,zeroResults:false};
}

export const DEFAULT_SEARCH_QA_QUERIES=[
  'women vampire costume','girls witch costume','boys ninja costume','kids skeleton costume','plus size witch costume',
  'michael myers mask','scary clown mask','green clown costume','family halloween costumes','couples costume',
  'outdoor skeleton','graveyard decorations','halloween inflatable','animatronic','gothic costume','vampire teeth',
  'witch wig','pirate costume','toddler pumpkin costume','baby halloween costume','cheap women halloween costume',
  'scary costume for 10 year old'
];
