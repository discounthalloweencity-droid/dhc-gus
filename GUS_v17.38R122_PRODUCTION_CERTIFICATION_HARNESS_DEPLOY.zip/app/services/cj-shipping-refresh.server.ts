import {db} from '../db.server';
import {fetchCjFreight,selectCjShipping} from './cj-shipping.server';

type WarehouseConfig={originCountry:string;method:string;processingMinDays:number;processingMaxDays:number};
function configMap(){
 const raw=String(process.env.GUS_CJ_FREIGHT_CONFIG_JSON||'').trim();if(!raw)return null;
 try{const parsed=JSON.parse(raw);if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))return null;return parsed as Record<string,WarehouseConfig>;}catch{return null;}
}
function validConfig(x:any):x is WarehouseConfig{return Boolean(x)&&/^[A-Z]{2}$/.test(String(x.originCountry||'').toUpperCase())&&String(x.method||'').trim().length>0&&Number.isSafeInteger(Number(x.processingMinDays))&&Number.isSafeInteger(Number(x.processingMaxDays))&&Number(x.processingMinDays)>=0&&Number(x.processingMaxDays)>=Number(x.processingMinDays);}
export async function refreshCjShippingEvidence(shop:string,fetcher:typeof fetch=fetch){
 const token=String(process.env.CJ_ACCESS_TOKEN||'').trim(),configs=configMap();
 if(!token)return {status:'NOT_CONFIGURED',refreshed:0,skipped:0,errors:['CJ_ACCESS_TOKEN is not configured.']};
 if(!configs)return {status:'NOT_CONFIGURED',refreshed:0,skipped:0,errors:['GUS_CJ_FREIGHT_CONFIG_JSON is not configured. Exact warehouse origin, shipping method and verified processing bounds are required before Gus may create CJ shipping promises.']};
 const limit=Math.max(1,Math.min(100,Number(process.env.GUS_CJ_FREIGHT_MAX_LINKS_PER_RUN||20)||20));
 const links=await db.supplierVariantLink.findMany({where:{shop,supplier:'CJ',enabled:true},orderBy:{updatedAt:'asc'},take:limit});
 const variantIds=[...new Set(links.map(x=>x.variantGid))],allLinks=variantIds.length?await db.supplierVariantLink.findMany({where:{shop,enabled:true,variantGid:{in:variantIds}},select:{variantGid:true}}):[];
 const counts=new Map<string,number>();for(const l of allLinks)counts.set(l.variantGid,(counts.get(l.variantGid)||0)+1);
 let refreshed=0,skipped=0;const errors:string[]=[];const now=new Date(),validUntil=new Date(now.getTime()+24*60*60*1000);
 for(const link of links){try{
  const cfg=configs[link.warehouse];if(!validConfig(cfg)){skipped++;continue;}
  const destination=String(link.destinationCountry||'US').toUpperCase();if(!/^[A-Z]{2}$/.test(destination))throw new Error('Mapped destination country is invalid');
  const quotes=await fetchCjFreight({vid:link.supplierVariantId,origin:String(cfg.originCountry).toUpperCase(),destination,warehouseId:link.warehouse||undefined},token,fetcher),selected=selectCjShipping(quotes,String(cfg.method),Number(cfg.processingMinDays),Number(cfg.processingMaxDays)),reference=`CJ_FREIGHT:${selected.reference}:${selected.method}`;
  await db.supplierShippingEvidence.upsert({where:{linkId:link.id},create:{linkId:link.id,minDays:selected.minDays,maxDays:selected.maxDays,source:'CJ_FREIGHT_API',reference,verifiedAt:now,validUntil},update:{minDays:selected.minDays,maxDays:selected.maxDays,source:'CJ_FREIGHT_API',reference,verifiedAt:now,validUntil}});
  // Variant-level shipping cost is only safe when this is the sole enabled supplier link.
  if((counts.get(link.variantGid)||0)===1){for(const [field,value] of [['shipping_cost',selected.priceUsd],['shipping_days',selected.maxDays]] as const)await db.supplierFactRecord.upsert({where:{shop_variantGid_field:{shop,variantGid:link.variantGid,field}},create:{shop,variantGid:link.variantGid,field,value,source:'CJ_FREIGHT_API',reference,verifiedAt:now,validUntil},update:{value,source:'CJ_FREIGHT_API',reference,verifiedAt:now,validUntil}});}
  refreshed++;
 }catch(error:any){errors.push(`${link.variantGid}: ${String(error?.message||error)}`);}}
 return {status:'DONE',refreshed,skipped,errors,rule:'CJ shipping evidence is refreshed only for explicitly configured warehouse/method/processing-time mappings. No origin, method or processing promise is inferred.'};
}
