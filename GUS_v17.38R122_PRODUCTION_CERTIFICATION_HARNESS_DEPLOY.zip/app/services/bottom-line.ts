export const ORGANIC_MONTHLY_REVENUE_FLOOR=30000;
export const SITE_CONVERSION_RATE_FLOOR=.04;
export type RevenueFloorInput={monthTarget?:number;monthToDateOrganicRevenue:number;daysElapsed:number;daysInMonth:number;organicSessions:number;organicOrders:number;siteSessions:number;siteOrders:number;revenue:number;adSpend?:number|null;attributedAdRevenue?:number|null;attributedAdOrders?:number|null;preAdContribution?:number|null;refunds?:number|null};
const finite=(n:number)=>Number.isFinite(n);
export function bottomLineMetrics(i:RevenueFloorInput){
 const target=finite(i.monthTarget??NaN)?Math.max(0,i.monthTarget!):ORGANIC_MONTHLY_REVENUE_FLOOR;
 const daysElapsed=Math.max(1,Math.min(i.daysInMonth,Math.floor(i.daysElapsed||1))),daysRemaining=Math.max(0,i.daysInMonth-daysElapsed);
 const pace=i.monthToDateOrganicRevenue/daysElapsed*i.daysInMonth; const gap=Math.max(0,target-i.monthToDateOrganicRevenue); const requiredDaily=daysRemaining?gap/daysRemaining:gap;
 const organicCvr=i.organicSessions>0?i.organicOrders/i.organicSessions:null,siteCvr=i.siteSessions>0?i.siteOrders/i.siteSessions:null,aov=i.siteOrders>0?i.revenue/i.siteOrders:null;
 const ordersNeeded=aov&&aov>0?Math.ceil(gap/aov):null; const sessionsNeeded=ordersNeeded!=null?Math.ceil(ordersNeeded/SITE_CONVERSION_RATE_FLOOR):null;
 const adSpend=i.adSpend??null,adRevenue=i.attributedAdRevenue??null,adOrders=i.attributedAdOrders??null; const roas=adSpend!=null&&adSpend>0&&adRevenue!=null?adRevenue/adSpend:null; const cac=adSpend!=null&&adSpend>0&&adOrders!=null&&adOrders>0?adSpend/adOrders:null;
 const preAd=i.preAdContribution??null,contributionAfterAds=preAd!=null&&adSpend!=null?preAd-adSpend:null; const marketingRoi=contributionAfterAds!=null&&adSpend!=null&&adSpend>0?contributionAfterAds/adSpend:null; const contributionMargin=preAd!=null&&i.revenue>0?preAd/i.revenue:null; const breakEvenRoas=contributionMargin!=null&&contributionMargin>0?1/contributionMargin:null;
 return {target,pace,pacePercent:target>0?pace/target:null,gap,requiredDaily,daysElapsed,daysRemaining,organicCvr,siteCvr,aov,ordersNeeded,sessionsNeeded,conversionFloor:SITE_CONVERSION_RATE_FLOOR,conversionGap:siteCvr==null?null:Math.max(0,SITE_CONVERSION_RATE_FLOOR-siteCvr),adSpend,roas,cac,preAdContribution:preAd,contributionAfterAds,marketingRoi,contributionMargin,breakEvenRoas,refunds:i.refunds??null,onRevenuePace:pace>=target,onConversionTarget:siteCvr!=null&&siteCvr>=SITE_CONVERSION_RATE_FLOOR};
}
