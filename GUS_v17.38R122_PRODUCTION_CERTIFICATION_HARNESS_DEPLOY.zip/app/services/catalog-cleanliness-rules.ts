import {normalizeCatalogValue,productTypeMismatch,type CatalogField} from './catalog-data-normalizer-rules.ts';

export type CleanlinessCounts={products:number;dirtySize:number;dirtyColor:number;dirtyTheme:number;dirtyGender:number;dirtyAge:number;dirtyAudience:number;reviewSize:number;variantSizeIssues:number;variantColorIssues:number;productTypeIssues:number;totalIssues:number};
export const emptyCleanliness=():CleanlinessCounts=>({products:0,dirtySize:0,dirtyColor:0,dirtyTheme:0,dirtyGender:0,dirtyAge:0,dirtyAudience:0,reviewSize:0,variantSizeIssues:0,variantColorIssues:0,productTypeIssues:0,totalIssues:0});

const fields:CatalogField[]=['size','color','theme','gender','age_group','audience'];
export function cleanlinessForProduct(p:any):CleanlinessCounts{
 const c=emptyCleanliness();c.products=1;
 for(const m of p?.metafields?.nodes||[]){if(!fields.includes(m.key as CatalogField))continue;const n=normalizeCatalogValue(m.key as CatalogField,m.value);if(n.status==='CANONICAL')continue;c.totalIssues++;
  if(m.key==='size'){if(n.status==='REVIEW')c.reviewSize++;else c.dirtySize++;}
  else if(m.key==='color')c.dirtyColor++;
  else if(m.key==='theme')c.dirtyTheme++;
  else if(m.key==='gender')c.dirtyGender++;
  else if(m.key==='age_group')c.dirtyAge++;
  else if(m.key==='audience')c.dirtyAudience++;
 }
 for(const v of p?.variants?.nodes||[])for(const o of v.selectedOptions||[]){
  const name=String(o.name||'').trim();let field:'size'|'color'|null=null;
  if(/^(size|sizes|size\s*\/\s*age|age|clothing size)$/i.test(name))field='size';else if(/^(color|colour|colors|colours)$/i.test(name))field='color';if(!field)continue;
  const n=normalizeCatalogValue(field,o.value);if(n.status!=='CANONICAL'){c.totalIssues++;if(field==='size'){c.variantSizeIssues++;if(n.status==='REVIEW')c.reviewSize++;}else c.variantColorIssues++;}
 }
 if(productTypeMismatch(p).mismatch){c.productTypeIssues++;c.totalIssues++;}
 return c;
}
export function addCleanliness(a:CleanlinessCounts,b:CleanlinessCounts):CleanlinessCounts{const out=emptyCleanliness();for(const k of Object.keys(out) as (keyof CleanlinessCounts)[])out[k]=Number(a[k]||0)+Number(b[k]||0);return out;}
export function cleanlinessPercent(c:CleanlinessCounts){const denominator=Math.max(1,c.products+c.totalIssues);return Math.round((1-c.totalIssues/denominator)*1000)/10;}
