export type CapturedError = {message:string;stack?:string|null;name?:string|null};
export function normalizeCapturedError(error:unknown):CapturedError{
 if(error instanceof Error)return {message:error.message||error.name||'Unknown error',stack:error.stack||null,name:error.name||null};
 if(typeof error==='string')return {message:error.trim()||'Empty error string received without diagnostic context.'};
 if(Array.isArray(error)&&error.length===0)return {message:'Empty error array received without diagnostic context.'};
 if(error&&typeof error==='object'&&Object.keys(error as Record<string,unknown>).length===0)return {message:'Empty error object received without diagnostic context.'};
 try{const message=JSON.stringify(error);return {message:message&&message!=='[]'&&message!=='{}'?message:'Empty error payload received without diagnostic context.'};}catch{return {message:'Unserializable error'};}
}
export function responseForCapturedError(errorKey:string,status=503){
 return Response.json({ok:false,error:status===503?'Service temporarily unavailable':'Internal error',errorKey},{status});
}
