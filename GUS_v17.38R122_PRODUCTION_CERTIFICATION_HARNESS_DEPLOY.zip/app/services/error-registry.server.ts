import { createHash, randomBytes } from "node:crypto";
import { db } from "../db.server";
import pkg from "../../package.json";
import {reconcileHistoricalErrors} from './error-reconciliation.server';
import {databaseSchemaHealth} from './database-schema-health.server';

export type ErrorSeverity = "INFO"|"WARN"|"ERROR"|"FATAL";
export type ErrorInput = {
  shop:string; source:string; message:string; severity?:ErrorSeverity;
  stack?:string|null; route?:string|null; jobType?:string|null; context?:unknown;
  releaseVersion?:string;
};

const SECRET_PATTERN = /(access[_-]?token|api[_-]?secret|password|authorization|cookie|session|secret|token)\s*[=:]\s*([^\s,;]+)/ig;
function redactText(value:string|undefined|null){
  if(!value)return null;
  return value.replace(SECRET_PATTERN,"$1=[REDACTED]").slice(0,16000);
}
function safeContext(value:unknown){
  if(value==null)return null;
  try{
    const json=JSON.stringify(value,(key,val)=>/token|secret|password|authorization|cookie|session/i.test(key)?"[REDACTED]":val);
    return json.slice(0,16000);
  }catch{return JSON.stringify({unserializable:true});}
}
function fingerprint(input:ErrorInput){
  const normalized=[input.source,input.route||"",input.jobType||"",input.message.replace(/\b\d+\b/g,"#").slice(0,1000)].join("|");
  return createHash("sha256").update(normalized).digest("hex").slice(0,32);
}
function publicKey(){return `DHC-${randomBytes(4).toString("hex").toUpperCase()}`;}

export async function registerError(input:ErrorInput){
  const fp=fingerprint(input); const now=new Date();
  const existing=await db.errorEvent.findUnique({where:{shop_fingerprint:{shop:input.shop,fingerprint:fp}}});
  const message=redactText(input.message)||"Unknown error";
  const stack=redactText(input.stack);
  const contextJson=safeContext(input.context);
  if(existing){
    return db.errorEvent.update({where:{id:existing.id},data:{
      severity:input.severity||existing.severity,source:input.source,route:input.route||existing.route,jobType:input.jobType||existing.jobType,
      message,stack,contextJson,releaseVersion:input.releaseVersion||pkg.version,status:"OPEN",resolvedAt:null,resolution:null,
      occurrenceCount:{increment:1},lastSeenAt:now
    }});
  }
  return db.errorEvent.create({data:{shop:input.shop,errorKey:publicKey(),fingerprint:fp,severity:input.severity||"ERROR",source:input.source,
    route:input.route||null,jobType:input.jobType||null,message,stack,contextJson,releaseVersion:input.releaseVersion||pkg.version,firstSeenAt:now,lastSeenAt:now}});
}

export async function buildDiagnosticBundle(shop:string){
  const warnings:string[]=[];
  const schemaHealth=await databaseSchemaHealth();
  const reconciliation=await reconcileHistoricalErrors(shop).catch(error=>{warnings.push(`historical error reconciliation: ${String((error as any)?.message||error).slice(0,500)}`);return {checked:0,superseded:0,releaseBoundary:null,proofs:[]};});
  async function safe<T>(label:string,task:Promise<T>,fallback:T):Promise<T>{
    try{return await task;}catch(error:any){
      const message=String(error?.message||error).slice(0,500);
      warnings.push(`${label}: ${message}`);
      console.warn(`[gus-diagnostics] ${label} unavailable`,message);
      return fallback;
    }
  }
  const [errors,jobs,changes,releases,automation,config,snapshotCount,findings]=await Promise.all([
    safe('errors',db.errorEvent.findMany({where:{shop},orderBy:{lastSeenAt:'desc'},take:300}),[] as any[]),
    safe('jobs',db.jobRun.findMany({where:{shop},orderBy:{startedAt:'desc'},take:100}),[] as any[]),
    safe('changes',db.changeLog.findMany({where:{shop},orderBy:{createdAt:'desc'},take:150}),[] as any[]),
    safe('releases',db.updateRelease.findMany({where:{shop},orderBy:{createdAt:'desc'},take:30}),[] as any[]),
    safe('automation',db.automationControl.findUnique({where:{shop}}),null as any),
    safe('config',db.storeConfig.findUnique({where:{shop}}),null as any),
    safe('product snapshots',db.productSnapshot.count({where:{shop}}),0),
    safe('findings',db.finding.findMany({where:{shop,status:'OPEN'},orderBy:{createdAt:'desc'},take:100}),[] as any[])
  ]);
  // Normalize every collection before diagnostics touch .length/filter/reduce. Older
  // production rows or a partially upgraded Prisma client must never make the
  // Black Box endpoint itself become another 5xx error.
  const errorRows=Array.isArray(errors)?errors:[];
  const jobRows=Array.isArray(jobs)?jobs:[];
  const changeRows=Array.isArray(changes)?changes:[];
  const releaseRows=Array.isArray(releases)?releases:[];
  const findingRows=Array.isArray(findings)?findings:[];
  const open=errorRows.filter((e:any)=>e?.status==='OPEN');
  const currentOpen=open.filter((e:any)=>e?.releaseVersion===pkg.version);
  const bySource=Object.entries(currentOpen.reduce((m:any,e:any)=>{const source=String(e?.source||'UNKNOWN');m[source]=(m[source]||0)+Number(e?.occurrenceCount||0);return m;},{})).sort((a:any,b:any)=>Number(b[1])-Number(a[1]));
  const health={
    runtime:true,database:schemaHealth.status!=='UNAVAILABLE',databaseSchema:schemaHealth.status,automationKnown:Boolean(automation),catalogEvidence:snapshotCount>0,
    openErrors:currentOpen.length,historicalOpenErrors:Math.max(0,open.length-currentOpen.length),fatalErrors:currentOpen.filter((e:any)=>e?.severity==='FATAL').length,repeatedErrors:currentOpen.filter((e:any)=>Number(e?.occurrenceCount||0)>1).length
  };
  return {schemaVersion:2,generatedAt:new Date().toISOString(),shop,releaseVersion:pkg.version,warnings,reconciliation,schemaHealth,health,summary:{openErrors:currentOpen.length,historicalOpenErrors:Math.max(0,open.length-currentOpen.length),totalOccurrences:errorRows.reduce((n:number,e:any)=>n+Number(e?.occurrenceCount||0),0),topSources:bySource.slice(0,10),productSnapshots:Number(snapshotCount||0),openFindings:findingRows.length},automation,config:config?{mode:config.mode,targetMargin:config.targetMargin,minimumMargin:config.minimumMargin,maxShippingDays:config.maxShippingDays,shippingChargeUnder:config.shippingChargeUnder,customerShippingCharge:config.customerShippingCharge,adultCostumeFloor:config.adultCostumeFloor,kidsCostumeFloor:config.kidsCostumeFloor,latexMaskFloor:config.latexMaskFloor}:null,errors:errorRows,jobs:jobRows,changes:changeRows,releases:releaseRows,findings:findingRows};
}
