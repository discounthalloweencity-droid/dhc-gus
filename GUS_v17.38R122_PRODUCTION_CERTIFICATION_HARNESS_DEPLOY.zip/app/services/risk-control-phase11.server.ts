import {db} from '../db.server';
import {deploymentReadiness} from './deployment-gates';
import {ensureConfig} from './scan.server';
import {automationState} from './automation-control.server';

export type RiskMode='approvals'|'margin'|'limits'|'rollbacks'|'anomalies'|'failed'|'audit'|'data'|'system';

export async function loadRiskControl(shop:string,mode:RiskMode){
 const [config,automation,deploy,pending,openFindings,errors,changes,jobs,snapshots,supplierLinks,coverage,actions,batches]=await Promise.all([
  ensureConfig(shop), automationState(shop), Promise.resolve(deploymentReadiness()),
  db.actionProposal.count({where:{shop,status:'PENDING'}}),
  db.finding.findMany({where:{shop,status:'OPEN'},orderBy:{createdAt:'desc'},take:160}),
  db.errorEvent.findMany({where:{shop},orderBy:{lastSeenAt:'desc'},take:120}),
  db.changeLog.findMany({where:{shop},orderBy:{createdAt:'desc'},take:180}),
  db.jobRun.findMany({where:{shop},orderBy:{startedAt:'desc'},take:100}),
  db.productSnapshot.findMany({where:{shop},orderBy:{capturedAt:'desc'},take:500}),
  db.supplierVariantLink.count({where:{shop,enabled:true}}),
  db.supplierVariantCoverage.findMany({where:{shop},take:200}),
  db.actionProposal.findMany({where:{shop},orderBy:{createdAt:'desc'},take:160}),
  db.bulkBatch.findMany({where:{shop},orderBy:{createdAt:'desc'},take:60}),
 ]);
 const openErrors=errors.filter(e=>e.status==='OPEN');
 const failedJobs=jobs.filter(j=>j.status==='FAILED');
 const failedActions=actions.filter(a=>a.status==='FAILED'||Boolean(a.error));
 const reversible=changes.filter(c=>c.reversible);
 const lowMargin=snapshots.filter(s=>s.margin!=null && s.margin<config.minimumMargin);
 const missingCost=snapshots.filter(s=>s.productCost==null||s.supplierShippingCost==null);
 const severe=openFindings.filter(f=>['HIGH','CRITICAL'].includes(f.severity));
 const incompleteCoverage=coverage.filter((c:any)=>!c.complete||!c.fulfillmentOwnerVerified);
 const activeBatches=batches.filter(b=>!['COMPLETED','FAILED','CANCELLED'].includes(b.status));
 return {mode,config,automation,deploy,pending,openFindings,errors,openErrors,changes,jobs,snapshots,failedJobs,failedActions,reversible,lowMargin,missingCost,severe,supplierLinks,incompleteCoverage,actions,batches,activeBatches,
  hardRules:{maxBulkActions:350,minimumMargin:config.minimumMargin,targetMargin:config.targetMargin,maxShippingDays:config.maxShippingDays,adultCostumeFloor:config.adultCostumeFloor,kidsCostumeFloor:config.kidsCostumeFloor,latexMaskFloor:config.latexMaskFloor,liveWrites:deploy.liveWritesEnabled}
 };
}
