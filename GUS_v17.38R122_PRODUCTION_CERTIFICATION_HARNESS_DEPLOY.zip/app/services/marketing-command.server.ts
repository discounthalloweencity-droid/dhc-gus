import { db } from "../db.server";

export async function marketingCommandSnapshot(shop: string) {
  const [bottom, spend, traffic, growth, orders, proposals] = await Promise.all([
    db.bottomLineSnapshot.findFirst({ where: { shop }, orderBy: { capturedAt: "desc" } }),
    db.marketingSpendEvidence.findMany({ where: { shop }, orderBy: { observedAt: "desc" }, take: 200 }),
    db.trafficEvidenceRecord.findFirst({ where: { shop, source: "TRAFFIC_QUALITY_SUMMARY" }, orderBy: { observedAt: "desc" } }),
    db.growthEvidence.findMany({ where: { shop }, orderBy: { importedAt: "desc" }, take: 50 }),
    db.orderProfitSnapshot.findMany({ where: { shop }, orderBy: { capturedAt: "desc" }, take: 200 }),
    db.actionProposal.findMany({ where: { shop, status: { in: ["PROPOSED", "APPROVED"] } }, orderBy: { createdAt: "desc" }, take: 100 }),
  ]);
  const revenue = orders.reduce((n,o)=>n+Number(o.grossRevenue||0),0);
  const orderCount = orders.length;
  const observedAov = orderCount ? revenue/orderCount : null;
  const channels = [...new Set(spend.map(s=>s.channel))].sort();
  const totalSpend = spend.reduce((n,s)=>n+Number(s.spend||0),0);
  const attributedRevenue = spend.reduce((n,s)=>n+Number(s.attributedRevenue||0),0);
  const attributedOrdersKnown = spend.filter(s=>s.attributedOrders!=null);
  const attributedOrders = attributedOrdersKnown.length ? attributedOrdersKnown.reduce((n,s)=>n+Number(s.attributedOrders||0),0) : null;
  const observedRoas = totalSpend>0 && attributedRevenue>0 ? attributedRevenue/totalSpend : null;
  const observedCac = totalSpend>0 && attributedOrders && attributedOrders>0 ? totalSpend/attributedOrders : null;
  let trafficQuality:any=null;try{trafficQuality=traffic?JSON.parse(traffic.evidenceJson||'{}'):null}catch{}
  const promoProposals = proposals.filter(p=>/promo|offer|discount|markdown|flash|upsell|bundle|conversion|cart/i.test(`${p.action} ${p.reason}`));
  return { bottom, spend, traffic, trafficQuality, growth, orders, proposals, promoProposals, channels, totalSpend, attributedRevenue, attributedOrders, observedRoas, observedCac, observedAov };
}
