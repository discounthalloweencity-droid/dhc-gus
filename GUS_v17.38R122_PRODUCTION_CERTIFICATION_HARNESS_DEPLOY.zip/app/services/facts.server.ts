import {db} from '../db.server';
import {parseMoney,parseDays,validFact,type SupplierFact} from './safety';
export const FACT_FIELDS=['product_cost','shipping_cost','shipping_days','payment_percent','payment_fixed'] as const;
export type FactField=typeof FACT_FIELDS[number];
export type FactInput={variantGid:string;field:FactField;value:number|string;source:string;reference:string;verifiedAt:string;validUntil?:string};
export function validateFactInput(row:FactInput,now=new Date()){
 if(!/^gid:\/\/shopify\/ProductVariant\/\d+$/.test(row.variantGid))throw new Error('A valid Shopify variant GID is required.');
 if(!FACT_FIELDS.includes(row.field))throw new Error('Unknown supplier fact field.');
 const value=row.field==='shipping_days'?parseDays(row.value):parseMoney(row.value);
 if(value==null)throw new Error('Invalid nonnegative numeric value.');
 const fact={value,source:row.source,reference:row.reference,verifiedAt:row.verifiedAt,validUntil:row.validUntil};
 if(!validFact(fact,now))throw new Error('Source, reference and valid verification date are required; expired facts are rejected.');
 return {...fact,variantGid:row.variantGid,field:row.field,verifiedAt:new Date(row.verifiedAt),validUntil:row.validUntil?new Date(row.validUntil):null};
}
export async function importFacts(shop:string,rows:FactInput[]){
 const validated=rows.map(r=>validateFactInput(r));
 return db.$transaction(async tx=>{
  for(const row of validated)await tx.supplierFactRecord.upsert({where:{shop_variantGid_field:{shop,variantGid:row.variantGid,field:row.field}},create:{shop,...row},update:row});
  return validated.length;
 });
}
export async function factsForShop(shop:string){
 const rows=await db.supplierFactRecord.findMany({where:{shop}});
 const map=new Map<string,Record<string,SupplierFact>>();
 for(const r of rows){const item=map.get(r.variantGid)||{};item[r.field]={value:r.value,source:r.source,reference:r.reference,verifiedAt:r.verifiedAt.toISOString(),validUntil:r.validUntil?.toISOString()};map.set(r.variantGid,item);}
 return map;
}
