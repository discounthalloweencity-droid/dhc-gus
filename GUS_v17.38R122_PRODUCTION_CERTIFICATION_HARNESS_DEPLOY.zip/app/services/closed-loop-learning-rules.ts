
export type OutcomeInput={domain:string;baseline:number|null;after:number|null;higherIsBetter:boolean;confidence:number;sampleAdequate:boolean};
export function evaluateOutcome(i:OutcomeInput){
 if(!i.sampleAdequate||i.baseline==null||i.after==null||!Number.isFinite(i.baseline)||!Number.isFinite(i.after))return {verdict:'INSUFFICIENT_EVIDENCE' as const,lift:null,weight:0,lesson:'Do not learn from this intervention yet.'};
 const denom=Math.max(Math.abs(i.baseline),.0001),raw=(i.after-i.baseline)/denom,lift=i.higherIsBetter?raw:-raw;
 const conf=Math.max(0,Math.min(1,i.confidence));let verdict:'POSITIVE'|'NEGATIVE'|'NEUTRAL'='NEUTRAL';
 if(lift>=.05)verdict='POSITIVE';else if(lift<=-.05)verdict='NEGATIVE';
 const weight=Math.round(Math.min(1,Math.abs(lift)*2)*conf*100)/100;
 return {verdict,lift:Math.round(lift*10000)/10000,weight,lesson:verdict==='POSITIVE'?'Increase confidence in this intervention pattern.':verdict==='NEGATIVE'?'Reduce priority for this intervention pattern until better evidence exists.':'Keep the intervention weight stable.'};
}
export function learnedPriorityAdjustment(verdict:string,weight:number){return verdict==='POSITIVE'?Math.round(12*weight):verdict==='NEGATIVE'?-Math.round(15*weight):0}
