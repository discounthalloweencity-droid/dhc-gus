export type ShopperIntent={
 raw:string; normalized:string; themes:string[]; aesthetics:string[]; colors:string[]; audiences:string[]; sizes:string[]; productTypes:string[]; occasions:string[]; coverage:string[];
};
const MAP={
 aesthetics:['sexy','cute','spooky cute','gothic','romantic goth','dark feminine','witchy','witchcore','fairycore','cottagecore','glamorous','funny','elegant horror'],
 colors:['black','white','red','pink','purple','green','orange','blue','silver','gold'],
 audiences:['women','woman','womens','men','mens','kids','kid','child','children','girls','boys','unisex'],
 sizes:['plus size','plus-size','petite','small','medium','large','xl','2xl','3xl'],
 productTypes:['costume','dress','mask','wig','makeup','prop','cape','fangs','hat','gloves','decor','decoration','lighting','tarot','crystal','candle','accessories','accessory'],
 occasions:['party','work event','couples','family','cosplay','festival','haunted attraction','photoshoot','photo shoot'],
 coverage:['full coverage','modest','low cut','short','long sleeve','sleeveless'],
 themes:['witch','vampire','zombie','skeleton','pumpkin','ghost','clown','pirate','devil','angel','fairy','werewolf','classic horror','goth','occult','tarot']
} as const;
function norm(v:string){return v.toLowerCase().normalize('NFKD').replace(/[^a-z0-9+\- ]+/g,' ').replace(/\s+/g,' ').trim();}
function hits(q:string,terms:readonly string[]){return terms.filter(t=>q.includes(t)).map(t=>t.replace(/-/g,' '));}
export function parseShopperIntent(raw:string):ShopperIntent{
 const normalized=norm(raw);
 return {raw,normalized,themes:hits(normalized,MAP.themes),aesthetics:hits(normalized,MAP.aesthetics),colors:hits(normalized,MAP.colors),audiences:hits(normalized,MAP.audiences),sizes:hits(normalized,MAP.sizes),productTypes:hits(normalized,MAP.productTypes),occasions:hits(normalized,MAP.occasions),coverage:hits(normalized,MAP.coverage)};
}
export function intentSimilarity(a:ShopperIntent,b:ShopperIntent){
 const fields:(keyof Pick<ShopperIntent,'themes'|'aesthetics'|'colors'|'audiences'|'sizes'|'productTypes'|'occasions'|'coverage'>)[]=['themes','aesthetics','colors','audiences','sizes','productTypes','occasions','coverage'];
 let shared=0,total=0;
 for(const f of fields){const A=new Set(a[f]),B=new Set(b[f]); total+=Math.max(A.size,B.size); for(const x of A)if(B.has(x))shared++;}
 return total?Number((shared/total).toFixed(4)):0;
}
export function shouldMergeSearchIntent(a:ShopperIntent,b:ShopperIntent){
 if(a.normalized===b.normalized)return true;
 const hardFields:['colors','audiences','sizes','productTypes']=['colors','audiences','sizes','productTypes'];
 for(const f of hardFields){if(a[f].length&&b[f].length&&!a[f].some(x=>b[f].includes(x)))return false;}
 return intentSimilarity(a,b)>=.75;
}
