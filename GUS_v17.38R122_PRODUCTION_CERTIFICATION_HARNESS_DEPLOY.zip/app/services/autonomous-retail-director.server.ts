
import {db} from '../db.server';
import {allocateDirectorFocus} from './autonomous-retail-director-rules';
import {refreshExecutivePlan} from './executive.server';
import {learningAdjustmentFor} from './closed-loop-learning.server';
const JOB='AUTONOMOUS_RETAIL_DIRECTOR';
const SOURCES=['ORDER_RISK_INTELLIGENCE','CUSTOMER_RETENTION_INTELLIGENCE','PREDICTIVE_SUPPLIER_RISK','DEMAND_AVAILABILITY_FORECAST','CONTENT_QUALITY_ENGINE','DYNAMIC_PRICING_OPTIMIZER','BASKET_BUILDER_INTELLIGENCE','CONTROLLED_EXPERIMENT','ACTION_ROI'];
export async function runAutonomousRetailDirector(shop:string,force=false){
 const last=force?null:await db.jobRun.findFirst({where:{shop,jobType:JOB,status:'DONE'},orderBy:{finishedAt:'desc'}});if(last?.finishedAt&&Date.now()-last.finishedAt.getTime()<60*60*1000)return {status:'NOT_DUE'};
 const job=await db.jobRun.create({data:{shop,jobType:JOB,status:'RUNNING',details:'{}'}});
 try{
  const signals=await db.intelligenceSignal.findMany({where:{shop,source:{in:SOURCES},observedAt:{gte:new Date(Date.now()-7*86400000)}},orderBy:[{severity:'desc'},{observedAt:'desc'}],take:1000});
  const focus=allocateDirectorFocus(signals.map(s=>({id:s.id,source:s.source,signalType:s.signalType,severity:s.severity,score:s.score,confidence:s.confidence,metric:s.metric,entityType:s.entityType,entityId:s.entityId})),12);
  const domains:any={};for(const f of focus)domains[f.domain]=(domains[f.domain]||0)+1;
  // Feed only high-value cross-engine priorities into the existing ExecutiveWorkItem queue.
  let queued=0;
  for(const f of focus){const learned=await learningAdjustmentFor(shop,'DIRECTOR_SIGNAL_REVIEW',f.domain);f.priority=Math.max(0,Math.min(100,f.priority+learned));if(f.priority<55)continue;const key=`R56:${shop}:${f.id}`;const human=['LOSS_PREVENTION'].includes(f.domain)||String(f.severity).toUpperCase()==='CRITICAL';
   await db.executiveWorkItem.upsert({where:{workKey:key},create:{shop,workKey:key,domain:f.domain,objective:`Act on the highest-value ${f.domain.toLowerCase().replace(/_/g,' ')} evidence first`,title:`${f.signalType}: ${f.metric||f.severity}`,actionType:'DIRECTOR_SIGNAL_REVIEW',workClass:human?'HUMAN_REVIEW':'SAFE_INTERNAL',targetType:f.entityType,targetId:f.entityId,evidenceJson:JSON.stringify({signalId:f.id,source:f.source,priority:f.priority}),expectedImpact:f.impact,confidence:f.confidence,effort:25,urgency:f.priority,riskLevel:human?'HIGH':'MEDIUM',priorityScore:f.priority,lane:human?'ESCALATE':'AUTO_SAFE',status:human?'ESCALATED':'QUEUED',reversible:true,requiresHuman:human},update:{priorityScore:f.priority,urgency:f.priority,expectedImpact:f.impact,confidence:f.confidence,evidenceJson:JSON.stringify({signalId:f.id,source:f.source,priority:f.priority})}});queued++;
  }
  // Existing executive planner remains authoritative for supported execution and human gates.
  const executive=await refreshExecutivePlan(shop);
  const details={signalsConsidered:signals.length,focusItems:focus.length,queuedToExecutive:queued,domainMix:domains,topFocus:focus.slice(0,12),executive,doctrine:'R56 prioritizes work across Gus engines. Existing execution gates remain authoritative; critical/customer-loss actions are not silently executed.'};
  await db.jobRun.update({where:{id:job.id},data:{status:'DONE',scanned:signals.length,changed:queued,warnings:focus.filter(x=>String(x.severity).toUpperCase()==='CRITICAL').length,details:JSON.stringify(details),finishedAt:new Date()}});
  return {status:'DONE',...details};
 }catch(e:any){await db.jobRun.update({where:{id:job.id},data:{status:'FAILED',details:JSON.stringify({error:String(e?.message||e)}),finishedAt:new Date()}}).catch(()=>{});throw e;}
}
export async function retailDirectorSummary(shop:string){const latest=await db.jobRun.findFirst({where:{shop,jobType:JOB},orderBy:{startedAt:'desc'}});let details:any={};try{details=latest?.details?JSON.parse(latest.details):{}}catch{}return {latest,details};}
