export type RecoveryState='RECOVER_NOW'|'WATCH'|'BLOCKED_DEPENDENCY'|'HEALTHY';
export type RecoveryInput={engine:string;state:string;waiting:number;failed:number;itemsPerHour:number;lastRunAt?:Date|null;lastSuccessAt?:Date|null;dependencyBlocked?:boolean};
const PROTECTED=/CUSTOMER|ORDER|FULFILL|INVENTORY|FRAUD|RISK/i;
const RECOVERABLE=/CATALOG|NORMAL|QUALITY|TAXON|PDP|SEO|GROWTH|CONTENT|MERCH/i;
export function recoveryAssessment(x:RecoveryInput){
 const protectedEngine=PROTECTED.test(x.engine),recoverable=RECOVERABLE.test(x.engine)&&!protectedEngine;
 if(x.dependencyBlocked)return {recoveryState:'BLOCKED_DEPENDENCY' as RecoveryState,score:0,recoverable:false,reason:'Required upstream data or connection is blocked.'};
 if(['FAILED','STALLED'].includes(x.state)){const score=100+Math.min(40,x.failed*5)+Math.min(40,Math.floor(x.waiting/25));return {recoveryState:'RECOVER_NOW' as RecoveryState,score,recoverable,reason:`${x.state} engine requires recovery.`};}
 if(x.waiting>=100&&x.itemsPerHour<100){return {recoveryState:'RECOVER_NOW' as RecoveryState,score:80+Math.min(40,Math.floor(x.waiting/50)),recoverable,reason:'Large backlog is moving too slowly.'};}
 if(x.waiting>0)return {recoveryState:'WATCH' as RecoveryState,score:30+Math.min(40,Math.floor(x.waiting/50)),recoverable,reason:'Queued work remains.'};
 return {recoveryState:'HEALTHY' as RecoveryState,score:0,recoverable,reason:'No recovery signal.'};
}
export function recoveryRank<T extends RecoveryInput>(rows:T[]){return rows.map(r=>({...r,...recoveryAssessment(r)})).sort((a,b)=>b.score-a.score||b.waiting-a.waiting||a.engine.localeCompare(b.engine));}
