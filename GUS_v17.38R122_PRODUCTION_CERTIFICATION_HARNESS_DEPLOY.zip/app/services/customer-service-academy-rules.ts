import {CUSTOMER_SERVICE_ACADEMY_VERSION,CUSTOMER_SERVICE_SCENARIOS,type CustomerServiceScenario} from '../knowledge/customer-service-academy-v1.ts';
import {CUSTOMER_SERVICE_EXCELLENCE_VERSION,CUSTOMER_SERVICE_STYLE_DRILLS} from '../knowledge/customer-service-excellence-v1.ts';
import {auditCustomerServiceNaturalness} from './customer-service-naturalness.ts';
import {DHC_SUPPORT_PERSONAS} from './customer-service-persona.ts';
export type AcademyDecision={lane:'AUTO_REPLY'|'HUMAN_REVIEW'|'IGNORE';resolution:string};
export function customerServiceAcademyDecision(input:CustomerServiceScenario['input']):AcademyDecision{
 if(input.legal)return {lane:'HUMAN_REVIEW',resolution:'LEGAL_ESCALATION'};
 if(input.chargeback)return {lane:'HUMAN_REVIEW',resolution:'CHARGEBACK_ESCALATION'};
 if(input.fraud)return {lane:'HUMAN_REVIEW',resolution:'FRAUD_ESCALATION'};
 if(input.kind==='NON_CUSTOMER')return {lane:'IGNORE',resolution:'NON_CUSTOMER'};
 if(['PRODUCT_QUESTION','AMBIGUOUS','STORE_CREDIT','PAYMENT_SECRET','ADDRESS_CHANGE','UNKNOWN'].includes(input.kind))return {lane:'HUMAN_REVIEW',resolution:input.kind==='PRODUCT_QUESTION'?'PRODUCT_QUESTION_REVIEW':input.kind==='AMBIGUOUS'?'AMBIGUOUS_REVIEW':input.kind==='STORE_CREDIT'?'STORE_CREDIT_REVIEW':input.kind==='PAYMENT_SECRET'?'SENSITIVE_DATA_REVIEW':input.kind==='ADDRESS_CHANGE'?'ADDRESS_CHANGE_REVIEW':'UNKNOWN_REVIEW'};
 if(input.kind==='CANCEL')return input.within60?{lane:'AUTO_REPLY',resolution:'REFUND_REQUIRED_60_MINUTE_CANCEL'}:{lane:'AUTO_REPLY',resolution:'CANCELLATION_REVIEW'};
 if(input.kind==='ORDER_HELP'&&!input.orderVerified)return {lane:'AUTO_REPLY',resolution:'NEED_ORDER_NUMBER'};
 if(input.kind==='ORDER_NOT_VERIFIED')return {lane:'AUTO_REPLY',resolution:'ORDER_NOT_VERIFIED'};
 if(input.multiItem&&input.dhcFault&&input.customerWantsRefund&&!input.affectedItemKnown)return {lane:'AUTO_REPLY',resolution:'NEED_AFFECTED_ITEM_FOR_REFUND'};
 if(input.dhcFault&&input.customerWantsRefund)return {lane:'AUTO_REPLY',resolution:'REFUND_REQUIRED_DHC_ERROR'};
 if(input.kind==='REFUND_FOLLOWUP'&&input.dhcFault)return {lane:'AUTO_REPLY',resolution:'REFUND_REQUIRED_DHC_ERROR'};
 if(input.kind==='REPLACEMENT_FOLLOWUP'&&input.dhcFault)return {lane:'AUTO_REPLY',resolution:'FREE_REPLACEMENT_REQUESTED'};
 if(input.dhcFault)return {lane:'AUTO_REPLY',resolution:'FREE_REPLACEMENT_OFFERED'};
 if(input.kind==='REFUND'&&input.customerWantsRefund)return {lane:'AUTO_REPLY',resolution:'REFUND_REVIEW_REQUIRED'};
 return {lane:'AUTO_REPLY',resolution:'GENERAL_SUPPORT'};
}
export function evaluateCustomerServiceAcademy(){
 const checks=CUSTOMER_SERVICE_SCENARIOS.map(s=>{const actual=customerServiceAcademyDecision(s.input);const ok=actual.lane===s.expected.lane&&actual.resolution===s.expected.resolution;return {id:s.id,title:s.title,hardGate:Boolean(s.hardGate),expected:s.expected,actual,ok};});
 const passed=checks.filter(x=>x.ok).length,total=checks.length;const hardFailures=checks.filter(x=>x.hardGate&&!x.ok);
 return {version:CUSTOMER_SERVICE_ACADEMY_VERSION,passed,total,accuracy:total?passed/total:0,threshold:1,hardFailures,failures:checks.filter(x=>!x.ok),checks,pass:passed===total&&hardFailures.length===0};
}

export function evaluateCustomerServiceStyleAcademy(){
 const checks=CUSTOMER_SERVICE_STYLE_DRILLS.map(d=>{const persona=DHC_SUPPORT_PERSONAS.find(p=>d.reply.includes(`\n${p.name}\nDHC Support`))||null;const audit=auditCustomerServiceNaturalness(d.reply,persona);const ok=d.expect==='STRONG'?audit.score>=90&&!audit.hardFail:audit.score<90||audit.hardFail;return {id:d.id,expected:d.expect,actualScore:audit.score,hardFail:audit.hardFail,flags:audit.flags,ok};});
 const passed=checks.filter(x=>x.ok).length,total=checks.length;return {version:CUSTOMER_SERVICE_EXCELLENCE_VERSION,passed,total,accuracy:total?passed/total:0,threshold:1,failures:checks.filter(x=>!x.ok),checks,pass:passed===total};
}
