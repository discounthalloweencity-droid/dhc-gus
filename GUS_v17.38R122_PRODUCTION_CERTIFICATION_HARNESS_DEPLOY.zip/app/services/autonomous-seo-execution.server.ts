import {db} from '../db.server';
import {automationState} from './automation-control.server';
import {liveWritesEnabled} from './deployment-gates';
import {executeAction,proposeAction,rollbackAction,recentSeoWriteMismatchBlock} from './actions.server';
import {currentCollectionSeo,currentProductSeo} from './shopify-api.server';
import {resolveStrikeSeoTarget,type SeoTarget} from './strike-keyword-diagnosis.server';
import {resolveSearchConsoleEvidence} from './search-console-evidence.server';
import {seoRiskDecision} from './seo-risk-escalation.server';
import {buildSeoMetadataDecision} from './seo-metadata-intelligence';
import {compareSeoWindows} from './seo-outcome-intelligence';
import {autonomousSeoActionTypes,seoCapabilityForAction} from './seo-capability-map';
import {classifySeoExecutionFailure,recoverFailedSeoWorkItems} from './seo-execution-recovery.server';

const DAY=86400000;
const AUTO_ACTIONS=new Set(autonomousSeoActionTypes());
const MIN_CONFIDENCE=.86;
const DEFAULT_LIMIT=8;
const COOLDOWN_DAYS=14;
const MEASURE_AFTER_DAYS=7;
const ROLLBACK_AFTER_DAYS=14;

const parse=<T>(raw:string|null|undefined,fallback:T):T=>{try{return JSON.parse(raw||'') as T}catch{return fallback}};
const clamp=(n:number,min:number,max:number)=>Math.max(min,Math.min(max,n));
const normalizeUrl=(raw:string)=>{try{const u=new URL(raw);u.hash='';u.search='';return u.href.replace(/\/$/,'');}catch{return String(raw||'').replace(/\/$/,'')}};
const clean=(s:string)=>String(s||'').replace(/\s+/g,' ').trim();
const seoWritesEnabled=()=>process.env.GUS_SEO_AUTONOMOUS_WRITES_ENABLED!=='false';

function boundedLimit(value:number|undefined){const n=Number(value??process.env.GUS_SEO_AUTO_WRITE_LIMIT??DEFAULT_LIMIT);return Number.isFinite(n)?clamp(Math.round(n),1,25):DEFAULT_LIMIT;}

export function buildAutonomousSeoMetadata(query:string,target:SeoTarget,context:any={}){return buildSeoMetadataDecision(query,target,context);}

function baselineFromEvidence(e:any){return {query:String(e.query||''),page:String(e.page||e.currentPage||''),position:e.position==null?null:Number(e.position),ctr:e.ctr==null?null:Number(e.ctr),impressions:e.impressions==null?null:Number(e.impressions),clicks:e.clicks==null?null:Number(e.clicks),capturedAt:new Date().toISOString()};}
async function freshReadback(admin:any,type:'PRODUCT'|'COLLECTION',gid:string){const live=type==='PRODUCT'?await currentProductSeo(admin,gid):await currentCollectionSeo(admin,gid);return {title:clean(live?.seo?.title||''),description:clean(live?.seo?.description||'')};}
async function latestSeoChange(shop:string,gid:string,since:Date){return db.changeLog.findFirst({where:{shop,productGid:gid,action:{in:['SEO','COLLECTION_SEO']},createdAt:{gte:since}},orderBy:{createdAt:'desc'}});}

export async function drainSafeSeoProposals(admin:any,shop:string,limit=10){
  const [config,automation]=await Promise.all([db.storeConfig.findUnique({where:{shop}}),automationState(shop)]);
  if(!seoWritesEnabled()||!liveWritesEnabled()||!automation?.running||config?.mode!=='AUTOPILOT')return {enabled:false,attempted:0,applied:0,failed:0};
  const rows=(await db.actionProposal.findMany({where:{shop,status:'PENDING',action:{in:['SEO','COLLECTION_SEO']},createdAt:{gte:new Date(Date.now()-48*60*60*1000)}},orderBy:{createdAt:'asc'},take:clamp(limit*3,1,50)})).filter(row=>/^(Autonomous SEO|Strike Keyword|Factual SEO metadata generated only)/i.test(String(row.reason||''))).slice(0,clamp(limit,1,25));
  let applied=0,failed=0,deferred=0;
  for(const row of rows){
   const action=row.action as 'SEO'|'COLLECTION_SEO';const blocked=await recentSeoWriteMismatchBlock(shop,row.productGid,action,row.afterValue,admin);
   if(blocked?.alreadyCompliant){await db.actionProposal.updateMany({where:{id:row.id,shop,status:'PENDING'},data:{status:'SUPERSEDED',error:'Live Shopify SEO now matches the intended state after late readback reconciliation; duplicate write suppressed.'}}).catch(()=>{});deferred++;continue;}
   if(blocked&&blocked.id!==row.id){const scope=(blocked as any).circuitScope==='GLOBAL'?'store-wide':'target';await db.actionProposal.updateMany({where:{id:row.id,shop,status:'PENDING'},data:{status:'SUPERSEDED',error:`Held by 0.16.57 R7 ${scope} SEO mismatch circuit breaker; prior proposal ${blocked.id} is current recovery evidence.`}}).catch(()=>{});deferred++;continue;}
   try{await executeAction(admin,shop,row.id,false);applied++;}catch(error){failed++;console.warn('[autonomous-seo] safe proposal execution failed',row.id,error instanceof Error?error.message:error);}
  }
  return {enabled:true,attempted:rows.length,applied,failed,deferred};
}

export async function runAutonomousSeoExecution(admin:any,shop:string,options:{limit?:number}={}){
  const limit=boundedLimit(options.limit);
  const [config,automation]=await Promise.all([db.storeConfig.findUnique({where:{shop}}),automationState(shop)]);
  const enabled=seoWritesEnabled()&&liveWritesEnabled()&&Boolean(automation?.running)&&config?.mode==='AUTOPILOT';
  const recovery=enabled?await recoverFailedSeoWorkItems(shop):{scanned:0,requeued:0,escalated:0,waiting:0,maxRetries:3,rows:[]};
  const proposalDrain=enabled?await drainSafeSeoProposals(admin,shop,Math.min(10,limit)): {enabled:false,attempted:0,applied:0,failed:0};
  if(!enabled)return {enabled:false,reason:!seoWritesEnabled()?'SEO_AUTONOMY_KILL_SWITCH':!liveWritesEnabled()?'LIVE_WRITES_DISABLED':!automation?.running?'GUS_STOPPED':'AUTOPILOT_DISABLED',attempted:0,applied:proposalDrain.applied,verified:0,failed:proposalDrain.failed,skipped:0,escalated:0,proposalDrain,recovery,results:[]};
  const candidates=await db.executiveWorkItem.findMany({where:{shop,domain:'SEO',status:'QUEUED',lane:'AUTO_SAFE',requiresHuman:false,actionType:{in:[...AUTO_ACTIONS]}},orderBy:[{priorityScore:'desc'},{updatedAt:'asc'}],take:limit*3});
  const seenPages=new Set<string>();const results:any[]=[];let applied=proposalDrain.applied,verified=proposalDrain.applied,failed=proposalDrain.failed,skipped=0,escalated=0,attempted=0;
  for(const item of candidates){if(attempted>=limit)break;const evidence=parse<any>(item.evidenceJson,{});const targetRaw=/^https?:\/\//i.test(String(item.targetId||''))?String(item.targetId):String(evidence.page||evidence.currentPage||'');const page=normalizeUrl(targetRaw);const query=clean(String(evidence.query||''));if(!page||!query||seenPages.has(page)){skipped++;continue;}seenPages.add(page);attempted++;
    const cannibal=await db.executiveWorkItem.findFirst({where:{shop,domain:'SEO',actionType:'SEO_CANNIBALIZATION_REVIEW',targetId:query,status:{in:['QUEUED','ESCALATED','RUNNING']}},select:{id:true}}).catch(()=>null);if(cannibal){skipped++;results.push({workItemId:item.id,status:'CANNIBALIZATION_REVIEW_PENDING',reviewWorkItemId:cannibal.id});continue;}
    const capability=seoCapabilityForAction(item.actionType,evidence);
    if(capability.mode==='OWNER_APPROVAL'){await db.executiveWorkItem.update({where:{id:item.id},data:{lane:'APPROVAL_REQUIRED',requiresHuman:true,status:'ESCALATED',riskLevel:'HIGH',resultJson:JSON.stringify({mode:'ESCALATED',capability,at:new Date().toISOString()})}});escalated++;results.push({workItemId:item.id,status:'ESCALATED',reason:capability.reason});continue;}
    if(capability.mode!=='AUTO_EXECUTE'){await db.executiveWorkItem.update({where:{id:item.id},data:{status:'COMPLETED',completedAt:new Date(),verifiedAt:new Date(),resultJson:JSON.stringify({mode:'NO_WRITE',status:capability.mode,capability,at:new Date().toISOString()})}});skipped++;results.push({workItemId:item.id,status:capability.mode,reason:capability.reason});continue;}
    const risk=seoRiskDecision({action:item.actionType,signalType:item.targetType||'',evidence});
    if(risk.approval==='REQUIRED'||['HIGH','CRITICAL'].includes(String(item.riskLevel).toUpperCase())){await db.executiveWorkItem.update({where:{id:item.id},data:{lane:'APPROVAL_REQUIRED',requiresHuman:true,status:'ESCALATED',riskLevel:'HIGH',resultJson:JSON.stringify({mode:'ESCALATED',decision:risk,at:new Date().toISOString()})}});escalated++;results.push({workItemId:item.id,status:'ESCALATED',reason:risk.reason});continue;}
    if(item.confidence<MIN_CONFIDENCE||evidence.promotionEligible!==true||(Array.isArray(evidence.promotionBlockReasons)&&evidence.promotionBlockReasons.length)){skipped++;await db.executiveWorkItem.update({where:{id:item.id},data:{status:'BLOCKED',completedAt:null,verifiedAt:null,startedAt:null,error:null,resultJson:JSON.stringify({mode:'NO_WRITE',status:'BLOCKED_BY_EVIDENCE',confidence:item.confidence,blockReasons:evidence.promotionBlockReasons||[],at:new Date().toISOString()})}});results.push({workItemId:item.id,status:'BLOCKED_BY_EVIDENCE'});continue;}
    const claim=await db.executiveWorkItem.updateMany({where:{id:item.id,shop,status:'QUEUED'},data:{status:'RUNNING',startedAt:new Date(),error:null}});if(!claim.count){skipped++;continue;}
    try{
      const target=await resolveStrikeSeoTarget(admin,page);if(!target.gid||!['PRODUCT','COLLECTION'].includes(target.type))throw new Error('SHOPIFY_TARGET_UNRESOLVED');if(Number(evidence.position)>0&&Number(evidence.position)<=3){await db.executiveWorkItem.update({where:{id:item.id},data:{status:'COMPLETED',completedAt:new Date(),verifiedAt:new Date(),resultJson:JSON.stringify({mode:'NO_WRITE',status:'TOP3_DEFEND_MODE',position:Number(evidence.position),at:new Date().toISOString()})}});skipped++;results.push({workItemId:item.id,status:'TOP3_DEFEND_MODE'});continue;}
      const recent=await latestSeoChange(shop,target.gid,new Date(Date.now()-COOLDOWN_DAYS*DAY));if(recent){await db.executiveWorkItem.update({where:{id:item.id},data:{status:'COMPLETED',completedAt:new Date(),verifiedAt:new Date(),resultJson:JSON.stringify({mode:'NO_WRITE',status:'COOLDOWN_ACTIVE',changeId:recent.id,cooldownDays:COOLDOWN_DAYS,at:new Date().toISOString()})}});skipped++;results.push({workItemId:item.id,status:'COOLDOWN_ACTIVE',changeId:recent.id});continue;}
      const draft=buildAutonomousSeoMetadata(query,target,{deliveryDays:evidence.deliveryDays??evidence.shippingDays??null,deliveryVerified:Boolean(evidence.deliveryVerified||evidence.shippingVerified),availabilityVerified:Boolean(evidence.availabilityVerified)});if(draft.status!=='READY'){await db.executiveWorkItem.update({where:{id:item.id},data:{status:'COMPLETED',completedAt:new Date(),verifiedAt:new Date(),resultJson:JSON.stringify({mode:'NO_WRITE',status:draft.reason,relevance:draft.relevance,at:new Date().toISOString()})}});skipped++;results.push({workItemId:item.id,status:draft.reason});continue;}
      const before={title:clean(target.seoTitle||''),description:clean(target.seoDescription||'')};const after={title:draft.title,description:draft.description};if(before.title===after.title&&before.description===after.description){await db.executiveWorkItem.update({where:{id:item.id},data:{status:'COMPLETED',completedAt:new Date(),verifiedAt:new Date(),resultJson:JSON.stringify({mode:'NO_WRITE',status:'ALREADY_OPTIMIZED',before,after,at:new Date().toISOString()})}});skipped++;results.push({workItemId:item.id,status:'ALREADY_OPTIMIZED'});continue;}
      const action=target.type==='COLLECTION'?'COLLECTION_SEO':'SEO';const baseline=baselineFromEvidence(evidence);const reason=`Autonomous SEO work ${item.id}: ${query} · ${item.actionType} · confidence=${item.confidence.toFixed(2)} · relevance=${draft.relevance.toFixed(2)}`;const afterJson=JSON.stringify(after);
      const mismatchBlock=await recentSeoWriteMismatchBlock(shop,target.gid,action,afterJson,admin);if(mismatchBlock){skipped++;if(mismatchBlock.alreadyCompliant){await db.executiveWorkItem.update({where:{id:item.id},data:{status:'COMPLETED',completedAt:new Date(),verifiedAt:new Date(),resultJson:JSON.stringify({mode:'NO_WRITE',status:'ALREADY_COMPLIANT_AFTER_LATE_READBACK',proposalId:mismatchBlock.id,at:new Date().toISOString()}),error:null}}).catch(()=>{});results.push({workItemId:item.id,status:'ALREADY_COMPLIANT_AFTER_LATE_READBACK',proposalId:mismatchBlock.id});continue;}await db.executiveWorkItem.update({where:{id:item.id},data:{status:'QUEUED',startedAt:null,resultJson:JSON.stringify({mode:'NO_WRITE',status:'SEO_WRITE_QUARANTINED',proposalId:mismatchBlock.id,holdUntil:((mismatchBlock as any).holdUntil||new Date(mismatchBlock.updatedAt.getTime()+24*60*60*1000)).toISOString(),at:new Date().toISOString()}),error:null}}).catch(()=>{});results.push({workItemId:item.id,status:'SEO_WRITE_QUARANTINED',proposalId:mismatchBlock.id});continue;}
      const proposal=await proposeAction(shop,target.gid,null,action,JSON.stringify(before),afterJson,reason);await executeAction(admin,shop,proposal.id,false);
      const readback=await freshReadback(admin,target.type as 'PRODUCT'|'COLLECTION',target.gid);const readbackOk=readback.title===after.title&&readback.description===after.description;const change=await db.changeLog.findFirst({where:{shop,productGid:target.gid,action,createdAt:{gte:new Date(Date.now()-5*60*1000)}},orderBy:{createdAt:'desc'}});
      if(!readbackOk){if(change?.reversible)await rollbackAction(admin,shop,change.id).catch(()=>{});throw new Error('SEO_READBACK_MISMATCH_ROLLBACK_ATTEMPTED');}
      const now=new Date();const result={mode:'AUTO_APPLIED',status:'VERIFIED_IN_SHOPIFY',workItemId:item.id,proposalId:proposal.id,changeId:change?.id||null,action,targetType:target.type,targetGid:target.gid,query,page,confidence:item.confidence,relevance:draft.relevance,baseline,before,after,readback,appliedAt:now.toISOString(),measurement:{state:'WAITING',earliestEvaluation:new Date(now.getTime()+MEASURE_AFTER_DAYS*DAY).toISOString(),rollbackEvaluation:new Date(now.getTime()+ROLLBACK_AFTER_DAYS*DAY).toISOString(),finalEvaluation:new Date(now.getTime()+28*DAY).toISOString()}};
      await db.executiveWorkItem.update({where:{id:item.id},data:{status:'COMPLETED',completedAt:now,verifiedAt:now,resultJson:JSON.stringify(result),error:null}});applied++;verified++;results.push({workItemId:item.id,status:'AUTO_APPLIED',proposalId:proposal.id,changeId:change?.id||null,page,query});
    }catch(error:any){failed++;const message=String(error?.message||error),classification=classifySeoExecutionFailure(error),prior=parse<any>(item.resultJson,{}),retryCount=Number(prior.retryCount||0);await db.executiveWorkItem.update({where:{id:item.id},data:{status:'FAILED',completedAt:new Date(),error:message,resultJson:JSON.stringify({mode:'AUTO_EXECUTION_FAILED',error:message,failureClass:classification.kind,retryable:classification.retryable,retryAfterMs:classification.retryAfterMs,retryCount,failedAt:new Date().toISOString()})}}).catch(()=>{});results.push({workItemId:item.id,status:'FAILED',error:message,failureClass:classification.kind,retryable:classification.retryable,retryCount});}
  }
  return {enabled:true,attempted,applied,verified,failed,skipped,escalated,proposalDrain,recovery,results};
}

export async function measureAutonomousSeoOutcomes(admin:any,shop:string){
  const items=await db.executiveWorkItem.findMany({where:{shop,domain:'SEO',status:{in:['COMPLETED','ROLLED_BACK']},resultJson:{not:null},completedAt:{not:null}},orderBy:{completedAt:'desc'},take:120});
  const eligible=items.filter(item=>{const r=parse<any>(item.resultJson,{});return r.mode==='AUTO_APPLIED'&&r.appliedAt&&Date.now()-Date.parse(r.appliedAt)>=MEASURE_AFTER_DAYS*DAY;});
  if(!eligible.length)return {measured:0,improved:0,regressed:0,rolledBack:0,waiting:items.filter(i=>parse<any>(i.resultJson,{}).mode==='AUTO_APPLIED').length};
  const evidence=await resolveSearchConsoleEvidence(shop,{refresh:false});const allRows=[...(evidence.previousRows||[]),...(evidence.rows||[])];let measured=0,improved=0,regressed=0,rolledBack=0,waiting=0;
  for(const item of eligible){const result=parse<any>(item.resultJson,{});if(result.rollback?.status==='ROLLED_BACK')continue;const baseline=result.baseline||{};const query=clean(String(result.query||baseline.query||'')),page=normalizeUrl(String(result.page||baseline.page||''));const settledThrough=String(evidence.windows?.current?.endDate||'');
    if(String(evidence.source||'').startsWith('VERIFIED_GSC_SNAPSHOT')){result.measurement={state:'WAITING',reason:'LIVE_OR_DAILY_GSC_REQUIRED',source:evidence.source,checkedAt:new Date().toISOString()};await db.executiveWorkItem.update({where:{id:item.id},data:{resultJson:JSON.stringify(result)}}).catch(()=>{});waiting++;continue;}
    const comparison=compareSeoWindows(allRows,query,page,result.appliedAt,settledThrough,new Date());if(!comparison.ready){result.measurement={state:'WAITING',reason:comparison.reason,source:evidence.source,preWindow:comparison.preWindow,postWindow:comparison.postWindow,checkedAt:new Date().toISOString()};await db.executiveWorkItem.update({where:{id:item.id},data:{resultJson:JSON.stringify(result)}}).catch(()=>{});waiting++;continue;}
    const outcome={state:'MEASURED',measuredAt:new Date().toISOString(),source:evidence.source,daysSinceChange:Math.floor((Date.now()-Date.parse(result.appliedAt))/DAY),...comparison};result.measurement=outcome;measured++;if(comparison.classification==='IMPROVED')improved++;if(comparison.classification==='REGRESSED')regressed++;
    if(comparison.severeRegression&&result.changeId&&seoWritesEnabled()&&liveWritesEnabled()){const automation=await automationState(shop);if(automation?.running){try{await rollbackAction(admin,shop,Number(result.changeId));result.rollback={status:'ROLLED_BACK',reason:'SEVERE_GSC_REGRESSION',at:new Date().toISOString(),outcome};await db.executiveWorkItem.update({where:{id:item.id},data:{status:'ROLLED_BACK',resultJson:JSON.stringify(result),verifiedAt:new Date()}});rolledBack++;continue;}catch(error:any){result.rollback={status:'ROLLBACK_FAILED',reason:String(error?.message||error),at:new Date().toISOString()};}}}
    await db.executiveWorkItem.update({where:{id:item.id},data:{resultJson:JSON.stringify(result),verifiedAt:comparison.classification==='IMPROVED'?new Date():item.verifiedAt}}).catch(()=>{});
  }
  return {measured,improved,regressed,rolledBack,waiting,source:evidence.source};
}
