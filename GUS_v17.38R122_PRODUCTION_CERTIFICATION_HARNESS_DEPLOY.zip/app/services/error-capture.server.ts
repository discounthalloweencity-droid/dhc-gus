import {registerError} from './error-registry.server';
import {normalizeCapturedError,responseForCapturedError} from './error-capture';

type CaptureMeta={shop:string;source:string;route?:string;jobType?:string;severity?:'INFO'|'WARN'|'ERROR'|'FATAL';context?:unknown};
export async function captureError(error:unknown,meta:CaptureMeta){
 const e=normalizeCapturedError(error);
 return registerError({...meta,message:e.message,stack:e.stack,severity:meta.severity||'ERROR'});
}
export async function captureAndRespond(error:unknown,meta:CaptureMeta,status=503){
 const event=await captureError(error,meta);
 return responseForCapturedError(event.errorKey,status);
}
