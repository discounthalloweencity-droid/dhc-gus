import {db} from '../db.server';

export const GUS_V1055_CONTRACT_VERSION='DHC-GUS-V1055.1-PROXY-CONTRACT-1.0';
export const GUS_PROXY_ENDPOINTS=['session','message','image','cart','order'] as const;
export const GUS_MESSAGE_KEYS=['reply','next_question','choices','products','actions'] as const;
export const GUS_PRODUCT_KEYS=['product_id','variant_id','title','image','price','available_sizes','product_url','match_reason','availability_status','confidence'] as const;

type Check={id:string,status:'PASS'|'FAIL'|'BLOCKED',detail:string};
type Cert={version:string,theme:'v1055.1',backendRuntime:string,baseUrl:string,startedAt:string,finishedAt:string,checks:Check[],pass:number,fail:number,blocked:number,goLiveReady:boolean,manualGates:string[]};

function cleanBase(v:string){return String(v||'').trim().replace(/\/+$/,'');}
function hasKeys(o:any,keys:readonly string[]){return Boolean(o&&typeof o==='object'&&keys.every(k=>Object.prototype.hasOwnProperty.call(o,k)));}
async function jsonFetch(url:string,init:RequestInit={}){
 const r=await fetch(url,{...init,headers:{'content-type':'application/json','accept':'application/json',...(init.headers||{})},redirect:'follow',signal:AbortSignal.timeout(20000)});
 const text=await r.text();let data:any=null;try{data=text?JSON.parse(text):null}catch{}
 return {status:r.status,ok:r.ok,data,text:text.slice(0,1200)};
}
function add(checks:Check[],id:string,ok:boolean,detail:string,blocked=false){checks.push({id,status:blocked?'BLOCKED':ok?'PASS':'FAIL',detail});}
function validProduct(p:any){return hasKeys(p,GUS_PRODUCT_KEYS)&&/^gid:\/\/shopify\/Product\//.test(String(p.product_id||''))&&/^gid:\/\/shopify\/ProductVariant\//.test(String(p.variant_id||''))&&/^\/products\/[^?]+(?:\?variant=\d+)?$/.test(String(p.product_url||''))&&Number(p.price)>0;}
function viewMatches(p:any,a:any){return a?.type==='VIEW_PRODUCT'&&a?.product_id===p?.product_id&&a?.variant_id===p?.variant_id&&a?.url===p?.product_url;}

export async function runV1055ProductionCertification(input:{baseUrl?:string;backendRuntime?:string}={}):Promise<Cert>{
 const baseUrl=cleanBase(input.baseUrl||process.env.GUS_STOREFRONT_PROXY_BASE||'https://www.discounthalloweencity.com/apps/gus-support/gus');
 const startedAt=new Date().toISOString(),checks:Check[]=[];let sessionId='';let product:any=null;
 // Route/session: proves Shopify app proxy is actually forwarding to Gus.
 const s=await jsonFetch(`${baseUrl}/session`,{method:'POST',body:JSON.stringify({mode:'FIND_MY_COSTUME',client:'v1055.1-certification'})}).catch(e=>({status:0,ok:false,data:null,text:String(e)}));
 sessionId=String((s as any).data?.session_id||'');
 add(checks,'proxy.session',Boolean((s as any).ok&&sessionId),(s as any).ok?`session ${sessionId.slice(0,10)}… created`:`HTTP ${(s as any).status}: ${(s as any).text||'no response'}`);
 // Resume is a hard requirement.
 if(sessionId){
  const r=await jsonFetch(`${baseUrl}/session/${encodeURIComponent(sessionId)}`).catch(e=>({status:0,ok:false,data:null,text:String(e)}));
  add(checks,'proxy.session_resume',Boolean((r as any).ok&&(r as any).data?.session_id===sessionId),(r as any).ok?'same session restored':`HTTP ${(r as any).status}: ${(r as any).text||'no response'}`);
 }else add(checks,'proxy.session_resume',false,'blocked because session start failed',true);

 // Message contract. One message intentionally contains enough shopping intent to exercise backend-owned questions/recommendations.
 let m:any=null;
 if(sessionId){
  m=await jsonFetch(`${baseUrl}/message`,{method:'POST',body:JSON.stringify({session_id:sessionId,route:'costume',message:"Adult woman, scary complete costume, size L, under $50.",page_url:'https://www.discounthalloweencity.com/'})}).catch(e=>({status:0,ok:false,data:null,text:String(e)}));
  add(checks,'proxy.message',Boolean(m.ok),m.ok?'message endpoint responded':`HTTP ${m.status}: ${m.text||'no response'}`);
  add(checks,'contract.message_shape',Boolean(m.ok&&hasKeys(m.data,GUS_MESSAGE_KEYS)),m.ok?`keys: ${Object.keys(m.data||{}).join(', ')}`:'message unavailable');
  const products=Array.isArray(m.data?.products)?m.data.products:[];
  if(products.length){
    product=products[0];
    add(checks,'contract.product_shape',validProduct(product),validProduct(product)?'real Shopify product+variant IDs, price and PDP URL present':'product contract invalid');
    const action=(m.data?.actions||[]).find((a:any)=>a?.type==='VIEW_PRODUCT');
    add(checks,'contract.view_product',viewMatches(product,action),viewMatches(product,action)?'VIEW_PRODUCT matches exact recommended variant/PDP':'VIEW_PRODUCT does not match recommendation');
  }else{
    const q=String(m.data?.next_question||'');
    add(checks,'contract.backend_question_owner',Boolean(q&&Array.isArray(m.data?.choices)),q?'backend returned next_question + choices':'no products and no backend next_question');
    add(checks,'contract.product_shape',false,'blocked until this live journey reaches recommendations',true);
    add(checks,'contract.view_product',false,'blocked until a live product recommendation is returned',true);
  }
 }else{
  for(const id of ['proxy.message','contract.message_shape','contract.backend_question_owner','contract.product_shape','contract.view_product'])add(checks,id,false,'blocked because session start failed',true);
 }

 // All five frontend routes must start/resume as backend modes; do not hard-code questionnaire behavior here.
 for(const [route,prompt] of [['costume','Find My Costume'],['look','Complete My Look'],['decide','Help Me Decide'],['chat','Ask Gus Anything'],['order','Order Help']] as const){
  const rs=await jsonFetch(`${baseUrl}/session`,{method:'POST',body:JSON.stringify({page_url:'https://www.discounthalloweencity.com/',client:'v1055.1-certification'})}).catch(e=>({status:0,ok:false,data:null,text:String(e)}));
  const rid=String((rs as any).data?.session_id||'');
  if(!rid){add(checks,`route.${route}`,false,`session failed: HTTP ${(rs as any).status}`,false);continue;}
  const r=await jsonFetch(`${baseUrl}/message`,{method:'POST',body:JSON.stringify({session_id:rid,route,message:prompt,page_url:'https://www.discounthalloweencity.com/'})}).catch(e=>({status:0,ok:false,data:null,text:String(e)}));
  add(checks,`route.${route}`,Boolean((r as any).ok),(r as any).ok?`${route} route accepted by backend`:`HTTP ${(r as any).status}: ${(r as any).text||'no response'}`);
 }

 // Complete My Look: description path is safe to automate. Image binary/vision availability is a separate manual gate.
 if(sessionId){
  const img=await jsonFetch(`${baseUrl}/image`,{method:'POST',body:JSON.stringify({session_id:sessionId,description:'I already own a black witch dress. I need complementary accessories, makeup, wig or prop.'})}).catch(e=>({status:0,ok:false,data:null,text:String(e)}));
  add(checks,'proxy.image_description',Boolean((img as any).ok),(img as any).ok?'Complete My Look description pipeline responded':`HTTP ${(img as any).status}: ${(img as any).text||'no response'}`);
 }else add(checks,'proxy.image_description',false,'blocked because session start failed',true);

 // Cart validates exact variant but does not mutate a shopper cart during certification.
 if(sessionId&&product?.variant_id){
  const c=await jsonFetch(`${baseUrl}/cart`,{method:'POST',body:JSON.stringify({session_id:sessionId,action:'VALIDATE_ADD',variant_id:product.variant_id,product_id:product.product_id,quantity:1})}).catch(e=>({status:0,ok:false,data:null,text:String(e)}));
  add(checks,'proxy.cart_exact_variant',Boolean((c as any).ok&&(c as any).data?.requiresCustomerAction===true&&(c as any).data?.action?.variant_id===product.variant_id),(c as any).ok?'exact variant validated; customer action still required':`HTTP ${(c as any).status}: ${(c as any).text||'no response'}`);
 }else add(checks,'proxy.cart_exact_variant',false,'blocked until a live recommendation supplies an exact variant',true);

 // Privacy gate: certification deliberately omits checkout email. A safe refusal is the expected result.
 if(sessionId){
  const o=await jsonFetch(`${baseUrl}/order`,{method:'POST',body:JSON.stringify({session_id:sessionId,action:'OPEN_ORDER_HELP',payload:{order_number:'DHC-CERT-NO-ORDER',summary:'production certification privacy gate'}})}).catch(e=>({status:0,ok:false,data:null,text:String(e)}));
  const safeRefusal=!((o as any).ok)&&/email|required|order-specific|unavailable/i.test(String((o as any).data?.error||(o as any).text||''));
  add(checks,'proxy.order_privacy_gate',safeRefusal,safeRefusal?'order-specific disclosure refused without checkout email':`unexpected order response HTTP ${(o as any).status}: ${(o as any).text||''}`);
 }else add(checks,'proxy.order_privacy_gate',false,'blocked because session start failed',true);

 const fail=checks.filter(x=>x.status==='FAIL').length,blocked=checks.filter(x=>x.status==='BLOCKED').length,pass=checks.filter(x=>x.status==='PASS').length;
 const manualGates=[
  'Run v1055.1 as an unpublished Shopify theme: open Gus → route → questions → recommendation → PDP → reopen Gus → same session → back navigation.',
  'Upload a real non-sensitive test costume image in Complete My Look and verify observed vs uncertain image analysis plus complementary-only results.',
  'Use a dedicated test order and checkout email to verify authenticated Order Help status/tracking/actions without exposing another customer.',
  'Confirm the storefront executes ADD_EXACT_VARIANT only after shopper confirmation and that Shopify cart reflects the same variant/quantity.'
 ];
 return {version:GUS_V1055_CONTRACT_VERSION,theme:'v1055.1',backendRuntime:input.backendRuntime||'0.16.57-customer-service-excellence-persona-qa' /* previous: 0.16.50-r5-app-proxy-json-auth-recovery */,baseUrl,startedAt,finishedAt:new Date().toISOString(),checks,pass,fail,blocked,goLiveReady:fail===0&&blocked===0,manualGates};
}

export async function persistV1055Certification(shop:string,cert:Cert){
 await db.growthEvidence.create({data:{shop,source:'GUS_V1055_INTEGRATION_CERTIFICATION',reference:cert.finishedAt,rowsJson:JSON.stringify(cert)}}).catch(()=>{});
 return cert;
}
export async function latestV1055Certification(shop:string){
 const row=await db.growthEvidence.findFirst({where:{shop,source:'GUS_V1055_INTEGRATION_CERTIFICATION'},orderBy:{importedAt:'desc'}});
 if(!row)return null;try{return JSON.parse(row.rowsJson||'{}')}catch{return null}
}
