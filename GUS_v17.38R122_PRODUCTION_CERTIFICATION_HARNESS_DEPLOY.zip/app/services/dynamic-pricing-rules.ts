
import {recommendRetailPrice,inferPriceFloor,estimateMargin,type PricingInput} from './pricing.server.ts';
export type DynamicPricingInput=PricingInput&{
 title:string;productType?:string;demandState?:string;stockoutRisk?:string;supplierRisk?:string;
 daysToHalloween:number;competitorPrice?:number|null;acquisitionCostPerOrder?:number|null;
};
const money=(n:number)=>Math.round(n*100)/100;
function ending97(n:number){if(!Number.isFinite(n)||n<=0)return n;return money(Math.floor(n)+.97)}
export function dynamicPricingDecision(i:DynamicPricingInput){
 const floor=inferPriceFloor(i.title,29.97,19.97,16.97,i.productType||'');
 const base=recommendRetailPrice({...i,floorPrice:Math.max(i.floorPrice??0,floor??0)});
 if(base.status!=='PROPOSED'||base.recommendedPrice==null)return {...base,action:'REVIEW_REQUIRED' as const,confidence:.35,reasons:[base.reason]};
 let candidate=base.recommendedPrice,reasons:string[]=[];
 const demand=String(i.demandState||'').toUpperCase(),stock=String(i.stockoutRisk||'').toUpperCase(),supplier=String(i.supplierRisk||'').toUpperCase();
 // Never discount scarce/risky supply. Rising demand may support one controlled tier increase.
 if(['SURGING','RISING'].includes(demand)&&!['LOW','UNKNOWN',''].includes(stock)){candidate=Math.max(candidate,i.currentPrice);reasons.push('Rising demand plus constrained availability blocks an automated markdown recommendation.');}
 else if(demand==='SURGING'&&stock==='LOW'&&supplier!=='CRITICAL'){candidate=Math.max(candidate,ending97(i.currentPrice+2));reasons.push('Surging demand with healthy availability supports a small controlled price-up experiment.');}
 // Late-season urgency can justify a controlled markdown only when supply is healthy and margin remains protected.
 if(i.daysToHalloween<=14&&['SLOW','NO_SIGNAL'].includes(demand)&&stock==='LOW'){candidate=Math.min(candidate,ending97(Math.max(floor??0,i.currentPrice-2)));reasons.push('Late-season slow demand supports a small controlled markdown test.');}
 if(i.competitorPrice!=null&&Number.isFinite(i.competitorPrice)&&i.competitorPrice>0&&candidate>i.competitorPrice*1.08){const near=ending97(i.competitorPrice);const m=estimateMargin(near,i);if(Number.isFinite(m)&&m>=i.minimumMargin&&near>=(floor??0)){candidate=near;reasons.push('Verified competitor evidence supports a closer delivered-value price while preserving the minimum margin.');}}
 candidate=Math.max(candidate,floor??0,base.requiredPrice??0);candidate=ending97(candidate);
 // If acquisition cost is known, require it in contribution check. Do not assume one when missing.
 const shipping=i.shippingRevenueMode==='SINGLE_ITEM'&&candidate<i.shippingThreshold?i.customerShippingCharge:0;
 const revenue=candidate+shipping;
 const payment=revenue*i.paymentPercent+i.paymentFixed;
 const contribution=i.acquisitionCostPerOrder==null?null:money(revenue-i.productCost-(i.supplierShippingCost??0)-payment-i.acquisitionCostPerOrder);
 const currentContribution=i.acquisitionCostPerOrder==null?null:money((i.currentPrice+(i.shippingRevenueMode==='SINGLE_ITEM'&&i.currentPrice<i.shippingThreshold?i.customerShippingCharge:0))-i.productCost-(i.supplierShippingCost??0)-((i.currentPrice+(i.shippingRevenueMode==='SINGLE_ITEM'&&i.currentPrice<i.shippingThreshold?i.customerShippingCharge:0))*i.paymentPercent+i.paymentFixed)-i.acquisitionCostPerOrder);
 const changed=Math.abs(candidate-i.currentPrice)>=.01;
 return {status:'PROPOSED' as const,action:changed?'EXPERIMENT':'HOLD',recommendedPrice:candidate,currentPrice:i.currentPrice,floorPrice:floor,estimatedMargin:estimateMargin(candidate,i),currentMargin:estimateMargin(i.currentPrice,i),requiredPrice:base.requiredPrice,estimatedContribution:contribution,currentContribution,confidence:i.acquisitionCostPerOrder==null?.65:.85,reasons:[...reasons,...(i.acquisitionCostPerOrder==null?['Acquisition cost is missing, so contribution is not claimed and confidence is reduced.']:[])]};
}
