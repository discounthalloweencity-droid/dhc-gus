export type LayerState='PASS'|'FAIL'|'WARN'|'UNVERIFIED'|'SKIPPED';
export type CertificationVerdict='CERTIFIED'|'LOGIC_PASS_PROVIDER_UNVERIFIED'|'DEGRADED'|'FAILED';
export type CertificationLayer={state:LayerState;detail:string;durationMs?:number};
export type CertificationInputs={
 runtimeLoad:CertificationLayer;
 safeProbe:CertificationLayer;
 provider:CertificationLayer;
 execution:CertificationLayer;
 pureLogic?:boolean;
};

export function classifyEngineCertification(x:CertificationInputs):CertificationVerdict{
 if(x.runtimeLoad.state==='FAIL'||x.safeProbe.state==='FAIL'||x.execution.state==='FAIL'||x.provider.state==='FAIL')return 'FAILED';
 if(x.runtimeLoad.state==='WARN'||x.safeProbe.state==='WARN'||x.execution.state==='WARN'||x.provider.state==='WARN')return 'DEGRADED';
 if(x.pureLogic&&x.runtimeLoad.state==='PASS'&&x.safeProbe.state==='PASS')return 'CERTIFIED';
 if(x.runtimeLoad.state==='PASS'&&x.safeProbe.state==='PASS'&&x.provider.state==='PASS'&&x.execution.state==='PASS')return 'CERTIFIED';
 return 'LOGIC_PASS_PROVIDER_UNVERIFIED';
}

export function summarizeCertification(results:Array<{verdict:CertificationVerdict}>){
 const counts={CERTIFIED:0,LOGIC_PASS_PROVIDER_UNVERIFIED:0,DEGRADED:0,FAILED:0};
 for(const r of results)counts[r.verdict]++;
 return {total:results.length,...counts,allCertified:results.length>0&&counts.CERTIFIED===results.length};
}
