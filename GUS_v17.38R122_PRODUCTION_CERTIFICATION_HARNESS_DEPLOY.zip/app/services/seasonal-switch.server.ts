import {db} from '../db.server';
import {loadSales} from './reporting.server';
import {availabilityForShop} from './availability.server';
import {automationState,requireAutomationRunning} from './automation-control.server';
import {liveWritesEnabled,requireLiveWrites} from './deployment-gates';
import {graphqlData,isShopifyThrottleError,updateProductStatus} from './shopify-api.server';
import {registerError} from './error-registry.server';
import {effectiveSeasonalMode,seasonalProductWarehouseDecision,seasonalSeasonYear,verifiedUsWarehouse} from './seasonal-switch';
import {databaseSchemaHealth,workerSchemaGate} from './database-schema-health.server';
export {effectiveSeasonalMode,seasonalSeasonYear,verifiedUsWarehouse} from './seasonal-switch';

const SEASONAL_PRODUCT_QUERY=`#graphql
query GusSeasonalProducts($ids:[ID!]!){
  nodes(ids:$ids){
    ... on Product{
      id status
      variants(first:250){pageInfo{hasNextPage}nodes{id}}
    }
  }
}`;
const SHOP_TIME_ZONE_QUERY=`#graphql query GusSeasonalShopTimeZone{shop{ianaTimezone}}`;
const chunk=<T,>(rows:T[],size:number)=>{const out:T[][]=[];for(let i=0;i<rows.length;i+=size)out.push(rows.slice(i,i+size));return out;};

export async function getSeasonalSwitchConfig(shop:string){
 return db.storeConfig.upsert({where:{shop},create:{shop},update:{}});
}

export async function resolveSeasonalShopTimeZone(admin:any){
 const data=await graphqlData(admin,SHOP_TIME_ZONE_QUERY,{});
 return String(data?.shop?.ianaTimezone||'UTC').trim()||'UTC';
}

export async function seasonalSwitchState(shop:string,now=new Date(),timeZone='UTC'){
 const config=await getSeasonalSwitchConfig(shop);
 return {config,effectiveMode:effectiveSeasonalMode(config,now,timeZone),seasonYear:seasonalSeasonYear(config,now,timeZone),evaluatedAt:now.toISOString(),timeZone};
}

export async function loadSeasonalSwitch(admin:any,shop:string,now=new Date()){
 let timeZone='UTC',timeZoneError:string|null=null;
 try{timeZone=await resolveSeasonalShopTimeZone(admin);}catch(error:any){timeZoneError=String(error?.message||error);}
 const [{config,effectiveMode,evaluatedAt,seasonYear},links,salesResult,managed]=await Promise.all([
  seasonalSwitchState(shop,now,timeZone),
  db.supplierVariantLink.findMany({where:{shop,enabled:true},select:{variantGid:true,productGid:true,supplier:true,warehouse:true,updatedAt:true}}),
  (async()=>{try{return {ok:true,data:await loadSales(admin,shop,30)};}catch(e:any){return {ok:false,error:String(e?.message||e),data:null};}})(),
  db.seasonalManagedArchive.findMany({where:{shop,archiveApplied:true},orderBy:{createdAt:'desc'},take:10000}).catch(()=>[] as any[])
 ]);
 const usLinks=links.filter(l=>verifiedUsWarehouse(l.warehouse));
 const usVariants=new Set(usLinks.map(l=>l.variantGid));
 const usProducts=new Set(usLinks.map(l=>l.productGid));
 let sellingUsVariants=0,units=0,revenue=0;
 if(salesResult.ok){for(const p of salesResult.data!.summary.products||[]){if(usVariants.has(p.variantId)&&p.units>0){sellingUsVariants++;units+=p.units;revenue+=p.revenue;}}}
 return {
  config,effectiveMode,evaluatedAt,seasonYear,timeZone,timeZoneError,
  evidence:{mappedVariants:links.length,verifiedUsVariants:usVariants.size,verifiedUsProducts:usProducts.size,verifiedUsLinks:usLinks.length,salesAvailable:salesResult.ok,sellingUsVariants,units,revenue,salesError:salesResult.ok?null:salesResult.error},
  managed:{archived:managed.filter((r:any)=>!r.restoredAt).length,restored:managed.filter((r:any)=>!!r.restoredAt).length},
  note:'USA eligibility is counted only when stored supplier warehouse evidence explicitly identifies a US/USA/United States warehouse. Seasonal archival requires complete current variant coverage plus explicit non-US warehouse evidence; blank or ambiguous origin is never auto-archived. Every Seasonal Switch archive is ledgered for automatic restoration when FULL CATALOG resumes.'
 };
}

export async function setSeasonalSwitch(shop:string,input:{mode:string;cutoffMonth?:number;cutoffDay?:number;restoreMonth?:number;restoreDay?:number}){
 const mode=String(input.mode||'').toUpperCase();
 if(!['AUTO','FULL_CATALOG','USA_ONLY'].includes(mode))throw new Error('Seasonal Switch mode must be AUTO, FULL_CATALOG, or USA_ONLY.');
 const int=(n:unknown,min:number,max:number,label:string)=>{const x=Number(n);if(!Number.isSafeInteger(x)||x<min||x>max)throw new Error(`Invalid ${label}.`);return x;};
 const cutoffMonth=int(input.cutoffMonth??10,1,12,'cutoff month'),cutoffDay=int(input.cutoffDay??12,1,31,'cutoff day');
 const restoreMonth=int(input.restoreMonth??11,1,12,'restore month'),restoreDay=int(input.restoreDay??1,1,31,'restore day');
 return db.$transaction(async tx=>{
  const before=await tx.storeConfig.upsert({where:{shop},create:{shop},update:{}});
  const after=await tx.storeConfig.update({where:{shop},data:{seasonalSwitchMode:mode,seasonalCutoffMonth:cutoffMonth,seasonalCutoffDay:cutoffDay,seasonalRestoreMonth:restoreMonth,seasonalRestoreDay:restoreDay}});
  await tx.changeLog.create({data:{shop,action:'SEASONAL_SWITCH_POLICY',field:'seasonalSwitchMode',beforeValue:JSON.stringify({mode:before.seasonalSwitchMode,cutoff:[before.seasonalCutoffMonth,before.seasonalCutoffDay],restore:[before.seasonalRestoreMonth,before.seasonalRestoreDay]}),afterValue:JSON.stringify({mode,cutoff:[cutoffMonth,cutoffDay],restore:[restoreMonth,restoreDay]}),reason:'Merchant Seasonal Switch control update. Automatic archive/restore remains evidence-gated and reversible through the Seasonal Switch ledger.',reversible:true}});
  return after;
 });
}

function variantGroups(availability:any){
 const groups=new Map<string,any[]>();
 for(const row of availability.variants.values()){
  const productGid=String(row.productGid||'');if(!productGid)continue;
  const list=groups.get(productGid)||[];list.push(row);groups.set(productGid,list);
 }
 return groups;
}

function groupDecision(rows:any[]){
 return seasonalProductWarehouseDecision(rows.map(row=>({coverageComplete:!!row.coverageComplete,warehouses:(row.links||[]).map((link:any)=>link.warehouse)})));
}

async function currentSeasonalProducts(admin:any,ids:string[]){
 const out=new Map<string,any>();
 for(const batch of chunk(ids,10)){
  const data=await graphqlData(admin,SEASONAL_PRODUCT_QUERY,{ids:batch});
  for(const node of data?.nodes||[])if(node?.id)out.set(String(node.id),node);
 }
 return out;
}

function sameVariantSet(shopifyProduct:any,rows:any[]){
 if(!shopifyProduct||shopifyProduct.variants?.pageInfo?.hasNextPage)return false;
 const a=(shopifyProduct.variants?.nodes||[]).map((v:any)=>String(v.id)).filter(Boolean).sort();
 const b=rows.map((v:any)=>String(v.variantGid)).filter(Boolean).sort();
 return a.length===b.length&&a.every((id:string,index:number)=>id===b[index]);
}

async function archiveSeasonalProducts(admin:any,shop:string,config:any,seasonYear:number,limit:number,apply:boolean){
 const availability=await availabilityForShop(shop);
 const groups=variantGroups(availability);
 const candidateIds=[...groups.entries()].filter(([,rows])=>groupDecision(rows)==='ARCHIVE_ELIGIBLE').map(([id])=>id).sort().slice(0,Math.max(limit*4,limit));
 if(!candidateIds.length)return {scanned:groups.size,candidates:0,changed:0,remaining:0,skipped:0};
 const products=await currentSeasonalProducts(admin,candidateIds);
 let changed=0,skipped=0;const eligible:any[]=[];
 for(const productGid of candidateIds){
  const rows=groups.get(productGid)||[],product=products.get(productGid);
  if(!product||String(product.status)!=='ACTIVE'||!sameVariantSet(product,rows)){skipped++;continue;}
  const existing=await db.seasonalManagedArchive.findUnique({where:{shop_productGid_seasonYear:{shop,productGid,seasonYear}}}).catch(()=>null);
  if(existing?.archiveApplied&&!existing.restoredAt){skipped++;continue;}
  eligible.push({productGid,rows});
  if(eligible.length>=limit)break;
 }
 if(!apply)return {scanned:groups.size,candidates:eligible.length,changed:0,remaining:Math.max(0,candidateIds.length-eligible.length-skipped),skipped,preview:true};
 if(eligible.length){await requireAutomationRunning(shop);requireLiveWrites();}
 for(const item of eligible){
  const evidence={mode:'USA_ONLY',seasonYear,variantEvidence:item.rows.map((row:any)=>({variantGid:row.variantGid,coverageComplete:!!row.coverageComplete,warehouses:(row.links||[]).map((l:any)=>({supplier:l.supplier,warehouse:l.warehouse}))})),evaluatedAt:new Date().toISOString()};
  const ledger=await db.seasonalManagedArchive.upsert({where:{shop_productGid_seasonYear:{shop,productGid:item.productGid,seasonYear}},create:{shop,productGid:item.productGid,seasonYear,previousStatus:'ACTIVE',evidenceJson:JSON.stringify(evidence)},update:{evidenceJson:JSON.stringify(evidence)}});
  if(ledger.archiveApplied&&!ledger.restoredAt)continue;
  const fresh=await currentSeasonalProducts(admin,[item.productGid]);const current=fresh.get(item.productGid);
  if(!current||String(current.status)!=='ACTIVE'||!sameVariantSet(current,item.rows)||groupDecision(item.rows)!=='ARCHIVE_ELIGIBLE'){skipped++;continue;}
  await updateProductStatus(admin,item.productGid,'ARCHIVED');
  const at=new Date();
  await db.$transaction(async tx=>{
   await tx.seasonalManagedArchive.update({where:{id:ledger.id},data:{archiveApplied:true,archivedAt:at,restoredAt:null,restoreReason:null,evidenceJson:JSON.stringify(evidence)}});
   await tx.changeLog.create({data:{shop,productGid:item.productGid,action:'SEASONAL_SWITCH_ARCHIVE',field:'status',beforeValue:'ACTIVE',afterValue:'ARCHIVED',reason:`Seasonal Switch USA_ONLY ${seasonYear}: complete verified supplier coverage shows every current variant is non-US sourced. Auto-restore is scheduled when FULL CATALOG resumes.`,source:'SEASONAL_SWITCH',reversible:true}});
  });
  changed++;
 }
 return {scanned:groups.size,candidates:eligible.length,changed,remaining:Math.max(0,candidateIds.length-eligible.length-skipped),skipped};
}

async function restoreSeasonalProducts(admin:any,shop:string,limit:number,apply:boolean){
 const availability=await availabilityForShop(shop);const availabilityGroups=variantGroups(availability);
 const pending=await db.seasonalManagedArchive.findMany({where:{shop,archiveApplied:true,restoredAt:null},orderBy:{archivedAt:'asc'},take:Math.max(1,limit)});
 if(!pending.length)return {pending:0,changed:0,blocked:0};
 const current=await currentSeasonalProducts(admin,pending.map((r:any)=>r.productGid));
 let changed=0,blocked=0;
 if(apply){await requireAutomationRunning(shop);requireLiveWrites();}
 for(const row of pending){
  const product=current.get(row.productGid);const status=String(product?.status||'');
  if(status==='ACTIVE'){
   await db.seasonalManagedArchive.update({where:{id:row.id},data:{restoredAt:new Date(),restoreReason:'Already active when Seasonal Switch restore reconciliation ran.'}});continue;
  }
  if(status!=='ARCHIVED'){blocked++;continue;}
  // A separate managed availability archive is stronger than the seasonal
  // ledger. Do not resurrect a product that is currently held for a verified
  // stockout/availability reason.
  const availabilityHold=await db.availabilityManagedArchive.findUnique({where:{shop_productGid:{shop,productGid:row.productGid}}}).catch(()=>null);
  const currentAvailabilityRows=availabilityGroups.get(row.productGid)||[];
  const confirmedOutOfStock=currentAvailabilityRows.length>0&&currentAvailabilityRows.every((v:any)=>v.coverageComplete&&v.status==='OUT_OF_STOCK');
  const laterArchive=await db.changeLog.findFirst({where:{shop,productGid:row.productGid,action:'ARCHIVE',createdAt:{gt:row.archivedAt||row.createdAt}},orderBy:{createdAt:'desc'}}).catch(()=>null);
  if(availabilityHold||confirmedOutOfStock||laterArchive){blocked++;continue;}
  if(!apply)continue;
  await updateProductStatus(admin,row.productGid,'ACTIVE');
  const restoredAt=new Date(),reason='Seasonal Switch automatic post-Halloween restore: product was archived by Seasonal Switch only and FULL CATALOG is active.';
  await db.$transaction(async tx=>{
   await tx.seasonalManagedArchive.update({where:{id:row.id},data:{restoredAt,restoreReason:reason}});
   await tx.changeLog.create({data:{shop,productGid:row.productGid,action:'SEASONAL_SWITCH_RESTORE',field:'status',beforeValue:'ARCHIVED',afterValue:'ACTIVE',reason,source:'SEASONAL_SWITCH',reversible:true}});
  });
  changed++;
 }
 return {pending:pending.length,changed,blocked};
}

export async function runSeasonalSwitchMaintenance(admin:any,shop:string,options:{now?:Date;apply?:boolean;limit?:number}={}){
 const now=options.now||new Date(),apply=options.apply??liveWritesEnabled(),limit=Math.max(1,Math.min(100,Number(options.limit||40)));
 const schema=await databaseSchemaHealth();
 const gate=await workerSchemaGate('seasonalSwitch',schema);
 if(!gate.allowed)return {status:'SCHEMA_DEGRADED' as const,changed:0,missingTables:gate.missing,message:`Seasonal Switch paused safely because required database tables are missing: ${gate.missing.join(', ')}`};
 const job=await db.jobRun.create({data:{shop,jobType:'SEASONAL_SWITCH_MAINTENANCE',status:'RUNNING',details:JSON.stringify({phase:'STARTING'})}});
 try{
  const timeZone=await resolveSeasonalShopTimeZone(admin);
  const config=await getSeasonalSwitchConfig(shop),mode=effectiveSeasonalMode(config,now,timeZone),seasonYear=seasonalSeasonYear(config,now,timeZone);
  const automation=await automationState(shop);
  if(!automation?.running&&apply){
   await db.jobRun.update({where:{id:job.id},data:{status:'DONE',details:JSON.stringify({phase:'PAUSED',mode,timeZone,seasonYear,message:'Automation is stopped; Seasonal Switch did not write.'}),finishedAt:new Date()}});
   return {status:'PAUSED' as const,jobId:job.id,mode,timeZone,seasonYear,changed:0};
  }
  const result=mode==='USA_ONLY'?await archiveSeasonalProducts(admin,shop,config,seasonYear,limit,apply):await restoreSeasonalProducts(admin,shop,limit,apply);
  const changed=Number(result.changed||0),warnings=Number((result as any).blocked||0);
  await db.jobRun.update({where:{id:job.id},data:{status:'DONE',scanned:Number((result as any).scanned||(result as any).pending||0),changed,warnings,details:JSON.stringify({phase:'COMPLETE',mode,timeZone,seasonYear,apply,...result,message:mode==='USA_ONLY'?'Seasonal Switch evaluated verified non-US products for cutoff protection.':'Seasonal Switch reconciled post-Halloween restoration ledger.'}),finishedAt:new Date()}});
  const resolvedAt=new Date();
  await Promise.all([
   db.errorEvent.updateMany({where:{shop,source:'SEASONAL_SWITCH_WORKER',status:'OPEN',message:{contains:'Throttled'}},data:{status:'RESOLVED',resolvedAt,resolution:'Seasonal Switch completed after Shopify throttle recovery.'}}).catch(()=>{}),
   db.errorEvent.updateMany({where:{shop,source:'SEASONAL_SWITCH_WORKER',status:'OPEN',message:{contains:'SeasonalManagedArchive'}},data:{status:'RESOLVED',resolvedAt,resolution:'0.16.50 startup verified the SeasonalManagedArchive restoration ledger and a Seasonal Switch maintenance cycle completed successfully.'}}).catch(()=>{}),
  ]);
  return {status:'DONE' as const,jobId:job.id,mode,timeZone,seasonYear,apply,...result};
 }catch(error:any){
  const message=String(error?.message||error);
  if(isShopifyThrottleError(error)){
   const retryAfterMs=15*60*1000;
   await db.jobRun.update({where:{id:job.id},data:{status:'WAITING',details:JSON.stringify({phase:'THROTTLED_WAIT',message:'Shopify temporarily throttled Seasonal Switch evidence. No unsafe write was made; Gus will retry automatically.',retryAfterMs}),finishedAt:new Date()}}).catch(()=>{});
   await registerError({shop,source:'SEASONAL_SWITCH_WORKER',route:'/app/seasonal-switch',jobType:'SEASONAL_SWITCH_MAINTENANCE',message:'Throttled',severity:'WARN',context:{jobId:job.id,retryAfterMs}}).catch(()=>null);
   void import('./runtime-orchestrator-pulse.server').then(m=>m.requestAutonomousPulse(shop,retryAfterMs)).catch(()=>{});
   return {status:'WAITING' as const,jobId:job.id,changed:0,throttled:true,retryAfterMs};
  }
  await db.jobRun.update({where:{id:job.id},data:{status:'FAILED',details:JSON.stringify({phase:'FAILED',message}),finishedAt:new Date()}}).catch(()=>{});
  await registerError({shop,source:'SEASONAL_SWITCH_WORKER',route:'/app/seasonal-switch',jobType:'SEASONAL_SWITCH_MAINTENANCE',message,stack:error?.stack,severity:'ERROR',context:{jobId:job.id}}).catch(()=>null);
  throw error;
 }
}
