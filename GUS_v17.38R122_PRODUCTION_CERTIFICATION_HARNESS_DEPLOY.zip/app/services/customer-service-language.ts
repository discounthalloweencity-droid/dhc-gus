import {CUSTOMER_SERVICE_JARGON,CUSTOMER_SERVICE_TYPO_MAP,CUSTOMER_SERVICE_LANGUAGE_DRILLS} from '../knowledge/customer-service-language-academy-v1.ts';

export type UnderstoodCustomerLanguage={original:string;normalized:string;corrections:string[];jargon:string[];primaryIntent:string;secondaryIntents:string[];confidence:number;matched:string[]};

const INTENTS:{id:string;patterns:RegExp[]}[]=[
 {id:'INTERNAL',patterns:[/\binternal\s+(?:dhc|discount halloween city)\b/,/\binternal.{0,24}(?:escalation|case|ticket)\b/]},
 {id:'SUPPLIER_OPERATION',patterns:[/\b(?:cj\s*dropshipping|dsers|syncee|aliexpress)\b.{0,40}\b(?:sourcing|supplier|fulfillment|warehouse|request)\b/,/\bsourcing request\b/]},
 {id:'PLATFORM_NOTIFICATION',patterns:[/\bshopify\b.{0,32}\b(?:payout|notification|alert|billing|platform)\b/,/\bplatform notification\b/]},
 {id:'MARKETING_SOLICITATION',patterns:[/\b(?:improve|boost|grow).{0,30}\b(?:seo|backlinks?|traffic|rankings?)\b/,/\bseo backlinks?\b/]},
 {id:'SPAM_SCAM',patterns:[/\byou won\b.{0,30}\b(?:bitcoin|crypto|prize|gift)\b/,/\bclick here\b.{0,30}\b(?:bitcoin|crypto|prize)\b/]},
 {id:'CHARGEBACK',patterns:[/\bchargeback\b/,/\bbank dispute\b/,/\bdispute (?:the )?charge\b/]},
 {id:'LEGAL_REGULATORY',patterns:[/\battorney\b/,/\blawyer\b/,/\blegal action\b/,/\bbetter business bureau\b/,/\bconsumer protection\b/]},
 {id:'UNRECOGNIZED_CHARGE',patterns:[/\bunrecognized charged?\b/,/\bdon.?t recognize.{0,24}charged?\b/,/\bfraud(?:ulent)? charged?\b/,/\bidentity theft\b/]},
 {id:'DUPLICATE_CHARGE',patterns:[/\bduplicate charged?\b/,/\bdouble charged?\b/,/\bcharged twice\b/]},
 {id:'MISSING_DELIVERY',patterns:[/\bmarked delivered.{0,28}(?:not here|missing|did not receive)\b/,/\bsays (?:delivered|delivery).{0,28}(?:not here|missing|did not receive)\b/,/\bstolen package\b/,/\bporch pirate\b/]},
 {id:'RETURN_TO_SENDER',patterns:[/\breturn(?:ed)? to sender\b/,/\breturned2sender\b/,/\brts\b/]},
 {id:'DELIVERY_EXCEPTION',patterns:[/\bdelivery exception\b/,/\bfailed delivery\b/,/\bcarrier exception\b/,/\bheld at (?:carrier|post office|facility)\b/]},
 {id:'TRACKING_NO_MOVEMENT',patterns:[/\btracking.{0,30}(?:not moved|no movement|stuck|has not moved|hasn.?t moved)\b/,/\blabel created.{0,35}(?:no carrier movement|no scan|not moved|week|days?)\b/,/\bno carrier scan\b/,/\bpre-?shipment.{0,24}(?:no movement|week|days?)\b/]},
 {id:'NOT_SHIPPED',patterns:[/\bnot shipped\b/,/\bhas (?:not|n.?t) shipped\b/,/\bhasn.?t shipped\b/,/\bstill processing\b/,/\bwhy.{0,18}ship\b/]},
 {id:'LATE_DELIVERY',patterns:[/\blate\b/,/\bmissed (?:the )?(?:delivery|date)\b/,/\bneeded it by\b/,/\bwas supposed to arrive\b/]},
 {id:'ADDRESS_CHANGE',patterns:[/\bchange.{0,20}(?:shipping )?address\b/,/\bwrong address\b/,/\bshipping address.{0,15}(?:change|wrong)\b/]},
 {id:'CANCEL_ORDER',patterns:[/\bcancel.{0,20}(?:order|purchase)\b/,/\bstop.{0,15}(?:order|purchase)\b/]},
 {id:'ORDER_CHANGE',patterns:[/\bchange.{0,20}(?:quantity|qty|item|order|variant|color)\b/,/\bmodify.{0,18}order\b/]},
 {id:'CUSTOMER_ORDERED_WRONG',patterns:[/\b(?:i|we)\s+(?:accidentally\s+)?ordered\s+(?:the\s+)?wrong\s+(?:item|costume|size|color|product)\b/,/\b(?:i|we)\s+(?:picked|selected|chose)\s+(?:the\s+)?wrong\s+(?:item|costume|size|color|product)\b/]},
 {id:'WRONG_ITEM',patterns:[/\b(?:you|seller|store|they)\s+(?:sent|shipped).{0,20}(?:wrong|incorrect|different)\b/,/\b(?:received|got|was sent).{0,20}(?:the )?(?:wrong|incorrect|different) (?:item|costume|size|color|product)\b/,/\b(?:not|isn.?t|wasn.?t).{0,14}what i ordered\b/,/\bsent.{0,20}(?:wrong|incorrect) (?:item|costume|size|product)\b/,/\bwrong size.{0,24}you sent\b/,/\byou sent.{0,30}instead of\b/]},
 {id:'DAMAGED_ITEM',patterns:[/\bdamaged\b/,/\bbroken\b/,/\btorn\b/,/\bdefective\b/]},
 {id:'MISSING_ITEM',patterns:[/\bmissing (?:item|piece|accessory)\b/,/\bone (?:item|piece|accessory).{0,15}missing\b/,/\bnot in (?:the )?(?:box|package|order)\b/]},
 {id:'PARTIAL_SHIPMENT',patterns:[/\bpartial shipment\b/,/\bonly (?:half|part).{0,20}(?:came|arrived)\b/,/\bsplit shipment\b/]},
 {id:'SOLD_OUT',patterns:[/\bout of stock\b/,/\bsold out\b/,/\boversold\b/,/\bbackordered\b/]},
 {id:'REPLACEMENT_ACCEPTED',patterns:[/\boption\s*[1-3]\b.{0,20}(?:works|send|yes)\b/,/\b(?:yes|okay|ok).{0,20}(?:replacement|option)\b/]},
 {id:'REPLACEMENT_REQUEST',patterns:[/\breplacement\b/,/\bsend (?:the )?(?:correct|new) (?:one|item|size)\b/]},
 {id:'REFUND_STATUS',patterns:[/\bwhere.{0,15}(?:is )?my refund\b/,/\brefund.{0,15}(?:pending|never came|not received|status)\b/]},
 {id:'REFUND_REQUEST',patterns:[/\brefund\b/,/\bmoney back\b/,/\brefund me\b/]},
 {id:'WRONG_SIZE_FIT',patterns:[/\b(?:costume|item|cape|mask|dress|shirt|pants|robe|jacket|accessory|outfit|wings|gloves?|hat|piece).{0,24}(?:too small|too large|too big|too tight|too loose|does not fit|doesn.?t fit)\b/,/\b(?:too small|too large|too big|too tight|too loose)\b/,/\bneed (?:a )?(?:bigger|larger|smaller) size\b/,/\bordered wrong size\b/]},
 {id:'EXCHANGE_REQUEST',patterns:[/\bexchange\b/,/\bswap (?:size|it|item)\b/,/\bdifferent size\b/,/\bchange size\b/]},
 {id:'RETURN_REQUEST',patterns:[/\b(?:want|need|would like|like) to return\b/,/\breturn (?:this|item|order|costume|product|cape|accessory)\b/,/\breturn or exchange\b/,/\bexchange or return\b/,/\bsend (?:it|this) back\b/,/\breturn authorization\b/]},
 {id:'DUPLICATE_ORDER',patterns:[/\bordered twice\b/,/\bduplicate order\b/,/\btwo identical orders\b/]},
 {id:'ORDER_CONFIRMATION',patterns:[/\b(?:never|did not).{0,14}(?:get|got|receive).{0,16}(?:order )?confirmation\b/,/\bmissing confirmation\b/]},
 {id:'PAYMENT_DECLINED',patterns:[/\bcard.{0,24}declined\b/,/\bpayment.{0,12}(?:failed|declined)\b/]},
 {id:'DISCOUNT_PROMO',patterns:[/\b(?:promo|promotion|coupon|discount code).{0,20}(?:not work|won.?t work|invalid|failed)\b/]},
 {id:'FREE_SHIPPING',patterns:[/\bfree shipping\b/,/\bexpected free shipping\b/,/\bcheckout.{0,36}(?:adding|charging).{0,18}shipping\b/]},
 {id:'SHIPPING_FEE',patterns:[/\bshipping (?:fee|charge|cost)\b/,/\bwhy.{0,18}(?:pay|charged).{0,18}shipping\b/]},
 {id:'PRODUCT_CONTENTS',patterns:[/\bwhat.{0,12}(?:comes with|included)\b/,/\b(?:does|is).{0,20}(?:wig|mask|accessory).{0,20}included\b/,/\bincluded.{0,24}(?:wig|mask|accessory)\b/]},
 {id:'PRODUCT_MATERIAL',patterns:[/\bmaterial\b/,/\bfabric\b/,/\bmade of\b/,/\ballergy\b/]},
 {id:'PRODUCT_SIZE',patterns:[/\bsize chart\b/,/\bwhat (?:size|sz)\b/,/\bmeasurements?\b/,/\bfit\b/]},
 {id:'PRODUCT_AVAILABILITY',patterns:[/\bin stock\b/,/\bavailable\b/,/\bhave.{0,12}(?:size|xl|small|medium|large)\b/]},
 {id:'DELIVERY_BEFORE_DATE',patterns:[/\b(?:arrive|get here|delivered).{0,18}(?:before|by).{0,24}(?:halloween|oct(?:ober)?\s*31|party|event|friday|saturday|sunday|tomorrow)\b/]},
 {id:'BULK_GROUP_ORDER',patterns:[/\b(?:bulk|group|family|team).{0,18}(?:order|costumes?)\b/,/\bneed\s+(?:[5-9]|[1-9]\d+)\s+.{0,18}costumes?\b/]},
 {id:'PRIVACY_REQUEST',patterns:[/\bdelete.{0,18}(?:my )?(?:data|information|account)\b/,/\bprivacy request\b/,/\baccess my data\b/]},
 {id:'UNSUBSCRIBE',patterns:[/\bunsubscribe\b/,/\bstop.{0,18}(?:marketing|emails|emailing)\b/]},
 {id:'ACCOUNT_ACCESS',patterns:[/\bcan.?t log ?in\b/,/\bforgot password\b/,/\baccount locked\b/]},
 {id:'POSITIVE_FEEDBACK',patterns:[/\bthank you\b/,/\bthanks.{0,20}(?:help|fixed|great)\b/,/\bgreat service\b/]},
 {id:'GENERAL_COMPLAINT',patterns:[/\bterrible (?:service|experience)\b/,/\b(?:service|experience).{0,24}terrible\b/,/\bworst (?:service|experience)\b/,/\bvery disappointed\b/]},
 {id:'ORDER_STATUS',patterns:[/\bwhere.{0,16}(?:order|package)\b/,/\border status\b/,/\btracking\b/,/\bestimated arrival\b/,/\bhas (?:it|my (?:order|package)|the (?:order|package)) been shipped\b/,/\bhas (?:my |the )?(?:order|package) shipped\b/,/\bdid (?:my |the )?(?:order|package) ship\b/,/\bis (?:my |the )?(?:order|package) shipped\b/]},
];

const CANONICAL_WORDS=new Set(['order','costume','package','shipment','shipped','delivery','receive','received','delivered','refund','refunded','return','replacement','damaged','broken','wrong','incorrect','missing','address','cancel','cancellation','tracking','status','confirmation','duplicate','charged','declined','payment','available','inventory','size','small','large','cape','fit','measurements','material','included','accessory','shipping','fulfillment','supplier','shopify','chargeback','fraudulent','attorney','lawyer','privacy','unsubscribe','password','verification','verify','case','charge','change','quantity','different']);

function dist(a:string,b:string){const m=a.length,n=b.length,d=Array.from({length:m+1},()=>Array(n+1).fill(0));for(let i=0;i<=m;i++)d[i][0]=i;for(let j=0;j<=n;j++)d[0][j]=j;for(let i=1;i<=m;i++)for(let j=1;j<=n;j++)d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1));return d[m][n];}
function fuzzyWord(w:string){if(w.length<4||/\d/.test(w))return null;let best:string|null=null,bestD=99;for(const c of CANONICAL_WORDS){if(Math.abs(c.length-w.length)>2)continue;const dd=dist(w,c);const limit=w.length>=8?2:1;if(dd<=limit&&dd<bestD){best=c;bestD=dd;}}return best;}
function replacePhrases(input:string,map:Record<string,string>,hits:string[]){let s=input;for(const [from,to] of Object.entries(map).sort((a,b)=>b[0].length-a[0].length)){const re=new RegExp(`(^|[^a-z0-9])${from.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}(?=$|[^a-z0-9])`,'gi');if(re.test(s)){hits.push(`${from}→${to}`);s=s.replace(re,(_,p)=>`${p}${to}`);}}return s;}

export function understandCustomerServiceLanguage(raw:string):UnderstoodCustomerLanguage{
 const original=String(raw||'').slice(0,12000);let s=original.toLowerCase().replace(/[’]/g,"'").replace(/\s+/g,' ').trim();const jargon:string[]=[];const corrections:string[]=[];
 s=replacePhrases(s,CUSTOMER_SERVICE_JARGON,jargon);s=replacePhrases(s,CUSTOMER_SERVICE_TYPO_MAP,corrections);
 const tokens=s.split(/(\b)/);for(let i=0;i<tokens.length;i++){const w=tokens[i];if(!/^[a-z]{4,}$/.test(w)||CANONICAL_WORDS.has(w))continue;const f=fuzzyWord(w);if(f&&f!==w){corrections.push(`${w}→${f}`);tokens[i]=f;}}
 s=tokens.join('').replace(/\s+/g,' ').trim();const scores:{id:string;score:number;matches:string[]}[]=[];
 for(const intent of INTENTS){const matches=intent.patterns.filter(r=>r.test(s)).map(r=>r.source);if(matches.length)scores.push({id:intent.id,score:Math.min(.99,.70+matches.length*.12),matches});}
 scores.sort((a,b)=>b.score-a.score);const primary=scores[0]?.id||'UNKNOWN';const secondary=scores.slice(1,4).map(x=>x.id);const confidence=scores[0]?.score??(corrections.length||jargon.length?.65:.40);
 return {original,normalized:s,corrections:[...new Set(corrections)].slice(0,20),jargon:[...new Set(jargon)].slice(0,20),primaryIntent:primary,secondaryIntents:secondary,confidence,matched:scores[0]?.matches||[]};
}

export function evaluateCustomerServiceLanguageAcademy(){
 const checks=CUSTOMER_SERVICE_LANGUAGE_DRILLS.map(d=>{const actual=understandCustomerServiceLanguage(d.message);return {...d,actualIntent:actual.primaryIntent,normalized:actual.normalized,ok:actual.primaryIntent===d.expectedIntent};});
 const passed=checks.filter(x=>x.ok).length;const hardFailures=checks.filter(x=>x.hardGate&&!x.ok);return {version:'DHC-CUSTOMER-SERVICE-LANGUAGE-1.0',passed,total:checks.length,accuracy:checks.length?passed/checks.length:0,hardFailures,failures:checks.filter(x=>!x.ok),checks,pass:passed===checks.length&&hardFailures.length===0};
}
