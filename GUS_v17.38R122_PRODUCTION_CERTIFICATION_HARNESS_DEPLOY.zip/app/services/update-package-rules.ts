export type UpdateManifest = {
  schemaVersion: '1.0';
  type: 'DHC_GUS_UPDATE';
  fromVersion: string;
  targetVersion: string;
  createdAt: string;
  notes?: string;
  files: Array<{path:string; sha256:string}>;
  deletes?: string[];
  requiresDbMigration?: boolean;
  requiresDependencyInstall?: boolean;
  restartRequired?: boolean;
  godaddySource?: {path:string; sha256:string};
};

export function validateUpdatePath(input:string){
  const p=input.replace(/\\/g,'/').replace(/^\.\//,'');
  if(!p || p.startsWith('/') || p.includes('\0') || p.split('/').includes('..')) throw new Error(`Unsafe update path: ${input}`);
  const blocked=['.env','.env.production','.env.staging','node_modules/','.git/','.dhc-updates/'];
  if(blocked.some(x=>p===x.replace(/\/$/,'')||p.startsWith(x))) throw new Error(`Protected path cannot be updated: ${p}`);
  const allowed=['app/','prisma/','scripts/','config/','public/','docs/','server.js','package.json','package-lock.json','react-router.config.ts','tsconfig.json','vite.config.ts','shopify.app.toml','shopify.web.toml'];
  if(!allowed.some(x=>x.endsWith('/')?p.startsWith(x):p===x)) throw new Error(`Path is outside updater allow-list: ${p}`);
  return p;
}

export function compareUpdateVersion(a:string,b:string){
  const pa=a.replace(/^v/,'').split('.').map(x=>Number(x.replace(/\D.*$/,''))||0); const pb=b.replace(/^v/,'').split('.').map(x=>Number(x.replace(/\D.*$/,''))||0);
  for(let i=0;i<3;i++){if((pa[i]||0)!==(pb[i]||0))return (pa[i]||0)-(pb[i]||0);} return 0;
}

export function validateUpdateManifest(raw:any,currentVersion:string):UpdateManifest{
  if(!raw||raw.type!=='DHC_GUS_UPDATE'||raw.schemaVersion!=='1.0')throw new Error('Not a supported DHC Gus update package.');
  if(typeof raw.fromVersion!=='string'||typeof raw.targetVersion!=='string'||!Array.isArray(raw.files))throw new Error('Update manifest is incomplete.');
  if(raw.fromVersion!==currentVersion)throw new Error(`This update requires Gus ${raw.fromVersion}; this installation is ${currentVersion}. Request a cumulative update built from the installed version.`);
  if(compareUpdateVersion(raw.targetVersion,raw.fromVersion)<=0)throw new Error('Update target version must be newer than the installed version.');
  const seen=new Set<string>();
  for(const f of raw.files){const p=validateUpdatePath(String(f.path||''));if(seen.has(p))throw new Error(`Duplicate update path: ${p}`);seen.add(p);if(!/^[a-f0-9]{64}$/i.test(String(f.sha256||'')))throw new Error(`Invalid SHA-256 for ${p}`);f.path=p;}
  raw.deletes=(raw.deletes||[]).map((p:string)=>validateUpdatePath(String(p)));
  if(raw.godaddySource){
    const gp=String(raw.godaddySource.path||'');
    if(gp!=='godaddy-source.zip')throw new Error('GoDaddy durable source must be named godaddy-source.zip.');
    if(!/^[a-f0-9]{64}$/i.test(String(raw.godaddySource.sha256||'')))throw new Error('Invalid GoDaddy source ZIP SHA-256.');
  }
  return raw as UpdateManifest;
}
