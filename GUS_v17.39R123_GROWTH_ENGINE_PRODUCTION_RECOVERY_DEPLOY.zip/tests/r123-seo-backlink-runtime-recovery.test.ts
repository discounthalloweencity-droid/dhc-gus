import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root=process.cwd();
const read=(p:string)=>fs.readFileSync(path.join(root,p),'utf8');

test('R123 backlink parser supports current Bing b_algo markup and redirect decoding',()=>{
 const s=read('app/services/backlink-native-provider.server.ts');
 assert.match(s,/decodeBingResultUrl/);
 assert.match(s,/Buffer\.from\(padded,'base64'\)\.toString\('utf8'\)/);
 assert.match(s,/<li\\b\[\^>\]\*class=/);
 assert.match(s,/\\bb_algo\\b/);
 assert.match(s,/parseBingSearchResults/);
 assert.match(s,/BING_SEARCH_DISCOVERED/);
});

test('R123 build marker follows package VERSION rather than legacy 0.16.57',()=>{
 const s=read('server.js');
 assert.match(s,/marker\.release!==VERSION/);
 assert.doesNotMatch(s,/marker\.release!=='0\.16\.57'/);
});

test('R123 atomic build supports EXDEV layered filesystems',()=>{
 const s=read('scripts/build-production-atomic.mjs');
 assert.match(s,/error\?\.code!==['"]EXDEV['"]/);
 assert.match(s,/cpSync\(source,dest,\{recursive:true,force:true\}\)/);
});

test('R123 MySQL LONGTEXT defaults use MySQL 9 compatible expressions',()=>{
 const s=read('prisma/mysql/schema.prisma');
 assert.doesNotMatch(s,/@default\("(?:\{\}|\[\])"\) @db\.LongText/);
 assert.match(s,/JSON_OBJECT\(\)/);
 assert.match(s,/JSON_ARRAY\(\)/);
});

test('R123 release identity is aligned',()=>{
 const pkg=JSON.parse(read('package.json'));
 assert.equal(pkg.version,'0.17.39-r123');
 assert.ok(read('app/services/engine-rotation.server.ts').includes(pkg.version));
 assert.ok(read('app/services/engine-certification-registry.ts').includes(pkg.version));
 assert.ok(read('app/services/backlink-growth.server.ts').includes(pkg.version));
});

test('R123 backlink qualification rejects non-outreach and competitor domains',async()=>{
 const rules=await import('../app/services/backlink-growth-rules.ts');
 assert.equal(rules.backlinkDomainRejectionReason('https://www.spirithalloween.com/'),'COMPETITOR_DOMAIN');
 assert.equal(rules.backlinkDomainRejectionReason('https://en.wikipedia.org/wiki/Halloween'),'NON_OUTREACH_DOMAIN');
 assert.equal(rules.backlinkDomainRejectionReason('https://store.steampowered.com/app/1'),'NON_OUTREACH_DOMAIN');
 assert.equal(rules.backlinkDomainRejectionReason('https://dictionary.cambridge.org/dictionary/english/spirit'),'NON_OUTREACH_DOMAIN');
 assert.equal(rules.backlinkDomainRejectionReason('https://partycity.com/collections/halloween-costumes'),'COMPETITOR_DOMAIN');
 assert.equal(rules.backlinkSourceRejectionReason('https://astivahealth.lh1ondemand.com/login.aspx'),'NON_EDITORIAL_SOURCE_PATH');
 assert.equal(rules.backlinkDomainRejectionReason('https://www.goodhousekeeping.com/holidays/halloween-ideas/'),null);
 const rejected=rules.prospectQualification({score:90,domain:'halloweencostumes.com'});
 assert.equal(rejected.status,'REJECTED');
 assert.equal(rejected.reason,'COMPETITOR_DOMAIN');
});
