import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {summarizeCertificationChecks} from '../app/services/production-certification-rules.ts';

const root=process.cwd();
const read=(p:string)=>fs.readFileSync(path.join(root,p),'utf8');

test('R122 certification fails closed when a critical check is not run',()=>{
 const x=summarizeCertificationChecks([{key:'x',label:'x',category:'x',state:'NOT_RUN',critical:true,evidence:'',repair:''}]);
 assert.equal(x.verdict,'NOT_READY');assert.equal(x.criticalFailed,1);
});
test('R122 only reaches READY when all checks pass',()=>{const x=summarizeCertificationChecks([{key:'x',label:'x',category:'x',state:'PASS',critical:true,evidence:'',repair:''},{key:'y',label:'y',category:'x',state:'PASS',critical:false,evidence:'',repair:''}]);assert.equal(x.verdict,'READY');assert.equal(x.score,100)});
test('Production Certification route is registered and pinned',()=>{assert.match(read('app/routes.ts'),/production-certification/);assert.match(read('app/routes/app.tsx'),/Production Certification/)});
test('write canary is doubly gated and explicitly confirmed',()=>{const s=read('app/services/production-certification.server.ts');assert.match(s,/GUS_CERTIFICATION_CANARY_ENABLED/);assert.match(s,/AUTHORITY_LIVE_WRITES_ENABLED/);const r=read('app/routes/app.production-certification.tsx');assert.match(r,/RUN SAFE CANARY/)});
test('Shopify canary uses draft product and unpublished article',()=>{const s=read('app/services/production-certification.server.ts');assert.match(s,/status:'DRAFT'/);assert.match(s,/isPublished:false/);assert.match(s,/articleDelete/)});
test('product and collection canaries verify restore readbacks',()=>{const s=read('app/services/production-certification.server.ts');assert.match(s,/Product canary restore readback mismatch/);assert.match(s,/Collection canary restore readback mismatch/)});
test('artifact certification checks lockfile, dependencies and build marker',()=>{const s=read('app/services/production-certification.server.ts');for(const token of ['package-lock.json','node_modules','build','server','index.js','.gus-build.json'])assert.ok(s.includes(token),`missing artifact check token ${token}`)});
test('build marker release follows package version',()=>{const s=read('scripts/build-production-atomic.mjs');assert.match(s,/release:String\(pkg\.version\|\|''\)/);assert.doesNotMatch(s,/release:'0\.16\.57'/)});
test('package version and engine releases remain aligned at or beyond R122',()=>{const pkg=JSON.parse(read('package.json'));assert.match(pkg.version,/^0\.17\.(?:3[89]|[4-9]\d)-r\d+$/);assert.ok(read('app/services/engine-rotation.server.ts').includes(pkg.version));assert.ok(read('app/services/engine-certification-registry.ts').includes(pkg.version))});
