# R102 Mission Lifecycle Repair

Production evidence showed stale RUNNING CATALOG_SELF_HEAL and WEEKLY_COLLECTION_MAINTENANCE mission mirrors plus repeated recovery missions while efficiency steps could say DONE with 0 scanned / 0 changed.

R102 adds a mission lifecycle guardian before normal mission recovery. It reconciles legacy mission mirrors to their backing JobRun terminal state, fails orphaned mirrors, closes backing jobs that exceed a governed 45-minute lease, requeues/dead-letters stale native worker leases, and supersedes aged duplicate RUNNING missions for the same engine/scope when a newer active mission exists.

Efficiency telemetry now distinguishes productive DONE from NO_OP. A step that returns successfully but scans and changes zero items is NO_OP rather than being presented as productive completion. NOT_DUE/IDLE/skipped work is also NO_OP.

No Shopify write gates, approval gates, margin rules, supplier truth rules, customer-service rules, or learning safeguards are bypassed.
