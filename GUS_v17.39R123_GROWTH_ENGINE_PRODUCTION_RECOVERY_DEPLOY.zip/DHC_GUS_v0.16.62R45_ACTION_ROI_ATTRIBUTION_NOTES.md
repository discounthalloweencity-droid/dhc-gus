# Gus v0.16.62 R45 — Action ROI & Attribution

R45 adds the first closed-loop commercial measurement layer for Gus autonomous actions.

## Core behavior
- Discovers recent measurable ChangeLog actions.
- Creates a durable attribution record per change using IntelligenceSignal with dedupe key ACTION_ROI:<changeId>.
- Uses a 7-day pre-action baseline and 7-day post-action measurement window by default.
- Measures product orders, units, revenue, refunds, and estimated contribution when verified variant cost/shipping facts exist.
- Normalizes unequal windows.
- Produces POSITIVE / NEGATIVE / NEUTRAL / INCONCLUSIVE outcomes with confidence.
- Does not pretend before/after measurement is causal; confidence and coverage limitations remain attached to the evidence.
- Protective archives/blocks are tracked separately as PROTECTED and are never counted as observed incremental revenue without direct evidence.
- Runs daily from the master orchestrator.
- Adds Command Center north-star metrics for measured actions, positive/negative outcomes, protection actions, attributable contribution, and confidence-weighted value.

## Learning contract
Negative outcomes become explicit intelligence signals that the Learning Director can consume in later releases. R45 establishes the measurement substrate; R47 will add structured human feedback and R48 golden-set evaluation.

## Economics
Contribution is only estimated when current verified product cost + supplier shipping facts exist. Acquisition charges, historical cost changes, taxes, duties, return handling, and actual historical payment fees are not silently invented.
