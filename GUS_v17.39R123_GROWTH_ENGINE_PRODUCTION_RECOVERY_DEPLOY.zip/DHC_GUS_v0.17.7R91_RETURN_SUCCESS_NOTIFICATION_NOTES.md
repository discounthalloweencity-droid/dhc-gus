# DHC Gus v0.17.7 R91 — Return Success Notification + Durable Retry

## Purpose
R91 closes the remaining successful-return communication gap in the R90 customer-service workflow.

Every newly created Shopify return handled by Gus now performs the following sequence:
1. Shopify return is created from the verified fulfilled line item.
2. Customer receives the normal return/exchange confirmation and instructions.
3. Gus sends a separate internal operational email to the configured internal support address (default: `discounthalloweencity@gmail.com`).
4. The return lifecycle is authorized and remains open for return tracking / receipt monitoring.
5. If the internal success email fails, the durable customer-return monitor retains the exact notification payload and retries delivery on later monitor cycles.

## Internal email format
Subject:
`RETURN CREATED — <ORDER> — <SHOPIFY_RETURN_NAME_OR_ID>`

Body includes:
- Customer
- Order
- Shopify return
- Gus support case
- Exact returned item / variant and return reason
- Replacement state
- Refund state
- Confirmation that Gus will monitor tracking through receipt

## Fail-safe behavior
- Existing returns are not repeatedly announced as newly created.
- A failed internal success-notification send does not cancel or corrupt the Shopify return.
- Failed notices are persisted in the email case state and retried by `reconcileCustomerReturnTracking`.
- On the third failed delivery attempt, the support case is annotated so the communication problem is visible while Gus continues retrying.
- Refunds are never represented as issued unless Shopify financial evidence confirms submission.
- Exchange replacements remain separate from the original return lifecycle.

## Files added
- `app/services/support-return-created-notification.ts`
- `app/services/support-return-created-notification.server.ts`
- `tests/support-return-created-notification.test.ts`

## Main files changed
- `app/services/customer-service-email.server.ts`
- `app/services/support-customer-return-monitor.server.ts`
- `app/services/feature-registry.ts`
- `package.json`
- `tests/r77-full-system-wiring.test.ts`

## QA
- `npm test`: 166/166 passed
- Relative import resolution: 661 source files passed
- Route registrations: 229
- Duplicate route modules: 0
- App-link contract: 263 links passed
- Runtime wiring: 359/359 service modules reachable
- Integrated feature modules: 25/25 with runtime contracts
- Engine Certification: 25/25 contracts
- Inert execution exports: 0 unexpected
- `check:syntax`: PASS
- `verify:source`: PASS, 707 transpiled/source files checked

## Dependency-build limitation
`npm run typecheck` cannot execute from this source-only release because `node_modules` is not bundled; the local shell reports `react-router: not found`. The dependency-backed typecheck/build must run during deployment after dependencies are installed.

## Deployment truth
R91 is source/structural/test verified. It is not proven deployed or live until the hosted runtime is updated and production evidence confirms the new return-created notification path executes successfully.
