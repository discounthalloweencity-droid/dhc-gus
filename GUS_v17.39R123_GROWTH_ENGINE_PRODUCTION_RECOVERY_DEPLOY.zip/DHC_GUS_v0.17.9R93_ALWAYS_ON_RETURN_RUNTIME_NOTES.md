# DHC Gus v0.17.9 R93 — Always-On Return Runtime

R93 is cumulative on R92 and adds production always-on execution hardening.

## Always-on runtime
- Gus master automation is persisted in MySQL.
- Cold starts/redeploys automatically resume RUN unless the merchant explicitly issued STOP.
- Turbo is DB-only; silent in-memory fallback was removed.
- Turbo still auto-enables from backlog/rate thresholds and auto-disables when the cleanup queue reaches zero.
- Retail mission workers now execute with real bounded concurrency. Target workers are no longer only a display value.
- `/jobs/orchestrator` now runs the full autonomous heartbeat: support mailbox, exchange tracking, return monitoring, control plane and orchestrator.
- Every heartbeat writes durable JobRun evidence (`AUTONOMOUS_HEARTBEAT`).
- In-process five-minute pulses remain a secondary layer.

## Host scheduler requirement
A browser must never be the scheduler. For hard execution across host sleep/recycle, configure the production host or an external scheduler to POST every 5 minutes:

`POST https://my-app-dhc-command-center.c37.airoapp.ai/jobs/orchestrator`

Header:
`Authorization: Bearer <AUTHORITY_CRON_SECRET>`

The secret must match the production environment variable. Do not put the secret in a public URL.

## Returns / exchanges
Includes the R92 commerce workflow: cheapest verified EasyPost label, Shopify reverse-delivery attachment, customer label email, Shopify-calculated refund preview held READY / NOT ISSUED, 14-day first-carrier-scan deadline, day 7/day 12/final reminders, first-scan stop condition, and governed overdue collection that never charges without explicit consent and a valid Shopify payment mandate.
