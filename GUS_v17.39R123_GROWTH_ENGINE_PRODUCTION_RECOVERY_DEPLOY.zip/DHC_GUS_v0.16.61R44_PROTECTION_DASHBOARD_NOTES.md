# Gus v0.16.61 R44 — Protection Dashboard

Adds persistent morning visibility for the two daily protection engines.

## Command Center
Inventory Protection tile:
- products scanned
- variants blocked (inventory policy DENY)
- products archived
- unknown / incomplete inventory requiring review
- persisted status
- manual Run now control

Quality Protection tile:
- products scanned
- quality-risk flags
- products archived
- review queue
- persisted status
- manual Run now control

Metrics come from persisted JobRun details, so page refreshes and server restarts do not erase the last completed protection report.
