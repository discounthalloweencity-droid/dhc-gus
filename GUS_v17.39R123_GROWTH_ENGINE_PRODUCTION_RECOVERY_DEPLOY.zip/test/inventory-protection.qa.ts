import assert from 'node:assert/strict';
import {inventoryProtectionDecision} from '../app/services/inventory-protection-rules.ts';

const base={id:'gid://shopify/ProductVariant/1',inventoryQuantity:0,inventoryPolicy:'CONTINUE',inventoryItem:{tracked:true},availableForSale:true};
assert.equal(inventoryProtectionDecision(base,undefined).shouldDeny,true,'tracked zero stock must not continue selling');
assert.equal(inventoryProtectionDecision({...base,inventoryQuantity:3},undefined).unsafe,false,'positive tracked stock remains sellable');
assert.equal(inventoryProtectionDecision(base,{coverageComplete:true,status:'AVAILABLE'}).unsafe,false,'fresh complete supplier availability may keep dropship variant sellable');
assert.equal(inventoryProtectionDecision({...base,inventoryQuantity:9},{coverageComplete:true,status:'OUT_OF_STOCK'}).unsafe,true,'confirmed supplier stockout must win');
assert.equal(inventoryProtectionDecision({...base,inventoryItem:{tracked:false}},undefined).unsafe,false,'untracked inventory without supplier evidence is unknown, not auto-archived');
console.log('inventory-protection QA: 5/5 passed');
