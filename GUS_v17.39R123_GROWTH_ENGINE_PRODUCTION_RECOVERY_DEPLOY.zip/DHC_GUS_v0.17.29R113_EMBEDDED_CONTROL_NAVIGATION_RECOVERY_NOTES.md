# DHC Gus v0.17.29 R113 — Embedded Control & Navigation Recovery

## Fixed
- Command Center workspace groups are server-rendered open, so the left navigation remains usable even if Shopify Admin iframe hydration is delayed or fails.
- Shell navigation links use `reloadDocument` so clicks do not depend on the client router being healthy.
- Manual Operations Control buttons no longer inherit a stale dashboard `running` flag as a disabled HTML control. The server action remains the authority for whether a command may execute.
- Operations Control forms use document submissions for an explicit no-SPA fallback.
- Dashboard action requests clone the incoming Request before authentication/form parsing, making `safeAppAction` retries safe after transient runtime recovery.
- Runtime identity advanced to `0.17.29-r113`.

## Safety
- No Shopify write guardrails were bypassed.
- `AUTHORITY_LIVE_WRITES_ENABLED` remains authoritative.
- Manual controls still execute their existing server-side authenticated action handlers.
