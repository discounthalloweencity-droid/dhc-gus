# DHC Gus v0.16.58 R41 — Catalog Self-Heal Hardening

- Catalog self-heal default cadence reduced from 20 hours to 4 hours.
- Default controlled write batch raised from 25 to 75 (existing hard ceiling remains 100).
- Supplier-title detection expanded for live DHC failure patterns including leading NEW, piece-count marketplace phrasing, PESENAR residue, duplicated gender/category wording, and repeated LED wording.
- Catalog intent now gives explicit shopper-facing product titles precedence over stale Shopify/supplier productType values. This fixes cases where a clear costume title was incorrectly classified as a mask because productType said Halloween Masks.
- PDP repair readback now runs a second supplier-title QA gate; a write is not recorded as successfully applied if the resulting title is still dirty.
- Added regression tests based on defects publicly visible on Discount Halloween City on 2026-09-19.

Deployment note: this build does not directly mutate the live store by itself. Deploy to the Gus app, confirm live-write gates/automation are enabled, then run Catalog Self-Healing.
