# DHC Gus v0.17.3 R87 — Verified Refund / Cancellation Financial Closure

Date: 2026-09-22

## Objective
Close the final high-risk customer-service gap exposed by refund and cancellation cases: Gus must never tell a customer that a refund or cancellation is complete merely because a staff button was clicked, an internal instruction was sent, or an older case note says it was approved. Completion language now requires fresh Shopify financial/order evidence.

## R87 changes

### 1. Live Shopify financial closure is the source of truth
R87 adds a dedicated financial-closure read against the exact verified Shopify order. Gus reads:
- `cancelledAt` and cancellation reason,
- current Shopify financial status,
- order total,
- total refunded,
- Shopify Refund records,
- refund processed timestamps,
- refund transaction kind/status/error/gateway/amount.

Internal case notes and staff clicks are workflow evidence only. They cannot establish that money moved.

### 2. Refund completion is fail-closed
The former staff action that could mark a refund complete is now a verification action.

`Verify Refund / Cancellation` performs a fresh Shopify read before any completion email is sent.

For a refund case, Gus requires live Shopify evidence of:
- a positive `totalRefunded`, and
- a Shopify Refund record,
- with successful refund transaction evidence when Shopify exposes refund transactions.

If those facts are absent, Gus:
- does not tell the customer the refund is complete,
- sends no completion email,
- keeps the case open,
- records `SHOPIFY_FINANCIAL_CLOSURE_NOT_CONFIRMED` with the live financial evidence.

### 3. Cancellation closure verifies both order and money state
A cancellation job submission is explicitly recorded as:

`SHOPIFY_JOB_SUBMITTED_NOT_CONFIRMED`

Submitting the Shopify cancellation mutation is no longer treated as closure.

For a paid cancellation to close, Gus requires:
- Shopify `cancelledAt`, plus
- either a confirmed full refund/reversal or a Shopify `VOIDED` financial state.

A cancelled order that still shows an unconfirmed refund remains open as:

`CANCELLATION_CONFIRMED_REFUND_NOT_CONFIRMED`

This separates "the order is cancelled" from "the customer's money is financially reversed."

### 4. Correct handling for voided authorizations
If Shopify confirms the order is cancelled and the financial state is `VOIDED`, Gus does not incorrectly tell the customer to wait for a refund credit. He explains that the authorization/payment was voided and there is no separate refund credit waiting to post.

### 5. Exact verified refund amount in customer communication
When Shopify confirms a refund, Gus uses Shopify's live `totalRefunded` amount in the customer message instead of the original order total or a guessed line-item amount.

Example behavior:
- Shopify confirms refund: `USD 52.97`
- Gus says Shopify confirms `USD 52.97` was submitted through the order payment flow.
- Gus still distinguishes refund submission from the customer's bank/card posting time.

### 6. Historical completion markers are re-verified
R87 protects against stale data created by earlier releases.

When a customer replies that an older refund has not appeared, Gus no longer trusts only `REFUND_APPROVED_CUSTOMER_NOTIFIED` history. He re-reads Shopify first.

If live Shopify evidence does not confirm the historical completion marker:
- Gus says he cannot currently verify the refund as submitted,
- reopens/keeps the case in owner action,
- escalates for financial verification rather than repeating an unverified promise.

If Shopify does confirm the refund, the normal bank posting-window workflow continues.

### 7. Unified admin controls
Both customer-service admin paths now use the same verified financial closure engine.

The Support Email page is limited to active `REFUND` and `CANCEL` financial cases and exposes:
- `Escalate Refund`
- `Verify Refund / Cancellation`

The main Support desk also routes its refund-completion control through the same Shopify-verifying service.

### 8. Customer wording is evidence-specific
R87 distinguishes these states:
- `REFUND_CONFIRMED`
- `REFUND_NOT_CONFIRMED`
- `REFUND_PENDING_OR_FAILED`
- `CANCELLATION_AND_REFUND_CONFIRMED`
- `CANCELLATION_CONFIRMED_REFUND_NOT_CONFIRMED`
- `CANCELLATION_NOT_CONFIRMED`
- `CANCELLATION_VOID_CONFIRMED`

This prevents generic "refund completed" language from masking the actual Shopify state.

## Shopify API contract verified for R87
The R87 financial-closure query was validated against the current connected Shopify Admin GraphQL schema.

Validated fields include:
- `Order.cancelledAt`
- `Order.cancelReason`
- `Order.displayFinancialStatus`
- `Order.totalPriceSet`
- `Order.totalRefundedSet`
- `Order.refunds`
- `Refund.processedAt`
- `Refund.transactions`
- `Order.transactions`
- `OrderTransaction.kind`
- `OrderTransaction.status`
- `OrderTransaction.errorCode`
- `OrderTransaction.gateway`
- `OrderTransaction.amountSet`

The validation reported the expected order-read scopes for this query.

## Authority order for financial closure
1. Fresh Shopify order/refund/transaction financial evidence.
2. Verified Shopify cancellation state.
3. Verified support-case/order identity.
4. Internal staff actions and prior case state.
5. Customer statements/attachments as supporting evidence only.

A lower authority source can never upgrade a Shopify-unconfirmed financial action into a completed customer promise.

## Release integrity
R87 is cumulative from R86 and retains:
- Shopify-first order status,
- shipment-intent hardening,
- attachment intelligence/evidence reconciliation,
- exact product sizing intelligence,
- return-label verification and resend,
- return tracking lifecycle,
- customer-service continuity and escalation rules.
