# DHC Gus v0.17.28 R112 — Runtime Schema Recovery

This release is a focused corrective build on top of R111. It fixes the production errors visible in the Command Center without bypassing storefront safety gates.

## Fixes

- **Supplier Evidence Recovery:** corrected `JobRun` Prisma usage from the invalid `type` field to the canonical `jobType` field for both latest-run lookup and job creation.
- **Gus Learning Brain:** stopped spreading the transient `evidence` property into `BrainQuestion` Prisma data. Evidence is persisted only through the canonical `evidenceJson` column.
- **Executive work queue:** changed production MySQL `ExecutiveWorkItem.title` to `LONGTEXT` and added it to the guarded additive production schema repair so existing installs are widened safely at startup. This addresses `The provided value for the column is too long for the column's type` failures in executive planning/profit work-item upserts.
- **R111 safety semantics preserved:** write locks and provider throttles remain blocked/wait states rather than being misreported as code failures. No Shopify live-write gate is bypassed.

## Production behavior

`server.js` runs `scripts/ensure-production-db.mjs` before opening Gus. That readiness path runs `scripts/repair-production-schema-additive.mjs`, which performs additive/non-destructive column widening. No destructive migration fallback is introduced.

## Regression coverage

`tests/r112-runtime-schema-recovery.test.ts` verifies the Supplier Evidence Recovery field contract, BrainQuestion evidence mapping, ExecutiveWorkItem title widening, and startup repair wiring.
