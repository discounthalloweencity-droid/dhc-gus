# DHC Gus v0.17.8 R92 — Return Automation / 14-Day First-Scan Window

Release: `0.17.8-r92`
Artifact: `GUS_v17.08R92_RETURN_AUTOMATION_14_DAY_SCAN.zip`

## What R92 adds

R92 completes the approved fit-return / sizing-exchange workflow so Gus can move from customer email through return-label delivery and return monitoring without falsely claiming actions that did not happen.

### Cheapest verified prepaid return label
- Uses an existing verified Shopify return label when one already exists.
- Otherwise, when `EASYPOST_API_KEY` is configured, creates an EasyPost return shipment from the verified Shopify shipping address to the official DHC return address.
- Compares live USD EasyPost rates and buys the cheapest valid rate under `DHC_RETURN_LABEL_MAX_COST_USD` (default $50).
- Uses verified Shopify item weight when available. A configured `DHC_RETURN_DEFAULT_WEIGHT_OZ` may be used only as an explicit operational fallback.
- Attaches the purchased PDF label and tracking evidence to the existing Shopify return through `reverseDeliveryCreateWithShipping` and verifies a Shopify readback.
- Sends the PDF label in the customer email and also includes the verified label URL in the message as a fallback.
- Gus does not say a label was sent until the customer email send succeeds.
- If label purchase/attachment cannot be verified, Gus fails closed, tells the customer the label is not yet verified, and opens an internal review instead of inventing a label.

### Refund prepared, not falsely issued
- Uses Shopify `returnCalculate` for the exact returned fulfillment line to prepare the item/tax refund calculation.
- Stores the result as `READY_NOT_ISSUED` in the Gus case state.
- Does not claim the refund was issued and does not include original shipping in the prepared amount.
- Final refund submission remains downstream of verified return receipt/Shopify financial evidence.

### Amazon-style 14-day return window
- The 14-calendar-day clock starts only after the verified return-label email actually succeeds.
- The deadline is satisfied by the **first carrier acceptance scan**, not warehouse delivery.
- EasyPost-bought labels use the EasyPost Tracker created with the purchased shipment; carrier events are sorted chronologically before the first scan is selected.
- R92 sends governed reminders around day 7, day 12, and the final day.
- Once the first carrier scan is verified, the deadline clock is stopped. Gus continues monitoring transit through receipt.
- If a customer can prove timely carrier handoff with a receipt, the overdue workflow is designed for review rather than blindly continuing collection.

### Advance-exchange replacement-value protection
- The replacement can continue through the existing $0 Shopify replacement-order path.
- The customer email states the verified replacement value and requests an explicit `I AGREE` authorization for collection only if no first carrier scan occurs by the return deadline.
- Gus records explicit consent from the customer's reply.
- After an overdue deadline, automatic stored-payment collection is attempted only when **all** of the following are true:
  1. explicit advance-exchange consent is recorded;
  2. Shopify exposes an eligible vaulted payment mandate;
  3. the runtime has the required Shopify payment-mandate permissions/capability; and
  4. `GUS_RETURN_OVERDUE_AUTO_CHARGE_ENABLED=true`.
- If automatic collection is unavailable, Gus uses Shopify's secure additional-payment URL when available or escalates for human review.
- A submitted mandate payment is never described as completed until Shopify confirms the financial result.
- Refund-path returns are never converted into a replacement-value charge; an overdue refund return simply remains held/unissued pending resolution.

### Durable follow-through
- If a verified label exists but the initial customer email fails, the return monitor retries the same verified label rather than buying a duplicate.
- The deadline still does not start until that retry succeeds.
- Existing R91 successful-return internal Gmail notifications and retries remain intact.
- The five-minute runtime pulse now passes live Shopify Admin context into the return monitor so governed overdue payment capability can be evaluated.

### Runtime identity correction
- `server.js` now derives its runtime version from `package.json` instead of the stale hardcoded `0.16.57` marker.
- The main Command Center runtime/status display also uses the package release version.

## Required production configuration

For automatic label purchase:
- `EASYPOST_API_KEY`

Optional controls:
- `DHC_RETURN_LABEL_MAX_COST_USD` — maximum label cost accepted by autopilot; default is 50 USD.
- `DHC_RETURN_DEFAULT_WEIGHT_OZ` — explicit fallback only when verified Shopify item weight is unavailable.
- `GUS_RETURN_OVERDUE_AUTO_CHARGE_ENABLED=true` — enables eligible mandate-payment submission after the 14-day deadline. Leave unset/false to force secure payment link or review.

The SMTP attachment allowlist includes the verified Shopify and EasyPost label hosts used by this workflow.

## QA

- `npm test`: 174 / 174 passed.
- `npm run verify:pure`: PASS.
- Relative imports: 663 source files resolved.
- Routes: 229 registrations, 0 duplicate route modules.
- App links: 263 passed.
- Service reachability: 361 / 361.
- Integrated feature modules: 25 / 25 runtime contracts.
- Engine Certification: 25 / 25 contracts.
- Inert execution exports: 0 (one documented deterministic pure-helper allowlist entry).
- `npm run verify:source`: PASS; 710 source files structurally/transpile-checked; 49 Prisma models observed.
- `npm run check:syntax`: PASS.
- Full dependency typecheck/build: **not executed in this source-only environment** because `node_modules` is not bundled and `react-router` CLI is unavailable (`react-router: not found`). The deployment host must install dependencies and run the normal typecheck/build gate.

## Production-proof boundary

R92 is source-tested and packaged. It is **not** evidence that the Airo/GoDaddy production runtime has been deployed or that EasyPost/payment-mandate credentials are configured there. After deployment, production proof should verify a real return from: Shopify return creation → rate selection → label purchase/attachment → customer email → first carrier scan → receipt/refund or overdue exchange handling.
