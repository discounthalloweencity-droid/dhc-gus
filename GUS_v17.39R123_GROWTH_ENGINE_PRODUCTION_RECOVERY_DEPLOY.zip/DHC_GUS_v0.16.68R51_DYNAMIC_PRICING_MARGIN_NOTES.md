# Gus v0.16.68 R51 — Dynamic Pricing & Margin Optimization

Proposal-only pricing optimizer combining verified cost facts, DHC floors, margin guardrails, demand state, stockout risk, supplier risk, seasonal urgency and optional verified competitor evidence.

Hard guardrails:
- complete kids costumes >= $19.97
- complete men's/women's costumes >= $29.97
- latex masks >= $16.97
- standalone accessories do not inherit costume floors
- minimum margin 25%, target 30%
- .97 retail presentation
- missing acquisition charges are never invented; contribution remains unclaimed and confidence is reduced
- no direct Shopify price writes in R51; changed recommendations are controlled-experiment candidates
