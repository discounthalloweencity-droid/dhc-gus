# Gus ↔ Google Search Console via Windsor.ai

This build supports Windsor.ai as the preferred read-only Search Console provider for Gus Growth Engine.

## Production environment variables

Set these in the GoDaddy/Airo Node application environment (never commit the key):

- `WINDSOR_API_KEY` = Windsor.ai API key for the workspace that has Google Search Console connected.
- `WINDSOR_GSC_ACCOUNT` = `sc-domain:discounthalloweencity.com`
- `GSC_SITE_URL` = `sc-domain:discounthalloweencity.com` (recommended; existing direct-Google features use it too).

When `WINDSOR_API_KEY` is present, Search Console performance reads use Windsor.ai. Existing direct Google OAuth remains a fallback. Sitemap submission and URL Inspection still require direct Google OAuth because they are Search Console write/inspection operations, not Windsor performance reads.

## Security

The Windsor Connectors API currently authenticates with `api_key` in the query string. Gus constructs the URL server-side only. The key is never returned to the browser, written to GrowthEvidence, or included in stored Search Console evidence.

## Data path

Windsor `searchconsole` → `refreshSearchConsole()` → `TrafficEvidenceRecord(source=GOOGLE_SEARCH_CONSOLE)` → existing Search Console workforce / Growth Engine / SEO change ledger / 7-14-28 day outcome learning.
