# R70 Auto Turbo Dashboard + Resilient Control

- Turbo now auto-activates when queue >=500, queue >=200 and measured throughput <250/hr, or queue >=100 with zero running workers.
- Turbo auto-disables when automatic queue reaches zero.
- Manual Force Turbo On remains available from the main Command Center.
- Manual toggle performs server-side state write and readback verification.
- Turbo state has a migration-safe process fallback so a missing TurboCleanupControl table no longer makes the button silently fail. Database persistence remains preferred when migration exists.
- Main dashboard rebuilt with dedicated Turbo panel: mode, queue, items/hour, ETA, target workers, current running count and operational fault.
- Existing safety/customer/order/fulfillment priority behavior remains intact.
