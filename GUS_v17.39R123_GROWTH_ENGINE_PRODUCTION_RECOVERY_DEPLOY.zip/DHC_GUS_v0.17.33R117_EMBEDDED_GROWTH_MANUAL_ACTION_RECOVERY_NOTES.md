# DHC Gus v0.17.33 R117 — Embedded Growth Manual Action Recovery

R117 fixes the operator-facing failure where manual Growth/SEO buttons could follow a Shopify Admin re-auth redirect inside the embedded iframe and display `admin.shopify.com refused to connect`.

## Fix
- Authenticated Growth/SEO loaders mint a short-lived HMAC command token bound to the canonical DHC shop and route.
- Manual action POSTs still try Shopify embedded `authenticate.admin` first.
- If Shopify responds with a 3xx re-auth redirect, the server verifies the signed command token and executes the command with Gus's already-certified canonical offline Admin session instead of navigating the iframe to Admin.
- Invalid/expired/mismatched tokens do not receive the fallback and preserve normal Shopify authentication behavior.
- Form bodies are read from request clones so Shopify authentication cannot consume the operator command payload.

## Covered manual Growth controls
- Aggressive Organic Growth
- Commerce Editorial scan / draft
- Weekly SEO Watch
- Authority / backlink discovery, sending controls, measurement and proof
- Strike Keyword engine
- Growth Intelligence / Google refresh / evidence imports
- SEO Domination: Turbo SEO, SEO learning, Backlink Turbo, Blog Intelligence and governed blog publishing

## Autonomous execution
The Phase 6 Growth rotation remains server-side and browser independent when Gus is RUNNING. Manual controls are extra/force-run controls, not the scheduler.
