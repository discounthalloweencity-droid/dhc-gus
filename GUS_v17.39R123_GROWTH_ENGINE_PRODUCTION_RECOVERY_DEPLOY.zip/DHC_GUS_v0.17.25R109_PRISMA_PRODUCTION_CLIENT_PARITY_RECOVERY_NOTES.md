# GUS v17.25 R109 — Prisma Production Client Parity Recovery

R109 fixes a production-only Prisma schema/client mismatch proven by GoDaddy runtime logs.

## Root cause
The application schema contained 49 models, while `prisma/mysql/schema.prisma` contained only 45. Production generation therefore produced a Prisma client with no delegates for `RetailExperiment`, `ExperimentExposure`, `OperatorFeedback`, and `TurboCleanupControl`, even though those tables could already exist in MySQL. Calls such as `db.turboCleanupControl.upsert()` and `db.operatorFeedback.count()` therefore failed with `Cannot read properties of undefined`. The dedicated retail mission consumer failed before doing work.

## R109 changes
- Production MySQL schema now includes all 49 application models.
- `prisma-generate-production.mjs` verifies every generated model delegate and fails the deployment if any are missing.
- Added source-level schema parity QA so SQLite/application and MySQL/production model sets cannot silently drift again.
- Existing R108 database-pool protections remain intact.

## Deployment requirement
A cold deploy/restart is required so `postinstall` / production setup regenerates `@prisma/client` from the corrected 49-model MySQL schema before Gus starts.
