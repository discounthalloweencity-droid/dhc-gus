# DHC Gus v0.17.4 R88 — Customer Service Operations Center

Date: 2026-09-22

## Objective
Turn the cumulative R83-R87 customer-service intelligence into one operational GUI instead of scattering evidence across Support, Support Email, Returns, Size & Fit, and Order Help.

## R88 changes

### 1. New Customer Service Operations screen
New route: `/app/customer-service-operations`

The screen provides a two-pane service desk:
- searchable/filterable support-case queue on the left,
- selected customer/case workspace on the right.

The selected case shows one evidence-driven view covering:
- exact support case and linked Shopify order,
- live Shopify fulfillment/shipment state,
- email attachment evidence,
- Shopify return and return-label evidence,
- exact-product sizing evidence when the case is about size/fit,
- Shopify financial closure evidence for refund/cancellation cases,
- one chronological customer timeline.

### 2. Shopify-first live order readback
R88 adds `customer-service-operations.server.ts` with a dedicated Admin GraphQL read against the case's verified Shopify `orderGid`.

The query reads:
- order identity and totals,
- live financial + fulfillment status,
- line items / exact variants,
- fulfillments, tracking, fulfillment events and ETA,
- Shopify returns.

The query was validated against the connected Shopify Admin GraphQL schema before release.

### 3. Existing R83 shipment engine is reused
The new GUI does not invent a second shipping model.

Live order evidence is passed through the existing `evaluateShopifyOrderStatus` engine, so the page visually distinguishes:
- processing,
- shipped in window,
- shipped without ETA,
- fulfilled without tracking,
- overdue delivery,
- carrier exception,
- delivered,
- cancelled.

### 4. Attachment intelligence is visible
Recent Support Email activity is correlated to the support case by case key.

The operations screen surfaces:
- attachment analysis status,
- read/unread file counts,
- extracted evidence summary,
- high-confidence attachment facts such as order number, size, amount, tracking, dates, and status.

Attachments remain supporting evidence; they do not outrank live Shopify facts.

### 5. Return label status is visible and actionable
When the linked Shopify order has a return, R88 displays the verified R86 return-label state and tracking.

If a verified Shopify label exists, the operator can enter the customer's checkout email and click **Resend verified label**.

Before sending, R88 re-verifies the order number + checkout email and then resends only the label currently attached to the Shopify return record.

### 6. Exact sizing evidence is visible
For sizing / fit cases, R88 invokes the R85 exact-product sizing engine and shows:
- exact/ambiguous/no-match state,
- verified available sizes,
- product-specific measurement evidence when present,
- missing catalog evidence warning when no verified size chart exists.

No generic size chart is substituted.

### 7. Financial closure is visible and actionable
Refund/cancellation cases show the R87 live Shopify closure decision.

The screen only exposes **Verify Refund / Cancellation** when the case remains open in the financial action lane. The existing R87 service still controls whether customer completion language can be sent.

### 8. One chronological customer timeline
The selected case timeline merges:
- case creation,
- inbound support email decisions,
- Gus reply outcomes,
- return authorization,
- customer return tracking,
- return receipt,
- replacement order state,
- verified financial events.

This gives the operator one place to understand what happened without opening multiple modules.

### 9. Unified next-action signal
R88 computes a plain-language next action from the currently loaded evidence. Examples:
- review evidence-loading warning,
- verify Shopify financial closure,
- return label requires review,
- shipment/carrier exception requires investigation,
- product-specific size evidence is missing,
- attachment evidence is unreadable,
- no blocking exception detected.

### 10. Navigation + dashboard integration
R88 adds **Customer Service Ops** under Customers & Support and replaces the dashboard's generic Customer Support card with the new one-customer-timeline operations workspace.

## Release integrity
R88 is cumulative from R87 and retains:
- Shopify-first order status + shipment intent hardening,
- attachment intelligence and evidence reconciliation,
- exact product sizing intelligence,
- return-label verification/resend + return lifecycle,
- verified refund/cancellation financial closure,
- existing support-email, customer-service academy, and support-case workflows.


## R88 QA results
- Automated tests: **148 / 148 passed**.
- Source structural verification: **PASS** (699 source files transpiled for structural checks; 49 Prisma models detected).
- Relative import resolution: **PASS** (656 source files scanned).
- Route uniqueness: **PASS** (228 registrations, 0 duplicates).
- Static app links: **PASS** (259 checked).
- Runtime wiring: **PASS** (355 / 355 service modules reachable).
- Engine certification: **PASS** (25 / 25).
- TypeScript syntax: **PASS**.
- Shopify GraphQL operations query: **schema validated** against the connected Admin API.

The extracted deployment ZIP does not contain `node_modules`; full `react-router typegen && tsc --noEmit` and the dependency-backed production build require installing package dependencies on the deployment host. This release does not represent that unavailable step as passed.
