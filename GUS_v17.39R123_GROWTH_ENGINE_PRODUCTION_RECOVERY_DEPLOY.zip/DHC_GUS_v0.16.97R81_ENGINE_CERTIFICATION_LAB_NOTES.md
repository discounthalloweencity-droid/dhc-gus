# DHC Gus v0.16.97 R81 — Engine Certification Lab

## Purpose
R81 adds a permanent, no-write Engine Certification Lab so operator-visible ON/healthy labels cannot substitute for evidence that an engine can actually load, pass its logic contract, reach its required provider, and show runtime execution evidence.

## Operator path
- `/app/engine-certification-lab`
- Command navigation: **Engine Certification Lab**
- Protected machine endpoint: `/health/engines`
- Optional single-engine machine check: `/health/engines?engine=<engine-key>`

## Certification states
- **CERTIFIED** — runtime module/load contract passed, safe probe passed, required provider checks passed, and recent execution evidence passed where required. Pure deterministic engines may certify from their deterministic fixture execution.
- **LOGIC_PASS_PROVIDER_UNVERIFIED** — code/load/logic passed but provider or recent execution evidence is missing. This is intentionally not green.
- **DEGRADED** — stale/incomplete runtime evidence or warning-level behavior.
- **FAILED** — module load, required export, safe probe, provider access, or runtime execution evidence failed.

## Safety model
The lab is no-write by default. It does not change product prices, inventory, order status, fulfillment, customer data, promotions, or storefront content merely to make a test pass. Store-changing engines are loaded and checked against safe/read-only probes plus JobRun/RetailMission evidence.

## Engine coverage
All 25 `INTEGRATED` feature-registry modules have exactly one certification contract. Contracts explicitly identify runtime modules, required exports, safe probe type, JobRun/mission evidence aliases, Shopify dependency, and external provider evidence where applicable.

## What the lab tests
1. Real runtime module load with per-engine timeout.
2. Required runtime exports exist.
3. Safe deterministic/read-only engine probe.
4. Shopify read-only connectivity where the engine depends on Shopify.
5. External provider configuration evidence where required.
6. Recent JobRun/RetailMission success/failure/staleness where applicable.
7. Persistent certification history written into `JobRun` as `ENGINE_CERTIFICATION_LAB`, then read back and verified.
8. Repair packet for every non-certified engine.

## Release QA
- `check:engines`: PASS — 25/25 integrated engines have certification contracts; no duplicates/missing service files.
- Targeted Engine Certification tests: 8/8 PASS.
- Full deterministic regression suite: 112/112 PASS.
- Runtime wiring: 346/346 service modules reachable; 0 unregistered routes; 0 unexpected unreachable services; 0 inert execution exports.
- Routes: 227 registrations; 0 duplicate route modules.
- App links: 252 checked.
- Import resolution: 646 source files.
- Source structural verification: 683 transpiled files, 49 Prisma models.
- Full production dependency typecheck/build is not claimed from this source ZIP because `node_modules` is intentionally absent. The deployed Engine Certification Lab is the next gate for actual Prisma/database/provider runtime proof.

## Deployment acceptance
After deploying R81:
1. Open **Command → Engine Certification Lab**.
2. Click **Test All Engines**.
3. Do not accept `LOGIC_PASS_PROVIDER_UNVERIFIED` as healthy.
4. Repair `FAILED` engines one at a time and use **Test only this engine** after each code change.
5. Copy the Engine Repair Packet back to ChatGPT for code diagnosis.
6. Only treat an engine as production-proven when the lab reports **CERTIFIED** and Production Proof shows actual work movement.
