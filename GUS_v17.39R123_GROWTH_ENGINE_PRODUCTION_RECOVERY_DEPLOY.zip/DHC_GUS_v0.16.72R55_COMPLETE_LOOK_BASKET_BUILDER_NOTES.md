# Gus v0.16.72 R55 — Complete-the-Look & Basket Builder Intelligence

Compatibility-first basket intelligence:
- costume -> wig / makeup / prop
- decor -> skeleton / graveyard / lighting & fog
- skeleton/graveyard scenes -> complementary atmosphere pieces
- audience mismatch penalties
- availability and delivery gates
- margin preference when verified
- one-best-per-completion-slot diversity

R55 creates recommendation edges and does not force bundles, fabricate compatibility, or recommend unavailable products.
