# Gus v0.16.59 R42 — Daily Inventory Protection

Adds a daily inventory-protection pass to the autonomous orchestrator.

## Behavior
- Scans every ACTIVE product and its variants once every 24 hours.
- If a Shopify-tracked variant is at zero inventory and has no fresh complete supplier evidence showing AVAILABLE, changes inventoryPolicy from CONTINUE to DENY so it cannot keep selling after stockout.
- Fresh complete supplier AVAILABLE evidence can preserve a dropship variant even when Shopify quantity is not mirrored locally.
- Fresh complete supplier OUT_OF_STOCK evidence overrides local positive/unknown stock and blocks the variant.
- Archives an ACTIVE product when every fully enumerated variant is unsafe/out of stock.
- Re-reads the product and supplier evidence immediately before archive to reduce race risk.
- Never auto-archives products with >250 variants, missing variants, or untracked/unknown inventory without confirmed supplier stockout evidence.
- Records variant policy changes and product archives in ChangeLog and the DAILY_INVENTORY_PROTECTION JobRun.

## Kill switch
Set GUS_INVENTORY_PROTECTION_ENABLED=false to disable the worker.

## Deployment gate
Writes still require the existing live-write deployment gate.
