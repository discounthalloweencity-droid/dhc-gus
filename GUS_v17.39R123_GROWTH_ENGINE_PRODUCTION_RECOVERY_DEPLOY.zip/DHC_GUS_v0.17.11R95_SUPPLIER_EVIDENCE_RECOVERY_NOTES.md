# R95 Supplier Evidence Recovery

Built cumulatively on the supplied R94 ALL ENGINES ALWAYS ON release.

- Adds a 12-hour freshness contract for mapped CJ, DSers, and Syncee evidence.
- Automatically refreshes configured supplier sources every four hours while orchestrator is running.
- Measures fresh availability, shipping, and cost evidence per supplier.
- Missing connector configuration is BLOCKED, not silently healthy.
- Missing/stale evidence remains UNKNOWN and never becomes an in-stock claim.
- Does not write supplier stock directly into Shopify inventory.
- Does not fuzzy-link unmapped supplier variants.
- Creates durable SUPPLIER_EVIDENCE_RECOVERY findings for unhealthy supplier evidence.
- Adds Operations Center supplier coverage/status and manual Run Supplier Recovery control.
- Replaces duplicate per-cycle CJ/DSers/Syncee refresh calls with the centralized recovery pass.

No Prisma migration required.
