# DHC Gus v0.17.6 R90 — Commerce Editorial Engine

R90 adds an original Strategist-style commerce editorial system to the existing Growth / SEO backend. It does not copy NYMag text, product ordering, reviews, or claims. It uses the underlying editorial-commerce pattern: cluster real shopper intent, select live products using evidence, create a useful buying guide, route the shopper to the catalog, and keep the guide synchronized with inventory and risk.

## New GUI
- `/app/commerce-editorial`
- Visible as **Commerce Editorial** in the Growth workspace.
- Scan masks & build strategy.
- Draft the top three queued guides with the existing governed SEO draft factory.
- Shows GSC demand, eligible-product depth, evidence completeness, and work-item status.

## New backend
- `app/services/commerce-editorial-engine.server.ts`
- `app/services/commerce-editorial-rules.ts`

The engine currently starts with Masks and can be extended to Costumes, Decorations, Inflatables, Props, Party Supplies, and evergreen Spooky All Year categories.

## Selection guardrails
A product cannot enter the recommendation shortlist when any known evidence shows:
- no sellable inventory,
- margin below the DHC 25% floor,
- supplier delivery beyond 12 days,
- HIGH product-quality risk,
- or an intent mismatch.

Unknown margin/shipping/quality evidence is surfaced as incomplete instead of invented. The draft prompt is explicitly told not to fabricate reviews, first-hand testing, materials, fit, comfort, shipping promises, popularity, or unsupported product claims.

## Search-intent strategy
Mask guide clusters include:
- broad Halloween mask buying guide,
- latex / rubber masks,
- scary / horror masks,
- masks under $25,
- pumpkin masks,
- animal masks,
- plague doctor masks,
- realistic masks,
- funny / novelty masks.

Search Console evidence raises priority when matching queries exist. Catalog depth can still create an internal opportunity when GSC demand has not yet been observed.

## Publication model
R90 queues `SEO_NEW_CONTENT_CANDIDATE` work items so the existing R74–R76 SEO draft and publishing governance remains intact. Draft creation is autonomous and internal. Net-new public publication remains a separate governed action.

## Refresh model
The engine is designed to be rerun so stale/OOS/high-risk/low-margin recommendations are replaced before future publication or refresh cycles.
