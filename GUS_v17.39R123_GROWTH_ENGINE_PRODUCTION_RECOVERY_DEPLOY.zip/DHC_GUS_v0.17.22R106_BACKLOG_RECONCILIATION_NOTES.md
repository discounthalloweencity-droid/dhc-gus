# R106 Backlog Reconciliation & Catalog Closure

Release: 0.17.22-r106

R106 fixes mission-count accounting and catalog finding retirement without changing Shopify product IDs or inventing sequential catalog numbers.

- The mission ETA now counts only executable AUTO_FIX/AUTO_VERIFY findings in `auto left`.
- `EVIDENCE_WAIT` is reported separately because those rows cannot be deterministically drained until objective evidence arrives.
- Catalog normalization resolves stale taxonomy/product-type/variant-size findings when current Shopify evidence proves the issue is gone.
- Verified metafield normalization closes the corresponding taxonomy finding after Shopify readback.
- PDP self-healing closes supplier-title/description findings only after the current verified PDP is clean.
- The live mission card shows `auto left · evidence · review`, preventing evidence backlog from masquerading as executable cleanup work.

This is backlog reconciliation, not ID renumbering. Shopify product IDs remain immutable source identifiers.
