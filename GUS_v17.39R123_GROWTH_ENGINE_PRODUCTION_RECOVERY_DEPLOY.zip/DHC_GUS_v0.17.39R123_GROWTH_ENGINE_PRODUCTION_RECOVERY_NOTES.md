# DHC Gus v0.17.39 R123 — Growth Engine Production Recovery

## Purpose
R123 converts the live Railway/engine findings from the R122 certification into the deployable source. It is focused on production recovery for SEO/backlinks and runtime compatibility, not new feature expansion.

## Proven defects corrected
- Current Bing result markup is parsed using flexible `b_algo` matching instead of the obsolete exact `<li class="b_algo"><h2><a...` contract.
- Bing `/ck/a` redirect URLs are decoded back to the real publisher URL before domain scoring/persistence.
- Backlink prospect qualification rejects competitor domains and low-value/non-outreach classes such as encyclopedias/reference sites, marketplaces, social/UGC platforms, app stores and search engines while retaining rejection reasons for audit.
- Backlink workforce release identity is aligned to `0.17.39-r123`.
- Production build-marker validation now compares against the package VERSION instead of the stale `0.16.57` marker.
- Atomic production build rollback now handles `EXDEV` layered/container filesystems by copy+remove when rename cannot cross mounts.
- Prisma MySQL LONGTEXT JSON-string defaults use MySQL 9-compatible expression defaults (`JSON_OBJECT()` / `JSON_ARRAY()`).
- SEO Domination loader now binds `session.shop` before loading SEO subsystems; its degraded fallbacks are typed safely.
- SEO execution recovery orders Findings by the actual `createdAt` field instead of nonexistent `updatedAt` and uses real timestamps.
- PageSpeed fallback status can represent the `PAGESPEED` source without an impossible union comparison.

## Live certification evidence that drove R123
- Weekly SEO engine completed against the Railway MySQL certification database.
- SEO queue persisted 50 work items in the certification run, including broken-URL governance, CTR optimization, near-page-one opportunities, product cleanup, collections, internal linking and technical review.
- Self-evolving SEO persisted measured signals and remained fail-closed when GSC/OpenAI were unavailable.
- R122 backlink native search was proven broken: Bing returned result blocks while the old parser returned zero prospects.
- Patched parser live test returned 40 result rows / 24 unique external publisher URLs across five bounded searches.
- Patched persistence test produced real `BACKLINK_PROSPECT` rows; database verification showed 62 total and 7 created in the bounded test window, including editorial publishers such as Good Housekeeping, Reader's Digest, The Everymom and The Pioneer Woman.
- Outreach remained disabled throughout certification.

## R123 source QA
- Automated regression tests: 347 / 347 PASS.
- Relative imports: 693 source files PASS.
- Routes: 230 registrations, 0 duplicate route modules.
- Static internal app links: 264 PASS.
- Interactive controls: 204 buttons, 120 links, 24 anchors, 175 forms, 0 failures/warnings.
- Runtime wiring: 390 / 390 service modules reachable.
- Engine certification contracts: 25 / 25.
- Prisma application/production parity: 49 / 49 models.
- TypeScript syntax check: PASS.

## Remaining production truth
The clean local environment could not complete npm dependency installation, so it cannot independently re-run dependency-backed `react-router typegen && tsc --noEmit` here. The prior real Railway compiler exposed 160 inherited TypeScript type errors across the broader application. Several SEO/runtime-significant errors were corrected in R123, but R123 is not represented as globally type-clean until Railway re-runs the compiler on this exact package.

The actual React Router production bundle for R122 already built successfully on Railway in 7.64 seconds. R123 must be re-built there from this exact artifact before cutover.

Full embedded Shopify operation on Railway still requires the private `SHOPIFY_API_SECRET` and a valid/certified Shopify offline session. Do not enable autonomous live writes until the R123 runtime, database, authentication and production certification page all pass.
