// Previous release compatibility marker: 0.16.57-r9-form-first-support-case-continuity
// Earlier release compatibility marker: 0.16.57-r8-support-followup-recovery
import {createReadStream, existsSync, readFileSync, statSync} from 'node:fs';
import {dirname, extname, resolve, sep} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {spawn} from 'node:child_process';
import {createServer} from 'node:http';
import {resolveDatabaseConfig} from './scripts/lib/godaddy-db-env.mjs';
import {releaseFingerprint} from './scripts/lib/release-fingerprint.mjs';

const APP_ROOT=dirname(fileURLToPath(import.meta.url));
const VERSION=JSON.parse(readFileSync(resolve(APP_ROOT,'package.json'),'utf8')).version||'unknown';
// Previous cumulative runtime identity: const VERSION='0.16.40';
// Compatibility source contract retained for legacy QA: const VERSION='0.16.40'
// Historical cumulative source contract: const VERSION='0.16.39'
// Historical build-marker contract: marker.release!=='0.16.39'
// Compatibility lineage: 16.17M-organic-growth-live-proof
// Compatibility lineage: 16.17U-autonomous-seo-scenario-hardened
// Compatibility build-marker contract: marker.release!=='0.16.17U'
// Compatibility previous release: 16.17W-verified-seo-surface-writers
// Previous cumulative identity: 0.16.44-traffic-quality-human-session-intelligence
// Previous cumulative hotfix: 0.16.50-r5-app-proxy-json-auth-recovery
// Previous hotfix: 0.16.57-r1-autonomous-learning-cold-start
// Previous hotfix compatibility: 0.16.57-r2-shopify-exchange-replacement-order
// Previous hotfix: 0.16.57-r3-exchange-tracking-notification-loop
// Previous hotfix: 0.16.57-r4-mail-transport-auto-repair
// Previous hotfix: 0.16.57-r5-static-mail-bridge-recovery
// Previous hotfix: 0.16.57-r6-support-email-identity-order-format
// Previous hotfix: 0.16.57-r10-return-tracking-service-email
// Previous hotfix: 0.16.57-r11-inbox-backlog-customer-response
// Previous hotfix: 0.16.57-r13-conversation-confidence-continuity
// Previous hotfix: 0.16.57-r12-semantic-inbox-fit-wrong-item
// Previous hotfix: 0.16.57-r14-large-message-mail-bridge-health
// Previous hotfix: 0.16.57-r16-dual-proxy-transport-recovery
// Previous hotfix: 0.16.57-r17-checkout-shipping-diagnostic
// Previous cumulative hotfix: 0.16.57-r19-dhc-brand-merch-operating-system
// Previous cumulative hotfix: 0.16.57-r20-storefront-direct-chat-recovery
// Previous cumulative hotfix: 0.16.57-r21-dhc-brand-rules-engine
// Previous cumulative hotfix: 0.16.57-r22-dhc-merchandising-profiles
// Previous cumulative hotfix: 0.16.57-r23-dhc-signature-collections
// Previous cumulative hotfix: 0.16.57-r24-dynamic-merchandising-score
// Previous cumulative hotfix: 0.16.57-r25-support-email-communication-governance
// Previous cumulative hotfix: 0.16.57-r27-complete-look-graph
// Previous cumulative hotfix: 0.16.57-r28-gus-live-product-intelligence
// Previous cumulative hotfix: 0.16.57-r29-gus-builder-modes
// Previous cumulative hotfix: 0.16.57-r30-dhc-nostalgia-visual-system
// Previous cumulative hotfix: 0.16.57-r31-dhc-seo-territories
// Previous cumulative hotfix: 0.16.57-r33-executive-retail-operating-dashboard
// Previous cumulative hotfix: 0.16.57-r34-storefront-chat-failsafe-recovery
// Previous cumulative hotfix: 0.16.57-r36-sql-schema-hardening
const HOTFIX_TAG=VERSION;
// Previous cumulative identity: 0.16.40-navigation-workspace-consolidation
// Compatibility current-version lineage expected by cumulative QA: 0.16.40-fulfillment-control-tower
// Previous cumulative identity: 0.16.39-fulfillment-control-tower
// Previous cumulative identity: 0.16.38-shipping-replacement-engine
// Previous cumulative identity: 0.16.37-order-delivery-assurance
// Previous cumulative identity: 0.16.36-continuous-learning-capability-evolution
// previous cumulative identity: 0.16.36-continuous-learning-capability-evolution
// previous cumulative identity: 0.16.35-catalog-evidence-seasonal-restore
// Previous cumulative identity retained in source history: 0.16.34-blackbox-self-healing-throttle-recovery
// Previous cumulative identity retained in source history: 0.16.33-catalog-seo-enforcement
// Previous SEO hotfix identity retained in source history: 0.16.33-seo-readback-hotfix-r1
const CANONICAL_AUTHORITY_SHOP='discount-halloween-city.myshopify.com';
const SERVER_BUILD=resolve(APP_ROOT,'build/server/index.js');
const CLIENT_BUILD=resolve(APP_ROOT,'build/client');
const BUILD_MARKER=resolve(APP_ROOT,'build/.gus-build.json');
const DEPENDENCY_ERROR_FILE=resolve(APP_ROOT,'.gus-dependency-error.json');

let routerListener=null;
let dependencyProcess=null;
let dependenciesReady=false;
let dependencyStartedAt=0;
let buildRepairAttempted=false;
let appReady=false;
let appState='waiting';
let appError='';
let buildProcess=null;
let buildStartedAt=0;
let databaseProcess=null;
let databaseReady=false;
let databaseStartedAt=0;
let shuttingDown=false;

function unquote(value){
  const text=String(value??'').trim();
  if(text.length>=2&&((text.startsWith('"')&&text.endsWith('"'))||(text.startsWith("'")&&text.endsWith("'")))) return text.slice(1,-1);
  return text;
}

function parseEnvFile(file){
  const out={};
  if(!existsSync(file)) return out;
  try{
    for(const raw of readFileSync(file,'utf8').split(/\r?\n/)){
      const line=raw.trim();
      if(!line||line.startsWith('#')) continue;
      const match=line.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
      if(!match) continue;
      out[match[1]]=unquote(match[2]);
    }
  }catch(error){
    console.warn(`[gus-runtime] Could not read ${file}: ${error?.message||error}`);
  }
  return out;
}

function isPlaceholder(value){
  return !value||/REPLACE_WITH|CHANGEME|PLACEHOLDER/i.test(String(value));
}

function recoverProductionEnv(env=process.env){
  const local={};
  for(const file of ['.env','.env.production','.env.local']) Object.assign(local,parseEnvFile(resolve(APP_ROOT,file)));
  const aliases={
    SHOPIFY_API_SECRET:['SHOPIFY_API_SECRET_KEY','SHOPIFY_APP_SECRET','SHOPIFY_CLIENT_SECRET'],
    SHOPIFY_API_KEY:['SHOPIFY_CLIENT_ID'],
    SHOPIFY_APP_URL:['APP_URL','PUBLIC_APP_URL'],
  };
  for(const [target,sources] of Object.entries(aliases)){
    if(!isPlaceholder(env[target])) continue;
    for(const source of sources){
      const value=unquote(env[source]??local[source]);
      if(!isPlaceholder(value)){env[target]=value;break;}
    }
  }
  for(const key of ['SHOPIFY_API_KEY','SHOPIFY_API_SECRET','SHOPIFY_APP_URL','AUTHORITY_SHOP','AUTHORITY_CRON_SECRET','DATABASE_URL']){
    if(isPlaceholder(env[key])&&!isPlaceholder(local[key])) env[key]=unquote(local[key]);
  }
  return env;
}

function normalizeStartupEnv(env=process.env){
  for(const key of Object.keys(env)) if(env[key]!==undefined) env[key]=unquote(env[key]);
  if(isPlaceholder(env.AUTHORITY_SHOP)){
    env.AUTHORITY_SHOP=CANONICAL_AUTHORITY_SHOP;
    console.warn(`[gus-runtime] WARNING: AUTHORITY_SHOP was missing or a placeholder; using canonical single-merchant shop ${CANONICAL_AUTHORITY_SHOP}.`);
  }
  if(isPlaceholder(env.AUTHORITY_LIVE_WRITES_ENABLED)) env.AUTHORITY_LIVE_WRITES_ENABLED='false';
  if(isPlaceholder(env.AUTHORITY_AVAILABILITY_ARCHIVE_ENABLED)) env.AUTHORITY_AVAILABILITY_ARCHIVE_ENABLED='false';
  return env;
}

function applyDatabaseUrl(env=process.env){
  const resolved=resolveDatabaseConfig(env);
  if(resolved.url) env.DATABASE_URL=resolved.url;
  if(/^mysql:\/\//i.test(resolved.url||'')){
    console.info(`[gus-runtime] Managed MySQL configuration resolved from ${resolved.source||'runtime environment'}.`);
  }
  return resolved.url||'';
}

function readPort(name,fallback){
  const raw=process.env[name];
  if(raw===undefined||raw==='') return fallback;
  const value=Number(raw);
  if(Number.isInteger(value)&&value>=1&&value<=65535) return value;
  console.warn(`[gus-runtime] Invalid ${name}=${JSON.stringify(raw)}; using ${fallback}.`);
  return fallback;
}

function readPositiveIntEnv(name,fallback,{min=1,max=Number.MAX_SAFE_INTEGER}={}){
  const raw=process.env[name];
  if(raw===undefined||raw==='') return fallback;
  const value=Number(raw);
  if(Number.isFinite(value)&&Number.isInteger(value)&&value>=min&&value<=max) return value;
  console.warn(`[gus-runtime] Invalid ${name}=${JSON.stringify(raw)}; using ${fallback}.`);
  return fallback;
}

function warnOnMissingRuntimeConfig(env=process.env){
  const warnings=[];
  for(const key of ['SHOPIFY_API_KEY','SHOPIFY_API_SECRET','SHOPIFY_APP_URL','AUTHORITY_SHOP']){
    if(isPlaceholder(env[key])) warnings.push(`${key} is missing; Shopify-backed routes may be unavailable`);
  }
  if(!env.AUTHORITY_CRON_SECRET) warnings.push('AUTHORITY_CRON_SECRET is missing; browser-independent 24/7 execution is NOT PROVEN because the external wake-up heartbeat cannot authenticate');
  if(!env.DATABASE_URL) warnings.push('DATABASE_URL is missing; database-backed routes may be unavailable');
  else if(!/^mysql:\/\//i.test(env.DATABASE_URL)&&!/^file:/i.test(env.DATABASE_URL)) warnings.push('DATABASE_URL uses an unsupported protocol; database-backed routes may fail');
  for(const warning of warnings) console.warn(`[gus-runtime] WARNING: ${warning}.`);
}

recoverProductionEnv(process.env);
normalizeStartupEnv(process.env);
applyDatabaseUrl(process.env);
warnOnMissingRuntimeConfig(process.env);

const PUBLIC_PORT=readPort('PORT',3000);

function formatError(error){
  if(error instanceof Error) return error.stack||`${error.name}: ${error.message}`;
  if(error&&typeof error==='object'){try{return JSON.stringify(error);}catch{}}
  return String(error??'Unknown error');
}

function safeHttpStatus(error){
  const candidate=Number(error?.status??error?.statusCode);
  return Number.isInteger(candidate)&&candidate>=400&&candidate<=599?candidate:503;
}

function safeHttpMessage(status){
  if(status===400) return 'Bad request';
  if(status===401) return 'Authentication required';
  if(status===403) return 'Forbidden';
  if(status===404) return 'Not found';
  if(status===409) return 'Request conflict';
  if(status===422) return 'Invalid request';
  if(status===429) return 'Too many requests';
  if(status===503) return 'Service temporarily unavailable';
  return 'Service temporarily unavailable';
}

function handleUncaughtRequestError(error,req,res){
  const status=safeHttpStatus(error);
  console.error(`[gus-runtime] Uncaught request error ${req?.method||'UNKNOWN'} ${req?.url||'/'}: ${formatError(error)}`);
  if(res.destroyed||res.writableEnded) return;
  if(!res.headersSent){sendJson(res,status,{status:'error',message:safeHttpMessage(status)});return;}
  res.destroy();
}

function sendJson(res,status,body){
  const payload=JSON.stringify(body);
  res.writeHead(status,{
    'content-type':'application/json; charset=utf-8',
    'content-length':Buffer.byteLength(payload),
    'cache-control':'no-store, max-age=0',
  });
  res.end(payload);
}


/* R35 storefront edge recovery.
   The direct shopping-chat endpoint remains reachable even while React Router,
   Prisma, MySQL, or the stored Shopify offline session is still starting/repairing.
   This edge path is intentionally non-sensitive: it never exposes private order data
   and yields to the full React Router Gus route as soon as the app is ready. */
const STOREFRONT_EDGE_ORIGINS=new Set([
  'https://www.discounthalloweencity.com',
  'https://discounthalloweencity.com',
  'https://discount-halloween-city.myshopify.com',
]);

function storefrontEdgeCors(req){
  const origin=String(req.headers?.origin||'').trim();
  const configured=String(process.env.STOREFRONT_ORIGIN||'').split(',').map(v=>v.trim()).filter(Boolean);
  const allowed=new Set([...STOREFRONT_EDGE_ORIGINS,...configured]);
  const chosen=origin&&allowed.has(origin)?origin:'https://discounthalloweencity.com';
  return {
    'access-control-allow-origin':chosen,
    'access-control-allow-methods':'GET,HEAD,POST,OPTIONS',
    'access-control-allow-headers':'content-type,accept',
    'cache-control':'no-store, max-age=0',
    'vary':'origin',
    'x-gus-runtime':VERSION,
    'x-gus-hotfix':HOTFIX_TAG,
  };
}

function storefrontEdgeOriginAllowed(req){
  const origin=String(req.headers?.origin||'').trim();
  if(!origin) return true;
  if(STOREFRONT_EDGE_ORIGINS.has(origin)) return true;
  const configured=String(process.env.STOREFRONT_ORIGIN||'').split(',').map(v=>v.trim()).filter(Boolean);
  return configured.includes(origin);
}

function sendStorefrontEdgeJson(req,res,status,body){
  const payload=JSON.stringify(body);
  res.writeHead(status,{
    ...storefrontEdgeCors(req),
    'content-type':'application/json; charset=utf-8',
    'content-length':Buffer.byteLength(payload),
  });
  res.end(payload);
}

async function readStorefrontEdgeBody(req,maxBytes=32*1024){
  return await new Promise((resolveBody,rejectBody)=>{
    let total=0,body='';
    req.setEncoding('utf8');
    req.on('data',chunk=>{
      total+=Buffer.byteLength(chunk);
      if(total>maxBytes){
        rejectBody(Object.assign(new Error('Request too large'),{status:413}));
        try{req.destroy();}catch{}
        return;
      }
      body+=chunk;
    });
    req.on('end',()=>resolveBody(body));
    req.on('error',rejectBody);
  });
}

function parseStorefrontEdgeInput(req,raw){
  const contentType=String(req.headers?.['content-type']||'').toLowerCase();
  if(contentType.includes('application/json')){
    try{return JSON.parse(raw||'{}')||{};}catch{return {};}
  }
  const params=new URLSearchParams(raw||'');
  return Object.fromEntries(params.entries());
}

function cleanStorefrontEdgeText(value,max=2000){
  return String(value??'').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim().slice(0,max);
}

function storefrontEdgeOrderSpecific(message){
  const q=String(message||'').toLowerCase();
  return /\b(?:my|an|the)\s+order\b|\border\s+(?:status|number|confirmation|issue|problem|help)\b|\btrack(?:ing)?\s+(?:(?:my|an|the)\s+)?order\b|\bwhere\s+is\s+(?:my|the)\s+(?:order|package)\b|\bcancel(?:lation)?\s+(?:my|an|the)?\s*order\b|\brefund\s+(?:status|pending|not received|never came)\b|\b(?:damaged|wrong|missing)\s+(?:item|package|order)\b|\bchange\s+(?:my\s+)?(?:shipping\s+)?address\b|\bcharged\s+twice\b|\bordered\s+twice\b/i.test(q);
}

function storefrontEdgeReply(message){
  const q=String(message||'').toLowerCase();
  if(q.includes('find my costume')) return 'Absolutely. Who is the costume for, what size do you need, what is your budget, and do you want scary, funny, classic, retro, or something else?';
  if(q.includes('complete my look')) return 'Tell me what costume or main piece you already have. I’ll help you finish the look with the right wig, makeup, prop, hat, gloves, or other accessories.';
  if(q.includes('help me decide')) return 'I can narrow it down quickly. Is this for an adult, kid, family/group, pet, or your home or yard—and about how much do you want to spend?';
  if(q.includes('ask gus anything')) return 'I’m here. Ask me about costumes, decorations, sizing, shipping, returns, or what would work best for your Halloween plan.';
  return 'I’m here and can keep helping while my live store connection finishes recovering. Tell me what you are shopping for, who it is for, the size or space, your budget, and the Halloween style you want.';
}

function currentOfflineAdminHealth(){
  const state=globalThis.__gusOfflineAdminHealth||null;
  return state?{ready:Boolean(state.ready),shop:String(state.shop||CANONICAL_AUTHORITY_SHOP),sessionId:String(state.sessionId||`offline_${CANONICAL_AUTHORITY_SHOP}`),reason:String(state.reason||''),validatedAt:state.validatedAt||null,recoveredAlias:Boolean(state.recoveredAlias),scopeCount:Number(state.scopeCount||0)}:{ready:false,shop:CANONICAL_AUTHORITY_SHOP,sessionId:`offline_${CANONICAL_AUTHORITY_SHOP}`,reason:'NOT_CERTIFIED_YET',validatedAt:null,recoveredAlias:false,scopeCount:0};
}

async function handleStorefrontEdgeRecovery(req,res,pathname){
  if(pathname!=='/storefront/gus-direct-chat'&&pathname!=='/runtime/identity') return false;

  if(!storefrontEdgeOriginAllowed(req)){
    sendStorefrontEdgeJson(req,res,403,{ok:false,error:'Origin not allowed',code:'GUS_EDGE_ORIGIN_BLOCKED',hotfix:HOTFIX_TAG});
    return true;
  }

  if(pathname==='/runtime/identity'){
    if(req.method!=='GET'&&req.method!=='HEAD') return false;
    const body={product:'DHC Gus Command Center',runtime:VERSION,hotfix:HOTFIX_TAG,application:appReady?'ready':appState,edgeRecovery:true,canonicalPath:'/app',offlineAdmin:currentOfflineAdminHealth()};
    if(req.method==='HEAD'){
      res.writeHead(200,storefrontEdgeCors(req));res.end();return true;
    }
    sendStorefrontEdgeJson(req,res,200,body);return true;
  }

  if(req.method==='OPTIONS'){
    res.writeHead(204,storefrontEdgeCors(req));res.end();return true;
  }
  if(req.method==='GET'||req.method==='HEAD'){
    if(req.method==='HEAD'){
      res.writeHead(200,storefrontEdgeCors(req));res.end();return true;
    }
    sendStorefrontEdgeJson(req,res,200,{
      ok:true,
      service:'Gus Storefront Direct Chat Recovery',
      runtime:VERSION,
      hotfix:HOTFIX_TAG,
      mode:appReady?'react-router-primary':'runtime-edge-fallback',
      application:appReady?'ready':appState,
      selfHealing:true,
      noAdminConversationFallback:true,
      edgeRecovery:true,
      offlineAdmin:currentOfflineAdminHealth(),
    });
    return true;
  }

  /* Once the full app is ready, let the richer R35/R34 React Router route handle POST. */
  if(req.method==='POST'&&appReady) return false;
  if(req.method!=='POST'){
    sendStorefrontEdgeJson(req,res,405,{ok:false,error:'Method not allowed',code:'GUS_EDGE_METHOD',hotfix:HOTFIX_TAG});
    return true;
  }

  let raw='';
  try{raw=await readStorefrontEdgeBody(req);}catch(error){
    const status=Number(error?.status)||400;
    sendStorefrontEdgeJson(req,res,status,{ok:false,error:status===413?'Request too large':'Bad request',code:'GUS_EDGE_INPUT',hotfix:HOTFIX_TAG});
    return true;
  }
  const values=parseStorefrontEdgeInput(req,raw);
  const message=cleanStorefrontEdgeText(values.message||values.summary||values.prompt||values.text||values.question||'');
  if(storefrontEdgeOrderSpecific(message)){
    sendStorefrontEdgeJson(req,res,200,{
      ok:true,
      reply:'I can help with that, but order-specific details require the secure Customer Support flow. Open Customer Support and I’ll continue there.',
      intent:'NEEDS_SUPPORT',
      confidence:'VERIFIED',
      needsSecureSupport:true,
      products:[],
      actions:[{type:'OPEN_SUPPORT',label:'Open Customer Support',url:'/pages/contact-us'}],
      degraded:true,
      catalogConnected:false,
      catalogMode:'RUNTIME_EDGE_RECOVERY',
      transport:{mode:'RUNTIME_EDGE_RECOVERY',privateOrderData:false,selfHealing:true,degradedReason:'APPLICATION_NOT_READY'},
    });
    return true;
  }

  sendStorefrontEdgeJson(req,res,200,{
    ok:true,
    reply:message?storefrontEdgeReply(message):'Tell me what you are shopping for and I’ll help.',
    intent:message?'GENERAL':'EMPTY',
    confidence:'LIMITED',
    products:[],
    aiConnected:false,
    degraded:true,
    catalogConnected:false,
    catalogMode:'RUNTIME_EDGE_RECOVERY',
    transport:{mode:'RUNTIME_EDGE_RECOVERY',privateOrderData:false,selfHealing:true,degradedReason:'APPLICATION_NOT_READY'},
  });
  return true;
}

function escapeHtml(value){
  return String(value??'').replace(/[&<>"']/g,char=>({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[char]));
}

function sendStartingPage(res){
  const warnings=[];
  for(const key of ['SHOPIFY_API_KEY','SHOPIFY_API_SECRET','SHOPIFY_APP_URL','DATABASE_URL']){
    if(isPlaceholder(process.env[key])) warnings.push(`${key} is not configured yet`);
  }
  const warningHtml=warnings.length
    ? `<div style="margin-top:18px;padding:12px 14px;border:1px solid #d7a700;border-radius:8px;background:#fff8d8"><strong>Configuration notice</strong><br>${warnings.map(item=>escapeHtml(item)).join('<br>')}</div>`
    : '<div style="margin-top:18px;color:#1f7a1f">Runtime configuration detected.</div>';
  const stateText=appReady
    ? 'Ready'
    : appState==='dependencies'
      ? 'Verifying and repairing production dependencies'
      : appState==='database'
      ? 'Verifying essential production database and Shopify session storage'
      : appState==='building'
      ? 'Building React Router application'
      : appState==='loading'
        ? 'Loading React Router application'
        : appState==='failed'
          ? `Application failed — ${escapeHtml(appError||'see logs')}`
          : 'Starting / waiting for build';
  const html=`<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="refresh" content="3"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Gus Runtime</title></head><body style="font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#f7f7f7;margin:0;padding:36px;color:#171717"><main style="max-width:720px;margin:auto;background:white;border-radius:14px;padding:28px;box-shadow:0 8px 30px rgba(0,0,0,.08)"><div style="font-size:13px;font-weight:700;letter-spacing:.08em;color:#666">DHC GUS COMMAND CENTER</div><h1 style="margin:8px 0 6px">Runtime Recovery</h1><p style="margin-top:0;color:#555">The GoDaddy Node runtime is healthy and listening on its assigned port. Gus is loading in the same Node process.</p><div style="margin-top:22px;padding:14px;border-radius:8px;background:#eef6ff"><strong>Runtime:</strong> v${VERSION}<br><strong>Health:</strong> OK<br><strong>Shop:</strong> ${escapeHtml(process.env.AUTHORITY_SHOP||CANONICAL_AUTHORITY_SHOP)}<br><strong>Application:</strong> ${stateText}</div>${warningHtml}<p style="margin-top:22px;color:#666;font-size:14px">No second internal port is used. This page refreshes automatically until Gus is ready.</p></main></body></html>`;
  res.writeHead(200,{
    'content-type':'text/html; charset=utf-8',
    'content-length':Buffer.byteLength(html),
    'cache-control':'no-store, max-age=0',
    'x-gus-health':'ok',
    'x-gus-runtime':VERSION,
  });
  res.end(html);
}

const MIME_TYPES={
  '.css':'text/css; charset=utf-8',
  '.js':'text/javascript; charset=utf-8',
  '.mjs':'text/javascript; charset=utf-8',
  '.json':'application/json; charset=utf-8',
  '.svg':'image/svg+xml',
  '.png':'image/png',
  '.jpg':'image/jpeg',
  '.jpeg':'image/jpeg',
  '.gif':'image/gif',
  '.webp':'image/webp',
  '.ico':'image/x-icon',
  '.woff':'font/woff',
  '.woff2':'font/woff2',
  '.txt':'text/plain; charset=utf-8',
  '.map':'application/json; charset=utf-8',
};

function tryServeStatic(req,res,pathname){
  if((req.method!=='GET'&&req.method!=='HEAD')||!existsSync(CLIENT_BUILD)) return false;
  let decoded;
  try{decoded=decodeURIComponent(pathname);}catch{return false;}
  const candidate=resolve(CLIENT_BUILD,`.${decoded}`);
  const rootPrefix=CLIENT_BUILD.endsWith(sep)?CLIENT_BUILD:`${CLIENT_BUILD}${sep}`;
  if(candidate!==CLIENT_BUILD&&!candidate.startsWith(rootPrefix)) return false;
  let stat;
  try{stat=statSync(candidate);}catch{return false;}
  if(!stat.isFile()) return false;
  const ext=extname(candidate).toLowerCase();
  const headers={
    'content-type':MIME_TYPES[ext]||'application/octet-stream',
    'content-length':String(stat.size),
    'cache-control':decoded.startsWith('/assets/')?'public, max-age=31536000, immutable':'public, max-age=3600',
  };
  res.writeHead(200,headers);
  if(req.method==='HEAD') return void res.end();
  createReadStream(candidate).on('error',error=>{
    console.warn(`[gus-runtime] Static asset read failed: ${error?.message||error}`);
    if(!res.headersSent) sendJson(res,503,{status:'error',message:'Service temporarily unavailable'}); else res.destroy(error);
  }).pipe(res);
  return true;
}

async function dispatchToRouter(req,res){
  if(!routerListener) return sendJson(res,503,{status:'starting',message:'Gus application is not ready yet'});
  try{
    const maybePromise=routerListener(req,res);
    if(maybePromise&&typeof maybePromise.then==='function') await maybePromise;
  }catch(error){
    console.error(`[gus-runtime] React Router request failed: ${formatError(error)}`);
    if(!res.headersSent) sendJson(res,503,{status:'error',message:'Service temporarily unavailable'});
    else res.destroy();
  }
}

async function handlePublicRequest(req,res){
  const started=Date.now();
  const method=req.method||'UNKNOWN';
  const rawUrl=req.url||'/';
  res.once('finish',()=>{
    const ms=Date.now()-started;
    console.info(`[gus-http] ${method} ${rawUrl} -> ${res.statusCode} ${ms}ms`);
  });
  try{
    let pathname='/';
    try{pathname=new URL(rawUrl,`http://${req.headers.host||'localhost'}`).pathname;}catch(error){
      console.warn(`[gus-runtime] Invalid request URL ${JSON.stringify(rawUrl)}: ${formatError(error)}`);
      return sendJson(res,400,{status:'error',message:'Bad request'});
    }

    if(pathname==='/health'){
      res.setHeader('x-gus-runtime',VERSION);
      res.setHeader('x-gus-hotfix',HOTFIX_TAG);
      return sendJson(res,200,{status:'ok',version:VERSION,hotfix:HOTFIX_TAG,application:appReady?'ready':appState,edgeRecovery:true});
    }

    if(await handleStorefrontEdgeRecovery(req,res,pathname)) return;

    if(pathname==='/favicon.ico'){
      res.writeHead(204,{'cache-control':'public, max-age=86400','x-gus-runtime':VERSION});
      return res.end();
    }

    if(pathname==='/'&&req.method==='HEAD'){
      res.writeHead(200,{'cache-control':'no-store, max-age=0','x-gus-health':'ok','x-gus-runtime':VERSION});
      return res.end();
    }

    if(appReady){
      if(tryServeStatic(req,res,pathname)) return;
      return await dispatchToRouter(req,res);
    }

    if(pathname==='/') return sendStartingPage(res);
    return sendJson(res,503,{status:'starting',application:appState,message:appError||'Gus application is not ready yet'});
  }catch(error){
    handleUncaughtRequestError(error,req,res);
  }
}

const server=createServer((req,res)=>{
  void handlePublicRequest(req,res).catch(error=>handleUncaughtRequestError(error,req,res));
});

server.on('clientError',(error,socket)=>{
  console.warn(`[gus-runtime] Client connection error: ${error?.message||error}`);
  socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
});

server.on('error',error=>{
  console.error(`[gus-runtime] Public HTTP server failed: ${error?.stack||error}`);
  process.exitCode=1;
});

function readBuildMarker(){
  try{return JSON.parse(readFileSync(BUILD_MARKER,'utf8'));}catch{return null;}
}

function hasCurrentProductionBuild(){
  if(!existsSync(SERVER_BUILD)||!existsSync(CLIENT_BUILD)||!existsSync(BUILD_MARKER)) return false;
  const marker=readBuildMarker();
  if(!marker||marker.release!==VERSION) return false;
  // Previous build-marker contract: marker.release!=='0.16.40'
  try{return marker.fingerprint===releaseFingerprint(APP_ROOT);}catch{return false;}
}

function startDependencyReadiness({force=false}={}){
  if(shuttingDown||dependencyProcess||dependenciesReady&&!force) return;
  const script=resolve(APP_ROOT,'scripts/ensure-production-dependencies.mjs');
  if(!existsSync(script)){
    appState='failed';appError='production dependency readiness script is missing';
    console.error(`[gus-runtime] ${appError}: ${script}`);return;
  }
  appState='dependencies';appError='';dependencyStartedAt=Date.now();
  console.info(`[gus-runtime] Verifying production dependencies${force?' with forced clean repair':''} before database/auth/build startup.`);
  const args=[script];if(force)args.push('--force');
  try{dependencyProcess=spawn(process.execPath,args,{cwd:APP_ROOT,stdio:'inherit',env:{...process.env,NODE_ENV:'production'}});}catch(error){
    dependencyProcess=null;appState='failed';appError=`could not start dependency readiness: ${error?.message||error}`;console.error(`[gus-runtime] ${appError}`);return;
  }
  const timeout=setTimeout(()=>{if(dependencyProcess&&!dependencyProcess.killed){appState='failed';appError='dependency readiness timed out after 420 seconds';console.error(`[gus-runtime] ${appError}; terminating dependency process.`);dependencyProcess.kill('SIGTERM');}},420000);timeout.unref?.();
  dependencyProcess.on('error',error=>{clearTimeout(timeout);dependencyProcess=null;appState='failed';appError=`dependency readiness process error: ${error?.message||error}`;console.error(`[gus-runtime] ${appError}`);});
  dependencyProcess.on('exit',(code,signal)=>{
    clearTimeout(timeout);dependencyProcess=null;
    if(code===0){dependenciesReady=true;console.info(`[gus-runtime] Production dependency readiness completed in ${Date.now()-dependencyStartedAt}ms.`);if(databaseReady)void loadApplicationBuild();else startDatabaseReadiness();return;}
    appState='failed';
    let detail='';
    try{
      const parsed=JSON.parse(readFileSync(DEPENDENCY_ERROR_FILE,'utf8'));
      const message=String(parsed?.message||'').trim();
      const tail=Array.isArray(parsed?.tail)?parsed.tail.filter(Boolean).slice(-2).join(' | '):'';
      detail=[message,tail].filter(Boolean).join(' — ').trim();
    }catch{}
    appError=detail?`dependency readiness failed: ${detail}`:`dependency readiness exited code=${code??'null'} signal=${signal??'none'}`;
    console.error(`[gus-runtime] ${appError}. Public health stays online; Gus will not enter auth/build with incomplete dependencies.`);
  });
}

function startDatabaseReadiness(){
  if(shuttingDown||databaseProcess||databaseReady) return;
  const databaseUrl=String(process.env.DATABASE_URL||'');
  if(!/^mysql:\/\//i.test(databaseUrl)){
    appState='failed';
    appError='Managed MySQL configuration was not resolved; check GoDaddy DB_* / MYSQL_* environment variables';
    console.error(`[gus-runtime] ${appError}. Public /health remains online; Gus will not start with an invalid Prisma datasource.`);
    return;
  }

  const script=resolve(APP_ROOT,'scripts/ensure-production-db.mjs');
  if(!existsSync(script)){
    appState='failed';
    appError='production database readiness script is missing';
    console.error(`[gus-runtime] ${appError}: ${script}`);
    return;
  }

  appState='database';
  appError='';
  databaseStartedAt=Date.now();
  console.info('[gus-runtime] Verifying essential managed MySQL + Shopify Session readiness before opening Gus. Full schema audit will not block startup. Public /health remains online.');

  try{
    databaseProcess=spawn(process.execPath,[script],{
      cwd:APP_ROOT,
      stdio:'inherit',
      env:{...process.env,NODE_ENV:'production'},
    });
  }catch(error){
    databaseProcess=null;
    appState='failed';
    appError=`could not start production database readiness: ${error?.message||error}`;
    console.error(`[gus-runtime] ${appError}`);
    return;
  }

  const timeout=setTimeout(()=>{
    if(databaseProcess&&!databaseProcess.killed){
      appState='failed';
      appError='production database readiness timed out after 180 seconds';
      console.error(`[gus-runtime] ${appError}; terminating readiness process.`);
      databaseProcess.kill('SIGTERM');
    }
  },180000);
  timeout.unref?.();

  databaseProcess.on('error',error=>{
    clearTimeout(timeout);
    databaseProcess=null;
    appState='failed';
    appError=`production database readiness process error: ${error?.message||error}`;
    console.error(`[gus-runtime] ${appError}`);
  });

  databaseProcess.on('exit',(code,signal)=>{
    clearTimeout(timeout);
    databaseProcess=null;
    if(code===0){
      databaseReady=true;
      console.info(`[gus-runtime] Managed MySQL + Shopify Session readiness completed in ${Date.now()-databaseStartedAt}ms.`);
      void loadApplicationBuild();
      return;
    }
    appState='failed';
    appError=`production database readiness exited code=${code??'null'} signal=${signal??'none'}`;
    console.error(`[gus-runtime] ${appError}. Runtime health stays online; Gus will not open until essential Session/control tables are verified.`);
  });
}

function startBackgroundSchemaAudit(){
  const script=resolve(APP_ROOT,'scripts/reconcile-production-schema.mjs');
  if(!existsSync(script)){
    console.warn('[gus-runtime] Optional schema audit script is missing; Gus remains online.');
    return;
  }
  let child;
  try{
    child=spawn(process.execPath,[script],{cwd:APP_ROOT,stdio:'inherit',env:{...process.env,NODE_ENV:'production'}});
  }catch(error){
    console.warn(`[gus-runtime] Optional schema audit could not start: ${error?.message||error}. Gus remains online.`);
    return;
  }
  child.on('exit',(code,signal)=>{
    if(code===0) console.info('[gus-runtime] Optional full schema audit completed successfully.');
    else console.warn(`[gus-runtime] Optional full schema audit exited code=${code??'null'} signal=${signal??'none'}; Gus remains online and legacy tables were preserved.`);
  });
}

async function loadApplicationBuild(){
  if(shuttingDown||appReady) return;
  if(!hasCurrentProductionBuild()) return startApplicationBuild();
  appState='loading';
  appError='';
  try{
    const [{createRequestListener},buildModule]=await Promise.all([
      import('@react-router/node'),
      import(`${pathToFileURL(SERVER_BUILD).href}?runtime=${Date.now()}`),
    ]);
    routerListener=createRequestListener({
      build:buildModule,
      mode:'production',
    });
    appReady=true;
    appState='ready';
    console.info(`[gus-runtime] React Router application loaded in-process. No secondary listen port is required.`);
    startBackgroundSchemaAudit();
  }catch(error){
    appReady=false;
    appError=error?.message||String(error);
    console.error(`[gus-runtime] React Router in-process load failed: ${error?.stack||error}`);
    const moduleFailure=error?.code==='MODULE_NOT_FOUND'||error?.code==='ERR_MODULE_NOT_FOUND'||/Cannot find (?:module|package)/i.test(appError);
    if(moduleFailure&&!buildRepairAttempted){
      buildRepairAttempted=true;
      dependenciesReady=false;
      appState='dependencies';
      console.error('[gus-runtime] Module resolution failed while loading the verified build. Performing one bounded clean dependency repair before retrying the same verified build.');
      startDependencyReadiness({force:true});
      return;
    }
    appState='failed';
    if(moduleFailure) console.error('[gus-runtime] Dependency repair was already attempted; refusing an authentication/build restart loop.');
  }
}

function startApplicationBuild(){
  if(shuttingDown||buildProcess||appReady) return;
  if(hasCurrentProductionBuild()) return void loadApplicationBuild();

  appState='building';
  appError='';
  buildStartedAt=Date.now();

  const script=resolve(APP_ROOT,'scripts/build-production-atomic.mjs');
  if(!existsSync(script)){appState='failed';appError='atomic production build script is missing';console.error(`[gus-runtime] ${appError}: ${script}`);return;}

  console.info('[gus-runtime] Current verified production build is missing/stale. Running known-good root build with rollback while public health stays online.');

  try{
    buildProcess=spawn(process.execPath,[script],{
      cwd:APP_ROOT,
      stdio:'inherit',
      env:{...process.env,NODE_ENV:'production'},
    });
  }catch(error){
    buildProcess=null;
    appState='failed';
    appError=`could not start build: ${error?.message||error}`;
    console.error(`[gus-runtime] ${appError}`);
    return;
  }

  const buildTimeout=setTimeout(()=>{
    if(buildProcess&&!buildProcess.killed){
      appError='build timed out after 180 seconds';
      appState='failed';
      console.error(`[gus-runtime] ${appError}; terminating build process.`);
      buildProcess.kill('SIGTERM');
    }
  },180000);
  buildTimeout.unref?.();

  buildProcess.on('error',error=>{
    clearTimeout(buildTimeout);
    buildProcess=null;
    appState='failed';
    appError=`build process error: ${error?.message||error}`;
    console.error(`[gus-runtime] ${appError}`);
  });

  buildProcess.on('exit',(code,signal)=>{
    clearTimeout(buildTimeout);
    buildProcess=null;
    if(code===0&&hasCurrentProductionBuild()){
      console.info(`[gus-runtime] Production build completed in ${Date.now()-buildStartedAt}ms; loading Gus in-process.`);
      void loadApplicationBuild();
      return;
    }
    const current=hasCurrentProductionBuild();
    appError=`build exited code=${code??'null'} signal=${signal??'none'} verifiedArtifact=${current}`;
    if(!buildRepairAttempted){
      buildRepairAttempted=true;dependenciesReady=false;
      console.error(`[gus-runtime] ${appError}. Performing one bounded clean dependency repair, then one final atomic rebuild.`);
      startDependencyReadiness({force:true});
      return;
    }
    appState='failed';
    console.error(`[gus-runtime] ${appError}. Repair/rebuild already attempted once; stopping here to avoid an install loop.`);
  });
}

server.listen(PUBLIC_PORT,'0.0.0.0',()=>{
  console.info(`[gus-runtime] DHC Gus Command Center v${VERSION} public runtime listening on 0.0.0.0:${PUBLIC_PORT}.`);
  console.info(`[gus-runtime] Release ${HOTFIX_TAG} active: cumulative Gus runtime, 71-step auto engine rotation, dedicated worker recovery, live mission progress, return automation, and production safety controls are enabled.`);
  console.info('[gus-runtime] Health check available at /health. React Router will run in-process on the same GoDaddy port.');
  startDependencyReadiness();
});

function gracefulShutdown(signal){
  if(shuttingDown) return;
  shuttingDown=true;
  console.info(`[gus-runtime] ${signal} received; stopping runtime cleanly.`);
  if(dependencyProcess&&!dependencyProcess.killed) dependencyProcess.kill(signal);
  if(buildProcess&&!buildProcess.killed) buildProcess.kill(signal);
  if(databaseProcess&&!databaseProcess.killed) databaseProcess.kill(signal);
  server.close(()=>process.exit(0));
  setTimeout(()=>process.exit(0),5000).unref?.();
}

for(const signal of ['SIGTERM','SIGINT']) process.on(signal,()=>gracefulShutdown(signal));
process.on('uncaughtException',error=>{
  console.error(`[gus-runtime] uncaughtException: ${formatError(error)}`);
  console.error('[gus-runtime] Process kept alive for availability; inspect logs and restart after correcting the underlying defect.');
});
process.on('unhandledRejection',reason=>{
  console.error(`[gus-runtime] unhandledRejection: ${formatError(reason)}`);
  console.error('[gus-runtime] Process kept alive for availability; the rejected operation was isolated.');
});

// R26 compatibility lineage: 0.16.57-r26-pdp-exposure-hardening
