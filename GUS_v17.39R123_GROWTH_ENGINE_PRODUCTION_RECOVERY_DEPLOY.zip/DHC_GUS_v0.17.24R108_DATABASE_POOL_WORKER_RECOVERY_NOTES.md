# DHC Gus v0.17.24 R108 — Database Pool & Worker Recovery

- Prevents Command Center dashboard fan-out from exhausting the Prisma/MySQL connection pool.
- Removes non-cancelling dashboard Promise.race fallbacks that left timed-out Prisma queries running in the background.
- Limits dashboard data reads to a small bounded concurrency lane (default 3).
- Uses one global PrismaClient per Node process in production as well as development.
- Applies deterministic managed-MySQL pool parameters (default connection_limit=16, pool_timeout=30s, connect_timeout=10s; env-overridable).
- Prevents the dedicated retail mission consumer from overlapping the full orchestrator cycle.
- Retains the last good worker throughput snapshot and reports DATABASE_POOL_BUSY rather than falsely showing a zero queue.
- Mission truth, catalog sweep proof, and all R107 fail-closed behavior remain intact.
