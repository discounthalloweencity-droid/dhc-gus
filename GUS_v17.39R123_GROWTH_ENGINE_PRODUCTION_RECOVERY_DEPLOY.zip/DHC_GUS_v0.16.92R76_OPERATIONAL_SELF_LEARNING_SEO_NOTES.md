# DHC Gus v0.16.92 R76 — Operational Self-Learning SEO

R76 turns the R75 self-evolving SEO framework into an operational closed loop.

## What is new

- SEO-specific experiment lab for verified SEO changes. Search visitors are never randomized.
- GSC before/after checkpoints at 7, 14, 28, 60 and 90 days, with an optional matched reference page.
- Promotion/rejection logic that stores both wins and failed treatments as DHC-specific SEO knowledge.
- Learned SEO knowledge now feeds future Catalog Blog, Editorial Blog and Strike Keyword prioritization.
- Self-learning evaluation runs after the daily organic/GSC refresh so it can use fresher evidence.
- Central Content Intelligence now runs automatically in the autonomous SEO growth cycle.
- SEO Blog Draft Factory creates complete internal drafts from evidence-backed new-content candidates.
- Draft safeguards block invented product facts, fake experience/reviews, thin content, doorway patterns and unsafe HTML.
- Public net-new article publishing is explicit and approval-gated from the SEO dashboard.
- Publication creates/uses the configured Shopify blog, checks duplicate handles, requires zero unresolved fact-risk flags, requires the commercial internal link, writes SEO title/description metafields, and verifies the article publish state/handle.
- Shopify article publication also respects the global AUTHORITY_LIVE_WRITES_ENABLED deployment gate.

## SEO experiment doctrine

OBSERVE → DIAGNOSE → HYPOTHESIZE → EXECUTE REVERSIBLY → MEASURE 7/14/28/60/90 → LEARN → PROMOTE/REJECT → DEFEND

The experiment result is observational evidence. A matched reference page reduces obvious sitewide/seasonal confounding but does not prove universal causality. Promotion means Gus has enough DHC-specific evidence to cautiously reuse a treatment on materially similar pages while continuing to measure it.

## Blog architecture

Central SEO Content Intelligence controls two specialist engines:

1. Catalog Item Blog Engine — buying guides, complete-the-look, comparisons, fit/sizing, occasions and theme support for verified products/collections.
2. Editorial/Search-Demand Engine — informational/inspirational clusters derived from observed demand.

Neither engine has permission to mass-produce one thin article per SKU. Public publishing remains a separate governed action.

## Production requirements

- Search outcome learning: Windsor/GSC or direct Search Console credentials.
- Article drafting: OPENAI_API_KEY; optional GUS_SEO_BLOG_MODEL override.
- Shopify article publication: Shopify content-write scope plus AUTHORITY_LIVE_WRITES_ENABLED=true.
- Optional blog settings: GUS_SEO_BLOG_HANDLE, GUS_SEO_BLOG_TITLE, GUS_SEO_BLOG_AUTHOR.

## QA performed in source package

- TypeScript syntax checks.
- Relative import resolution.
- Route module uniqueness and route registration uniqueness.
- Client/server route boundary check.
- Static /app link contract.
- DHC rule validation.
- Source transpile/structural verification.
- Existing Node test suite.

A full dependency typecheck / React Router production build cannot be truthfully claimed from this source-only deployment ZIP because node_modules and the React Router CLI are intentionally absent. Run the package's dependency readiness and production build steps on the deployment host before promotion.
