# DHC Gus v0.16.93 R77 — Full System Wiring Audit & Runtime Hardening

## Purpose
R77 is a source-level functional wiring audit of Gus. The audit does not treat a file, dashboard card, or prior release note as proof that a feature works. A feature must have a reachable production entry point, its expected runtime implementation must be connected, and execution-style service functions must not be left orphaned.

## Runtime wiring gate
`node scripts/check-runtime-wiring.mjs` is now part of `npm run verify:pure` and fails the release when any of the following are true:

- a route file exists but is not registered;
- a service module cannot be reached from a production route/startup entry point;
- a package test script points to a missing test file;
- a required core runtime system is unreachable;
- an `INTEGRATED` feature-registry module has no runtime implementation contract;
- a feature-registry runtime implementation is missing or unreachable;
- an execution-style exported service function is defined but never invoked by production code, except an explicitly documented pure-helper allowlist.

Verified R77 wiring result:

- 223 parsed route registrations plus the multiline `/app` parent route accounted for by the audit
- 224 route files, 0 unregistered route modules
- 340 service modules, 340 reachable from production entry points
- 25 feature-registry modules marked `INTEGRATED`, all 25 covered by runtime contracts
- 0 feature modules without runtime contracts
- 0 feature runtime contract failures
- 0 broken package test references
- 0 inert execution-style service exports
- 1 explicit pure-helper exception: `basket-builder-rules.ts:buildBasket`; production consumes `basketCompatibility` directly and the composition helper is retained for deterministic rule regression coverage

The storefront/theme module remains correctly classified as `EXTERNAL_DEPENDENCY`; source wiring cannot prove that the active Shopify theme/app embed is enabled or pixel-perfect after deployment.

## Real disconnected or incomplete paths found and corrected

### 1. Job Progress API
R76 contained a job-progress route and signed-token helper, but the route was not registered and the app shell did not consume the token.

R77:
- registers `/api/job-progress`;
- creates a signed tenant-scoped job progress token after Shopify admin authentication;
- polls the signed endpoint from the app shell while visible;
- uses `no-store` reads and avoids re-running embedded Shopify authentication on every poll.

### 2. Canonical Complete-the-Look graph
R76 had storefront readers for `DHC_COMPLETE_LOOK_EDGE`, but the active builder path primarily fed the older basket signal.

R77:
- refreshes canonical Complete-the-Look edges from the live basket intelligence pass;
- evaluates candidate pairs through the canonical DHC Complete-the-Look rules;
- stores fresh edge observation time and 36-hour expiry;
- prunes superseded edges only after a successful refresh;
- removes the now-superseded unused bulk builder wrapper.

### 3. SEO learning checkpoints
A temporary GSC measurement error could previously occupy a 7/14/28/60/90-day checkpoint and stop that checkpoint from retrying.

R77:
- counts only successful measurements as completed checkpoints;
- replaces/retries measurement errors;
- increments retry attempts;
- records SEO experiments as full-page observational/matched-reference evaluation (`trafficSplit: 1`), not visitor-randomized SEO variants.

### 4. Specialist blog engines -> real draft pipeline
Catalog Blog and Editorial/Search-Demand engines were generating their own opportunities, while the governed draft factory consumed `SEO_NEW_CONTENT_CANDIDATE` work.

R77:
- applies shopper-intent parsing and intent clustering;
- promotes qualified Catalog Blog and Editorial Blog opportunities into `SEO_NEW_CONTENT_CANDIDATE` work;
- requires an observed-demand signal, verified commercial destination, anti-cannibalization check, fact gates, and human publication governance;
- limits promotion volume rather than mass-producing pages.

### 5. Customer-service language academy
The language academy existed but was not part of the Gus master academy. When connected, the original parser only passed 41/61 drills with 7 hard-gate misses.

R77:
- wires the language academy into the master academy as a required domain;
- improves intent handling for tracking/no movement, returns/exchanges, wrong item/size, billing/payment, platform/supplier/internal messages, shipping-fee/free-shipping issues, scams/solicitation, and common customer misspellings;
- verifies 61/61 drills passed with 0 hard-gate failures.

### 6. Learning instrumentation coverage
The learning instrumentation registry existed but was not itself used to verify that expected engines were actually producing learning evidence.

R77:
- adds live instrumentation coverage reporting;
- checks expected engine JobRun activity and `JOB_LEARNING_INSTRUMENTATION` capture;
- feeds coverage into the Continuous Product Learning Director.

### 7. CJ shipping/freight evidence
CJ stock refresh was connected, but CJ freight quote code was not feeding current shipping evidence.

R77 adds a conservative live refresh path that runs only when exact freight configuration exists:
- `GUS_CJ_FREIGHT_CONFIG_JSON` must provide exact CJ warehouse ID, origin country, exact method, processing minimum days and processing maximum days;
- destination comes from the exact supplier variant link;
- freight quote and processing/transit evidence are persisted with validity;
- variant-level cost/days are only written when one enabled supplier link makes ownership unambiguous;
- missing config returns `NOT_CONFIGURED`; Gus does not invent origin, method, processing time or delivery promises.

### 8. Retail Mission Stop/Cancel
The stop function existed but was not surfaced to an operator.

R77:
- adds active autonomous missions to Tasks & Queue;
- allows operator Stop/Cancel from the live queue;
- queued/waiting/non-running missions transition immediately to `CANCELLED`;
- running missions receive a persistent `STOP_REQUESTED` timestamp and terminate through existing governed mission checkpoints.

### 9. Superseded legacy services
The audit found three service implementations that were obsolete relative to the canonical current engines. They were removed rather than artificially re-wired and allowed to conflict:
- `ctl-policy.ts`
- `hero-merchandising-rules.ts`
- `shipping.server.ts`

Unused wrapper runners that duplicated active canonical execution paths were also removed from the Google quality, Search QA, and Complete-the-Look services.

### 10. Broken test-script references
R76 package scripts referenced missing test files. R77 restores the missing suites for:
- availability safety;
- CJ stock evidence;
- CJ shipping selection;
- reporting/stocking evidence;
- Node 22 core primitives.

R77 also adds `r77-full-system-wiring.test.ts` to keep the repaired runtime contracts from regressing.

## Feature-registry truth corrections
- Supplier module now explicitly documents configuration-gated CJ freight evidence refresh.
- Growth module documents promotion of specialist content-engine opportunities into the governed draft factory.
- Brain module documents instrumentation-coverage auditing and the 61-drill customer-service language hard gate.
- Orchestrator documentation now matches source: in-process pulse defaults to 5 minutes and is configurable, rather than the stale 15-minute description.

## Verified QA
- Full Node test suite: 89/89 tests passed.
- `verify:pure`: passed.
- Runtime wiring audit: passed.
- Relative imports: passed; 636 source files scanned.
- Route uniqueness: 223 parsed registrations; 0 duplicate route modules.
- Route boundaries: passed.
- Static app links: 250 checked, passed.
- DHC price-ladder rule validation: passed.
- Source verification: 49 Prisma models; 669 files transpiled/structurally checked, passed.
- Supplier suite: 6/6 passed.
- Reporting suite: 2/2 passed.
- Node core suite: 3/3 passed.
- Customer-service language academy: 61/61, 0 hard-gate failures.

## What source QA cannot honestly prove
The R77 source package intentionally does not include `node_modules`, so local `react-router typegen && tsc --noEmit` and the production React Router build cannot execute in this audit container. The observed failure is dependency readiness (`react-router: not found` / missing `node_modules/@react-router/dev/bin.js`), not a reported TypeScript diagnostic.

After deployment the host must install the pinned dependencies, then run the normal typecheck/build/deployment checks. Live external behavior also depends on the configured environment and provider credentials/scopes, including Shopify write/content scopes and live-write gate, Search Console/Windsor/Google access, OpenAI for draft generation, DSers/Syncee/CJ evidence sources, carrier tracking provider, support mail credentials, and theme/app-proxy/app-embed activation.

Those external dependencies remain fail-closed or `NOT_CONFIGURED`; R77 does not turn missing evidence into fabricated success.
