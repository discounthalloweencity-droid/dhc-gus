# DHC Gus v0.16.79 R62 — Catalog Data Normalization Engine

- Deterministic canonical normalization for Size, Age Group, Audience/Gender, Color and Theme.
- Repairs single-value JSON-array strings such as `["S"]` to canonical scalar `S`.
- Never guesses US sizing from supplier numeric/China sizing; routes ambiguous values to Finding review.
- Deduplicates tags and removes supplier-only tags.
- Detects likely product-type mismatches without auto-reclassifying ambiguous products.
- Live writes require existing Production Write Gate and automation running.
- Every metafield write is re-read from Shopify and must match before it is logged as verified.
- Changes create reversible ChangeLog evidence and Product Touch learning evidence.
- Variant option labels are detected and proposed for review; this release intentionally does not mutate variant option values automatically because that can alter storefront variant identity/selection semantics.
