# DHC Gus v0.17.36 R120 — Backend Completion Truth Recovery

R120 fixes live evidence showing that Gus could be active while critical completion loops remained unfinished.

- Shop / Sales-Channel Catalog Governor now performs Shopify post-write readback and cannot report success while active zero-inventory products or publishable Shop-hidden products remain.
- Governor exposes exact Shop hold-reason counts and held-product evidence.
- Failed and waiting engines remain ERROR/BLOCKED during cadence skips instead of becoming FRESH.
- The orchestrator now actually runs Catalog Data Normalizer alongside the cleanup campaign, restoring product-type and taxonomy normalization to the engine that advertises it.
- SEO blog publishing checks actual prior auto-publication evidence and reports STALE when overdue with no publishable draft or when all drafts are held/failed.
- Mission progress now counts failed governor/blog completion loops as unfinished automated work.
- Semantic engine results such as BACKLOG_REMAINS, STALE, FAILED, and WRITE_GATE_PROTECTED persist truthfully into efficiency/runtime status.

Deploy target: 0.17.36-r120.
