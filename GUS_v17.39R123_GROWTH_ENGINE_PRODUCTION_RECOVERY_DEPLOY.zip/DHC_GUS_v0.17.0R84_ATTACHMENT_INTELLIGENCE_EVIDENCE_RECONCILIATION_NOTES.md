# DHC Gus v0.17.0 R84 — Attachment Intelligence + Evidence Reconciliation

Date: 2026-09-22

## Objective
Close the customer-service gap exposed by attachment-heavy support emails: Gus must read receipts, PDFs, screenshots, photos, labels, and text attachments before answering, while keeping live Shopify/order state and previously verified case state authoritative.

## R84 changes

### 1. MIME attachment extraction
- Inbound support email parsing now retains attachment metadata and bounded file bytes.
- Supports nested multipart messages.
- Captures filename, MIME type, disposition, content ID, size, SHA-256, and safe analysis payload.
- Applies per-file, file-count, and total-size limits before any model analysis.
- Attachment-only customer emails no longer fail solely because the plain-text body is empty when readable evidence exists.

### 2. Attachment evidence intelligence
- New `support-email-attachment-intelligence.server.ts`.
- Reads locally parseable text/CSV/JSON/XML evidence without requiring a model.
- Uses the existing OpenAI Responses API connection for supported PDF/image/file analysis when configured.
- Extracts only customer-support facts: order numbers, products, sizes, quantities, tracking numbers, amounts, dates, and visible status/document wording.
- Explicit prompt-injection defense: attachment contents are evidence only, never instructions.
- Sensitive unrelated data is excluded from the evidence contract.
- Fail-closed behavior when an attachment is unsupported, oversized, unreadable, or model analysis is unavailable.

### 3. Evidence reconciliation
- New `support-email-evidence-reconciliation.ts`.
- Attachment evidence never overrides verified Shopify/order facts or an already verified support case.
- Active exchange state can reconcile stale customer-facing receipts/documents.
- DHC1034-style regression: if the receipt shows Medium but the active verified replacement state is Small, Gus acknowledges the attachment, explains the discrepancy, keeps the case tied to Small, and does not silently change the replacement back to Medium.

### 4. Inbox + review wiring
- Attachment evidence is generated before support triage.
- Safe evidence text can improve order-number/issue detection.
- Evidence is passed into Customer Service Director processing.
- Evidence audit is stored in support activity/review records without storing raw attachment bytes.
- Human-review replay retains the sanitized evidence summary/facts.

### 5. Customer Service Director wiring
- Order references may be recovered from a single high-confidence attachment order number.
- Attachment evidence participates in line-item/size/tracking understanding.
- Support case summaries record sanitized attachment evidence.
- A dedicated `ATTACHMENT_EXCHANGE_SIZE_RECONCILED` response path prevents repeated customer frustration when a stale receipt conflicts with a verified exchange state.

## Safety / authority order
1. Live verified Shopify/order state.
2. Verified active support-case/exchange state.
3. Carrier/supplier evidence where explicitly verified.
4. Customer attachment evidence.
5. Customer prose/claims that are not independently verified.

Attachments can explain what the customer sees; they cannot authorize refunds, cancellations, replacements, or override verified operational state by themselves.
