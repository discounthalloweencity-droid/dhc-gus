# DHC Gus v0.17.2 R86 — Return Label Verification + Automatic Resend

Date: 2026-09-22

## Objective
Close the approved-return label gap exposed by the DHC1066/FedEx customer-service case. Gus should be able to answer "where is my return label?" without human lookup, but only after verifying the exact label and return tracking against Shopify's return/reverse-delivery record.

## R86 changes

### 1. Shopify return label is the source of truth
New return-label services read the existing Shopify return graph:

`Return -> Reverse Fulfillment Order -> Reverse Delivery -> Shipping Deliverable`

Gus verifies:
- the Shopify return ID,
- reverse fulfillment order state,
- return-label public file URL,
- label creation/update timestamps,
- return carrier,
- return tracking number,
- return tracking URL.

A customer receipt, old email, note, or guessed carrier reference cannot override verified Shopify return data.

### 2. Return-label intent routing
Gus now recognizes customer language such as:
- "Where is my return label?"
- "Can you resend the FedEx label?"
- "I never received the return label."
- "I can't find/open/download my label."

This workflow runs before generic shipment-status logic so a phrase like "FedEx tracking" in a return-label email is not mistaken for the customer's outbound order shipment.

### 3. Verified automatic resend
When an existing Shopify return contains a verified downloadable label:
- Gus emails the verified customer immediately,
- states that he verified the label against Shopify,
- includes the exact return-label link,
- includes the verified carrier and return tracking number when present,
- attempts to attach that exact label when the direct SMTP transport can safely fetch it,
- records the resend in the support thread/case state.

The label is never regenerated from guessed data and a second Shopify return is not created just because the customer cannot find the first email.

### 4. Safe outbound attachment transport
The support SMTP protocol now supports bounded multipart attachments for trusted return-label URLs.

Controls include:
- HTTPS only,
- host allowlist with optional environment extension,
- no localhost, `.local`, or raw IP hosts,
- maximum 2 outbound attachments,
- maximum 768 KiB per attachment,
- 12-second fetch timeout,
- content-length and actual-byte checks,
- base64 MIME encoding.

The email body still contains the verified label URL so the customer has a usable path even when the configured mail bridge cannot carry a binary attachment.

### 5. Return tracking lifecycle handoff
After label verification, Gus stores:
- returnLabelUrl,
- returnLabelTrackingNumber,
- returnLabelCarrier,
- returnLabelVerifiedAt,
- returnLabelSentAt,
- returnLabelResendCount.

Verified label tracking is also copied into the existing customer-return tracking fields. That means the current return monitor can continue following the approved exchange/return through customer shipment and receipt rather than treating the resend as the end of the case.

### 6. Missing label fails closed
If Shopify shows the return but does not expose a verified downloadable label:
- Gus does not say the label was resent,
- Gus does not invent a FedEx/UPS/USPS label,
- Gus sends a customer-safe explanation,
- Gus creates a high-priority internal `RETURN LABEL REVIEW`,
- staff is instructed to repair/attach the label to the existing return workflow instead of creating a duplicate return.

New outcomes:
- `RETURN_LABEL_RESENT`
- `RETURN_LABEL_REVIEW_REQUIRED`

### 7. DHC1066 / FedEx regression
Regression coverage models the real support pattern in which a customer says a return label did not arrive and the verified return uses FedEx tracking `792766804982`.

The test requires Gus to:
- recognize the message as a return-label request,
- extract the verified Shopify reverse-delivery label,
- preserve the FedEx tracking number,
- provide the label URL,
- avoid claiming a resend if the label is missing.

## Shopify API contract verified for R86
The R86 read query was validated against the current connected Shopify Admin GraphQL schema. It reads the return's reverse fulfillment orders and reverse deliveries, including `ReverseDeliveryShippingDeliverable.label.publicFileUrl` and verified return tracking.

Shopify's current schema also exposes `reverseDeliveryCreateWithShipping` and `reverseDeliveryShippingUpdate` for apps that manage reverse-delivery shipping artifacts. R86 intentionally does not fabricate a new label: it resends a label that already exists in the verified Shopify return and escalates when the label artifact is absent.

## Authority order for return-label responses
1. Verified Shopify Return / Reverse Delivery label and tracking.
2. Existing approved DHC return-case state tied to that Shopify return.
3. Existing customer-return tracking lifecycle state.
4. Customer-provided attachment/message as evidence only.
5. Human review when the verified Shopify label artifact is absent or contradictory.

## Release integrity
R86 is cumulative from R85 and retains:
- Shopify-first outbound order status,
- shipment-intent hardening,
- attachment evidence reconciliation,
- exact-product sizing intelligence,
- approved-return lifecycle monitoring,
- existing customer-service continuity and escalation rules.
