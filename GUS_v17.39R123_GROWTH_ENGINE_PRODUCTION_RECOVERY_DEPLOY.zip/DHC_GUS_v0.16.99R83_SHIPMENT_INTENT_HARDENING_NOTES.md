# DHC Gus v0.16.99 R83 — Shipment Intent Hardening

## Why this release exists
R82 correctly made Shopify fulfillment/tracking the source of truth for order-status replies, but a short customer message such as **“Has it been shipped?”** could still miss the order-status intent classifier when it did not also contain the word “tracking” or “order status.”

## R83 changes
- Direct shipment questions now classify as `ORDER_STATUS` / `SHIPMENT_STATUS`:
  - “Has it been shipped?”
  - “Has my order shipped?”
  - “Did my order ship?”
  - “Is my order shipped?”
- The customer-language academy now contains hard-gate drills for these direct questions.
- First-pass support-email triage recognizes these phrases even when the body does not repeat the order number.
- The existing R82 Shopify-first workflow remains unchanged:
  - `FULFILLED` never means `DELIVERED` without explicit delivery evidence.
  - Tracking and ETA are pulled from Shopify before composing the reply.
  - Missing tracking fails closed to fulfillment review.
  - Passed ETA / carrier exceptions open an Order Delivery Investigation.
  - Missing ETA is stated as unavailable rather than invented.

## Customer-service behavior
For a message like Chelsey's — “Having trouble tracking this. Has it been shipped?” — Gus should identify the order, query live Shopify fulfillment evidence, and answer automatically with only verified shipment facts. A shorter follow-up such as “Has it been shipped?” now follows the same path.

## R83 QA
- 121/121 automated tests passed.
- Customer-language academy: 63/63 drills passed with zero hard failures.
- Source verification: 685 transpiled source files / 49 Prisma models — PASS.
- Pure wiring verification: 647 import sources, 227 routes with zero duplicates, 252 static app links, 347/347 reachable service modules, 25/25 engine contracts — PASS.
