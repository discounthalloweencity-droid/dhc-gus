# DHC Gus v0.17.5 R89 — Universal Agent Email Signature Standard

## Objective
Enforce the requested Discount Halloween City signature on every outbound email at the final mail transport boundary, while preserving the assigned support agent or bot name.

## Canonical signature
Every outbound email now ends with exactly:

Thank you,
[Agent or Bot Name] 👻
Customer Support
Discount Halloween City

Examples:
- Gus → `Gus 👻`
- Maya → `Maya 👻`
- Ethan → `Ethan 👻`
- Olivia → `Olivia 👻`
- Marcus → `Marcus 👻`
- Jenna → `Jenna 👻`

## Enforcement
- `sendSupportEmail()` is the final universal guard for direct SMTP and the HTTP outbound bridge.
- Existing legacy endings such as `Best, / Discount Halloween City Support` are removed before the canonical signature is appended.
- Emails without an explicit agent/bot identity default to Gus.
- Customer Service response coaching is not permitted to hide or replace the assigned agent signature.
- Naturalness QA now hard-fails missing or incorrect assigned-agent signatures.
- The Customer Service Operations GUI shows the active universal signature policy.

## Scope
This applies to customer replies, order-status replies, sizing replies, return-label emails, exchange tracking, return follow-ups, verified refund/cancellation notices, support acknowledgements, and internal support notifications sent through the shared DHC support outbound transport.
