# DHC Gus v0.17.26 R110 — Auto Engine Rotation + Live Activity

R110 formalizes the existing autonomous orchestrator as one visible 71-step engine rotation.

## Why
The orchestrator already called the engines in order, but the operator could not see which engine was running, which engines were fresh, which were blocked, or when each engine would be checked again. A cadence bookkeeping defect also persisted fresh-skip rows; because those rows became the newest cadence anchor on every five-minute pulse, engines with longer cadences could be postponed indefinitely.

## R110 changes
- 71/71 orchestrator steps are now explicitly registered in seven ordered phases.
- Every step has an explicit scheduler cadence of 24 hours or less for its scheduler check.
- Turning Gus on immediately starts the ordered rotation; the server-side runtime keeps it running without the browser.
- Fresh/skipped engines no longer persist a new efficiency JobRun, so a skip cannot move the next-due time forward forever.
- Efficiency due logic ignores historical `"skipped":true` rows when locating the real cadence anchor.
- Live in-process engine telemetry tracks current engine, phase, sequence position, status, last result, scanned/changed counts, duration, and next due time.
- The existing signed 4-second `/api/job-progress` channel now includes engine telemetry; it does not re-run Shopify embedded authentication.
- The Command Center main screen now has an Auto Engine Rotation window showing all 71 engines, the current engine, next engine, phase coverage, cadence, last check, result, and errors/blocks.
- A `Run rotation now` control uses the existing governed orchestrator and does not bypass safety or approval gates.

## Sequence phases
1. Core health & recovery
2. Protection, economics & demand
3. Catalog & merchandising
4. Learning & intelligence
5. Storefront, orders & fulfillment
6. Organic growth & SEO
7. Reconcile, supplier proof & certification

The sequence remains governed: engines that are not due show FRESH/CHECKED instead of doing redundant expensive work, and blocked engines remain visible rather than being reported as successful.
