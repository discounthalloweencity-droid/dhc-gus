# DHC Gus v0.17.12 R96 — Cumulative Recovery Stack

R96 is based on R95 Supplier Evidence Recovery / R94 All Engines Always On and merges the missing recovery work from the earlier branch without rolling back later releases.

## Merged capabilities
- Catalog Catch-Up Campaign with measurable before/after cleanliness, verified normalization writes, 4-hour retry cadence while dirty and 24-hour cadence when clean.
- Canonical storefront alias mappings including Multicolour → Multicolor, TV & Movie/Movie-Inspired → Movie & TV, and Medieval/Renaissance aliases → Medieval & Renaissance.
- Ambiguous numeric supplier sizes remain REVIEW rather than guessed US sizing.
- New-product intake pauses for up to 24 hours after a completed cleanup campaign when customer-facing taxonomy backlog remains.
- Engine Recovery Director ranks unhealthy engines, identifies dependency-blocked work, boosts safe cleanup missions, and can enable Turbo.
- Autonomous Recovery Executor prioritizes retryable missions and escalates exhausted failures rather than looping indefinitely.
- Shopify GraphQL cost/throttle telemetry is restored in the shared Shopify API wrapper and now feeds adaptive worker concurrency.
- R95 true bounded parallel worker execution is preserved; adaptive capacity controls worker count without reverting that implementation.
- Operations Center contains Supplier Evidence, Catalog Catch-Up, Engine Recovery, Recovery Executor, queue/throughput, and Shopify API capacity evidence in one place.
- Manual Recovery Executor action is wired (the older R74 UI exposed the button but omitted the action handler).

## Safety
- Customer service, order, fulfillment, inventory and risk engines remain protected from cleanup displacement.
- Existing write gates, approvals, readback verification and learning evidence remain in force.
- Missing supplier evidence remains UNKNOWN; R96 does not infer in-stock from absent evidence.
- Raw supplier sizing is not guessed into US sizing when mapping is ambiguous.

## Deployment
No new Prisma schema change was introduced by this merge. Existing R68 TurboCleanupControl migration/table is still preferred for durable Turbo state.
