import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const orchestrator=fs.readFileSync('app/services/orchestrator.server.ts','utf8');
const rotation=fs.readFileSync('app/services/engine-rotation.server.ts','utf8');
const runtime=fs.readFileSync('app/services/runtime-orchestrator-pulse.server.ts','utf8');
const dashboard=fs.readFileSync('app/routes/app._index.tsx','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));

function runSteps(src:string){return [...src.matchAll(/runStep\('([^']+)'/g)].map(m=>m[1]);}
function rotationKeys(src:string){
  const phaseBlock=src.match(/const PHASES:[\s\S]*?=\[([\s\S]*?)\];\n\nconst LABELS/);
  assert.ok(phaseBlock,'PHASES registry missing');
  return [...phaseBlock[1].matchAll(/keys:\[([^\]]*)\]/g)].flatMap(m=>[...m[1].matchAll(/'([^']+)'/g)].map(x=>x[1]));
}

test('R124 orchestrator and engine rotation registry are exact mirrors',()=>{
  const steps=runSteps(orchestrator);
  const keys=rotationKeys(rotation);
  assert.equal(steps.length,75);
  assert.equal(new Set(steps).size,75);
  assert.deepEqual(keys,steps);
});

test('R124 runtime proof derives operating step count from engine registry',()=>{
  assert.match(runtime,/import \{ENGINE_ROTATION_SEQUENCE\} from '.\/engine-rotation\.server';/);
  assert.match(runtime,/orchestratedOperatingSteps:ENGINE_ROTATION_SEQUENCE\.length/);
  assert.doesNotMatch(runtime,/orchestratedOperatingSteps:\s*71/);
});

test('R124 dashboard has no stale 71-step fallback or message',()=>{
  assert.doesNotMatch(dashboard,/71-step auto engine rotation/);
  assert.doesNotMatch(dashboard,/engineCycle\.total\|\|engineRows\.length\|\|71/);
});

test('R124 release identity aligned',()=>{
  assert.equal(pkg.version,'0.17.40-r124');
  assert.match(rotation,/ENGINE_ROTATION_RELEASE='0\.17\.40-r124'/);
});
