# DHC Gus v0.17.40-r124 — Main Engine Truth Recovery

## Scope
R124 is cumulative over R123 and repairs a truth-reporting drift discovered during direct main-engine testing.

## Main-engine finding fixed
The orchestrator contains 75 distinct ordered operating steps, while the browser-independent runtime proof and Command Center copy still reported/fell back to 71. R124 derives the runtime proof count from ENGINE_ROTATION_SEQUENCE.length and removes stale 71-step UI fallbacks/copy.

## Main-engine proof
- 75 orchestrator runStep keys detected.
- 75 unique rotation-registry keys.
- Orchestrator order and rotation-registry order are exact mirrors.
- Direct rotation state-machine execution reached 75/75 checked and 100% coverage while preserving COMPLETE, BLOCKED, and ERROR states.
- Core runtime/orchestrator/worker/learning/certification tests: 127/127 PASS before repair.
- Full R124 regression suite: 351/351 PASS.
- Relative imports: 693 source files PASS.
- Routes: 230 registrations, 0 duplicates.
- Static /app links: 264 PASS.
- Interactive controls: 244 files, 204 buttons, 120 links, 24 anchors, 175 forms, 173 POST forms; 0 failures/warnings.
- Runtime wiring: 390/390 service modules reachable.
- Engine certification contracts: 25/25.
- Prisma parity: 49/49 models.
- TypeScript syntax: PASS.

## Important limitation
This source-package certification is not a substitute for a dependency-backed production typecheck/build and deployed runtime proof. The inherited codebase still has known TypeScript debt from the earlier Railway full typecheck. R124 does not represent that debt as resolved. Final production certification still requires deployment with the Shopify private app secret, database, external heartbeat, and runtime proof.
